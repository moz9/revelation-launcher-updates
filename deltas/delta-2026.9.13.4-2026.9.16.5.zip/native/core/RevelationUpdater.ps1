﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:RevelationUpdaterVersion = '1'

function Read-RevelationUpdateKeyValueFile {
    param([string]$Path)

    $map = @{}
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) {
        return $map
    }

    foreach ($line in (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
        $text = [string]$line
        $idx = $text.IndexOf('=')
        if ($idx -le 0) { continue }
        $map[$text.Substring(0, $idx).Trim()] = $text.Substring($idx + 1)
    }

    return $map
}

function Resolve-RevelationUpdateLauncherRoot {
    param([string]$LauncherRoot)

    if ($LauncherRoot) {
        try {
            return (Resolve-Path -LiteralPath $LauncherRoot -ErrorAction Stop).Path
        } catch {
            return $LauncherRoot
        }
    }

    return $PSScriptRoot
}

function Normalize-RevelationUpdateChannel {
    param([string]$ReleaseChannel)

    $channel = ([string]$ReleaseChannel).Trim().ToLowerInvariant()
    if (-not $channel) { $channel = 'release' }
    if ($channel -eq 'public') { $channel = 'release' }
    if ($channel -notin @('release', 'experimental')) {
        throw ('Unsupported update channel: ' + $ReleaseChannel)
    }
    return $channel
}

function Get-RevelationUpdateObjectValue {
    param(
        [AllowNull()][object]$InputObject,
        [string[]]$Names,
        [AllowNull()][object]$Default = $null
    )

    if ($null -eq $InputObject) {
        return $Default
    }

    foreach ($name in @($Names)) {
        if ([string]::IsNullOrWhiteSpace([string]$name)) { continue }
        if ($InputObject -is [System.Collections.IDictionary]) {
            if ($InputObject.Contains([string]$name)) {
                return $InputObject[[string]$name]
            }
        } else {
            try {
                $property = $InputObject.PSObject.Properties[[string]$name]
                if ($property) {
                    return $property.Value
                }
            } catch {
            }
        }
    }

    return $Default
}

function Get-RevelationUpdateConfig {
    param([string]$LauncherRoot)

    $result = [ordered]@{
        updateManifestBaseUrl          = ''
        releaseUpdateManifestUrl       = ''
        experimentalUpdateManifestUrl  = ''
        updateManifestFallbackBaseUrl  = ''
        releaseUpdateManifestFallbackUrl = ''
        experimentalUpdateManifestFallbackUrl = ''
        updateRequestTimeoutSec        = '20'
        updateDownloadRoot             = ''
    }

    if (Get-Command -Name Get-LicenseConfig -ErrorAction SilentlyContinue) {
        $licenseConfig = Get-LicenseConfig -LauncherRoot $LauncherRoot
        foreach ($key in $licenseConfig.Keys) {
            if ([string]::IsNullOrWhiteSpace([string]$licenseConfig[$key])) { continue }
            $result[$key] = [string]$licenseConfig[$key]
        }
    } else {
        foreach ($candidateRoot in @($LauncherRoot, $PSScriptRoot)) {
            if (-not $candidateRoot) { continue }
            $configPath = Join-Path $candidateRoot 'license-config.ini'
            $map = Read-RevelationUpdateKeyValueFile -Path $configPath
            foreach ($key in $map.Keys) {
                if ([string]::IsNullOrWhiteSpace([string]$map[$key])) { continue }
                $result[$key] = [string]$map[$key]
            }
        }
    }

    if ($env:REVELATION_UPDATE_MANIFEST_BASE_URL) {
        $result['updateManifestBaseUrl'] = [string]$env:REVELATION_UPDATE_MANIFEST_BASE_URL
    }
    if ($env:REVELATION_RELEASE_UPDATE_MANIFEST_URL) {
        $result['releaseUpdateManifestUrl'] = [string]$env:REVELATION_RELEASE_UPDATE_MANIFEST_URL
    }
    if ($env:REVELATION_EXPERIMENTAL_UPDATE_MANIFEST_URL) {
        $result['experimentalUpdateManifestUrl'] = [string]$env:REVELATION_EXPERIMENTAL_UPDATE_MANIFEST_URL
    }

    $root = Resolve-RevelationUpdateLauncherRoot -LauncherRoot $LauncherRoot
    if (-not $result.updateDownloadRoot) {
        $result['updateDownloadRoot'] = Join-Path $root '.revelation-combat\updates'
    }

    return $result
}

function Get-RevelationUpdateRequestTimeoutSec {
    param([string]$LauncherRoot)

    $config = Get-RevelationUpdateConfig -LauncherRoot $LauncherRoot
    try {
        $configured = [int]([string]$config.updateRequestTimeoutSec)
    } catch {
        $configured = 5
    }
    if ($configured -le 0) { $configured = 5 }
    return [Math]::Min(5, $configured)
}

function Test-RevelationUpdateTransportFailure {
    param([AllowNull()][object]$ErrorValue)

    $exception = if ($ErrorValue -is [System.Management.Automation.ErrorRecord]) { $ErrorValue.Exception } else { $ErrorValue }
    while ($null -ne $exception) {
        # Windows PowerShell 5.1 does not always preload System.Net.Http, so a
        # direct HttpRequestException type literal can fail before fallback is tried.
        $exceptionTypeName = [string]$exception.GetType().FullName
        if ($exception -is [System.Threading.Tasks.TaskCanceledException] -or
            $exception -is [System.TimeoutException] -or
            $exceptionTypeName -eq 'System.Net.Http.HttpRequestException') {
            return $true
        }
        if ($exception -is [System.Net.WebException]) {
            return $exception.Status -in @(
                [System.Net.WebExceptionStatus]::ConnectFailure,
                [System.Net.WebExceptionStatus]::ConnectionClosed,
                [System.Net.WebExceptionStatus]::KeepAliveFailure,
                [System.Net.WebExceptionStatus]::NameResolutionFailure,
                [System.Net.WebExceptionStatus]::PipelineFailure,
                [System.Net.WebExceptionStatus]::ProxyNameResolutionFailure,
                [System.Net.WebExceptionStatus]::ReceiveFailure,
                [System.Net.WebExceptionStatus]::SecureChannelFailure,
                [System.Net.WebExceptionStatus]::SendFailure,
                [System.Net.WebExceptionStatus]::Timeout,
                [System.Net.WebExceptionStatus]::TrustFailure
            )
        }
        $exception = $exception.InnerException
    }
    return $false
}

function Read-RevelationUpdateJsonFile {
    param([string]$Path)

    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) {
        return $null
    }

    return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
}

function Hide-RevelationUpdateSensitiveText {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ''
    }

    $value = [string]$Text
    $value = [regex]::Replace($value, "https?://[^\s\)\]'`"]+", 'сервер обновлений', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $value = [regex]::Replace($value, "[A-Za-z]:\\[^\r\n\)\]'`"]+", 'локальный файл')
    $value = [regex]::Replace($value, "\\\\[^\s\)\]'`"]+", 'локальный файл')
    return $value
}

function Resolve-RevelationUpdateUrl {
    param(
        [string]$Value,
        [string]$SourceUrl = ''
    )

    $text = ([string]$Value).Trim()
    if (-not $text) {
        return ''
    }

    try {
        $uri = [System.Uri]$text
        if ($uri.IsAbsoluteUri) {
            return $uri.AbsoluteUri
        }
    } catch {
    }

    if (-not [string]::IsNullOrWhiteSpace($SourceUrl)) {
        $baseUri = [System.Uri]$SourceUrl
        return ([System.Uri]::new($baseUri, $text)).AbsoluteUri
    }

    return $text
}

function Get-RevelationInstalledVersionInfo {
    param([string]$LauncherRoot)

    $root = Resolve-RevelationUpdateLauncherRoot -LauncherRoot $LauncherRoot
    $manifestPath = Join-Path $root '.revelation-combat\install.json'
    $configPath = Join-Path $root 'launcher-config.ini'
    $manifest = Read-RevelationUpdateJsonFile -Path $manifestPath
    $config = Read-RevelationUpdateKeyValueFile -Path $configPath

    $channel = ''
    if ($config.ContainsKey('releaseChannel') -and $config['releaseChannel']) {
        $channel = [string]$config['releaseChannel']
    } elseif ($manifest -and $manifest.PSObject.Properties['ReleaseChannel']) {
        $channel = [string]$manifest.ReleaseChannel
    }
    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $channel

    $version = ''
    foreach ($buildPath in @(
            (Join-Path $root 'native\core\launcher-build.json'),
            (Join-Path $root 'app\native\core\launcher-build.json')
        )) {
        if (-not (Test-Path -LiteralPath $buildPath -PathType Leaf)) { continue }
        try {
            $build = Get-Content -LiteralPath $buildPath -Raw -ErrorAction Stop | ConvertFrom-Json
            $candidate = ([string]$build.version).Trim()
            if ($candidate) {
                $version = $candidate
                break
            }
        } catch {
        }
    }
    if (-not $version -and $manifest -and $manifest.PSObject.Properties['PackageVersion']) {
        $version = [string]$manifest.PackageVersion
    }

    $displayName = ''
    if ($config.ContainsKey('launcherDisplayName') -and $config['launcherDisplayName']) {
        $displayName = [string]$config['launcherDisplayName']
    } elseif ($manifest -and $manifest.PSObject.Properties['LauncherDisplayName']) {
        $displayName = [string]$manifest.LauncherDisplayName
    }

    # Shipped build metadata is separate from local settings and legacy install.json.
    $buildPath = Join-Path $root 'launcher-build.json'
    $build = Read-RevelationUpdateJsonFile -Path $buildPath
    if ($build -and $build.PSObject.Properties['schemaVersion'] -and $build.schemaVersion -eq 1 -and
        $build.PSObject.Properties['version'] -and [string]$build.version -match '^\d+\.\d+\.\d+\.\d+$' -and
        $build.PSObject.Properties['channel'] -and [string]$build.channel -in @('release','experimental')) {
        $version = [string]$build.version
        $channel = [string]$build.channel
        $displayName = if ($channel -eq 'experimental') {'Revelation Launcher — тестовая версия'} else {'Revelation Launcher — релизная версия'}
        $manifestPath = $buildPath
    }
    return [ordered]@{
        launcherRoot = $root
        manifestPath = $manifestPath
        releaseChannel = $channel
        packageVersion = $version
        launcherDisplayName = $displayName
    }
}

function Test-RevelationLicenseAllowsUpdateChannel {
    param(
        [AllowNull()][object]$LicenseState = $null,
        [string]$LauncherRoot = '',
        [string]$ReleaseChannel = 'release'
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $state = $LicenseState
    if ($null -eq $state) {
        if (-not (Get-Command -Name Read-LicenseState -ErrorAction SilentlyContinue)) {
            return [ordered]@{
                allowed = $false
                reason  = 'license-module-missing'
                message = 'Модуль лицензий не найден.'
            }
        }
        $state = Read-LicenseState -LauncherRoot $LauncherRoot
    }

    if (Get-Command -Name Test-LicenseAllowsUpdateChannel -ErrorAction SilentlyContinue) {
        return (Test-LicenseAllowsUpdateChannel -State $state -ReleaseChannel $channel)
    }

    if ($channel -eq 'release') {
        return [ordered]@{ allowed = $true; reason = 'release-default'; message = 'Стабильный канал доступен.' }
    }
    return [ordered]@{ allowed = $false; reason = 'license-helper-missing'; message = 'Нельзя проверить доступ к experimental.' }
}

function Test-RevelationUpdateDeveloperLicense {
    param(
        [AllowNull()][object]$LicenseState = $null
    )

    if ($null -eq $LicenseState) {
        return $false
    }
    if (-not (Get-Command -Name Get-LicenseStateValue -ErrorAction SilentlyContinue)) {
        return $false
    }

    $licenseType = ([string](Get-LicenseStateValue -State $LicenseState -Name 'licenseType' -Default '')).Trim().ToLowerInvariant()
    return ($licenseType -eq 'developer')
}

function Get-RevelationUpdateManifestCandidates {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = 'release'
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $config = Get-RevelationUpdateConfig -LauncherRoot $LauncherRoot
    $items = New-Object System.Collections.Generic.List[string]

    $explicitKey = if ($channel -eq 'experimental') { 'experimentalUpdateManifestUrl' } else { 'releaseUpdateManifestUrl' }
    foreach ($value in @(
            [string]$env:REVELATION_UPDATE_MANIFEST_URL,
            [string]$config[$explicitKey]
        )) {
        if ([string]::IsNullOrWhiteSpace($value)) { continue }
        $candidate = ([string]$value).Trim()
        if (-not $items.Contains($candidate)) {
            $items.Add($candidate) | Out-Null
        }
    }

    $base = ([string]$config.updateManifestBaseUrl).Trim().TrimEnd('/')
    if ($base) {
        foreach ($suffix in @(($channel + '.json'), $channel)) {
            $candidate = $base + '/' + $suffix
            if (-not $items.Contains($candidate)) {
                $items.Add($candidate) | Out-Null
            }
        }
    }

    $fallbackExplicitKey = if ($channel -eq 'experimental') { 'experimentalUpdateManifestFallbackUrl' } else { 'releaseUpdateManifestFallbackUrl' }
    $fallbackExplicit = ([string]$config[$fallbackExplicitKey]).Trim()
    if ($fallbackExplicit -and -not $items.Contains($fallbackExplicit)) {
        $items.Add($fallbackExplicit) | Out-Null
    }

    $fallbackBase = ([string]$config.updateManifestFallbackBaseUrl).Trim().TrimEnd('/')
    if ($fallbackBase) {
        foreach ($suffix in @(($channel + '.json'), $channel)) {
            $candidate = $fallbackBase + '/' + $suffix
            if (-not $items.Contains($candidate)) {
                $items.Add($candidate) | Out-Null
            }
        }
    }

    return @($items.ToArray())
}

function Get-RevelationUpdateInstallerCandidates {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = 'release',
        [Parameter(Mandatory = $true)][object]$Manifest
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $items = New-Object System.Collections.Generic.List[string]
    $installerUrl = ([string](Get-RevelationUpdateObjectValue -InputObject $Manifest -Names @('installerUrl') -Default '')).Trim()
    $fileName = ([string](Get-RevelationUpdateObjectValue -InputObject $Manifest -Names @('fileName') -Default '')).Trim()

    if ($installerUrl) {
        $items.Add($installerUrl) | Out-Null
    }
    if (-not $fileName -and $installerUrl) {
        try {
            $fileName = [System.IO.Path]::GetFileName(([System.Uri]$installerUrl).LocalPath)
        } catch {
        }
    }
    if (-not $fileName) {
        $fileName = if ($channel -eq 'experimental') { 'RevelationLauncherStandaloneInstaller-Experimental-RU.exe' } else { 'RevelationLauncherStandaloneInstaller-RU.exe' }
    }

    foreach ($manifestUrl in (Get-RevelationUpdateManifestCandidates -LauncherRoot $LauncherRoot -ReleaseChannel $channel)) {
        try {
            $candidate = Resolve-RevelationUpdateUrl -Value $fileName -SourceUrl $manifestUrl
            if ($candidate -and -not $items.Contains($candidate)) {
                $items.Add($candidate) | Out-Null
            }
        } catch {
        }
    }

    return @($items.ToArray())
}

function ConvertTo-RevelationUpdateManifest {
    param(
        [Parameter(Mandatory = $true)][object]$InputObject,
        [string]$ReleaseChannel = 'release',
        [string]$SourceUrl = ''
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $manifestChannel = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('channel', 'releaseChannel') -Default $channel)
    $manifestChannel = Normalize-RevelationUpdateChannel -ReleaseChannel $manifestChannel
    if ($manifestChannel -ne $channel) {
        throw ('Update manifest channel mismatch: expected ' + $channel + ', got ' + $manifestChannel)
    }

    $version = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('version', 'PackageVersion') -Default '')
    if ([string]::IsNullOrWhiteSpace($version)) {
        throw 'Update manifest does not contain version.'
    }

    $installerUrl = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('installerUrl', 'url') -Default '')
    if ([string]::IsNullOrWhiteSpace($installerUrl)) {
        throw 'Update manifest does not contain installerUrl.'
    }
    $installerUrl = Resolve-RevelationUpdateUrl -Value $installerUrl -SourceUrl $SourceUrl

    $finalUri = [System.Uri]$installerUrl
    if ($finalUri.Scheme -notin @('http', 'https', 'file')) {
        throw ('Unsupported installer URL scheme: ' + $finalUri.Scheme)
    }

    $historyUrl = Resolve-RevelationUpdateUrl -Value ([string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('historyUrl', 'notesUrl', 'changelogUrl') -Default '')) -SourceUrl $SourceUrl

    $sha256 = ''
    $sha256Value = Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('sha256') -Default ''
    if ($sha256Value) {
        $sha256 = ([string]$sha256Value).Trim().ToLowerInvariant()
    }
    if ($sha256 -and $sha256 -notmatch '^[0-9a-f]{64}$') {
        throw 'Update manifest contains invalid sha256.'
    }

    $fileName = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('fileName') -Default '')
    if (-not $fileName) { $fileName = [System.IO.Path]::GetFileName($finalUri.LocalPath) }
    if (-not $fileName) {
        $fileName = if ($channel -eq 'experimental') { 'RevelationLauncherStandaloneInstaller-Experimental-RU.exe' } else { 'RevelationLauncherStandaloneInstaller-RU.exe' }
    }

    return [ordered]@{
        delta        = Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('delta') -Default $null
        deltas       = @(Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('deltas') -Default @())
        channel      = $channel
        version      = $version
        installerUrl = $installerUrl
        sha256       = $sha256
        fileName     = $fileName
        sizeBytes    = [int64](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('sizeBytes') -Default 0)
        sourceUrl    = $SourceUrl
        historyUrl   = $historyUrl
        publishedAtUtc = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('publishedAtUtc') -Default '')
        notes        = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('notes') -Default '')
    }
}

function Get-RevelationUpdateManifest {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = 'release'
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $timeoutSec = Get-RevelationUpdateRequestTimeoutSec -LauncherRoot $LauncherRoot
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSec)

    $errors = New-Object System.Collections.Generic.List[string]
    $failedAuthorities = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($candidate in (Get-RevelationUpdateManifestCandidates -LauncherRoot $LauncherRoot -ReleaseChannel $channel)) {
        $remainingSec = [int][Math]::Ceiling(($deadline - [DateTime]::UtcNow).TotalSeconds)
        if ($remainingSec -le 0) { break }
        $uri = [System.Uri]$candidate
        $authority = $(if ($uri.IsAbsoluteUri -and $uri.Scheme -ne 'file') { $uri.GetLeftPart([System.UriPartial]::Authority) } else { '' })
        if ($authority -and $failedAuthorities.Contains($authority)) { continue }
        try {
            $raw = $null
            if ($uri.Scheme -eq 'file') {
                $raw = Get-Content -LiteralPath $uri.LocalPath -Raw -Encoding UTF8 | ConvertFrom-Json
            } else {
                $raw = Invoke-RestMethod -Method Get -Uri $candidate -TimeoutSec ([Math]::Min(2, $remainingSec))
            }
            return (ConvertTo-RevelationUpdateManifest -InputObject $raw -ReleaseChannel $channel -SourceUrl $candidate)
        } catch {
            $errors.Add((Hide-RevelationUpdateSensitiveText -Text $_.Exception.Message)) | Out-Null
            if ($authority -and (Test-RevelationUpdateTransportFailure -ErrorValue $_)) {
                $failedAuthorities.Add($authority) | Out-Null
            }
            if ([DateTime]::UtcNow -ge $deadline) { break }
        }
    }

    if ($errors.Count -gt 0) {
        throw ('Не удалось получить манифест обновления: ' + ($errors -join ' | '))
    }
    throw 'Адрес манифеста обновлений не настроен.'
}

function Get-RevelationUpdateVersionVector {
    param([string]$Version)

    $text = ([string]$Version).Trim()
    if (-not $text) {
        return $null
    }

    $parsed = $null
    if ([System.Version]::TryParse($text, [ref]$parsed)) {
        return @(
            [int]$parsed.Major,
            [int]$parsed.Minor,
            [int]$parsed.Build,
            [int]$parsed.Revision
        )
    }

    $dateMatch = [regex]::Match($text, '^(\d{4})[-.](\d{1,2})[-.](\d{1,2})(?:[-.](\d{1,3}))?')
    if ($dateMatch.Success) {
        return @(
            [int]$dateMatch.Groups[1].Value,
            [int]$dateMatch.Groups[2].Value,
            [int]$dateMatch.Groups[3].Value,
            $(if ($dateMatch.Groups[4].Success) { [int]$dateMatch.Groups[4].Value } else { 0 })
        )
    }

    return $null
}

function Compare-RevelationUpdateVersion {
    param(
        [string]$Left,
        [string]$Right
    )

    $leftText = ([string]$Left).Trim()
    $rightText = ([string]$Right).Trim()
    if ($leftText -eq $rightText) {
        return 0
    }
    if (-not $leftText -and $rightText) {
        return -1
    }
    if ($leftText -and -not $rightText) {
        return 1
    }

    $leftVector = Get-RevelationUpdateVersionVector -Version $leftText
    $rightVector = Get-RevelationUpdateVersionVector -Version $rightText
    if ($leftVector -and $rightVector) {
        $max = [Math]::Max($leftVector.Count, $rightVector.Count)
        for ($i = 0; $i -lt $max; $i++) {
            $leftPart = if ($i -lt $leftVector.Count) { [int]$leftVector[$i] } else { -1 }
            $rightPart = if ($i -lt $rightVector.Count) { [int]$rightVector[$i] } else { -1 }
            if ($leftPart -lt $rightPart) { return -1 }
            if ($leftPart -gt $rightPart) { return 1 }
        }
        return 0
    }

    if (-not $leftVector -and -not $rightVector) {
        return [string]::Compare($leftText, $rightText, [System.StringComparison]::OrdinalIgnoreCase)
    }

    return $null
}

function Get-RevelationUpdateHistoryCandidates {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = 'release',
        [AllowNull()][object]$Manifest = $null
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $config = Get-RevelationUpdateConfig -LauncherRoot $LauncherRoot
    $items = New-Object System.Collections.Generic.List[string]

    $manifestHistoryUrl = if ($Manifest) { [string](Get-RevelationUpdateObjectValue -InputObject $Manifest -Names @('historyUrl') -Default '') } else { '' }
    if ($manifestHistoryUrl -and -not $items.Contains($manifestHistoryUrl)) {
        $items.Add($manifestHistoryUrl) | Out-Null
    }

    $manifestSourceUrl = if ($Manifest) { [string](Get-RevelationUpdateObjectValue -InputObject $Manifest -Names @('sourceUrl') -Default '') } else { '' }
    if ($manifestSourceUrl) {
        $candidate = Resolve-RevelationUpdateUrl -Value ($channel + '-history.json') -SourceUrl $manifestSourceUrl
        if ($candidate -and -not $items.Contains($candidate)) {
            $items.Add($candidate) | Out-Null
        }
    }

    $base = ([string]$config.updateManifestBaseUrl).Trim().TrimEnd('/')
    if ($base) {
        foreach ($suffix in @(($channel + '-history.json'), ($channel + '.history.json'))) {
            $candidate = $base + '/' + $suffix
            if (-not $items.Contains($candidate)) {
                $items.Add($candidate) | Out-Null
            }
        }
    }

    return @($items.ToArray())
}

function ConvertTo-RevelationUpdateHistoryEntries {
    param(
        [AllowNull()][object]$InputObject = $null,
        [string]$ReleaseChannel = 'release'
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    if ($null -eq $InputObject) {
        return @()
    }

    $sourceEntries = $InputObject
    $inputChannel = [string](Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('channel', 'releaseChannel') -Default $channel)
    if ($inputChannel) {
        try {
            if ((Normalize-RevelationUpdateChannel -ReleaseChannel $inputChannel) -ne $channel) {
                return @()
            }
        } catch {
            return @()
        }
    }

    $namedEntries = Get-RevelationUpdateObjectValue -InputObject $InputObject -Names @('entries', 'history', 'items') -Default $null
    if ($null -ne $namedEntries) {
        $sourceEntries = $namedEntries
    }

    $result = New-Object System.Collections.Generic.List[object]
    foreach ($entry in @($sourceEntries)) {
        if ($null -eq $entry) { continue }
        $version = ([string](Get-RevelationUpdateObjectValue -InputObject $entry -Names @('version', 'PackageVersion') -Default '')).Trim()
        $notes = ([string](Get-RevelationUpdateObjectValue -InputObject $entry -Names @('notes', 'patchNotes', 'changelog') -Default '')).Trim()
        if (-not $version -or -not $notes) { continue }

        $result.Add([ordered]@{
            version        = $version
            publishedAtUtc = [string](Get-RevelationUpdateObjectValue -InputObject $entry -Names @('publishedAtUtc', 'publishedAt') -Default '')
            notes          = $notes
        }) | Out-Null
    }

    return @($result.ToArray())
}

function Sort-RevelationUpdateHistoryEntries {
    param([object[]]$Entries)

    $sorted = New-Object System.Collections.Generic.List[object]
    foreach ($entry in @($Entries)) {
        $inserted = $false
        for ($i = 0; $i -lt $sorted.Count; $i++) {
            $comparison = Compare-RevelationUpdateVersion -Left ([string]$entry.version) -Right ([string]$sorted[$i].version)
            if ($null -ne $comparison -and $comparison -lt 0) {
                $sorted.Insert($i, $entry)
                $inserted = $true
                break
            }
        }
        if (-not $inserted) {
            $sorted.Add($entry) | Out-Null
        }
    }

    return @($sorted.ToArray())
}

function Get-RevelationUpdateHistory {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = 'release',
        [AllowNull()][object]$Manifest = $null
    )

    $channel = Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel
    $config = Get-RevelationUpdateConfig -LauncherRoot $LauncherRoot
    try {
        $timeoutSec = [int]([string]$config.updateRequestTimeoutSec)
        if ($timeoutSec -le 0) { $timeoutSec = 20 }
    } catch {
        $timeoutSec = 20
    }

    foreach ($candidate in (Get-RevelationUpdateHistoryCandidates -LauncherRoot $LauncherRoot -ReleaseChannel $channel -Manifest $Manifest)) {
        try {
            $uri = [System.Uri]$candidate
            $raw = $null
            if ($uri.Scheme -eq 'file') {
                $raw = Get-Content -LiteralPath $uri.LocalPath -Raw -Encoding UTF8 | ConvertFrom-Json
            } else {
                $raw = Invoke-RestMethod -Method Get -Uri $candidate -TimeoutSec $timeoutSec
            }
            $entries = @(ConvertTo-RevelationUpdateHistoryEntries -InputObject $raw -ReleaseChannel $channel)
            if ($entries.Count -gt 0) {
                return (Sort-RevelationUpdateHistoryEntries -Entries $entries)
            }
        } catch {
        }
    }

    return @()
}

function Select-RevelationUpdateHistoryEntries {
    param(
        [object[]]$Entries,
        [string]$InstalledVersion = '',
        [string]$LatestVersion = ''
    )

    $selected = New-Object System.Collections.Generic.List[object]
    foreach ($entry in @($Entries)) {
        $entryVersion = [string]$entry.version
        if (-not $entryVersion) { continue }

        if ($InstalledVersion -and -not (Test-RevelationUpdateIsNewer -InstalledVersion $InstalledVersion -RemoteVersion $entryVersion)) {
            continue
        }
        if ($LatestVersion -and (Test-RevelationUpdateIsNewer -InstalledVersion $LatestVersion -RemoteVersion $entryVersion)) {
            continue
        }

        $selected.Add($entry) | Out-Null
    }

    return @($selected.ToArray())
}

function Format-RevelationUpdateHistoryNotes {
    param(
        [object[]]$Entries,
        [string]$InstalledVersion = '',
        [string]$LatestVersion = '',
        [string]$FallbackNotes = ''
    )

    $rangeEntries = @(Select-RevelationUpdateHistoryEntries -Entries $Entries -InstalledVersion $InstalledVersion -LatestVersion $LatestVersion)
    if ($rangeEntries.Count -eq 0) {
        return ([string]$FallbackNotes).Trim()
    }

    $lines = New-Object System.Collections.Generic.List[string]
    if ($InstalledVersion) {
        $lines.Add(('Изменения с версии ' + $InstalledVersion + ' до ' + $LatestVersion + ':')) | Out-Null
    } else {
        $lines.Add(('Изменения до версии ' + $LatestVersion + ':')) | Out-Null
    }

    foreach ($entry in $rangeEntries) {
        $entryNotes = ([string]$entry.notes).Trim()
        $entryNotes = [regex]::Replace($entryNotes, '^Патч-нот\s*:\s*', '', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase).Trim()
        if (-not $entryNotes) { continue }

        $lines.Add('') | Out-Null
        $lines.Add(('Версия ' + [string]$entry.version)) | Out-Null
        foreach ($line in ($entryNotes -split "\r?\n")) {
            $clean = ([string]$line).TrimEnd()
            if ($clean) {
                $lines.Add($clean) | Out-Null
            }
        }
    }

    return (($lines.ToArray()) -join "`n").Trim()
}

function Test-RevelationUpdateIsNewer {
    param(
        [string]$InstalledVersion,
        [string]$RemoteVersion
    )

    if ([string]::IsNullOrWhiteSpace($RemoteVersion)) { return $false }
    if ([string]::IsNullOrWhiteSpace($InstalledVersion)) { return $true }
    if ([string]$InstalledVersion -eq [string]$RemoteVersion) { return $false }

    $comparison = Compare-RevelationUpdateVersion -Left $RemoteVersion -Right $InstalledVersion
    if ($null -ne $comparison) {
        return ($comparison -gt 0)
    }

    return $true
}

function Get-RevelationUpdateStatus {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = '',
        [switch]$CheckOnline
    )

    $local = Get-RevelationInstalledVersionInfo -LauncherRoot $LauncherRoot
    $channel = if ($ReleaseChannel) { Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel } else { [string]$local.releaseChannel }
    $licenseState = $null
    if (Get-Command -Name Read-LicenseState -ErrorAction SilentlyContinue) {
        $licenseState = Read-LicenseState -LauncherRoot $LauncherRoot
    }
    $entitlement = Test-RevelationLicenseAllowsUpdateChannel -LicenseState $licenseState -LauncherRoot $LauncherRoot -ReleaseChannel $channel
    $canExposeManifestUrl = Test-RevelationUpdateDeveloperLicense -LicenseState $licenseState

    $status = [ordered]@{
        ok                    = $true
        supported             = $true
        releaseChannel         = $channel
        installedVersion       = [string]$local.packageVersion
        launcherRoot           = [string]$local.launcherRoot
        licenseType            = $(if ($licenseState) { [string](Get-LicenseStateValue -State $licenseState -Name 'licenseType' -Default 'normal') } else { 'unknown' })
        updateAllowed          = [bool]$entitlement.allowed
        updateAllowedReason    = [string]$entitlement.reason
        message                = [string]$entitlement.message
        manifestUrl            = ''
        latestVersion          = ''
        updateAvailable        = $false
        installerDownloaded    = $false
        installerPath          = ''
        sha256                 = ''
        notes                  = ''
        historyAvailable       = $false
        historyEntryCount      = 0
    }

    if (-not [bool]$entitlement.allowed) {
        return $status
    }

    if ($CheckOnline) {
        try {
            $manifest = Get-RevelationUpdateManifest -LauncherRoot $LauncherRoot -ReleaseChannel $channel
            if ($canExposeManifestUrl) {
                $status['manifestUrl'] = [string]$manifest.sourceUrl
            }
            $status['latestVersion'] = [string]$manifest.version
            $status['sha256'] = [string]$manifest.sha256
            $historyEntries = @(Get-RevelationUpdateHistory -LauncherRoot $LauncherRoot -ReleaseChannel $channel -Manifest $manifest)
            $rangeNotes = Format-RevelationUpdateHistoryNotes -Entries $historyEntries -InstalledVersion ([string]$local.packageVersion) -LatestVersion ([string]$manifest.version) -FallbackNotes ([string]$manifest.notes)
            $status['notes'] = $rangeNotes
            $status['historyAvailable'] = ($historyEntries.Count -gt 0)
            $status['historyEntryCount'] = [int]$historyEntries.Count
            $status['updateAvailable'] = [bool](Test-RevelationUpdateIsNewer -InstalledVersion ([string]$local.packageVersion) -RemoteVersion ([string]$manifest.version))
            $status['message'] = $(if ([bool]$status.updateAvailable) { 'Доступно обновление.' } else { 'Установлена актуальная версия.' })
        } catch {
            $status['ok'] = $false
            $status['message'] = $_.Exception.Message
        }
    }

    return $status
}

function Test-RevelationUpdateFileHash {
    param(
        [string]$Path,
        [string]$Sha256
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw 'Файл обновления не найден.'
    }
    $expected = ([string]$Sha256).Trim().ToLowerInvariant()
    if (-not $expected) {
        throw 'Манифест обновления не содержит sha256. Установка заблокирована.'
    }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected) {
        throw ('SHA256 обновления не совпал. Ожидалось ' + $expected + ', получено ' + $actual)
    }
    return $true
}

function ConvertTo-RevelationUpdateNativeArgument {
    param([AllowNull()][object]$Value)

    $text = [string]$Value
    if ([string]::IsNullOrEmpty($text)) {
        return '""'
    }
    if ($text -notmatch '[\s"]') {
        return $text
    }

    return '"' + ($text -replace '"', '\"') + '"'
}

function Join-RevelationUpdateNativeArguments {
    param([object[]]$Arguments)

    return (@($Arguments) | ForEach-Object { ConvertTo-RevelationUpdateNativeArgument -Value $_ }) -join ' '
}

function Write-RevelationUpdateProgress {
    param([string]$Phase,[string]$PartialPath='',[long]$TotalBytes=0)
    if (-not $env:REVELATION_UPDATE_PROGRESS_FILE) { return }
    $temporary = $env:REVELATION_UPDATE_PROGRESS_FILE + '.tmp'
    try {
        $json = @{phase=$Phase;partialPath=$PartialPath;totalBytes=$TotalBytes} | ConvertTo-Json -Compress
        [IO.File]::WriteAllText($temporary,$json,[Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporary -Destination $env:REVELATION_UPDATE_PROGRESS_FILE -Force -ErrorAction Stop
    } catch { # Progress must never turn an otherwise valid update into a failure.
    } finally { if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue } }
}

function Get-RevelationCompatibleDelta {
    param(
        [AllowNull()][object]$Manifest,
        [string]$InstalledVersion
    )

    $candidates = New-Object System.Collections.Generic.List[object]
    $listed = Get-RevelationUpdateObjectValue -InputObject $Manifest -Names @('deltas') -Default $null
    foreach ($candidate in @($listed)) {
        if ($null -ne $candidate) { $candidates.Add($candidate) }
    }
    $legacy = Get-RevelationUpdateObjectValue -InputObject $Manifest -Names @('delta') -Default $null
    if ($null -ne $legacy) { $candidates.Add($legacy) }

    foreach ($candidate in $candidates) {
        $baseVersion = [string](Get-RevelationUpdateObjectValue -InputObject $candidate -Names @('baseVersion') -Default '')
        if ($baseVersion -eq $InstalledVersion) {
            return $candidate
        }
    }
    return $null
}

function Copy-RevelationUpdateManifestWithDelta {
    param(
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Manifest,
        [Parameter(Mandatory = $true)][object]$Delta
    )

    $copy = [ordered]@{}
    foreach ($key in $Manifest.Keys) { $copy[$key] = $Manifest[$key] }
    $copy['delta'] = $Delta
    return $copy
}
function Save-RevelationLauncherUpdate {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = '',
        [AllowNull()][object]$Manifest = $null,
        [switch]$PreferDelta
    )

    $local = Get-RevelationInstalledVersionInfo -LauncherRoot $LauncherRoot
    $channel = if ($ReleaseChannel) { Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel } else { [string]$local.releaseChannel }
    $entitlement = Test-RevelationLicenseAllowsUpdateChannel -LauncherRoot $LauncherRoot -ReleaseChannel $channel
    if (-not [bool]$entitlement.allowed) {
        throw ([string]$entitlement.message)
    }

    Write-RevelationUpdateProgress -Phase checking
    $manifestObject = if ($Manifest) { ConvertTo-RevelationUpdateManifest -InputObject $Manifest -ReleaseChannel $channel } else { Get-RevelationUpdateManifest -LauncherRoot $LauncherRoot -ReleaseChannel $channel }
    if (-not [string]$manifestObject.sha256) {
        throw 'Манифест обновления без sha256: установка заблокирована.'
    }

    $config = Get-RevelationUpdateConfig -LauncherRoot $LauncherRoot
    $targetDir = Join-Path ([string]$config.updateDownloadRoot) (Join-Path $channel ([string]$manifestObject.version))
    if (-not (Test-Path -LiteralPath $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }
    if ($PreferDelta) {
        if (-not $env:REVELATION_LAUNCHER_INSTALL_ROOT) {
            throw 'Не удалось определить папку установленного лаунчера для точечного обновления.'
        }
        $delta = Get-RevelationCompatibleDelta -Manifest $manifestObject -InstalledVersion ([string]$local.packageVersion)
        if ($null -eq $delta) {
            throw ('Для установленной версии ' + [string]$local.packageVersion + ' нет точечного обновления. Полный установщик доступен отдельной кнопкой.')
        }
        try {
            . (Join-Path $PSScriptRoot 'tools/RevelationDeltaDownload.ps1')
            $deltaManifest = Copy-RevelationUpdateManifestWithDelta -Manifest $manifestObject -Delta $delta
            $deltaManifest['installedVersion'] = [string]$local.packageVersion
            $deltaResult = Save-RevelationDeltaUpdate $deltaManifest $targetDir $env:REVELATION_LAUNCHER_INSTALL_ROOT $LauncherRoot
            if ($deltaResult) { return $deltaResult }
            throw 'Совместимый точечный пакет не может быть применён.'
        } catch {
            throw ('Не удалось скачать точечное обновление. Полный установщик автоматически не скачивается. Причина: ' + (Hide-RevelationUpdateSensitiveText -Text $_.Exception.Message))
        }
    }
    $targetPath = Join-Path $targetDir ([string]$manifestObject.fileName)
    $downloaded = $false
    $downloadErrors = New-Object System.Collections.Generic.List[string]
    foreach ($candidate in (Get-RevelationUpdateInstallerCandidates -LauncherRoot $LauncherRoot -ReleaseChannel $channel -Manifest $manifestObject)) {
        $partialPath = $targetPath + '.downloading-' + [guid]::NewGuid().ToString('N')
        Write-RevelationUpdateProgress -Phase downloading -PartialPath $partialPath -TotalBytes ([long]$manifestObject.sizeBytes)
        try {
            $uri = [System.Uri]$candidate
            if ($uri.Scheme -eq 'file') {
                Copy-Item -LiteralPath $uri.LocalPath -Destination $partialPath -Force
            } else {
                Invoke-WebRequest -Uri $candidate -OutFile $partialPath -UseBasicParsing -TimeoutSec 120
            }
            Write-RevelationUpdateProgress -Phase verifying
            Test-RevelationUpdateFileHash -Path $partialPath -Sha256 ([string]$manifestObject.sha256) | Out-Null
            Move-Item -LiteralPath $partialPath -Destination $targetPath -Force
            $downloaded = $true
            break
        } catch {
            $downloadErrors.Add((Hide-RevelationUpdateSensitiveText -Text $_.Exception.Message)) | Out-Null
        } finally {
            if (Test-Path -LiteralPath $partialPath) {
                Remove-Item -LiteralPath $partialPath -Force -ErrorAction SilentlyContinue
            }
        }
    }
    if (-not $downloaded) {
        throw ('Не удалось скачать установщик ни с одного сервера обновлений: ' + ($downloadErrors -join ' | '))
    }

    $statePath = Join-Path $targetDir 'manifest.json'
    Write-RevelationUpdateProgress -Phase ready
    $manifestObject | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statePath -Encoding UTF8

    $licenseState = $null
    if (Get-Command -Name Read-LicenseState -ErrorAction SilentlyContinue) {
        $licenseState = Read-LicenseState -LauncherRoot $LauncherRoot
    }
    $canExposeManifestUrl = Test-RevelationUpdateDeveloperLicense -LicenseState $licenseState
    $historyEntries = @(Get-RevelationUpdateHistory -LauncherRoot $LauncherRoot -ReleaseChannel $channel -Manifest $manifestObject)
    $rangeNotes = Format-RevelationUpdateHistoryNotes -Entries $historyEntries -InstalledVersion ([string]$local.packageVersion) -LatestVersion ([string]$manifestObject.version) -FallbackNotes ([string]$manifestObject.notes)

    return [ordered]@{
        ok                    = $true
        supported             = $true
        releaseChannel         = $channel
        installedVersion       = [string]$local.packageVersion
        launcherRoot           = [string]$local.launcherRoot
        licenseType            = $(if ($licenseState) { [string](Get-LicenseStateValue -State $licenseState -Name 'licenseType' -Default 'normal') } else { 'unknown' })
        updateAllowed          = [bool]$entitlement.allowed
        updateAllowedReason    = [string]$entitlement.reason
        message                = 'Обновление скачано и проверено.'
        manifestUrl            = $(if ($canExposeManifestUrl) { [string]$manifestObject.sourceUrl } else { '' })
        latestVersion          = [string]$manifestObject.version
        updateAvailable        = [bool](Test-RevelationUpdateIsNewer -InstalledVersion ([string]$local.packageVersion) -RemoteVersion ([string]$manifestObject.version))
        installerDownloaded    = $true
        installerPath          = $targetPath
        sha256                 = [string]$manifestObject.sha256
        notes                  = $rangeNotes
        historyAvailable       = ($historyEntries.Count -gt 0)
        historyEntryCount      = [int]$historyEntries.Count
        downloaded             = $true
        manifestPath           = $statePath
    }
}

function Install-RevelationLauncherUpdate {
    param(
        [string]$LauncherRoot,
        [string]$ReleaseChannel = '',
        [string]$InstallerPath = '',
        [string]$Sha256 = '',
        [switch]$PreferDelta = $true
    )

    $local = Get-RevelationInstalledVersionInfo -LauncherRoot $LauncherRoot
    $root = [string]$local.launcherRoot
    $channel = if ($ReleaseChannel) { Normalize-RevelationUpdateChannel -ReleaseChannel $ReleaseChannel } else { [string]$local.releaseChannel }
    $entitlement = Test-RevelationLicenseAllowsUpdateChannel -LauncherRoot $root -ReleaseChannel $channel
    if (-not [bool]$entitlement.allowed) {
        throw ([string]$entitlement.message)
    }

    $installer = $InstallerPath
    $expectedHash = $Sha256
    if (-not $installer) {
        $download = Save-RevelationLauncherUpdate -LauncherRoot $root -ReleaseChannel $channel -PreferDelta:$PreferDelta
        $installer = [string]$download.installerPath
        $expectedHash = [string]$download.sha256
    }
    if ($expectedHash) {
        Write-RevelationUpdateProgress -Phase verifying
        Test-RevelationUpdateFileHash -Path $installer -Sha256 $expectedHash | Out-Null
    }

    $installRoot = $root
    if ($env:REVELATION_LAUNCHER_INSTALL_ROOT -and (Test-Path -LiteralPath (Join-Path $root 'launcher-build.json'))) {
        $candidate = [IO.Path]::GetFullPath($env:REVELATION_LAUNCHER_INSTALL_ROOT)
        if (-not (Test-Path -LiteralPath (Join-Path $candidate 'app\RevelationLauncher.exe') -PathType Leaf) -and
            -not (Test-Path -LiteralPath (Join-Path $candidate 'app\RevelationLauncherCanary.exe') -PathType Leaf)) {
            throw 'Не найдена папка установленного лаунчера.'
        }
        $installRoot = $candidate
    }
    if($installer.EndsWith('.delta.json',[StringComparison]::OrdinalIgnoreCase)) {
        . (Join-Path $PSScriptRoot 'tools/RevelationDeltaDownload.ps1')
        return Start-RevelationDeltaUpdate $installer $expectedHash $installRoot
    }
    $args = @(
        '-InstallAction', 'update',
        '-LauncherTargetRoot', $installRoot,
        '-ReleaseChannel', $channel,
        '-SkipLicenseDialog',
        '-SkipOptionalInstallDialog',
        '-LaunchAfterInstall',
        '-SuppressSuccessDialog'
    )
    if ($env:REVELATION_LAUNCHER_PID -match '^\d+$' -and $installRoot -ne $root) {
        $args += @('-WaitForProcessId', $env:REVELATION_LAUNCHER_PID)
    }
    $argumentLine = Join-RevelationUpdateNativeArguments -Arguments $args
    Write-RevelationUpdateProgress -Phase installing
    $process = Start-Process -FilePath $installer -ArgumentList $argumentLine -WorkingDirectory (Split-Path -Parent $installer) -PassThru

    return [ordered]@{
        ok          = $true
        started     = $true
        processId   = [int]$process.Id
        installerPath = $installer
        channel     = $channel
        message     = 'Установщик обновления запущен. Лаунчер закроется, чтобы установщик мог заменить файлы.'
    }
}



