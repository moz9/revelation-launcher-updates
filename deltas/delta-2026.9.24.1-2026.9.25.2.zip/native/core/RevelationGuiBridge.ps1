﻿param(
    [Parameter(Position = 0)]
    [ValidateSet('GetStatus', 'GetStartupStatus', 'CleanupStartupSession', 'CleanupGameExitSession', 'RelogGame', 'FastRelogGame', 'SavePendingRelogResume', 'ConsumePendingRelogResume', 'RunPendingRelogAsAdmin', 'LaunchGame', 'CancelActiveOperation', 'CheckServerPreflight', 'NetworkApply', 'SetNetworkStagedPreference', 'SetNetworkAutoApplyPreference', 'SetExperimentalFullLogPreference', 'SaveLauncherSettings', 'NetworkRestore', 'KillWatcher', 'EnablePvpRecoveryMode', 'DisablePvpRecoveryMode', 'PreparePvpResearchBundle', 'MarkPvpLagEvent', 'OpenVkPlay', 'OpenRevonlineCabinet', 'RunDemonsTask', 'RunFrameTimeAudit', 'PrepareDiagnostics', 'SendDiagnostics', 'SaveCurrentUserConfigPreset', 'ImportUserConfigPreset', 'ApplyUserConfigPreset', 'RenameUserConfigPreset', 'DeleteUserConfigPreset', 'SetRecoveryUserConfigPreset', 'RestoreUserConfig', 'GetGpuProfileStatus', 'SaveGpuProfileSettings', 'ApplyGpuProfileSettings', 'InstallNvidiaProfileInspector', 'RelaunchAsAdmin', 'GetActivationStatus', 'ActivateLicense', 'RefreshLicenseStatus', 'ApplyUnlockCode', 'DeactivateLocalCache', 'GetMachineRequestCode', 'GetUpdateStatus', 'CheckLauncherUpdate', 'SaveLauncherUpdate', 'InstallLauncherUpdate', 'VerifyLauncherHealth', 'ApplyUiGuardConfig', 'ApplyDisplaySettings', 'GetGameConfigEditor', 'SaveGameConfigEditor')]
    [string]$Action = 'GetStatus',

    [string]$LauncherRoot,
    [ValidateSet('normal', 'quick', 'full_log', 'pvp_safe', 'pvp_aggressive')]
    [string]$Mode = 'normal',
    [string]$Staged = '',
    [string]$AutoApply = '',
    [string]$FullLog = '',
    [string]$UploadDir = '',
    [string]$PresetId = '',
    [string]$PresetName = '',
    [string]$SourceDir = '',
    [string]$IncludeLarge = '',
    [uint32]$CurrentLauncherPid = 0,
    [string]$ActivationKey = '',
    [string]$UnlockCode = '',
    [string]$DisableIntroMovies = '',
    [string]$UiSpamGuard = '',
    [string]$ClientMitigation = '',
    [string]$DirectGameLaunch = '',
    [string]$SkipCharacterSelection = '',
    [string]$ServerPreflight = '',
    [string]$TrafficBudgetShield = '',
    [string]$TrafficBudgetShieldLimitParsec = '',
    [ValidateSet('auto', 'force-native', 'force-dxvk')]
    [string]$DxvkMode = 'auto',
    [string]$AutoCheckUpdatesOnStartup = '',
    [string]$CloseVkPlayAfterGameExit = '',
    [string]$PendingRelogFast = '',
    [ValidateSet('off', 'auto', 'manual')]
    [string]$GpuFpsCapMode = 'off',
    [int]$GpuManualFpsCap = 0,
    [string]$NvidiaProfileInspectorPath = '',
    [string]$NvidiaRecommendedPresetEnabled = '',
    [string]$UpdateChannel = '',
    [string]$UpdateInstallerPath = '',
    [string]$UpdateSha256 = '',
    [switch]$UpdatePreferDelta,
    [switch]$SkipRuntimeStatus,
    [string]$ConfigEditorPayloadB64 = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$bridgeLauncherRootArgument = $LauncherRoot
$script:BridgeOperationContext = $null
$script:BridgeOperationFailed = $false

$licenseScriptPath = Join-Path $PSScriptRoot 'RevelationLicense.ps1'
if (Test-Path -LiteralPath $licenseScriptPath) {
    . $licenseScriptPath
}

$updaterScriptPath = Join-Path $PSScriptRoot 'RevelationUpdater.ps1'
if (Test-Path -LiteralPath $updaterScriptPath) {
    . $updaterScriptPath
}

$loadHeavyBridgeModules = $Action -ne 'GetStartupStatus'
if ($loadHeavyBridgeModules) {
    $userConfigScriptPath = Join-Path $PSScriptRoot 'RevelationUserConfig.ps1'
    if (Test-Path -LiteralPath $userConfigScriptPath) {
        . $userConfigScriptPath
    }

    $pvpRecoveryScriptPath = Join-Path $PSScriptRoot 'RevelationPvpRecovery.ps1'
    if (Test-Path -LiteralPath $pvpRecoveryScriptPath) {
        . $pvpRecoveryScriptPath
    }

    $gpuProfileScriptPath = Join-Path $PSScriptRoot 'RevelationGpuProfiles.ps1'
    if (Test-Path -LiteralPath $gpuProfileScriptPath) {
        . $gpuProfileScriptPath
    }
}

function Write-JsonResponse {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Value,
        [int]$ExitCode = 0
    )

    if ($null -ne $script:BridgeOperationContext) {
        Complete-BridgeCancellableOperation -Failed:$script:BridgeOperationFailed
    }

    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $json = $Value | ConvertTo-Json -Depth 14 -Compress
    Write-Output $json
    exit $ExitCode
}

function Fail-Bridge {
    param([string]$Message)

    Write-JsonResponse -Value ([ordered]@{
        ok    = $false
        error = $Message
    }) -ExitCode 1
}

function ConvertTo-BridgeBoolean {
    param(
        [AllowNull()]
        [AllowEmptyString()]
        [string]$Value,
        [bool]$Default = $false
    )

    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace($Value)) {
        return [bool]$Default
    }

    $normalized = ([string]$Value).Trim().ToLowerInvariant()
    switch ($normalized) {
        '1' { return $true }
        '0' { return $false }
        'true' { return $true }
        'false' { return $false }
        '$true' { return $true }
        '$false' { return $false }
        'yes' { return $true }
        'no' { return $false }
        default {
            throw ('Invalid boolean value: ' + $Value)
        }
    }
}

function ConvertTo-NativeArgumentString {
    param([string[]]$Arguments)

    if (-not $Arguments -or $Arguments.Count -eq 0) {
        return ''
    }

    $quoted = foreach ($argument in $Arguments) {
        if ($null -eq $argument) {
            '""'
            continue
        }

        $text = [string]$argument
        if ($text.Length -eq 0) {
            '""'
            continue
        }

        if ($text -match '[\s"]') {
            '"' + ($text -replace '"', '\"') + '"'
        } else {
            $text
        }
    }

    return ($quoted -join ' ')
}

function ConvertTo-PowerShellSingleQuotedLiteral {
    param([AllowNull()][string]$Value)

    if ($null -eq $Value) {
        return "''"
    }

    return ("'" + ([string]$Value).Replace("'", "''") + "'")
}

function ConvertTo-PowerShellInvocationToken {
    param([AllowNull()][string]$Value)

    if ($null -eq $Value) {
        return "''"
    }

    $text = [string]$Value
    if ($text -match '^-{1,2}[A-Za-z_][A-Za-z0-9_]*$') {
        return $text
    }

    return (ConvertTo-PowerShellSingleQuotedLiteral -Value $text)
}

function ConvertTo-EncodedPowerShellInvocationArguments {
    param([string[]]$Arguments)

    if (-not $Arguments -or $Arguments.Count -eq 0) {
        return @()
    }

    $fileIndex = -1
    for ($i = 0; $i -lt $Arguments.Count; $i++) {
        if ([string]$Arguments[$i] -ieq '-File') {
            $fileIndex = $i
            break
        }
    }

    if ($fileIndex -lt 0 -or ($fileIndex + 1) -ge $Arguments.Count) {
        return @($Arguments)
    }

    $prefix = @()
    for ($i = 0; $i -lt $fileIndex; $i++) {
        $prefix += [string]$Arguments[$i]
    }

    $scriptPath = [string]$Arguments[$fileIndex + 1]
    $scriptArguments = @()
    for ($i = $fileIndex + 2; $i -lt $Arguments.Count; $i++) {
        $scriptArguments += [string]$Arguments[$i]
    }

    $commandParts = @('&', (ConvertTo-PowerShellSingleQuotedLiteral -Value $scriptPath))
    foreach ($argument in $scriptArguments) {
        $commandParts += (ConvertTo-PowerShellInvocationToken -Value ([string]$argument))
    }

    $commandText = ($commandParts -join ' ')
    $commandBytes = [System.Text.Encoding]::Unicode.GetBytes($commandText)
    $encodedCommand = [Convert]::ToBase64String($commandBytes)

    return @($prefix + @('-EncodedCommand', $encodedCommand))
}

function Assert-BridgeLicense {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$Context,
        [switch]$ForceRefresh
    )

    if (-not (Get-Command -Name Assert-LicenseValid -ErrorAction SilentlyContinue)) {
        throw 'Лицензионный модуль не найден.'
    }

    return (Assert-LicenseValid -LauncherRoot $ResolvedLauncherRoot -Context $Context -ForceRefresh:$ForceRefresh)
}

function Ensure-Directory {
    param([string]$Path)

    if ($Path -and (-not (Test-Path -LiteralPath $Path))) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Get-BridgeOperationStatePaths {
    param([string]$ResolvedLauncherRoot)

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    return [ordered]@{
        active = Join-Path $stateDir 'active-operation.json'
        cancel = Join-Path $stateDir 'cancel-operation.json'
        last   = Join-Path $stateDir 'last-operation.json'
    }
}

function Read-BridgeOperationJson {
    param([string]$Path)

    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) {
        return $null
    }

    try {
        return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    } catch {
        return $null
    }
}

function Write-BridgeOperationJson {
    param(
        [string]$Path,
        [object]$Value
    )

    Ensure-Directory -Path (Split-Path -Parent $Path)
    $tempPath = $Path + '.tmp-' + [Guid]::NewGuid().ToString('N')
    try {
        $json = $Value | ConvertTo-Json -Depth 10
        [System.IO.File]::WriteAllText($tempPath, $json, [System.Text.UTF8Encoding]::new($false))
        if (Test-Path -LiteralPath $Path) {
            try {
                [System.IO.File]::Replace($tempPath, $Path, $null, $true)
            } catch {
                Copy-Item -LiteralPath $tempPath -Destination $Path -Force
                Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
            }
        } else {
            Move-Item -LiteralPath $tempPath -Destination $Path -Force
        }
    } finally {
        Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
    }
}

function Start-BridgeCancellableOperation {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$Kind
    )

    $paths = Get-BridgeOperationStatePaths -ResolvedLauncherRoot $ResolvedLauncherRoot
    Remove-Item -LiteralPath $paths.cancel -Force -ErrorAction SilentlyContinue
    $operation = [ordered]@{
        operationId      = [Guid]::NewGuid().ToString('N')
        kind             = [string]$Kind
        phase            = 'starting'
        cancellable      = $true
        bridgeProcessId  = [int]$PID
        startedAtUtc     = [DateTime]::UtcNow.ToString('o')
        lastUpdatedAtUtc = [DateTime]::UtcNow.ToString('o')
    }
    Write-BridgeOperationJson -Path $paths.active -Value $operation
    $script:BridgeOperationContext = [ordered]@{
        root      = [string]$ResolvedLauncherRoot
        operation = $operation
        paths     = $paths
    }
    return $operation
}

function Set-BridgeOperationPhase {
    param(
        [string]$Phase,
        [AllowNull()]
        [object]$Cancellable = $null,
        [string]$Message = ''
    )

    if ($null -eq $script:BridgeOperationContext) {
        return
    }

    $operation = $script:BridgeOperationContext.operation
    $operation['phase'] = [string]$Phase
    $operation['message'] = $Message
    if ($null -ne $Cancellable) {
        $operation['cancellable'] = [bool]$Cancellable
    }
    $operation['lastUpdatedAtUtc'] = [DateTime]::UtcNow.ToString('o')
    Write-BridgeOperationJson -Path $script:BridgeOperationContext.paths.active -Value $operation
}

function Test-BridgeOperationCancelled {
    if ($null -eq $script:BridgeOperationContext) {
        return $false
    }

    $request = Read-BridgeOperationJson -Path $script:BridgeOperationContext.paths.cancel
    if ($null -eq $request) {
        return $false
    }

    $requestedId = [string](Get-CompatManifestPropertyValue -Manifest $request -PropertyNames @('operationId'))
    $operationId = [string]$script:BridgeOperationContext.operation.operationId
    return [bool]($requestedId -and $requestedId -eq $operationId)
}

function Assert-BridgeOperationNotCancelled {
    if (Test-BridgeOperationCancelled) {
        throw [System.OperationCanceledException]::new('Операция остановлена пользователем.')
    }
}

function Request-BridgeActiveOperationCancel {
    param([string]$ResolvedLauncherRoot)

    $paths = Get-BridgeOperationStatePaths -ResolvedLauncherRoot $ResolvedLauncherRoot
    $active = Read-BridgeOperationJson -Path $paths.active
    if ($null -eq $active) {
        return [ordered]@{
            ok              = $true
            cancelRequested = $false
            message         = 'Активная операция уже завершена.'
        }
    }

    $operationId = [string](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('operationId'))
    $bridgeProcessId = [int](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('bridgeProcessId'))
    $cancellable = [bool](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('cancellable'))
    if (-not $operationId -or $bridgeProcessId -le 0 -or -not (Get-Process -Id $bridgeProcessId -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $paths.active -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $paths.cancel -Force -ErrorAction SilentlyContinue
        return [ordered]@{
            ok              = $true
            cancelRequested = $false
            message         = 'Активная операция уже завершена.'
        }
    }

    if (-not $cancellable) {
        return [ordered]@{
            ok              = $true
            cancelRequested = $false
            operationId     = $operationId
            kind            = [string](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('kind'))
            phase           = [string](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('phase'))
            message         = 'Команда запуска уже передана внешней программе; этот этап нельзя безопасно отменить.'
        }
    }

    $request = [ordered]@{
        operationId  = $operationId
        kind         = [string](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('kind'))
        requestedAtUtc = [DateTime]::UtcNow.ToString('o')
        requestedByPid = [int]$PID
    }
    Write-BridgeOperationJson -Path $paths.cancel -Value $request
    return [ordered]@{
        ok              = $true
        cancelRequested = $true
        operationId     = $operationId
        kind            = [string]$request.kind
        message         = 'Остановка запрошена. Лаунчер завершит текущий безопасный этап.'
    }
}

function Complete-BridgeCancellableOperation {
    param([switch]$Failed)

    if ($null -eq $script:BridgeOperationContext) {
        return
    }

    $context = $script:BridgeOperationContext
    $cancelled = Test-BridgeOperationCancelled
    $operation = $context.operation
    $operation['completedAtUtc'] = [DateTime]::UtcNow.ToString('o')
    $operation['status'] = $(if ($cancelled) { 'cancelled' } elseif ($Failed) { 'failed' } else { 'completed' })
    try {
        Write-BridgeOperationJson -Path $context.paths.last -Value $operation
        $active = Read-BridgeOperationJson -Path $context.paths.active
        $activeId = [string](Get-CompatManifestPropertyValue -Manifest $active -PropertyNames @('operationId'))
        if ($activeId -eq [string]$operation.operationId) {
            Remove-Item -LiteralPath $context.paths.active -Force -ErrorAction SilentlyContinue
        }
        $request = Read-BridgeOperationJson -Path $context.paths.cancel
        $requestId = [string](Get-CompatManifestPropertyValue -Manifest $request -PropertyNames @('operationId'))
        if ($requestId -eq [string]$operation.operationId) {
            Remove-Item -LiteralPath $context.paths.cancel -Force -ErrorAction SilentlyContinue
        }
    } finally {
        $script:BridgeOperationContext = $null
    }
}

function Assert-BridgeUserConfigBackend {
    if (-not (Get-Command -Name Get-LauncherUserConfigStatus -ErrorAction SilentlyContinue)) {
        throw 'Модуль пользовательских конфигов не найден.'
    }
}

function Assert-BridgePvpRecoveryBackend {
    if (-not (Get-Command -Name Get-LauncherPvpRecoveryStatus -ErrorAction SilentlyContinue)) {
        throw 'Модуль игрового буста не найден.'
    }
}

function Assert-BridgeGpuProfileBackend {
    if (-not (Get-Command -Name Get-RevelationGpuProfileStatus -ErrorAction SilentlyContinue)) {
        throw 'Модуль профилей видеокарты не найден.'
    }
}

function Assert-BridgeUpdaterBackend {
    if (-not (Get-Command -Name Get-RevelationUpdateStatus -ErrorAction SilentlyContinue)) {
        throw 'Модуль обновления лаунчера не найден.'
    }
}

function Read-KeyValueFile {
    param([string]$Path)

    $map = @{}
    if (-not (Test-Path -LiteralPath $Path)) {
        return $map
    }

    foreach ($line in (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
        $text = [string]$line
        $index = $text.IndexOf('=')
        if ($index -le 0) { continue }
        $key = $text.Substring(0, $index).Trim()
        $value = $text.Substring($index + 1)
        $map[$key] = $value
    }

    return $map
}

function Get-CompatManifestPropertyValue {
    param(
        [AllowNull()]
        [object]$Manifest,
        [string[]]$PropertyNames
    )

    if ($null -eq $Manifest -or -not $PropertyNames) {
        return $null
    }

    $properties = $null
    try {
        $properties = $Manifest.PSObject.Properties
    } catch {
        return $null
    }

    foreach ($propertyName in $PropertyNames) {
        if ([string]::IsNullOrWhiteSpace($propertyName)) {
            continue
        }

        $property = @($properties.Match($propertyName) | Select-Object -First 1)[0]
        if ($null -ne $property) {
            return $property.Value
        }
    }

    return $null
}

function Initialize-CompatInstallManifest {
    param([AllowNull()][object]$Manifest)

    if ($null -eq $Manifest) {
        return $null
    }

    $releaseChannel = [string](Get-CompatManifestPropertyValue -Manifest $Manifest -PropertyNames @('ReleaseChannel', 'releaseChannel'))
    $launcherDisplayName = [string](Get-CompatManifestPropertyValue -Manifest $Manifest -PropertyNames @('LauncherDisplayName', 'launcherDisplayName'))

    Add-Member -InputObject $Manifest -MemberType NoteProperty -Name ReleaseChannel -Value $releaseChannel -Force
    Add-Member -InputObject $Manifest -MemberType NoteProperty -Name LauncherDisplayName -Value $launcherDisplayName -Force
    return $Manifest
}

function Read-BridgeInstallManifest {
    param([string]$ResolvedLauncherRoot)

    $manifestPath = Join-Path $ResolvedLauncherRoot '.revelation-combat\install.json'
    if (-not (Test-Path -LiteralPath $manifestPath)) {
        return $null
    }

    try {
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop | ConvertFrom-Json
        return (Initialize-CompatInstallManifest -Manifest $manifest)
    } catch {
        return $null
    }
}

function Get-LauncherStatusIdentity {
    param(
        [string]$ResolvedLauncherRoot,
        [object]$Config
    )

    $manifest = Read-BridgeInstallManifest -ResolvedLauncherRoot $ResolvedLauncherRoot
    $releaseChannel = if ((Test-BridgeMapHasKey -Map $Config -Key 'releaseChannel') -and $Config['releaseChannel']) {
        [string]$Config['releaseChannel']
    } elseif ($manifest -and $manifest.ReleaseChannel) {
        [string]$manifest.ReleaseChannel
    } else {
        'release'
    }

    if ($releaseChannel -eq 'public') {
        $releaseChannel = 'release'
    }
    if ($releaseChannel -notin @('release', 'experimental')) {
        $releaseChannel = 'release'
    }

    $launcherDisplayName = if ((Test-BridgeMapHasKey -Map $Config -Key 'launcherDisplayName') -and $Config['launcherDisplayName']) {
        [string]$Config['launcherDisplayName']
    } elseif ($manifest -and $manifest.LauncherDisplayName) {
        [string]$manifest.LauncherDisplayName
    } elseif ($releaseChannel -eq 'experimental') {
        'Revelation Launcher Experimental'
    } else {
        'Revelation Launcher'
    }

    return [ordered]@{
        releaseChannel     = $releaseChannel
        launcherDisplayName = $launcherDisplayName
    }
}

function Write-KeyValueFile {
    param(
        [string]$Path,
        [hashtable]$Map
    )

    Ensure-Directory -Path (Split-Path -Parent $Path)
    $lines = foreach ($key in ($Map.Keys | Sort-Object)) {
        '{0}={1}' -f $key, ([string]$Map[$key]).Replace("`r", ' ').Replace("`n", ' ')
    }
    Set-Content -LiteralPath $Path -Value $lines -Encoding UTF8
}

function Get-PreferredPowerShellExe {
    $candidates = @()
    if ($env:WINDIR) {
        $candidates += (Join-Path $env:WINDIR 'Sysnative\WindowsPowerShell\v1.0\powershell.exe')
        $candidates += (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
        $candidates += (Join-Path $env:WINDIR 'SysWOW64\WindowsPowerShell\v1.0\powershell.exe')
    }
    $candidates += 'powershell.exe'

    foreach ($candidate in $candidates) {
        if ($candidate -eq 'powershell.exe' -or (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }

    return 'powershell.exe'
}


function Resolve-LauncherRoot {
    param([string]$ConfiguredRoot)

    $candidates = New-Object System.Collections.Generic.List[string]
    if ($ConfiguredRoot) { $candidates.Add($ConfiguredRoot) }
    if ($PSScriptRoot) { $candidates.Add($PSScriptRoot) }
    if ($pwd) { $candidates.Add($pwd.Path) }

    foreach ($candidate in $candidates) {
        if (-not $candidate) { continue }
        try {
            $resolved = if (Test-Path -LiteralPath 'Function:\Resolve-LauncherUserConfigCanonicalPath') {
                Resolve-LauncherUserConfigCanonicalPath -Path $candidate
            } else {
                (Resolve-Path -LiteralPath $candidate).Path
            }
            if ($resolved -and ((Test-Path -LiteralPath (Join-Path $resolved 'RevelationUniversal.cmd')) -or (Test-Path -LiteralPath (Join-Path $resolved 'launcher-config.ini')))) {
                return $resolved
            }
        } catch {
        }
    }

    throw 'Launcher root could not be resolved.'
}

function Test-BridgeMapHasKey {
    param(
        [object]$Map,
        [string]$Key
    )

    if ($null -eq $Map -or [string]::IsNullOrWhiteSpace($Key)) {
        return $false
    }

    if ($Map -is [System.Collections.IDictionary]) {
        return $Map.Contains($Key)
    }

    try {
        return ($null -ne $Map.PSObject.Properties[$Key])
    } catch {
        return $false
    }
}

function Get-ConfiguredGameRootFromLauncher {
    param([string]$ResolvedLauncherRoot)

    $configPath = Join-Path $ResolvedLauncherRoot 'launcher-config.ini'
    $map = Read-KeyValueFile -Path $configPath
    if ((Test-BridgeMapHasKey -Map $map -Key 'gameRoot') -and $map['gameRoot']) {
        return [string]$map['gameRoot']
    }

    return ''
}

function Resolve-GameRoot {
    param([string]$ResolvedLauncherRoot)

    $candidates = New-Object System.Collections.Generic.List[string]
    if ($env:REVELATION_GAME_ROOT) { $candidates.Add([string]$env:REVELATION_GAME_ROOT) }
    $configured = Get-ConfiguredGameRootFromLauncher -ResolvedLauncherRoot $ResolvedLauncherRoot
    if ($configured) { $candidates.Add($configured) }
    $candidates.Add($ResolvedLauncherRoot)
    $parent = Split-Path -Parent $ResolvedLauncherRoot
    if ($parent) { $candidates.Add($parent) }

    foreach ($candidatePath in $candidates) {
        if (-not $candidatePath) { continue }
        try {
            $resolved = (Resolve-Path -LiteralPath $candidatePath).Path
            if (Test-Path -LiteralPath (Join-Path $resolved 'game\tianyu.exe')) {
                return $resolved
            }
            if (Test-Path -LiteralPath (Join-Path $resolved 'tianyu.exe')) {
                return (Split-Path -Parent $resolved)
            }
        } catch {
        }
    }

    throw 'Game root could not be resolved.'
}

function Resolve-GameDir {
    param([string]$ResolvedGameRoot)

    $gameDir = Join-Path $ResolvedGameRoot 'game'
    if (-not (Test-Path -LiteralPath (Join-Path $gameDir 'tianyu.exe'))) {
        throw ('Game directory not found: ' + $gameDir)
    }

    return $gameDir
}

function New-EmptyProcessRuntimeStatus {
    return [ordered]@{
        running             = $false
        processCount        = 0
        pid                 = 0
        path                = ''
        matchedExpectedPath = $false
    }
}

function New-UnresolvedDxvkStatus {
    return [ordered]@{
        activePath = ''
        envValue   = $(try { Get-DxvkEnvValue } catch { '' })
        preset     = 'unresolved'
        confirmed  = $false
        summary    = 'game_root_unresolved'
    }
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-BridgeProcessTokenType {
    if ('RevelationLauncher.ProcessToken' -as [type]) {
        return
    }

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

namespace RevelationLauncher {
    public static class ProcessToken {
        [DllImport("kernel32.dll", SetLastError=true)]
        private static extern IntPtr OpenProcess(UInt32 access, bool inherit, UInt32 pid);

        [DllImport("advapi32.dll", SetLastError=true)]
        private static extern bool OpenProcessToken(IntPtr processHandle, UInt32 desiredAccess, out IntPtr tokenHandle);

        [DllImport("advapi32.dll", SetLastError=true)]
        private static extern bool GetTokenInformation(IntPtr tokenHandle, int tokenInformationClass, out int tokenInformation, int tokenInformationLength, out int returnLength);

        [DllImport("kernel32.dll", SetLastError=true)]
        private static extern bool CloseHandle(IntPtr handle);

        private const UInt32 PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
        private const UInt32 TOKEN_QUERY = 0x0008;

        public static int ElevationByPid(int pid) {
            IntPtr processHandle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, (UInt32)pid);
            if (processHandle == IntPtr.Zero) {
                return -10;
            }

            IntPtr tokenHandle;
            if (!OpenProcessToken(processHandle, TOKEN_QUERY, out tokenHandle)) {
                CloseHandle(processHandle);
                return -20;
            }

            int elevated;
            int returnedLength;
            bool ok = GetTokenInformation(tokenHandle, 20, out elevated, 4, out returnedLength);
            CloseHandle(tokenHandle);
            CloseHandle(processHandle);
            if (!ok) {
                return -30;
            }

            return elevated;
        }
    }
}
'@ -ErrorAction Stop
}

function Get-BridgeProcessElevationStatus {
    param([int]$ProcessId)

    if ($ProcessId -le 0) {
        return [ordered]@{
            ok       = $false
            pid      = [int]$ProcessId
            elevated = $false
            code     = -1
            message  = 'Process PID is not valid.'
        }
    }

    try {
        Ensure-BridgeProcessTokenType
        $code = [int][RevelationLauncher.ProcessToken]::ElevationByPid([int]$ProcessId)
        return [ordered]@{
            ok       = [bool]($code -ge 0)
            pid      = [int]$ProcessId
            elevated = [bool]($code -eq 1)
            code     = [int]$code
            message  = $(if ($code -ge 0) { 'Process token elevation checked.' } else { 'Process token elevation could not be checked.' })
        }
    } catch {
        return [ordered]@{
            ok       = $false
            pid      = [int]$ProcessId
            elevated = $false
            code     = -99
            error    = $_.Exception.Message
            message  = 'Process token elevation check failed: ' + $_.Exception.Message
        }
    }
}

function Get-BridgeGameInputElevationRequirement {
    param([string]$ResolvedGameDir = '')

    $launcherElevated = [bool](Test-IsAdministrator)
    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir)
    $statuses = New-Object System.Collections.Generic.List[object]
    $gameElevated = $false
    $elevationUnknown = $false
    foreach ($proc in $processes) {
        $status = Get-BridgeProcessElevationStatus -ProcessId ([int]$proc.Id)
        [void]$statuses.Add([ordered]@{
                pid                   = [int]$proc.Id
                name                  = [string]$proc.ProcessName
                mainWindowHandle      = [int64]$proc.MainWindowHandle
                mainWindowTitle       = [string]$proc.MainWindowTitle
                elevation             = $status
            })
        if ([bool]$status.elevated) {
            $gameElevated = $true
        }
        if (-not [bool]$status.ok) { $elevationUnknown = $true }
    }

    return [ordered]@{
        ok               = $true
        launcherElevated = [bool]$launcherElevated
        gameElevated     = [bool]$gameElevated
        requiresAdmin    = [bool](($gameElevated -or $elevationUnknown) -and -not $launcherElevated)
        elevationUnknown = [bool]$elevationUnknown
        processCount     = [int]$processes.Count
        processes        = @($statuses.ToArray())
        message          = $(if (($gameElevated -or $elevationUnknown) -and -not $launcherElevated) {
                'Игра запущена с повышенными правами; для релога нужен запуск лаунчера от администратора.'
            } else {
                'Права лаунчера достаточны для ввода в окно игры.'
            })
    }
}

function Get-GameCenterExePath {
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'GameCenter\GameCenter.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\GameCenter\GameCenter.exe'),
        (Join-Path $env:ProgramFiles 'VK Play\GameCenter.exe'),
        $(if ($programFilesX86) { Join-Path $programFilesX86 'VK Play\GameCenter.exe' } else { '' })
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    return ''
}

function Get-RevelationGameCenterLaunchUri {
    param([string]$ResolvedGameRoot)

    foreach ($configPath in @(
            (Join-Path $env:LOCALAPPDATA 'GameCenter\configBigGames.xml'),
            (Join-Path $env:LOCALAPPDATA 'Programs\GameCenter\configBigGames.xml'),
            (Join-Path $env:APPDATA 'GameCenter\configBigGames.xml')
        )) {
        if (-not (Test-Path -LiteralPath $configPath)) {
            continue
        }

        try {
            [xml]$xml = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 -ErrorAction Stop
            $items = @($xml.BigGame.BigGameItem)
            foreach ($item in $items) {
                $name = [string]$item.Name
                $title = [string]$item.Title
                $installed = [string]$item.InstalledFileNames
                $distribId = [string]$item.DistribId
                if (-not $distribId) {
                    continue
                }

                if ($name -ieq 'revelation' -or $title -ieq 'Revelation' -or $installed -match '(?i)tianyu(?:\.exe)?') {
                    return ('vkplay://play/0.' + $distribId)
                }
            }
        } catch {
        }
    }

    return 'vkplay://play/0.1000146'
}

function Start-RevelationViaGameCenter {
    param([string]$ResolvedGameRoot)

    $gameCenterExe = Get-GameCenterExePath
    if (-not $gameCenterExe) {
        return [ordered]@{
            started   = $false
            fallback  = $false
            path      = ''
            launchUri = ''
        }
    }

    $launchUri = Get-RevelationGameCenterLaunchUri -ResolvedGameRoot $ResolvedGameRoot
    try {
        Start-Process -FilePath $gameCenterExe -ArgumentList @($launchUri) | Out-Null
        return [ordered]@{
            started   = $true
            fallback  = $false
            path      = $gameCenterExe
            launchUri = $launchUri
        }
    } catch {
    }

    try {
        Start-Process -FilePath $gameCenterExe | Out-Null
        return [ordered]@{
            started   = $true
            fallback  = $true
            path      = $gameCenterExe
            launchUri = ''
        }
    } catch {
    }

    return [ordered]@{
        started   = $false
        fallback  = $false
        path      = $gameCenterExe
        launchUri = $launchUri
    }
}

function Open-GameCenterLauncher {
    $gameCenterExe = Get-GameCenterExePath
    if (-not $gameCenterExe) {
        return [ordered]@{
            started = $false
            path    = ''
        }
    }

    try {
        Start-Process -FilePath $gameCenterExe | Out-Null
        return [ordered]@{
            started = $true
            path    = $gameCenterExe
        }
    } catch {
        return [ordered]@{
            started = $false
            path    = $gameCenterExe
        }
    }
}

function Get-DxvkEnvValue {
    $user = [Environment]::GetEnvironmentVariable('DXVK_CONFIG_FILE', 'User')
    if ($user) { return [string]$user }
    $process = [Environment]::GetEnvironmentVariable('DXVK_CONFIG_FILE', 'Process')
    if ($process) { return [string]$process }
    return ''
}


function Get-PerUserBaselineDir {
    param([string]$LauncherRoot)

    if (Test-Path -LiteralPath 'Function:\Get-LauncherUserConfigLegacyBaselineDir') {
        return (Get-LauncherUserConfigLegacyBaselineDir -LauncherRoot $LauncherRoot)
    }

    $normalizedRoot = [string]$LauncherRoot
    if (-not $normalizedRoot) {
        $normalizedRoot = 'unknown'
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($normalizedRoot.ToLowerInvariant())
        $hash = (($sha.ComputeHash($bytes) | Select-Object -First 4 | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally {
        $sha.Dispose()
    }
    return (Join-Path $env:LOCALAPPDATA ("RevelationLauncher\profiles\{0}@{1}_{2}\baseline" -f $env:USERNAME, $env:COMPUTERNAME, $hash))
}

function Get-SettingsState {
    param([string]$StateDir)

    $settingsPath = Join-Path $StateDir 'launcher-settings.ini'
    $map = Read-KeyValueFile -Path $settingsPath
    $dxvkModeRaw = $(if (Test-BridgeMapHasKey -Map $map -Key 'dxvkMode') { ([string]$map['dxvkMode']).Trim().ToLowerInvariant() } else { 'auto' })
    $dxvkMode = switch ($dxvkModeRaw) {
        { $_ -in @('force-native', 'forcenative', 'native', 'off', 'disabled', '0') } { 'force-native'; break }
        { $_ -in @('force-dxvk', 'forcedxvk', 'dxvk', 'on', 'enabled', '1') } { 'force-dxvk'; break }
        default { 'auto' }
    }
    return [ordered]@{
        path             = $settingsPath
        dxvkMode         = $dxvkMode
        uploadDir        = $(if ((Test-BridgeMapHasKey -Map $map -Key 'uploadDir') -and $map['uploadDir']) { [string]$map['uploadDir'] } else { Join-Path $StateDir 'developer-outbox' })
        includeLarge     = [bool]((Test-BridgeMapHasKey -Map $map -Key 'includeLarge') -and [string]$map['includeLarge'] -eq '1')
        networkStaged    = [bool]((Test-BridgeMapHasKey -Map $map -Key 'networkStaged') -and [string]$map['networkStaged'] -eq '1')
        networkAutoApply = $(if (Test-BridgeMapHasKey -Map $map -Key 'networkAutoApply') {
                [bool]([string]$map['networkAutoApply'] -eq '1')
            } else {
                $true
            })
        experimentalFullLog = $(if (Test-BridgeMapHasKey -Map $map -Key 'experimentalFullLog') {
                [bool]([string]$map['experimentalFullLog'] -eq '1')
            } else {
                $true
        })
        directGameLaunch = [bool](((-not (Test-BridgeMapHasKey -Map $map -Key 'directGameLaunch')) -or [string]$map['directGameLaunch'] -eq '1'))
        skipCharacterSelection = [bool]((Test-BridgeMapHasKey -Map $map -Key 'skipCharacterSelection') -and [string]$map['skipCharacterSelection'] -eq '1')
        autoCheckUpdatesOnStartup = $(if (Test-BridgeMapHasKey -Map $map -Key 'autoCheckUpdatesOnStartup') {
                [bool]([string]$map['autoCheckUpdatesOnStartup'] -eq '1')
            } else {
                $true
            })
        closeVkPlayAfterGameExit = $(if (Test-BridgeMapHasKey -Map $map -Key 'closeVkPlayAfterGameExit') {
                [bool]([string]$map['closeVkPlayAfterGameExit'] -eq '1')
            } else {
                $true
            })
        uiSpamGuard = $(if (Test-BridgeMapHasKey -Map $map -Key 'uiSpamGuard') {
                [bool]([string]$map['uiSpamGuard'] -eq '1')
            } else {
                $false
            })
        clientMitigation = $(if (Test-BridgeMapHasKey -Map $map -Key 'clientMitigation') {
                [bool]([string]$map['clientMitigation'] -eq '1')
            } else {
                $false
            })
        serverPreflight = $(if (Test-BridgeMapHasKey -Map $map -Key 'serverPreflight') {
                [bool]([string]$map['serverPreflight'] -eq '1')
            } else {
                $true
            })
        disableIntroMovies = [bool]((Test-BridgeMapHasKey -Map $map -Key 'disableIntroMovies') -and [string]$map['disableIntroMovies'] -eq '1')
        trafficBudgetShield = $(if (Test-BridgeMapHasKey -Map $map -Key 'trafficBudgetShield') {
                [bool]([string]$map['trafficBudgetShield'] -eq '1')
            } else {
                $true
            })
        trafficBudgetShieldLimitParsec = $(if (Test-BridgeMapHasKey -Map $map -Key 'trafficBudgetShieldLimitParsec') {
                [bool]([string]$map['trafficBudgetShieldLimitParsec'] -eq '1')
            } else {
                $false
            })
    }
}

function Get-BridgeXmlTagValue {
    param(
        [AllowNull()][string]$Text,
        [string]$Parent,
        [string]$Key
    )

    if ([string]::IsNullOrWhiteSpace($Text) -or [string]::IsNullOrWhiteSpace($Parent) -or [string]::IsNullOrWhiteSpace($Key)) {
        return ''
    }

    $parentEscaped = [regex]::Escape($Parent)
    $keyEscaped = [regex]::Escape($Key)
    $pattern = "(?s)<$parentEscaped>\s*(?:(?!</$parentEscaped>).)*?<$keyEscaped>\s*(.*?)\s*</$keyEscaped>.*?</$parentEscaped>"
    $match = [regex]::Match($Text, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($match.Success) {
        return ([string]$match.Groups[1].Value).Trim()
    }

    return ''
}

function Get-BridgeHideModeFlagValue {
    param(
        [AllowNull()][string]$Text,
        [int]$GroupIndex,
        [int]$ValueIndex
    )

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ''
    }

    $match = [regex]::Match($Text, '(?s)<hideMode>\s*([^<]*?)\s*</hideMode>', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $match.Success) {
        return ''
    }

    $groups = ([string]$match.Groups[1].Value).Trim() -split '@'
    if ($GroupIndex -lt 0 -or $GroupIndex -ge $groups.Count) {
        return ''
    }

    $values = ([string]$groups[$GroupIndex]).Trim() -split ','
    if ($ValueIndex -lt 0 -or $ValueIndex -ge $values.Count) {
        return ''
    }

    return ([string]$values[$ValueIndex]).Trim()
}

function Set-BridgeHideModeFlagValue {
    param(
        [string]$Text,
        [int]$GroupIndex,
        [int]$ValueIndex,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return $Text
    }

    $match = [regex]::Match($Text, '(?s)<hideMode>\s*([^<]*?)\s*</hideMode>', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $match.Success) {
        return $Text
    }

    $groups = ([string]$match.Groups[1].Value).Trim() -split '@'
    if ($GroupIndex -lt 0 -or $GroupIndex -ge $groups.Count) {
        return $Text
    }

    $values = ([string]$groups[$GroupIndex]).Trim() -split ','
    if ($ValueIndex -lt 0 -or $ValueIndex -ge $values.Count) {
        return $Text
    }

    $values[$ValueIndex] = $Value
    $groups[$GroupIndex] = ($values -join ',')
    $replacement = '<hideMode>' + "`t" + ($groups -join '@') + "`t" + '</hideMode>'
    return $Text.Substring(0, $match.Index) + $replacement + $Text.Substring($match.Index + $match.Length)
}

function Get-BridgeUiGuardWidgetNames {
    return @(
        'systemtips',
        'pushmsg',
        'systempush',
        'topmessage',
        'singletip',
        'pushMessageV2',
        'warMessage',
        'playtips',
        'continuoushit',
        'region',
        'spriteani',
        'buffmotice',
        'debuffmotice',
        'bufflistenershow'
    )
}

function Get-BridgeUiGuardWidgetVisibilityDefaults {
    return [ordered]@{
        systemtips       = '0'
        pushmsg          = '0'
        systempush       = '0'
        topmessage       = '0'
        singletip        = '0'
        pushMessageV2    = '0'
        warMessage       = '0'
        playtips         = '0'
        continuoushit    = '0'
        region           = '0'
        spriteani        = '0'
        buffmotice       = '0'
        debuffmotice     = '0'
        bufflistenershow = '1'
    }
}

function Restore-BridgeUiGuardWidgetVisibility {
    param([string]$Text)

    $updated = $Text
    $defaults = Get-BridgeUiGuardWidgetVisibilityDefaults
    foreach ($widgetName in $defaults.Keys) {
        $updated = Set-BridgeWidgetTagValueIfPresent -Text $updated -WidgetName $widgetName -TagName 'hidden' -Value $defaults[$widgetName]
    }

    return $updated
}

function Get-BridgeUiGuardStatePath {
    param([string]$ResolvedLauncherRoot)

    return (Join-Path (Join-Path $ResolvedLauncherRoot '.revelation-combat') 'ui-guard-state.json')
}

function Write-BridgeUiGuardRepairState {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ConfigPath
    )

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $configWriteUtc = (Get-Item -LiteralPath $ConfigPath -ErrorAction Stop).LastWriteTimeUtc
    $state = [ordered]@{
        configPath             = $ConfigPath
        launcherConfigWriteUtc = $configWriteUtc.ToString('o')
        updatedUtc             = (Get-Date).ToUniversalTime().ToString('o')
    }
    $statePath = Get-BridgeUiGuardStatePath -ResolvedLauncherRoot $ResolvedLauncherRoot
    [System.IO.File]::WriteAllText($statePath, ($state | ConvertTo-Json -Depth 5), [System.Text.UTF8Encoding]::new($false))
}

function Read-BridgeUiGuardRepairState {
    param([string]$ResolvedLauncherRoot)

    $statePath = Get-BridgeUiGuardStatePath -ResolvedLauncherRoot $ResolvedLauncherRoot
    if (-not (Test-Path -LiteralPath $statePath)) {
        return $null
    }

    try {
        return (Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json)
    } catch {
        return $null
    }
}

function Set-BridgeNestedXmlScalar {
    param(
        [string]$Text,
        [string]$Parent,
        [string]$Key,
        [string]$Value
    )

    $parentEscaped = [regex]::Escape($Parent)
    $keyEscaped = [regex]::Escape($Key)
    $pattern = "(?s)(<$parentEscaped\b[^>]*>.*?<$keyEscaped\b[^>]*>)\s*[^<]*\s*(</$keyEscaped>)"
    $rx = [regex]$pattern
    if ($rx.IsMatch($Text)) {
        return $rx.Replace($Text, { param($m) $m.Groups[1].Value + "`t$Value`t" + $m.Groups[2].Value }, 1)
    }

    $closeRx = [regex]("(?s)(</$parentEscaped>)")
    if ($closeRx.IsMatch($Text)) {
        return $closeRx.Replace($Text, { param($m) "`t`t<$Key>`t$Value`t</$Key>`r`n" + $m.Groups[1].Value }, 1)
    }

    return $Text
}

function Set-BridgeWidgetTagValueIfPresent {
    param(
        [string]$Text,
        [string]$WidgetName,
        [string]$TagName,
        [string]$Value
    )

    $pattern = "(?s)(<$WidgetName\b[^>]*>.*?<$TagName\b[^>]*>\s*)([^<]*?)(\s*</$TagName>)"
    if ($Text -notmatch $pattern) {
        return $Text
    }

    return [regex]::Replace($Text, $pattern, ('${1}' + $Value + '${3}'), 1)
}

function Set-BridgeNpcQuickRead {
    param([string]$Text)

    $existingPattern = "(?s)<npcV2\b[^>]*>.*?<quickRead\b[^>]*>\s*[^<]*\s*</quickRead>.*?</npcV2>"
    if ([regex]::IsMatch($Text, $existingPattern)) {
        return Set-BridgeNestedXmlScalar -Text $Text -Parent 'npcV2' -Key 'quickRead' -Value '0'
    }

    $updated = Set-BridgeNestedXmlScalar -Text $Text -Parent 'npcV2' -Key 'quickRead' -Value '0'
    if ($updated -ne $Text) {
        return $updated
    }

    $closeRx = [regex]"(?s)(</ui>)"
    if ($closeRx.IsMatch($Text)) {
        return $closeRx.Replace($Text, { param($m) "`t`t<npcV2>`r`n`t`t`t<quickRead>`t0`t</quickRead>`r`n`t`t</npcV2>`r`n" + $m.Groups[1].Value }, 1)
    }

    return $Text
}

function Repair-BridgeUiGuardConfig {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir,
        [switch]$RequireUiSpamGuardEnabled
    )

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    $settings = Get-SettingsState -StateDir $stateDir
    if ($RequireUiSpamGuardEnabled -and -not [bool]$settings.uiSpamGuard) {
        return [ordered]@{
            ok             = $true
            skipped        = $true
            changed        = $false
            uiSpamGuard    = [bool]$settings.uiSpamGuard
            configPath     = ''
            backupPath     = ''
            message        = 'UI guard выключен; repair не выполнялся.'
        }
    }

    $confPath = Join-Path $ResolvedGameDir 'conf.xml'
    if (-not (Test-Path -LiteralPath $confPath)) {
        return [ordered]@{
            ok             = $false
            skipped        = $true
            changed        = $false
            uiSpamGuard    = [bool]$settings.uiSpamGuard
            configPath     = $confPath
            backupPath     = ''
            message        = 'conf.xml не найден.'
        }
    }

    $raw = [System.IO.File]::ReadAllText($confPath, [System.Text.UTF8Encoding]::new($false))
    $updated = $raw
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'Debug' -Key 'showMonsterName' -Value '1'
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'personal' -Key 'hideOtherEntityName' -Value '1'
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'personal' -Key 'hideOtherEntityTitle' -Value '1'
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'personal' -Key 'hideOtherEntityBlood' -Value '1'
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'personal' -Key 'hideOtherSpriteName' -Value '0'
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'personal' -Key 'hideOtherSpriteBlood' -Value '0'
    $updated = Set-BridgeHideModeFlagValue -Text $updated -GroupIndex 2 -ValueIndex 0 -Value '1'
    $updated = Set-BridgeHideModeFlagValue -Text $updated -GroupIndex 2 -ValueIndex 1 -Value '1'
    $updated = Set-BridgeHideModeFlagValue -Text $updated -GroupIndex 2 -ValueIndex 2 -Value '1'
    $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent 'advance' -Key 'multithreadrender' -Value '1'
    $updated = Restore-BridgeUiGuardWidgetVisibility -Text $updated

    $changed = [bool]($updated -ne $raw)
    $backupPath = ''
    if ($changed) {
        $backupDir = Join-Path $stateDir 'ui-guard-backups'
        Ensure-Directory -Path $backupDir
        $backupPath = Join-Path $backupDir ('conf-before-ui-guard-repair-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.xml')
        [System.IO.File]::WriteAllText($backupPath, $raw, [System.Text.UTF8Encoding]::new($false))
        [System.IO.File]::WriteAllText($confPath, $updated, [System.Text.UTF8Encoding]::new($false))
        Write-BridgeUiGuardRepairState -ResolvedLauncherRoot $ResolvedLauncherRoot -ConfigPath $confPath
    }

    return [ordered]@{
        ok             = $true
        skipped        = $false
        changed        = $changed
        uiSpamGuard    = [bool]$settings.uiSpamGuard
        configPath     = $confPath
        backupPath     = $backupPath
        message        = $(if ($changed) { 'Настройки отображения сохранены. Создана резервная копия.' } else { 'Настройки отображения уже соответствуют выбранному варианту.' })
    }
}

function New-BridgeConfigEditorItemDefinition {
    param(
        [string]$Id,
        [string]$GroupId,
        [string]$Parent,
        [string]$Key,
        [string]$Label,
        [string]$Description,
        [string]$EnabledValue = '1',
        [string]$DisabledValue = '0',
        [string]$Tone = 'neutral'
    )

    return [ordered]@{
        id              = $Id
        groupId         = $GroupId
        parent          = $Parent
        key             = $Key
        path            = ($Parent + '/' + $Key)
        label           = $Label
        description     = $Description
        kind            = 'boolean'
        enabledValue    = $EnabledValue
        disabledValue   = $DisabledValue
        tone            = $Tone
        requiresRestart = $true
    }
}

function New-BridgeHideModeEditorItemDefinition {
    param(
        [string]$Id,
        [string]$GroupId,
        [int]$GroupIndex,
        [int]$ValueIndex,
        [string]$Label,
        [string]$Description,
        [string]$Tone = 'neutral'
    )

    return [ordered]@{
        id                 = $Id
        groupId            = $GroupId
        parent             = 'ui'
        key                = 'hideMode'
        path               = ('hideMode[' + $GroupIndex + '][' + $ValueIndex + ']')
        label              = $Label
        description        = $Description
        kind               = 'hideModeFlag'
        enabledValue       = '1'
        disabledValue      = '0'
        tone               = $Tone
        requiresRestart    = $true
        hideModeGroupIndex = $GroupIndex
        hideModeValueIndex = $ValueIndex
    }
}

function New-BridgeConfigEditorGroupDefinition {
    param(
        [string]$Id,
        [string]$Title,
        [string]$Summary,
        [object[]]$Items
    )

    return [ordered]@{
        id      = $Id
        title   = $Title
        summary = $Summary
        items   = @($Items)
    }
}

function Get-BridgeGameConfigEditorDefinitions {
    $groups = @(
        (New-BridgeConfigEditorGroupDefinition -Id 'names' -Title 'Имена, здоровье и подписи' -Summary 'Персонажи игры, монстры, игроки, духи и полоски здоровья.' -Items @(
            (New-BridgeConfigEditorItemDefinition -Id 'showMonsterName' -GroupId 'names' -Parent 'Debug' -Key 'showMonsterName' -Label 'Имена игровых персонажей и монстров' -Description 'Основной переключатель отображения имён игровых персонажей и монстров. Если включён, но имён нет, проверьте соседние параметры ниже.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeHideModeEditorItemDefinition -Id 'hideModeNpcMonsterHp' -GroupId 'names' -GroupIndex 2 -ValueIndex 0 -Label 'Здоровье игровых персонажей и монстров' -Description 'Игровая галочка из блока «Персонажи игры и монстры». Должна быть включена, чтобы над существами отображались полоски здоровья.'),
            (New-BridgeHideModeEditorItemDefinition -Id 'hideModeNpcMonsterName' -GroupId 'names' -GroupIndex 2 -ValueIndex 1 -Label 'Имена игровых персонажей и монстров в мире' -Description 'Игровая галочка имени из блока «Персонажи игры и монстры». Этот параметр может скрывать плавающие имена даже при включённых соседних параметрах.' -Tone 'warn'),
            (New-BridgeHideModeEditorItemDefinition -Id 'hideModeNpcMonsterTitle' -GroupId 'names' -GroupIndex 2 -ValueIndex 2 -Label 'Титулы игровых персонажей и монстров' -Description 'Игровая галочка титула из блока «Персонажи игры и монстры». Нужна для подписей и титулов над частью объектов.'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideOtherEntityName' -GroupId 'names' -Parent 'personal' -Key 'hideOtherEntityName' -Label 'Имена игровых персонажей и монстров в мире' -Description 'Соответствует игровой галочке «Имя персонажа» при выборе «Персонажи игры и монстры».' -EnabledValue '1' -DisabledValue '0' -Tone 'warn'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideOtherEntityTitle' -GroupId 'names' -Parent 'personal' -Key 'hideOtherEntityTitle' -Label 'Титулы игровых персонажей и монстров' -Description 'Соответствует игровой галочке «Титул» при выборе «Персонажи игры и монстры».' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideOtherEntityBlood' -GroupId 'names' -Parent 'personal' -Key 'hideOtherEntityBlood' -Label 'Здоровье игровых персонажей и монстров' -Description 'Соответствует игровой галочке «Шкала здоровья» при выборе «Персонажи игры и монстры».' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideOtherSpriteName' -GroupId 'names' -Parent 'personal' -Key 'hideOtherSpriteName' -Label 'Плавающие имена монстров и существ' -Description 'Дополнительный слой подписей над моделями. У части монстров имя появляется только если включён и этот параметр.' -EnabledValue '0' -DisabledValue '1' -Tone 'warn'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideOtherSpriteBlood' -GroupId 'names' -Parent 'personal' -Key 'hideOtherSpriteBlood' -Label 'Полоски здоровья монстров и существ' -Description 'Дополнительный слой полосок здоровья над моделями существ и части монстров.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hidePlayerName' -GroupId 'names' -Parent 'personal' -Key 'hidePlayerName' -Label 'Имя моего персонажа' -Description 'Отображение имени своего персонажа.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hidePlayerTitle' -GroupId 'names' -Parent 'personal' -Key 'hidePlayerTitle' -Label 'Титул моего персонажа' -Description 'Отображение титула своего персонажа.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hidePlayerBlood' -GroupId 'names' -Parent 'personal' -Key 'hidePlayerBlood' -Label 'Здоровье моего персонажа' -Description 'Отображение здоровья своего персонажа над моделью.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hidePlayerGuild' -GroupId 'names' -Parent 'personal' -Key 'hidePlayerGuild' -Label 'Гильдия моего персонажа' -Description 'Отображение гильдии своего персонажа.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideAvatarName' -GroupId 'names' -Parent 'personal' -Key 'hideAvatarName' -Label 'Имена других игроков' -Description 'Отображение имён других игроков.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideAvatarTitle' -GroupId 'names' -Parent 'personal' -Key 'hideAvatarTitle' -Label 'Титулы других игроков' -Description 'Отображение титулов других игроков.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideAvatarBlood' -GroupId 'names' -Parent 'personal' -Key 'hideAvatarBlood' -Label 'Здоровье других игроков' -Description 'Отображение здоровья других игроков над моделью.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'hideAvatarGuild' -GroupId 'names' -Parent 'personal' -Key 'hideAvatarGuild' -Label 'Гильдии других игроков' -Description 'Отображение гильдий других игроков.' -EnabledValue '0' -DisabledValue '1'),
            (New-BridgeConfigEditorItemDefinition -Id 'showBloodLabel' -GroupId 'names' -Parent 'screen' -Key 'showBloodLabel' -Label 'Числа здоровья на полосках' -Description 'Показывает числовые значения здоровья рядом с полосками здоровья.' -EnabledValue '1' -DisabledValue '0')
        )),
        (New-BridgeConfigEditorGroupDefinition -Id 'ui-noise' -Title 'Сообщения и подсказки' -Summary 'Блоки интерфейса, которые чаще всего создают лишнюю отрисовку.' -Items @(
            (New-BridgeConfigEditorItemDefinition -Id 'disableSkillHover' -GroupId 'ui-noise' -Parent 'screen' -Key 'disableSkillHover' -Label 'Отключить подсказки навыков' -Description 'Отключает пояснения при наведении на умения.' -EnabledValue '1' -DisabledValue '0' -Tone 'warn'),
            (New-BridgeConfigEditorItemDefinition -Id 'topmessageHidden' -GroupId 'ui-noise' -Parent 'topmessage' -Key 'hidden' -Label 'Скрыть верхние сообщения' -Description 'Скрывает отдельную область верхних сообщений.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'playtipsHidden' -GroupId 'ui-noise' -Parent 'playtips' -Key 'hidden' -Label 'Скрыть игровые подсказки' -Description 'Скрывает всплывающие игровые подсказки.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'systemtipsHidden' -GroupId 'ui-noise' -Parent 'systemtips' -Key 'hidden' -Label 'Скрыть системные подсказки' -Description 'Скрывает системные всплывающие подсказки.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'pushmsgHidden' -GroupId 'ui-noise' -Parent 'pushmsg' -Key 'hidden' -Label 'Скрыть всплывающие уведомления' -Description 'Скрывает часть всплывающих уведомлений интерфейса.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'systempushHidden' -GroupId 'ui-noise' -Parent 'systempush' -Key 'hidden' -Label 'Скрыть системные уведомления' -Description 'Скрывает системный блок всплывающих уведомлений.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'singletipHidden' -GroupId 'ui-noise' -Parent 'singletip' -Key 'hidden' -Label 'Скрыть одиночные подсказки' -Description 'Скрывает одиночные всплывающие подсказки.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'pushMessageV2Hidden' -GroupId 'ui-noise' -Parent 'pushMessageV2' -Key 'hidden' -Label 'Скрыть новые уведомления' -Description 'Скрывает новый блок всплывающих уведомлений, если он есть в текущем интерфейсе.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'warMessageHidden' -GroupId 'ui-noise' -Parent 'warMessage' -Key 'hidden' -Label 'Скрыть боевые сообщения' -Description 'Скрывает отдельный блок боевых уведомлений, если он есть в текущем интерфейсе.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'continuoushitHidden' -GroupId 'ui-noise' -Parent 'continuoushit' -Key 'hidden' -Label 'Скрыть счётчик серии ударов' -Description 'Скрывает блок счётчика серии ударов.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'buffmoticeHidden' -GroupId 'ui-noise' -Parent 'buffmotice' -Key 'hidden' -Label 'Скрыть уведомления усилений' -Description 'Скрывает отдельные уведомления о усилениях.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'debuffmoticeHidden' -GroupId 'ui-noise' -Parent 'debuffmotice' -Key 'hidden' -Label 'Скрыть уведомления ослаблений' -Description 'Скрывает отдельные уведомления о ослаблениях.' -EnabledValue '1' -DisabledValue '0')
        )),
        (New-BridgeConfigEditorGroupDefinition -Id 'render' -Title 'Графика и эффекты' -Summary 'Параметры отображения, доступные в игре.' -Items @(
            (New-BridgeConfigEditorItemDefinition -Id 'multithreadrender' -GroupId 'render' -Parent 'advance' -Key 'multithreadrender' -Label 'Многопоточная отрисовка' -Description 'Включает многопоточную отрисовку, если клиент игры её поддерживает.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'enableMemorySetting' -GroupId 'render' -Parent 'screen' -Key 'enableMemorySetting' -Label 'Оптимизация памяти' -Description 'Соответствует игровой галочке оптимизации памяти.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'motionBlur' -GroupId 'render' -Parent 'screen' -Key 'motionBlur' -Label 'Размытие движения' -Description 'Соответствует игровой галочке размытия движения.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'screenEffect' -GroupId 'render' -Parent 'screen' -Key 'screenEffect' -Label 'Спецэффекты экрана' -Description 'Включает/выключает часть полноэкранных эффектов.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'animateCamera' -GroupId 'render' -Parent 'screen' -Key 'animateCamera' -Label 'Анимация камеры' -Description 'Соответствует игровой галочке анимации камеры.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'cameraShake' -GroupId 'render' -Parent 'screen' -Key 'cameraShake' -Label 'Тряска камеры' -Description 'Соответствует игровой галочке тряски камеры.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'blockFirework' -GroupId 'render' -Parent 'personal' -Key 'blockFirework' -Label 'Скрыть фейерверк' -Description 'Включённая галочка скрывает фейерверки.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'showEquipEnhanceEffect' -GroupId 'render' -Parent 'screen' -Key 'showEquipEnhanceEffect' -Label 'Свечение экипировки' -Description 'Показывает эффекты усиления экипировки.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'enablePhysics' -GroupId 'render' -Parent 'screen' -Key 'enablePhysics' -Label 'Физические эффекты' -Description 'Соответствует игровой галочке физических эффектов.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'blockSkillAppearance' -GroupId 'render' -Parent 'screen' -Key 'blockSkillAppearance' -Label 'Скрыть облики навыков' -Description 'Включённая галочка блокирует/скрывает часть обликов навыков.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'enableRandWing' -GroupId 'render' -Parent 'screen' -Key 'enableRandWing' -Label 'Случайные крылья и скакуны' -Description 'Соответствует игровой галочке случайных скакунов и крыльев.' -EnabledValue '1' -DisabledValue '0'),
            (New-BridgeConfigEditorItemDefinition -Id 'ckBoxbuffListener' -GroupId 'render' -Parent 'personal' -Key 'ckBoxbuffListener' -Label 'Отслеживание усилений' -Description 'Дополнительное отслеживание усилений; лучше менять только для теста нагрузки интерфейса.' -EnabledValue '1' -DisabledValue '0' -Tone 'warn')
        ))
    )

    return @($groups)
}

function Get-BridgeGameConfigEditorDefinitionMap {
    $map = @{}
    foreach ($group in (Get-BridgeGameConfigEditorDefinitions)) {
        foreach ($item in @($group.items)) {
            $map[[string]$item.id] = $item
        }
    }

    return $map
}

function New-BridgeGameConfigEditorItemState {
    param(
        [string]$Text,
        [object]$Definition
    )

    if ([string]$Definition.kind -eq 'hideModeFlag') {
        $value = Get-BridgeHideModeFlagValue -Text $Text -GroupIndex ([int]$Definition.hideModeGroupIndex) -ValueIndex ([int]$Definition.hideModeValueIndex)
    } else {
        $value = Get-BridgeXmlTagValue -Text $Text -Parent ([string]$Definition.parent) -Key ([string]$Definition.key)
    }
    $available = -not [string]::IsNullOrWhiteSpace($value)
    $enabled = [bool]($available -and ([string]$value -eq [string]$Definition.enabledValue))
    $item = [ordered]@{}
    foreach ($key in $Definition.Keys) {
        $item[$key] = $Definition[$key]
    }
    $item['value'] = [string]$value
    $item['enabled'] = [bool]$enabled
    $item['available'] = [bool]$available
    return $item
}

function ConvertFrom-BridgeConfigEditorPayload {
    param([string]$PayloadB64)

    if ([string]::IsNullOrWhiteSpace($PayloadB64)) {
        throw 'Config editor payload is required.'
    }

    try {
        $bytes = [Convert]::FromBase64String($PayloadB64)
        $json = [System.Text.Encoding]::UTF8.GetString($bytes)
        return ($json | ConvertFrom-Json)
    } catch {
        throw ('Invalid config editor payload: ' + $_.Exception.Message)
    }
}

function ConvertTo-BridgeConfigEditorBoolean {
    param(
        [AllowNull()][object]$Value,
        [string]$Id
    )

    if ($Value -is [bool]) {
        return [bool]$Value
    }
    if ($Value -is [int] -or $Value -is [long]) {
        return [bool]([int]$Value -ne 0)
    }

    return (ConvertTo-BridgeBoolean -Value ([string]$Value) -Default:$false)
}

function Get-BridgeGameConfigEditor {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir
    )

    $confPath = Join-Path $ResolvedGameDir 'conf.xml'
    if (-not (Test-Path -LiteralPath $confPath)) {
        return [ordered]@{
            ok              = $false
            supported       = $false
            experimentalOnly = $true
            configPath      = $confPath
            groups          = @()
            gameRunning     = $false
            restartRequired = $false
            message         = 'conf.xml не найден.'
        }
    }

    $text = [System.IO.File]::ReadAllText($confPath, [System.Text.UTF8Encoding]::new($false))
    $groups = foreach ($group in (Get-BridgeGameConfigEditorDefinitions)) {
        $items = foreach ($itemDefinition in @($group.items)) {
            New-BridgeGameConfigEditorItemState -Text $text -Definition $itemDefinition
        }
        [ordered]@{
            id      = [string]$group.id
            title   = [string]$group.title
            summary = [string]$group.summary
            items   = @($items)
        }
    }
    $gameRunning = [bool](@(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir).Count -gt 0)

    return [ordered]@{
        ok              = $true
        supported       = $true
        experimentalOnly = $true
        configPath      = $confPath
        groups          = @($groups)
        gameRunning     = [bool]$gameRunning
        restartRequired = $false
        changed         = $false
        changedItems    = @()
        backupPath      = ''
        message         = 'conf.xml загружен.'
    }
}

function Save-BridgeGameConfigEditor {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir,
        [string]$PayloadB64
    )

    $confPath = Join-Path $ResolvedGameDir 'conf.xml'
    if (-not (Test-Path -LiteralPath $confPath)) {
        return [ordered]@{
            ok              = $false
            supported       = $false
            experimentalOnly = $true
            configPath      = $confPath
            changed         = $false
            backupPath      = ''
            message         = 'conf.xml не найден.'
        }
    }

    $payload = ConvertFrom-BridgeConfigEditorPayload -PayloadB64 $PayloadB64
    $values = Get-BridgeObjectPropertyValue -Object $payload -Name 'values' -Default $null
    if ($null -eq $values) {
        throw 'Config editor payload must contain values.'
    }

    $definitions = Get-BridgeGameConfigEditorDefinitionMap
    $raw = [System.IO.File]::ReadAllText($confPath, [System.Text.UTF8Encoding]::new($false))
    $updated = $raw
    $changedItems = New-Object System.Collections.Generic.List[string]

    foreach ($id in @($definitions.Keys)) {
        if (-not (Test-BridgeMapHasKey -Map $values -Key $id)) {
            continue
        }

        $definition = $definitions[$id]
        $incoming = Get-BridgeObjectPropertyValue -Object $values -Name $id -Default $null
        $enabled = ConvertTo-BridgeConfigEditorBoolean -Value $incoming -Id $id
        $targetValue = $(if ($enabled) { [string]$definition.enabledValue } else { [string]$definition.disabledValue })
        $before = $updated
        if ([string]$definition.kind -eq 'hideModeFlag') {
            $updated = Set-BridgeHideModeFlagValue -Text $updated -GroupIndex ([int]$definition.hideModeGroupIndex) -ValueIndex ([int]$definition.hideModeValueIndex) -Value $targetValue
        } else {
            $updated = Set-BridgeNestedXmlScalar -Text $updated -Parent ([string]$definition.parent) -Key ([string]$definition.key) -Value $targetValue
        }
        if ($updated -ne $before) {
            [void]$changedItems.Add($id)
        }
    }

    $changed = [bool]($updated -ne $raw)
    $backupPath = ''
    if ($changed) {
        $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
        $backupDir = Join-Path $stateDir 'config-editor-backups'
        Ensure-Directory -Path $backupDir
        $backupPath = Join-Path $backupDir ('conf-before-config-editor-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.xml')
        [System.IO.File]::WriteAllText($backupPath, $raw, [System.Text.UTF8Encoding]::new($false))
        [System.IO.File]::WriteAllText($confPath, $updated, [System.Text.UTF8Encoding]::new($false))
    }

    $result = Get-BridgeGameConfigEditor -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $ResolvedGameDir
    $gameRunning = [bool]$result.gameRunning
    $result['changed'] = [bool]$changed
    $result['changedItems'] = @($changedItems.ToArray())
    $result['backupPath'] = [string]$backupPath
    $result['restartRequired'] = [bool]($changed -and $gameRunning)
    $result['message'] = $(if (-not $changed) {
            'Изменений нет.'
        } elseif ($gameRunning) {
            'Конфиг сохранён. Полностью перезапусти игру, чтобы изменения применились.'
        } else {
            'Конфиг сохранён.'
        })
    return $result
}

function Get-BridgeUiGuardStatus {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir,
        [bool]$SettingsEnabled,
        [bool]$GameRunning
    )

    $confPath = Join-Path $ResolvedGameDir 'conf.xml'
    if (-not (Test-Path -LiteralPath $confPath)) {
        return [ordered]@{
            supported          = $false
            settingsEnabled    = [bool]$SettingsEnabled
            configPath         = $confPath
            currentApplied       = $false
            baseApplied          = $false
            noisyWidgetsHidden   = $false
            widgetVisibilityRestored = $false
            restartRequired      = $false
            activeSessionStale   = $false
            configLastWriteUtc   = ''
            gameStartedUtc       = ''
            hiddenWidgetCount    = 0
            matchedWidgetCount   = 0
            requiredWidgetCount  = 0
            showMonsterName      = ''
            hideOtherEntityName  = ''
            hideOtherEntityTitle = ''
            hideOtherEntityBlood = ''
            hideOtherSpriteName  = ''
            hideOtherSpriteBlood = ''
            hideMode             = ''
            hideModeNpcHp        = ''
            hideModeNpcName      = ''
            hideModeNpcTitle     = ''
            disableSkillHover    = ''
            quickRead            = ''
            message              = 'conf.xml не найден.'
            widgets              = @()
        }
    }

    try {
        $text = [System.IO.File]::ReadAllText($confPath, [System.Text.UTF8Encoding]::new($false))
    } catch {
        return [ordered]@{
            supported           = $false
            settingsEnabled     = [bool]$SettingsEnabled
            configPath          = $confPath
            currentApplied       = $false
            baseApplied          = $false
            noisyWidgetsHidden   = $false
            restartRequired      = $false
            activeSessionStale   = $false
            configLastWriteUtc   = ''
            gameStartedUtc       = ''
            hiddenWidgetCount    = 0
            requiredWidgetCount  = 0
            showMonsterName      = ''
            hideOtherEntityName  = ''
            hideOtherEntityTitle = ''
            hideOtherEntityBlood = ''
            hideOtherSpriteName  = ''
            hideOtherSpriteBlood = ''
            hideMode             = ''
            hideModeNpcHp        = ''
            hideModeNpcName      = ''
            hideModeNpcTitle     = ''
            disableSkillHover    = ''
            quickRead            = ''
            message              = 'conf.xml не удалось прочитать.'
            widgets              = @()
        }
    }
    $showMonsterName = Get-BridgeXmlTagValue -Text $text -Parent 'Debug' -Key 'showMonsterName'
    $hideOtherEntityName = Get-BridgeXmlTagValue -Text $text -Parent 'personal' -Key 'hideOtherEntityName'
    $hideOtherEntityTitle = Get-BridgeXmlTagValue -Text $text -Parent 'personal' -Key 'hideOtherEntityTitle'
    $hideOtherEntityBlood = Get-BridgeXmlTagValue -Text $text -Parent 'personal' -Key 'hideOtherEntityBlood'
    $hideOtherSpriteName = Get-BridgeXmlTagValue -Text $text -Parent 'personal' -Key 'hideOtherSpriteName'
    $hideOtherSpriteBlood = Get-BridgeXmlTagValue -Text $text -Parent 'personal' -Key 'hideOtherSpriteBlood'
    $hideMode = ''
    $hideModeMatch = [regex]::Match($text, '(?s)<hideMode>\s*([^<]*?)\s*</hideMode>', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($hideModeMatch.Success) {
        $hideMode = ([string]$hideModeMatch.Groups[1].Value).Trim()
    }
    $hideModeNpcHp = Get-BridgeHideModeFlagValue -Text $text -GroupIndex 2 -ValueIndex 0
    $hideModeNpcName = Get-BridgeHideModeFlagValue -Text $text -GroupIndex 2 -ValueIndex 1
    $hideModeNpcTitle = Get-BridgeHideModeFlagValue -Text $text -GroupIndex 2 -ValueIndex 2
    $disableSkillHover = Get-BridgeXmlTagValue -Text $text -Parent 'screen' -Key 'disableSkillHover'
    $quickRead = Get-BridgeXmlTagValue -Text $text -Parent 'npcV2' -Key 'quickRead'
    $baseApplied = [bool]($showMonsterName -eq '1' -and $hideOtherEntityName -eq '1' -and $hideOtherEntityTitle -eq '1' -and $hideOtherEntityBlood -eq '1' -and $hideOtherSpriteName -eq '0' -and $hideOtherSpriteBlood -eq '0' -and $hideModeNpcHp -eq '1' -and $hideModeNpcName -eq '1' -and $hideModeNpcTitle -eq '1')
    $activeSessionStale = $false
    $configLastWriteUtc = $null
    $launcherConfigWriteUtc = $null
    $gameStartedUtc = $null
    if ($GameRunning) {
        try {
            $configLastWriteUtc = (Get-Item -LiteralPath $confPath -ErrorAction Stop).LastWriteTimeUtc
            $repairState = if (-not [string]::IsNullOrWhiteSpace($ResolvedLauncherRoot)) { Read-BridgeUiGuardRepairState -ResolvedLauncherRoot $ResolvedLauncherRoot } else { $null }
            $repairStateWriteUtcText = if ($repairState) { [string](Get-BridgeObjectPropertyValue -Object $repairState -Name 'launcherConfigWriteUtc' -Default '') } else { '' }
            if ($repairState -and -not [string]::IsNullOrWhiteSpace($repairStateWriteUtcText)) {
                $stateConfigPath = [string](Get-BridgeObjectPropertyValue -Object $repairState -Name 'configPath' -Default '')
                $sameConfig = [string]::IsNullOrWhiteSpace($stateConfigPath)
                if (-not $sameConfig) {
                    try {
                        $sameConfig = [string]::Equals(
                            [System.IO.Path]::GetFullPath($stateConfigPath).TrimEnd('\'),
                            [System.IO.Path]::GetFullPath($confPath).TrimEnd('\'),
                            [System.StringComparison]::OrdinalIgnoreCase
                        )
                    } catch {
                        $sameConfig = [string]::Equals($stateConfigPath, $confPath, [System.StringComparison]::OrdinalIgnoreCase)
                    }
                }
                $parsedLauncherWriteUtc = [datetime]::MinValue
                if ($sameConfig -and [datetime]::TryParse($repairStateWriteUtcText, [ref]$parsedLauncherWriteUtc)) {
                    $launcherConfigWriteUtc = $parsedLauncherWriteUtc.ToUniversalTime()
                }
            }
            $gameProcesses = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir)
            $startedValues = @(
                $gameProcesses | ForEach-Object {
                    try {
                        $_.StartTime.ToUniversalTime()
                    } catch {
                        $null
                    }
                } | Where-Object { $null -ne $_ }
            )
            if ($startedValues.Count -gt 0) {
                $gameStartedUtc = @($startedValues | Sort-Object | Select-Object -First 1)[0]
                $activeSessionStale = [bool]($launcherConfigWriteUtc -and $launcherConfigWriteUtc -gt $gameStartedUtc.AddSeconds(5))
            }
        } catch {
            $activeSessionStale = $false
        }
    }

    $widgetDefaults = Get-BridgeUiGuardWidgetVisibilityDefaults
    $requiredWidgets = @($widgetDefaults.Keys)
    $widgets = foreach ($widgetName in $requiredWidgets) {
        $hidden = Get-BridgeXmlTagValue -Text $text -Parent $widgetName -Key 'hidden'
        $expected = [string]$widgetDefaults[$widgetName]
        $available = -not [string]::IsNullOrWhiteSpace($hidden)
        [ordered]@{
            name           = $widgetName
            hidden         = $hidden
            expectedHidden = $expected
            available      = [bool]$available
            ok             = [bool]((-not $available) -or $hidden -eq $expected)
        }
    }
    $hiddenWidgetCount = @($widgets | Where-Object { [string]$_['hidden'] -eq '1' }).Count
    $matchedWidgetCount = @($widgets | Where-Object { [bool]$_['ok'] }).Count
    $widgetVisibilityRestored = [bool]($matchedWidgetCount -eq $requiredWidgets.Count)
    $noisyWidgetsHidden = [bool]($hiddenWidgetCount -eq $requiredWidgets.Count)
    $fileApplied = if ($SettingsEnabled) {
        [bool]($baseApplied -and $widgetVisibilityRestored)
    } else {
        [bool]$baseApplied
    }
    $currentApplied = [bool]($fileApplied -and -not $activeSessionStale)
    $restartRequired = [bool]($GameRunning -and ((-not $currentApplied) -or $activeSessionStale))
    $message = if ($SettingsEnabled -and -not $baseApplied) {
        'UI guard включён, но conf.xml сброшен игрой. Конфиг будет восстановлен после выхода из игры или при следующем запуске.'
    } elseif ($SettingsEnabled -and -not $widgetVisibilityRestored) {
        'Часть игровых UI-элементов всё ещё скрыта. Лаунчер вернёт безопасную видимость после выхода из игры или при следующем запуске.'
    } elseif ($activeSessionStale -and $SettingsEnabled) {
        'UI guard записан в конфиг и применится после полного перезапуска игры.'
    } elseif ($activeSessionStale) {
        'Базовые UI-настройки записаны в конфиг и применятся после полного перезапуска игры.'
    } elseif ($currentApplied -and $SettingsEnabled) {
        'Безопасные UI-настройки применены.'
    } elseif ($currentApplied) {
        'Базовые безопасные UI-настройки применены.'
    } elseif ($SettingsEnabled -and $GameRunning) {
        'UI guard включён, но текущий игровой конфиг ещё старый. Перезапусти игру через лаунчер.'
    } elseif ($SettingsEnabled) {
        'UI guard включён и применится при следующем запуске игры.'
    } else {
        'Базовые UI-настройки применятся при следующем запуске игры.'
    }

    return [ordered]@{
        supported          = $true
        settingsEnabled    = [bool]$SettingsEnabled
        configPath         = $confPath
        currentApplied       = [bool]$currentApplied
        baseApplied          = [bool]$baseApplied
        noisyWidgetsHidden   = [bool]$noisyWidgetsHidden
        widgetVisibilityRestored = [bool]$widgetVisibilityRestored
        restartRequired      = [bool]$restartRequired
        activeSessionStale   = [bool]$activeSessionStale
        configLastWriteUtc   = $(if ($configLastWriteUtc) { $configLastWriteUtc.ToString('o') } else { '' })
        launcherConfigWriteUtc = $(if ($launcherConfigWriteUtc) { $launcherConfigWriteUtc.ToString('o') } else { '' })
        gameStartedUtc       = $(if ($gameStartedUtc) { $gameStartedUtc.ToString('o') } else { '' })
        hiddenWidgetCount    = [int]$hiddenWidgetCount
        matchedWidgetCount   = [int]$matchedWidgetCount
        requiredWidgetCount  = [int]$requiredWidgets.Count
        showMonsterName      = $showMonsterName
        hideOtherEntityName  = $hideOtherEntityName
        hideOtherEntityTitle = $hideOtherEntityTitle
        hideOtherEntityBlood = $hideOtherEntityBlood
        hideOtherSpriteName  = $hideOtherSpriteName
        hideOtherSpriteBlood = $hideOtherSpriteBlood
        hideMode             = $hideMode
        hideModeNpcHp        = $hideModeNpcHp
        hideModeNpcName      = $hideModeNpcName
        hideModeNpcTitle     = $hideModeNpcTitle
        disableSkillHover    = $disableSkillHover
        quickRead            = $quickRead
        message              = $message
        widgets              = @($widgets)
    }
}

function Save-SettingsState {
    param(
        [string]$StateDir,
        [string]$UploadDir,
        [bool]$IncludeLarge,
        [bool]$NetworkStaged,
        [bool]$NetworkAutoApply = $true,
        [AllowNull()][object]$ExperimentalFullLog = $null,
        [AllowNull()][object]$DirectGameLaunch = $null,
        [AllowNull()][object]$SkipCharacterSelection = $null,
        [AllowNull()][object]$ServerPreflight = $null,
        [AllowNull()][object]$DisableIntroMovies = $null,
        [AllowNull()][object]$TrafficBudgetShield = $null,
        [AllowNull()][object]$TrafficBudgetShieldLimitParsec = $null,
        [AllowNull()][string]$DxvkMode = $null,
        [AllowNull()][object]$AutoCheckUpdatesOnStartup = $null,
        [AllowNull()][object]$CloseVkPlayAfterGameExit = $null,
        [AllowNull()][object]$UiSpamGuard = $null,
        [AllowNull()][object]$ClientMitigation = $null
    )

    $settingsPath = Join-Path $StateDir 'launcher-settings.ini'
    $existing = Read-KeyValueFile -Path $settingsPath
    $existing['uploadDir'] = $(if ($UploadDir) { $UploadDir } else { Join-Path $StateDir 'developer-outbox' })
    $existing['includeLarge'] = $(if ($IncludeLarge) { '1' } else { '0' })
    $existing['networkStaged'] = $(if ($NetworkStaged) { '1' } else { '0' })
    $existing['networkAutoApply'] = $(if ($NetworkAutoApply) { '1' } else { '0' })
    if ($PSBoundParameters.ContainsKey('ExperimentalFullLog')) {
        $existing['experimentalFullLog'] = $(if ([bool]$ExperimentalFullLog) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('experimentalFullLog')) {
        $existing['experimentalFullLog'] = '1'
    }
    if ($PSBoundParameters.ContainsKey('DirectGameLaunch')) {
        $existing['directGameLaunch'] = $(if ([bool]$DirectGameLaunch) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('directGameLaunch')) {
        $existing['directGameLaunch'] = '1'
    }
    if ($PSBoundParameters.ContainsKey('SkipCharacterSelection')) {
        $existing['skipCharacterSelection'] = $(if ([bool]$SkipCharacterSelection) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('skipCharacterSelection')) {
        $existing['skipCharacterSelection'] = '0'
    }
    if ($PSBoundParameters.ContainsKey('DxvkMode') -and -not [string]::IsNullOrWhiteSpace($DxvkMode)) {
        $normalizedDxvkMode = switch (([string]$DxvkMode).Trim().ToLowerInvariant()) {
            { $_ -in @('force-native', 'forcenative', 'native', 'off', 'disabled', '0') } { 'force-native'; break }
            { $_ -in @('force-dxvk', 'forcedxvk', 'dxvk', 'on', 'enabled', '1') } { 'force-dxvk'; break }
            default { 'auto' }
        }
        $existing['dxvkMode'] = $normalizedDxvkMode
    } elseif (-not $existing.ContainsKey('dxvkMode')) {
        $existing['dxvkMode'] = 'auto'
    }
    if ($PSBoundParameters.ContainsKey('AutoCheckUpdatesOnStartup')) {
        $existing['autoCheckUpdatesOnStartup'] = $(if ([bool]$AutoCheckUpdatesOnStartup) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('autoCheckUpdatesOnStartup')) {
        $existing['autoCheckUpdatesOnStartup'] = '1'
    }
    if ($PSBoundParameters.ContainsKey('CloseVkPlayAfterGameExit')) {
        $existing['closeVkPlayAfterGameExit'] = $(if ([bool]$CloseVkPlayAfterGameExit) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('closeVkPlayAfterGameExit')) {
        $existing['closeVkPlayAfterGameExit'] = '1'
    }
    if ($PSBoundParameters.ContainsKey('UiSpamGuard')) {
        $existing['uiSpamGuard'] = $(if ([bool]$UiSpamGuard) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('uiSpamGuard')) {
        $existing['uiSpamGuard'] = '0'
    }
    if ($PSBoundParameters.ContainsKey('ClientMitigation')) {
        $existing['clientMitigation'] = $(if ([bool]$ClientMitigation) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('clientMitigation')) {
        $existing['clientMitigation'] = '0'
    }
    if ($PSBoundParameters.ContainsKey('ServerPreflight')) {
        $existing['serverPreflight'] = $(if ([bool]$ServerPreflight) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('serverPreflight')) {
        $existing['serverPreflight'] = '1'
    }
    if ($PSBoundParameters.ContainsKey('DisableIntroMovies')) {
        $existing['disableIntroMovies'] = $(if ([bool]$DisableIntroMovies) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('disableIntroMovies')) {
        $existing['disableIntroMovies'] = '0'
    }
    foreach ($obsoleteKey in @('cursorAssistEnabled', 'cursorAssistTriggerSpeed', 'cursorAssistVisibleMs', 'cursorAssistRadius')) {
        if ($existing.ContainsKey($obsoleteKey)) {
            $existing.Remove($obsoleteKey)
        }
    }
    if ($PSBoundParameters.ContainsKey('TrafficBudgetShield')) {
        $existing['trafficBudgetShield'] = $(if ([bool]$TrafficBudgetShield) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('trafficBudgetShield')) {
        $existing['trafficBudgetShield'] = '1'
    }
    if ($PSBoundParameters.ContainsKey('TrafficBudgetShieldLimitParsec')) {
        $existing['trafficBudgetShieldLimitParsec'] = $(if ([bool]$TrafficBudgetShieldLimitParsec) { '1' } else { '0' })
    } elseif (-not $existing.ContainsKey('trafficBudgetShieldLimitParsec')) {
        $existing['trafficBudgetShieldLimitParsec'] = '0'
    }
    Write-KeyValueFile -Path $settingsPath -Map $existing
}

function Get-XmlAttributeValue {
    param(
        [AllowNull()][object]$Node,
        [string]$Name
    )

    try {
        if ($null -ne $Node -and $null -ne $Node.Attributes) {
            $attribute = $Node.Attributes.GetNamedItem($Name)
            if ($null -ne $attribute) {
                return [string]$attribute.Value
            }
        }
    } catch {
    }
    return ''
}

function Get-RevelationLoginPreflightTargets {
    param(
        [string]$ResolvedGameDir
    )

    $targets = New-Object System.Collections.ArrayList
    $seen = @{}
    $diagPath = Join-Path $ResolvedGameDir 'diag.xml'

    if (Test-Path -LiteralPath $diagPath) {
        try {
            [xml]$diag = Get-Content -LiteralPath $diagPath -Raw -Encoding UTF8
            $nodes = @()
            if ($diag.Diag.PortCheck) { $nodes += @($diag.Diag.PortCheck) }
            if ($diag.Diag.Ping) { $nodes += @($diag.Diag.Ping) }

            foreach ($node in $nodes) {
                $targetHost = (Get-XmlAttributeValue -Node $node -Name 'ServerName').Trim()
                if (-not $targetHost) { continue }
                $serverType = Get-XmlAttributeValue -Node $node -Name 'ServerType'
                if ($serverType -and $serverType -ne 'Shard') { continue }
                $portText = Get-XmlAttributeValue -Node $node -Name 'Port'
                $port = 8766
                if ($portText -match '^\d+$') {
                    $port = [int]$portText
                }
                $key = ($targetHost.ToLowerInvariant() + ':' + $port)
                if ($seen.ContainsKey($key)) { continue }
                $seen[$key] = $true
                [void]$targets.Add([ordered]@{ host = $targetHost; port = $port; source = 'diag.xml' })
            }
        } catch {
        }
    }

    foreach ($fallbackHost in @(
            'gtlogin.live.ro.gmru.net',
            'login.live04.ro.gmru.net',
            'login.live10.ro.gmru.net',
            'login.live13.ro.gmru.net',
            'login.live08.ro.gmru.net',
            'login.live09.ro.gmru.net'
        )) {
        $key = ($fallbackHost.ToLowerInvariant() + ':8766')
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true
        [void]$targets.Add([ordered]@{ host = $fallbackHost; port = 8766; source = 'fallback' })
    }

    return @($targets)
}

function Get-RevelationShardPreflightSnapshot {
    param([string]$ResolvedGameRoot)

    $shardsPath = Join-Path $ResolvedGameRoot '-gup-\shards.xml'
    $items = @()
    $messages = @()
    $maintenanceHint = $false
    $blockedHint = $false
    $availableHint = $false
    $errorMessage = ''

    if (-not (Test-Path -LiteralPath $shardsPath)) {
        return [ordered]@{
            path            = $shardsPath
            source          = 'local_cache'
            lastWriteAtUtc  = $null
            exists          = $false
            parsed          = $false
            maintenanceHint = $false
            blockedHint     = $false
            availableHint   = $false
            messages        = @()
            shards          = @()
            error           = ''
        }
    }

    try {
        [xml]$xml = Get-Content -LiteralPath $shardsPath -Raw -Encoding UTF8
        $nodes = @()
        if ($xml.Shards.Shard) {
            $nodes = @($xml.Shards.Shard)
        }
        foreach ($node in $nodes) {
            $name = Get-XmlAttributeValue -Node $node -Name 'Name'
            $allow = Get-XmlAttributeValue -Node $node -Name 'Allow'
            $hidden = Get-XmlAttributeValue -Node $node -Name 'Hidden'
            $msg = (Get-XmlAttributeValue -Node $node -Name 'Msg').Trim()
            if ($msg) {
                $messages += $msg
                if ($msg -match 'профилакти|техническ|maintenance|обслужив|недоступ|закрыт|timeout|try later') {
                    $maintenanceHint = $true
                }
            }
            if ($allow -eq '0' -or $hidden -eq '1') {
                $blockedHint = $true
            }
            if ($allow -eq '1' -and $hidden -ne '1') {
                $availableHint = $true
            }
            $items += [ordered]@{
                id     = Get-XmlAttributeValue -Node $node -Name 'Id'
                name   = $name
                allow  = $allow
                hidden = $hidden
                msg    = $msg
            }
        }
    } catch {
        $errorMessage = $_.Exception.Message
    }

    return [ordered]@{
        path            = $shardsPath
        source          = 'local_cache'
        lastWriteAtUtc  = (Get-Item -LiteralPath $shardsPath).LastWriteTimeUtc.ToString('o')
        exists          = $true
        parsed          = [bool](-not $errorMessage)
        maintenanceHint = [bool]$maintenanceHint
        blockedHint     = [bool]$blockedHint
        availableHint   = [bool]$availableHint
        messages        = @($messages | Select-Object -Unique)
        shards          = @($items)
        error           = $errorMessage
    }
}

function Test-RevelationTcpEndpointFast {
    param(
        [string]$HostName,
        [int]$Port = 8766,
        [int]$TimeoutMs = 1200
    )

    $client = [System.Net.Sockets.TcpClient]::new()
    $asyncResult = $null
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $asyncResult = $client.BeginConnect($HostName, $Port, $null, $null)
        $connected = $asyncResult.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
        $stopwatch.Stop()
        if (-not $connected) {
            return [ordered]@{
                host      = $HostName
                port      = $Port
                open      = $false
                elapsedMs = [int]$stopwatch.ElapsedMilliseconds
                reason    = 'timeout'
            }
        }
        $client.EndConnect($asyncResult)
        return [ordered]@{
            host      = $HostName
            port      = $Port
            open      = $true
            elapsedMs = [int]$stopwatch.ElapsedMilliseconds
            reason    = 'open'
        }
    } catch {
        $stopwatch.Stop()
        return [ordered]@{
            host      = $HostName
            port      = $Port
            open      = $false
            elapsedMs = [int]$stopwatch.ElapsedMilliseconds
            reason    = $_.Exception.Message
        }
    } finally {
        try {
            if ($null -ne $asyncResult -and $null -ne $asyncResult.AsyncWaitHandle) {
                $asyncResult.AsyncWaitHandle.Close()
            }
        } catch {
        }
        $client.Close()
    }
}

function Test-RevelationTcpEndpointsParallel {
    param(
        [object[]]$Targets,
        [int]$TimeoutMs = 1200
    )

    $batchWatch = [System.Diagnostics.Stopwatch]::StartNew()
    $pending = New-Object System.Collections.Generic.List[object]
    foreach ($target in @($Targets)) {
        $client = [System.Net.Sockets.TcpClient]::new()
        $hostName = [string]$target.host
        $port = [int]$target.port
        $startedMs = [int64]$batchWatch.ElapsedMilliseconds
        $asyncResult = $null
        $startError = ''
        try {
            $asyncResult = $client.BeginConnect($hostName, $port, $null, $null)
        } catch {
            $startError = $_.Exception.Message
        }
        [void]$pending.Add([pscustomobject]@{
                HostName    = $hostName
                Port        = $port
                Client      = $client
                AsyncResult = $asyncResult
                StartedMs   = $startedMs
                StartError  = $startError
            })
    }

    $results = New-Object System.Collections.Generic.List[object]
    $openFound = $false
    foreach ($entry in @($pending.ToArray())) {
        $open = $false
        $reason = 'timeout'
        $checked = $false
        try {
            if ($openFound) {
                $reason = 'skipped_after_open'
            } elseif ($entry.StartError) {
                $checked = $true
                $reason = [string]$entry.StartError
            } elseif ($null -ne $entry.AsyncResult) {
                $checked = $true
                $remainingMs = [math]::Max(0, $TimeoutMs - [int]$batchWatch.ElapsedMilliseconds)
                $completed = [bool]$entry.AsyncResult.IsCompleted
                if (-not $completed -and $remainingMs -gt 0) {
                    $completed = $entry.AsyncResult.AsyncWaitHandle.WaitOne([int]$remainingMs, $false)
                }
                if ($completed) {
                    $entry.Client.EndConnect($entry.AsyncResult)
                    $open = [bool]$entry.Client.Connected
                    $reason = $(if ($open) { 'open' } else { 'closed' })
                    if ($open) {
                        $openFound = $true
                    }
                }
            }
        } catch {
            $reason = $_.Exception.Message
        } finally {
            $elapsedMs = [math]::Max(0, [int]$batchWatch.ElapsedMilliseconds - [int]$entry.StartedMs)
            [void]$results.Add([ordered]@{
                    host      = [string]$entry.HostName
                    port      = [int]$entry.Port
                    checked   = [bool]$checked
                    open      = [bool]$open
                    elapsedMs = [int]$elapsedMs
                    reason    = [string]$reason
                })
            try {
                if ($null -ne $entry.AsyncResult -and $null -ne $entry.AsyncResult.AsyncWaitHandle) {
                    $entry.AsyncResult.AsyncWaitHandle.Close()
                }
            } catch {
            }
            $entry.Client.Close()
        }
    }
    $batchWatch.Stop()

    return @($results.ToArray())
}

function ConvertFrom-RevelationMaintenanceAnnouncement {
    param([string]$Html, [string]$SourceUri, [DateTimeOffset]$NowUtc = [DateTimeOffset]::UtcNow)
    $result = [ordered]@{ checked = $true; sourceUri = $SourceUri; state = 'unknown'; startAtUtc = $null; endAtUtc = $null }
    # Only the dated official article's own text is evidence, not its navigation or related news.
    if ($SourceUri -notmatch '^https://revonline\.ru/news/maintenance-(\d{2}-\d{2}-\d{4})$') { return $result }
    $date = [DateTime]::MinValue
    if (-not [DateTime]::TryParseExact($Matches[1], 'dd-MM-yyyy', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$date)) { return $result }
    $body = [regex]::Match($Html, '(?is)<div\b[^>]*class=["''][^"'']*\bjs-mediator-article\b[^"'']*["''][^>]*>(.*?)</div>')
    if (-not $body.Success) { return $result }
    $text = [Net.WebUtility]::HtmlDecode([regex]::Replace($body.Groups[1].Value, '<[^>]*>', ' '))
    $text = [regex]::Replace($text, '\s+', ' ').Trim()
    if ($text -match '(?i)(?:^|[.!])\s*(?:Профилактические\s+)?работы\s+(?:успешно\s+)?завершены\b') {
        $result.state = 'completed'
        return $result
    }
    $months = @('января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря')
    $window = [regex]::Match($text, '(?i)\b(\d{1,2})\s+(' + ($months -join '|') + ')\s+с\s+(\d{1,2}):([0-5]\d)\s*мск\s+до\s+(\d{1,2}):([0-5]\d)\s*мск\b')
    if (-not $window.Success -or $text -notmatch '(?i)все\s+игровые\s+серверы\s+будут\s+недоступны') { return $result }
    if ([int]$window.Groups[1].Value -ne $date.Day -or $window.Groups[2].Value.ToLowerInvariant() -ne $months[$date.Month-1]) { return $result }
    $startHour = [int]$window.Groups[3].Value; $endHour = [int]$window.Groups[5].Value
    if ($startHour -gt 23 -or $endHour -gt 23) { return $result }
    # The announcement specifies Moscow, independent of the user's Windows timezone.
    $start = [DateTimeOffset]::new($date.Year,$date.Month,$date.Day,$startHour,[int]$window.Groups[4].Value,0,[TimeSpan]::FromHours(3))
    $end = [DateTimeOffset]::new($date.Year,$date.Month,$date.Day,$endHour,[int]$window.Groups[6].Value,0,[TimeSpan]::FromHours(3))
    if ($end -le $start) { return $result } # Ambiguous overnight dates need an explicit dated interval.
    $result.startAtUtc = $start.ToUniversalTime().ToString('o')
    $result.endAtUtc = $end.ToUniversalTime().ToString('o')
    $result.state = if ($NowUtc -lt $start) { 'scheduled' } elseif ($NowUtc -lt $end) { 'active' } else { 'elapsed' }
    return $result
}

function Get-RevelationMaintenanceAnnouncement {
    param([DateTimeOffset]$NowUtc = [DateTimeOffset]::UtcNow)
    $result = [ordered]@{ checked = $false; sourceUri = 'https://revonline.ru/'; state = 'unknown'; startAtUtc = $null; endAtUtc = $null }
    try {
        # Read-only public requests: no account, login attempt or game command. No cached outage verdict.
        $headers = @{ 'Cache-Control' = 'no-cache' }
        $index = Invoke-WebRequest -Uri 'https://revonline.ru/' -UseBasicParsing -TimeoutSec 3 -MaximumRedirection 2 -Headers $headers -ErrorAction Stop
        $paths = @([regex]::Matches([string]$index.Content, 'href=["''](/news/maintenance-\d{2}-\d{2}-\d{4})["'']') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
        $todayMoscow = $NowUtc.ToOffset([TimeSpan]::FromHours(3)).Date
        $candidates = @(foreach ($path in $paths) {
            $date = [DateTime]::MinValue
            if ([DateTime]::TryParseExact($path.Substring('/news/maintenance-'.Length), 'dd-MM-yyyy', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$date) -and
                $date -le $todayMoscow -and $date -ge $todayMoscow.AddDays(-7)) { [pscustomobject]@{ path = $path; date = $date } }
        })
        if ($candidates.Count -gt 0) {
            $latest = $candidates | Sort-Object date -Descending | Select-Object -First 1
            $uri = 'https://revonline.ru' + $latest.path
            $article = Invoke-WebRequest -Uri $uri -UseBasicParsing -TimeoutSec 3 -MaximumRedirection 2 -Headers $headers -ErrorAction Stop
            $result = ConvertFrom-RevelationMaintenanceAnnouncement -Html ([string]$article.Content) -SourceUri $uri -NowUtc $NowUtc
        }
    } catch {
        # A website outage is not evidence that the game is offline (or online).
    }
    $result['fetchedAtUtc'] = [DateTimeOffset]::UtcNow.ToString('o')
    return $result
}

function Read-RevelationVkPlayLogTail {
    param([string]$Path)
    $stream = $null
    try {
        $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        # Snapshot at most 128 KiB, even if the writer keeps appending. Never export raw text.
        $length = $stream.Length
        $count = [int][Math]::Min(131072, $length)
        [void]$stream.Seek(($length - $count), [IO.SeekOrigin]::Begin)
        $buffer = New-Object byte[] $count
        $read = 0
        while ($read -lt $count) {
            $part = $stream.Read($buffer, $read, ($count - $read))
            if ($part -eq 0) { break }
            $read += $part
        }
        $text = [Text.Encoding]::UTF8.GetString($buffer, 0, $read)
        if ($length -gt $count) {
            $newline = $text.IndexOf("`n")
            if ($newline -lt 0) { return '' }
            $text = $text.Substring($newline + 1)
        }
        return $text
    } catch {
        return ''
    } finally {
        if ($null -ne $stream) { $stream.Dispose() }
    }
}

function ConvertFrom-RevelationVkPlayLoginLog {
    param(
        [string]$Text,
        [object[]]$ProcessSessions,
        [DateTimeOffset]$NowUtc = [DateTimeOffset]::UtcNow
    )
    $result = $null
    $login = $null
    $scopedError = $null
    # Only newline-terminated records count: a concurrent write can leave a partial reason.
    foreach ($line in [regex]::Matches($Text, '(?m)^[^\r\n]+\r?\n')) {
        $entry = [regex]::Match($line.Value, '^Message: (?<time>\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2}\.\d{3}) (?<process>\d+)\.(?<thread>\d+) \[Main thread\] (?<body>[^\r\n]*)')
        if (-not $entry.Success) { continue }
        $stamp = $entry.Groups['time'].Value
        $processId = [int]$entry.Groups['process'].Value
        $key = $stamp + '|' + $processId + '|' + $entry.Groups['thread'].Value
        $body = $entry.Groups['body'].Value
        $parsedTime = [DateTime]::MinValue
        if (-not [DateTime]::TryParseExact($stamp, 'dd.MM.yyyy HH:mm:ss.fff', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeLocal, [ref]$parsedTime)) { continue }
        $atUtc = [DateTimeOffset]$parsedTime.ToUniversalTime()
        $age = ($NowUtc - $atUtc).TotalSeconds
        if ($age -lt 0 -or $age -gt 86400) { continue }
        $sessionMatches = @($ProcessSessions | Where-Object { $_.id -eq $processId -and [DateTimeOffset]$_.startedAtUtc -le $atUtc })
        if ($sessionMatches.Count -eq 0) { continue }

        if ($body -match '(?:Click on button .* Game: 0\.1000146(?:\s|$)|TShardSelectForm Initialized for game=0\.1000146(?:\s|$)|OnClientClientConnect called for GameId:\s*0\.1000146(?:\s|$))') {
            $result = $null
            $login = $null
            $scopedError = $null
        }
        if ($body -match '^Login ErrorCode=(\d+)\s') {
            $login = @{ key = $key; code = [int]$Matches[1] }
            $scopedError = $null
        } elseif ($body -match '^TheEvent: \{1071\} (\d+)\b.* TGame\.Revelation:0\.1000146\s*$') {
            # Explicit game id + exact time/process/thread ties this response to Revelation.
            $result = $null
            $scopedError = $null
            if ($null -ne $login -and $login.key -eq $key -and $login.code -eq [int]$Matches[1]) {
                $scopedError = $login
            }
        } elseif ($body -match '^Reason=' -and $null -ne $scopedError -and $scopedError.key -eq $key) {
            $maintenance = $scopedError.code -eq 791 -and $body -match '^Reason=Профилактические работы[.!]?\s*$'
            # Only typed fields and fixed safe wording leave the parser, never account data.
            $result = [ordered]@{
                source = 'vk_play_login_response'
                scope = 'last_login_attempt'
                gameId = '0.1000146'
                outcome = 'rejected'
                errorCode = $scopedError.code
                reason = $(if ($maintenance) { 'maintenance' } else { 'login_rejected' })
                message = $(if ($maintenance) { 'профилактические работы' } else { 'ошибка авторизации' })
                observedAtUtc = $atUtc.ToString('o')
                ageSeconds = [int][Math]::Floor($age)
                fresh = $age -le 600
            }
            $scopedError = $null
        } else {
            # A reason must follow its scoped event without an intervening main-thread record.
            $scopedError = $null
            $login = $null
        }
    }
    return $result
}

function Get-RevelationVkPlayLoginObservation {
    try {
        $sessions = @(Get-Process -Name GameCenter -ErrorAction SilentlyContinue | ForEach-Object {
            try { @{ id = $_.Id; startedAtUtc = $_.StartTime.ToUniversalTime().ToString('o') } } catch { }
        })
        if ($sessions.Count -eq 0) { return $null }
        $text = Read-RevelationVkPlayLogTail -Path (Join-Path $env:LOCALAPPDATA 'GameCenter\main.log')
        return ConvertFrom-RevelationVkPlayLoginLog -Text $text -ProcessSessions $sessions
    } catch {
        return $null
    }
}

function Test-RevelationLaunchServerPreflight {
    param(
        [string]$ResolvedGameRoot,
        [string]$ResolvedGameDir,
        [string]$StateDir
    )

    $lastLoginAttempt = Get-RevelationVkPlayLoginObservation
    $shardSnapshot = Get-RevelationShardPreflightSnapshot -ResolvedGameRoot $ResolvedGameRoot
    $announcement = Get-RevelationMaintenanceAnnouncement
    $targets = @(Get-RevelationLoginPreflightTargets -ResolvedGameDir $ResolvedGameDir)
    $targetLimit = 6
    $testedTargets = @($targets | Select-Object -First $targetLimit)
    $previousOpenTarget = $null
    $previousPath = Join-Path $StateDir 'server-preflight-last.json'
    if (Test-Path -LiteralPath $previousPath -PathType Leaf) {
        try {
            $previous = Get-Content -LiteralPath $previousPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $previousOpenResult = @($previous.results | Where-Object { [bool]$_.open } | Select-Object -First 1)
            if ($previousOpenResult.Count -gt 0) {
                $previousHost = [string]$previousOpenResult[0].host
                $previousPort = [int]$previousOpenResult[0].port
                $previousOpenTarget = @($testedTargets | Where-Object { [string]$_.host -eq $previousHost -and [int]$_.port -eq $previousPort } | Select-Object -First 1)
                if ($previousOpenTarget.Count -gt 0) {
                    $testedTargets = @($previousOpenTarget[0]) + @($testedTargets | Where-Object { -not ([string]$_.host -eq $previousHost -and [int]$_.port -eq $previousPort) })
                }
            }
        } catch {
            $previousOpenTarget = $null
        }
    }
    $results = @(Test-RevelationTcpEndpointsParallel -Targets $testedTargets -TimeoutMs 1200)

    $openCount = @($results | Where-Object { [bool]$_.open }).Count
    $checkedResults = @($results | Where-Object { [bool]$_.checked })
    $shardStateChecked = [bool](
        [bool]$shardSnapshot.exists -and
        [bool]$shardSnapshot.parsed -and
        @($shardSnapshot.shards).Count -gt 0
    )
    $checked = [bool]($checkedResults.Count -gt 0 -or $shardStateChecked)
    $allClosed = [bool]($checkedResults.Count -gt 0 -and $openCount -eq 0)
    $closedEnoughToBlock = [bool]($allClosed -and $checkedResults.Count -ge 2)
    $message = 'Сервер входа отвечает. Доступность выбранного игрового сервера не подтверждена.'
    $diagnosticMessage = 'TCP-проверка не выполняет авторизацию и не проверяет вход на Рэалис, Кенсай или Атум.'
    $blockReason = 'login_only'
    $available = $null
    # ok means a launch may be attempted, NOT that entry into a realm is available.
    $ok = $true
    $warning = $true

    if ($closedEnoughToBlock) {
        $ok = $false
        $available = $false
        $blockReason = 'login_tcp_closed'
        $diagnosticMessage = 'Все проверенные login-адреса на порту 8766 не отвечают.'
        $message = 'Серверы входа не отвечают. Причина может быть в сети или на стороне игры.'
    } elseif ([bool]$shardSnapshot.maintenanceHint -or [bool]$shardSnapshot.blockedHint) {
        $blockReason = 'maintenance_hint'
        $message = 'В локальных данных есть сообщение о профилактике или закрытии серверов. Доступность входа не подтверждена.'
        $diagnosticMessage = 'shards.xml — локальный кэш, а Allow/Hidden относятся к каналу Live, не к выбранному игровому серверу. Сообщение нельзя считать устаревшим только по Allow=1.'
    } elseif ($openCount -eq 0) {
        $blockReason = 'no_login_targets'
        $message = 'Не удалось проверить вход в игру.'
        $diagnosticMessage = 'Нет достаточного подтверждения соединения с login-адресами.'
    }

    if ($null -ne $lastLoginAttempt -and $lastLoginAttempt.fresh) {
        $attemptTime = [DateTimeOffset]::Parse($lastLoginAttempt.observedAtUtc).ToLocalTime().ToString('HH:mm')
        $attemptMessage = 'VK Play отклонил вход в ' + $attemptTime + ': ' + $lastLoginAttempt.message + '.'
        if ($closedEnoughToBlock) {
            $message += ' ' + $attemptMessage
        } else {
            $blockReason = 'vk_play_last_attempt_rejected'
            $message = $attemptMessage + ' Новая попытка не выполнялась.'
        }
        $diagnosticMessage += ' Отказ относится только к указанной попытке; не блокирует повторный запуск и не подтверждает текущее состояние игровых серверов.'
    }

    # Editorial schedules are secondary information, never a launch gate or proof of access.
    if ($announcement.state -eq 'active') {
        $endMoscow = [DateTimeOffset]::Parse($announcement.endAtUtc).ToOffset([TimeSpan]::FromHours(3))
        $message += ' Справочно: на сайте профилактика до ' + $endMoscow.ToString('HH:mm') + ' МСК.'
    }

    $payload = [ordered]@{
        ok          = [bool]$ok
        available   = $available
        worldChecked = $false
        lastLoginAttempt = $lastLoginAttempt
        announcement = $announcement
        enabled     = $true
        checked     = [bool]$checked
        checkedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
        reason      = $blockReason
        warning     = [bool]$warning
        message     = $message
        diagnosticMessage = $diagnosticMessage
        shards      = $shardSnapshot
        targets     = @($testedTargets)
        results     = @($results)
        openCount   = [int]$openCount
        closedCount = [int](@($checkedResults | Where-Object { -not [bool]$_.open }).Count)
    }

    try {
        Ensure-Directory -Path $StateDir
        $payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $StateDir 'server-preflight-last.json') -Encoding UTF8
    } catch {
    }

    return $payload
}

function Set-RevelationIntroPackageState {
    param(
        [string]$ResolvedGameRoot,
        [bool]$DisableIntroMovies
    )

    $packagesPath = Join-Path $ResolvedGameRoot 'res\packages.xml'
    if (-not (Test-Path -LiteralPath $packagesPath -PathType Leaf)) {
        return [ordered]@{
            supported   = $false
            exists      = $false
            path        = $packagesPath
            disabled    = [bool]$DisableIntroMovies
            changed     = $false
            activeIntro = $false
            introCount  = 0
            message     = 'res\packages.xml не найден.'
        }
    }

    $originalText = [System.IO.File]::ReadAllText($packagesPath, [System.Text.Encoding]::UTF8)
    $newline = if ($originalText -match "`r`n") { "`r`n" } elseif ($originalText -match "`n") { "`n" } else { "`r`n" }
    $hasTrailingNewline = [bool]($originalText -match "(`r`n|`n|`r)$")
    $lines = @([regex]::Split($originalText, "`r`n|`n|`r"))
    if ($hasTrailingNewline -and $lines.Count -gt 0 -and $lines[$lines.Count - 1] -eq '') {
        if ($lines.Count -eq 1) {
            $lines = @()
        } else {
            $lines = @($lines[0..($lines.Count - 2)])
        }
    }

    $introLinePattern = '^\s*(?:<!--\s*)?<package>\s*intro\s*</package>(?:\s*-->)?\s*$'
    $textureLinePattern = '^\s*<package>\s*textures\s*</package>\s*$'
    $tinytexLinePattern = '^\s*<package>\s*tinytex\s*</package>\s*$'
    $rootEndPattern = '^\s*</root>\s*$'

    $withoutIntro = @($lines | Where-Object { $_ -notmatch $introLinePattern })
    $newLines = @($withoutIntro)

    if (-not $DisableIntroMovies) {
        $insertAt = -1
        $indent = '    '
        for ($i = 0; $i -lt $newLines.Count; $i++) {
            if ($newLines[$i] -match $textureLinePattern) {
                $insertAt = $i + 1
                if ($newLines[$i] -match '^(\s*)') {
                    $indent = $Matches[1]
                }
                break
            }
        }

        if ($insertAt -lt 0) {
            for ($i = 0; $i -lt $newLines.Count; $i++) {
                if ($newLines[$i] -match $tinytexLinePattern) {
                    $insertAt = $i
                    if ($newLines[$i] -match '^(\s*)') {
                        $indent = $Matches[1]
                    }
                    break
                }
            }
        }

        if ($insertAt -lt 0) {
            for ($i = 0; $i -lt $newLines.Count; $i++) {
                if ($newLines[$i] -match $rootEndPattern) {
                    $insertAt = $i
                    break
                }
            }
        }

        $introLine = $indent + '<package>intro</package>'
        if ($insertAt -lt 0 -or $insertAt -ge $newLines.Count) {
            $newLines = @($newLines + $introLine)
        } else {
            $before = if ($insertAt -gt 0) { @($newLines[0..($insertAt - 1)]) } else { @() }
            $after = @($newLines[$insertAt..($newLines.Count - 1)])
            $newLines = @($before + $introLine + $after)
        }
    }

    $newText = ($newLines -join $newline)
    if ($hasTrailingNewline -or $originalText.Length -eq 0) {
        $newText += $newline
    }

    $changed = -not [string]::Equals($originalText, $newText, [System.StringComparison]::Ordinal)
    if ($changed) {
        [System.IO.File]::WriteAllText($packagesPath, $newText, [System.Text.UTF8Encoding]::new($false))
    }

    $activeIntroCount = ([regex]::Matches($newText, '<package>\s*intro\s*</package>')).Count
    return [ordered]@{
        supported   = $true
        exists      = $true
        path        = $packagesPath
        disabled    = [bool]$DisableIntroMovies
        changed     = [bool]$changed
        activeIntro = [bool]($activeIntroCount -gt 0)
        introCount  = [int]$activeIntroCount
        message     = $(if ($DisableIntroMovies) {
                'Вступительный ролик отключён в res\packages.xml.'
            } else {
                'Вступительный ролик включён в res\packages.xml.'
            })
    }
}

function Get-LastUniversalCapturePath {
    param([string]$StateDir)

    $pathFile = Join-Path $StateDir 'last-universal-capture.txt'
    if (Test-Path -LiteralPath $pathFile) {
        return [string](Get-Content -LiteralPath $pathFile -Raw -ErrorAction SilentlyContinue).Trim()
    }

    return ''
}

function Get-LatestCaptureFolder {
    param([string]$LauncherRoot)

    $capturesRoot = Join-Path $LauncherRoot 'captures'
    if (-not (Test-Path -LiteralPath $capturesRoot)) {
        return ''
    }

    $dir = Get-ChildItem -LiteralPath $capturesRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like 'capture-*' -or $_.Name -like 'bundle-*' } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if ($dir) { return $dir.FullName }
    return ''
}

function Get-FileTail {
    param(
        [string]$Path,
        [int]$Lines = 150
    )

    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    return @(Get-Content -LiteralPath $Path -Tail $Lines -ErrorAction SilentlyContinue)
}

function Get-FileTailText {
    param(
        [string]$Path,
        [int]$Lines = 150
    )

    $tail = @(Get-FileTail -Path $Path -Lines $Lines)
    if ($tail.Count -eq 0) { return '' }
    return ($tail -join "`n")
}

function Test-ProcessRunning {
    param([string]$ProcessIdText)

    if (-not $ProcessIdText) { return $false }
    $procId = 0
    if (-not [int]::TryParse($ProcessIdText, [ref]$procId)) { return $false }

    try {
        $proc = Get-Process -Id $procId -ErrorAction Stop
        return $null -ne $proc
    } catch {
        return $false
    }
}

function Get-ProcessExecutableMatches {
    param(
        [AllowNull()][string]$ProcessPath,
        [AllowNull()][string]$ExpectedPath
    )

    if ([string]::IsNullOrWhiteSpace($ProcessPath) -or [string]::IsNullOrWhiteSpace($ExpectedPath)) {
        return $false
    }

    try {
        $normalizedProcessPath = [System.IO.Path]::GetFullPath($ProcessPath).TrimEnd('\')
        $normalizedExpectedPath = [System.IO.Path]::GetFullPath($ExpectedPath).TrimEnd('\')
        return ($normalizedProcessPath -ieq $normalizedExpectedPath)
    } catch {
        return (([string]$ProcessPath).Trim().ToLowerInvariant() -eq ([string]$ExpectedPath).Trim().ToLowerInvariant())
    }
}

function Get-ProcessRuntimeStatus {
    param(
        [string]$ProcessName,
        [string]$ExpectedPath = ''
    )

    # Primary path: Get-Process (always available, no WMI dependency, works with
    # any token level). We augment with path info opportunistically, but we do
    # NOT gate running=true on path match. Old gating made launcher "не видеть"
    # tianyu.exe whenever WMI path lookup was inconsistent (different spacing,
    # junction, or permission quirks). For game detection, presence-by-name is
    # enough and dramatically more reliable.
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension([string]$ProcessName)
    $procList = @()
    try {
        $procList = @(Get-Process -Name $baseName -ErrorAction Stop | ForEach-Object {
                [pscustomobject]@{
                    ProcessId      = $_.Id
                    Name           = $_.Name
                    ExecutablePath = $(try { [string]$_.Path } catch { '' })
                }
            })
    } catch {
        $procList = @()
    }

    # Opportunistic WMI augmentation: fills ExecutablePath for processes where
    # Get-Process .Path returned empty (happens for cross-session elevated
    # queries, protected processes, etc.).
    if ($procList.Count -gt 0) {
        try {
            $escapedName = ([string]$ProcessName).Replace("'", "''")
            $wmiRows = @(Get-CimInstance Win32_Process -Filter ("Name='" + $escapedName + "'") -ErrorAction Stop)
            $wmiMap = @{}
            foreach ($wmiRow in $wmiRows) {
                if ($null -ne $wmiRow -and $wmiRow.ProcessId) {
                    $wmiMap[[int]$wmiRow.ProcessId] = [string]$wmiRow.ExecutablePath
                }
            }
            foreach ($proc in $procList) {
                if ([string]::IsNullOrWhiteSpace($proc.ExecutablePath) -and $wmiMap.ContainsKey([int]$proc.ProcessId)) {
                    $proc.ExecutablePath = [string]$wmiMap[[int]$proc.ProcessId]
                }
            }
        } catch {
        }
    }

    $pathMatchFound = $false
    if (-not [string]::IsNullOrWhiteSpace($ExpectedPath)) {
        foreach ($proc in $procList) {
            $processPath = $(if ($proc -and $proc.PSObject.Properties.Name -contains 'ExecutablePath') { [string]$proc.ExecutablePath } else { '' })
            if ($processPath -and (Get-ProcessExecutableMatches -ProcessPath $processPath -ExpectedPath $ExpectedPath)) {
                $pathMatchFound = $true
                break
            }
        }
    }

    $firstMatch = $(if ($procList.Count -gt 0) { $procList[0] } else { $null })

    return [ordered]@{
        running             = [bool]($procList.Count -gt 0)
        processCount        = [int]$procList.Count
        pid                 = $(if ($firstMatch) { [int]$firstMatch.ProcessId } else { 0 })
        path                = $(if ($firstMatch -and $firstMatch.PSObject.Properties.Name -contains 'ExecutablePath') { [string]$firstMatch.ExecutablePath } else { '' })
        matchedExpectedPath = [bool]$pathMatchFound
    }
}

function Get-RevelationGameProcessNames {
    return @('tianyu.exe', 'tianyu64.exe', 'tianyu_dx11.exe', 'tianyu_beta.exe', 'tianyu64_beta.exe', 'tianyu_p.exe', 'tianyu_rs.exe')
}

function Get-RevelationGameRuntimeStatus {
    param([string]$ResolvedGameDir = '')

    $statuses = @()
    foreach ($processName in (Get-RevelationGameProcessNames)) {
        $expectedPath = ''
        if ($ResolvedGameDir) {
            $expectedPath = Join-Path $ResolvedGameDir $processName
        }
        $statuses += (Get-ProcessRuntimeStatus -ProcessName $processName -ExpectedPath $expectedPath)
    }

    $runningStatuses = @($statuses | Where-Object { [bool]$_.running })
    $firstRunning = $(if ($runningStatuses.Count -gt 0) { $runningStatuses[0] } else { $null })
    $processCount = 0
    foreach ($runtime in $statuses) {
        $processCount += [int]$runtime.processCount
    }

    return [ordered]@{
        running             = [bool]($runningStatuses.Count -gt 0)
        processCount        = [int]$processCount
        pid                 = $(if ($firstRunning) { [int]$firstRunning.pid } else { 0 })
        path                = $(if ($firstRunning) { [string]$firstRunning.path } else { '' })
        matchedExpectedPath = [bool](@($statuses | Where-Object { [bool]$_.matchedExpectedPath }).Count -gt 0)
    }
}

function Get-DxvkStatus {
    param(
        [string]$StateDir,
        [string]$GameDir
    )

    $envValue = Get-DxvkEnvValue
    $managedPath = Join-Path $StateDir 'dxvk.conf'
    $activePath = ''
    if ($envValue -and (Test-Path -LiteralPath $envValue)) {
        $activePath = $envValue
    } elseif (Test-Path -LiteralPath $managedPath) {
        $activePath = $managedPath
    }

    $configText = ''
    if ($activePath -and (Test-Path -LiteralPath $activePath)) {
        $configText = Get-Content -LiteralPath $activePath -Raw -ErrorAction SilentlyContinue
    }
    $effectiveConfigText = ''
    if ($configText) {
        $effectiveConfigText = [string]::Join("`n", @(
                foreach ($line in (($configText -replace "\r\n", "`n") -split "`n")) {
                    $trimmed = $line.Trim()
                    if ($trimmed -and (-not $trimmed.StartsWith('#'))) {
                        $trimmed
                    }
                }
            ))
    }
    $configActive = -not [string]::IsNullOrWhiteSpace($effectiveConfigText)

    $logText = ''
    foreach ($candidate in @((Join-Path $GameDir 'tianyu_d3d9.log'), (Join-Path $GameDir 'tianyu_d3d11.log'))) {
        if (Test-Path -LiteralPath $candidate) {
            $logText = Get-Content -LiteralPath $candidate -Raw -ErrorAction SilentlyContinue
            if ($logText) { break }
        }
    }

    $antistutter = $false
    $aggressive = $false
    if ($configActive) {
        $antistutter = ($effectiveConfigText -match 'd3d9\.maxAvailableMemory\s*=\s*8192') -and
            ($effectiveConfigText -match 'd3d9\.maxFrameLatency\s*=\s*1') -and
            ($effectiveConfigText -match 'dxvk\.latencySleep\s*=\s*Auto') -and
            ($effectiveConfigText -match 'dxvk\.trackPipelineLifetime\s*=\s*Auto') -and
            ($effectiveConfigText -match 'dxvk\.enableMemoryDefrag\s*=\s*Auto')
        $aggressive = ($effectiveConfigText -match 'dxvk\.allowFse\s*=\s*True') -and
            ($effectiveConfigText -match 'd3d9\.maxAvailableMemory\s*=\s*8192') -and
            ($effectiveConfigText -match 'd3d9\.maxFrameLatency\s*=\s*1') -and
            ($effectiveConfigText -match 'd3d9\.presentInterval\s*=\s*0') -and
            ($effectiveConfigText -match 'dxgi\.syncInterval\s*=\s*0') -and
            ($effectiveConfigText -match 'dxvk\.latencyTolerance\s*=\s*3000')
    }

    $confirmed = $false
    if ($configActive -and $activePath -and $logText) {
        $escaped = [regex]::Escape($activePath)
        $confirmed = $logText -match ('Found config file: ' + $escaped)
    }
    $preflightPath = Join-Path $StateDir 'dxvk-preflight.json'
    $preflight = $null
    if (Test-Path -LiteralPath $preflightPath) {
        try {
            $preflight = Get-Content -LiteralPath $preflightPath -Raw -ErrorAction Stop | ConvertFrom-Json
        } catch {
            $preflight = $null
        }
    }

    return [ordered]@{
        activePath = $(if ($configActive) { $activePath } else { '' })
        envValue   = $envValue
        preset     = $(if ($aggressive) { 'aggressive' } elseif ($antistutter) { 'antistutter' } elseif ($configActive) { 'custom' } else { 'off' })
        confirmed  = [bool]$confirmed
        summary    = $(if ($confirmed) { 'external_config_active' } elseif ($configActive -and $activePath) { 'external_config_pending_confirmation' } else { 'fallback_or_not_configured' })
        preflightAllowed = $(if ($preflight) { [bool]$preflight.Allowed } else { $null })
        preflightReason  = $(if ($preflight) { [string]$preflight.Reason } else { '' })
        warning    = $(if ($preflight -and -not [bool]$preflight.Allowed) { 'DXVK disabled: Vulkan 1.3 adapter not available' } else { '' })
    }
}

function Get-FrameTimePercentile {
    param(
        [double[]]$SortedValues,
        [ValidateRange(0, 100)]
        [double]$Percentile
    )

    if (-not $SortedValues -or $SortedValues.Count -eq 0) {
        return 0.0
    }

    $index = [int][Math]::Ceiling(($Percentile / 100.0) * $SortedValues.Count) - 1
    $index = [Math]::Max(0, [Math]::Min($SortedValues.Count - 1, $index))
    return [double]$SortedValues[$index]
}

function Initialize-RevelationProcessIoCountersType {
    if ('RevelationLauncher.ProcessIoNative' -as [type]) {
        return
    }

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

namespace RevelationLauncher {
    [StructLayout(LayoutKind.Sequential)]
    public struct ProcessIoCounters {
        public UInt64 ReadOperationCount;
        public UInt64 WriteOperationCount;
        public UInt64 OtherOperationCount;
        public UInt64 ReadTransferCount;
        public UInt64 WriteTransferCount;
        public UInt64 OtherTransferCount;
    }

    public static class ProcessIoNative {
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool GetProcessIoCounters(IntPtr processHandle, out ProcessIoCounters counters);
    }
}
'@
}

function Get-RevelationProcessIoCounters {
    param([System.Diagnostics.Process]$Process)

    Initialize-RevelationProcessIoCountersType
    $counters = New-Object RevelationLauncher.ProcessIoCounters
    try {
        if ([RevelationLauncher.ProcessIoNative]::GetProcessIoCounters($Process.Handle, [ref]$counters)) {
            return [ordered]@{
                supported  = $true
                readBytes  = [uint64]$counters.ReadTransferCount
                writeBytes = [uint64]$counters.WriteTransferCount
                otherBytes = [uint64]$counters.OtherTransferCount
            }
        }
    } catch {
    }

    return [ordered]@{
        supported  = $false
        readBytes  = [uint64]0
        writeBytes = [uint64]0
        otherBytes = [uint64]0
    }
}

function Get-FrameTimeAuditMetrics {
    param([double[]]$FrameTimes)

    if (-not $FrameTimes -or $FrameTimes.Count -eq 0) {
        throw 'Для расчёта метрик не получено ни одного кадра.'
    }

    [double[]]$sorted = @($FrameTimes | Sort-Object)
    $averageMs = [double](($FrameTimes | Measure-Object -Average).Average)
    $slowestCount = [Math]::Max(1, [int][Math]::Ceiling($sorted.Count * 0.01))
    $slowestAverageMs = [double]((@($sorted | Select-Object -Last $slowestCount) | Measure-Object -Average).Average)
    $over33Count = @($FrameTimes | Where-Object { $_ -gt 33.333 }).Count
    $over50Count = @($FrameTimes | Where-Object { $_ -gt 50.0 }).Count

    return [ordered]@{
        frameCount       = [int]$FrameTimes.Count
        averageFps       = [Math]::Round((1000.0 / $averageMs), 1)
        onePercentLowFps = [Math]::Round((1000.0 / $slowestAverageMs), 1)
        p95FrameMs       = [Math]::Round((Get-FrameTimePercentile -SortedValues $sorted -Percentile 95), 2)
        p99FrameMs       = [Math]::Round((Get-FrameTimePercentile -SortedValues $sorted -Percentile 99), 2)
        over33msPercent  = [Math]::Round(($over33Count * 100.0 / $FrameTimes.Count), 2)
        over50msPercent  = [Math]::Round(($over50Count * 100.0 / $FrameTimes.Count), 2)
    }
}

function Invoke-FrameTimeAudit {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir,
        [ValidateRange(15, 120)]
        [int]$DurationSeconds = 60
    )

    Set-BridgeOperationPhase -Phase 'preparing_audit'
    Assert-BridgeOperationNotCancelled
    if (-not (Test-IsAdministrator)) {
        throw 'Тест плавности требует запуска лаунчера от имени администратора.'
    }

    $target = @(
        foreach ($name in @('tianyu', 'tianyu64', 'tianyu_dx11', 'tianyu_beta', 'tianyu64_beta')) {
            Get-Process -Name $name -ErrorAction SilentlyContinue
        }
    ) | Sort-Object StartTime -Descending | Select-Object -First 1
    if (-not $target) {
        throw 'Сначала запустите игру и войдите в мир.'
    }

    $presentMonFileName = if ([Environment]::Is64BitOperatingSystem) {
        'PresentMon-2.5.0-x64.exe'
    } else {
        'PresentMon-2.4.1-x86.exe'
    }
    $presentMonPath = @(
        (Join-Path $ResolvedLauncherRoot (Join-Path 'tools' $presentMonFileName)),
        (Join-Path $ResolvedLauncherRoot $presentMonFileName)
    ) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $presentMonPath) {
        throw 'PresentMon не найден в комплекте лаунчера.'
    }

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    $auditRoot = Join-Path $stateDir 'frame-time-audits'
    $auditDir = Join-Path $auditRoot ('audit-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Ensure-Directory -Path $auditDir

    $csvPath = Join-Path $auditDir 'presentmon.csv'
    $stdoutPath = Join-Path $auditDir 'presentmon-stdout.txt'
    $stderrPath = Join-Path $auditDir 'presentmon-stderr.txt'
    $summaryPath = Join-Path $auditDir 'summary.json'
    $runtimeSamplesPath = Join-Path $auditDir 'runtime-samples.csv'
    $sessionName = 'RevAudit-' + (Get-Date -Format 'MMddHHmmss') + '-' + $target.Id
    $wprPath = Join-Path $env:WINDIR 'System32\wpr.exe'
    $wprTracePath = Join-Path $auditDir 'cpu-fileio-network.etl'
    $wprStartLogPath = Join-Path $auditDir 'wpr-start.txt'
    $wprStopLogPath = Join-Path $auditDir 'wpr-stop.txt'
    $wprInstanceName = $sessionName + '-ETW'
    $arguments = @(
        '--session_name', $sessionName,
        '--process_id', $target.Id.ToString(),
        '--output_file', $csvPath,
        '--qpc_time_ms',
        '--terminate_on_proc_exit',
        '--terminate_after_timed',
        '--timed', $DurationSeconds.ToString(),
        '--no_console_stats'
    )
    $argumentString = ConvertTo-NativeArgumentString -Arguments $arguments

    Initialize-RevelationProcessIoCountersType
    $initialProcess = Get-Process -Id $target.Id -ErrorAction Stop
    $initialProcess.Refresh()
    $previousProcessCpuMs = [double]$initialProcess.TotalProcessorTime.TotalMilliseconds
    $previousIo = Get-RevelationProcessIoCounters -Process $initialProcess
    $previousThreadCpu = @{}
    $mainThreadId = 0
    $earliestThreadStart = [DateTime]::MaxValue
    foreach ($thread in @($initialProcess.Threads)) {
        try {
            $threadId = [int]$thread.Id
            $previousThreadCpu[$threadId] = [double]$thread.TotalProcessorTime.TotalMilliseconds
            $threadStart = $thread.StartTime
            if ($threadStart -lt $earliestThreadStart) {
                $earliestThreadStart = $threadStart
                $mainThreadId = $threadId
            }
        } catch {
        }
    }

    $runtimeSamples = [System.Collections.Generic.List[object]]::new()
    $wprStarted = $false
    $wprError = ''
    if (Test-Path -LiteralPath $wprPath) {
        try {
            $wprStartOutput = @(& $wprPath -start CPU.light -start FileIO.light -start DiskIO.light -start Network.light -filemode -recordtempto $auditDir -instancename $wprInstanceName 2>&1)
            $wprStartOutput | Set-Content -LiteralPath $wprStartLogPath -Encoding UTF8
            $wprStarted = [bool]($LASTEXITCODE -eq 0)
            if (-not $wprStarted) {
                $wprError = 'WPR start failed with exit code ' + [string]$LASTEXITCODE
            }
        } catch {
            $wprError = $_.Exception.Message
        }
    } else {
        $wprError = 'wpr.exe was not found.'
    }

    $capture = $null
    $stopwatch = $null
    try {
        Set-BridgeOperationPhase -Phase 'capturing_frame_times'
        Assert-BridgeOperationNotCancelled
        $capture = Start-Process -FilePath $presentMonPath -ArgumentList $argumentString -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
        # Retain the process handle before polling HasExited; Windows PowerShell
        # otherwise loses ExitCode for redirected Start-Process captures.
        [void]$capture.Handle
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $previousElapsedMs = 0.0
        while ($stopwatch.Elapsed.TotalSeconds -lt ($DurationSeconds + 3) -and -not $capture.HasExited) {
            if (Test-BridgeOperationCancelled) {
                try { $capture.Kill() } catch { }
                throw [System.OperationCanceledException]::new('Тест плавности остановлен пользователем.')
            }
            Start-Sleep -Milliseconds 250
            $elapsedMs = [double]$stopwatch.Elapsed.TotalMilliseconds
            $intervalMs = [Math]::Max(1.0, $elapsedMs - $previousElapsedMs)
            $previousElapsedMs = $elapsedMs

            try {
                $sampleProcess = Get-Process -Id $target.Id -ErrorAction Stop
                $sampleProcess.Refresh()
                $processCpuMs = [double]$sampleProcess.TotalProcessorTime.TotalMilliseconds
                $processCpuCores = [Math]::Max(0.0, ($processCpuMs - $previousProcessCpuMs) / $intervalMs)
                $previousProcessCpuMs = $processCpuMs

            $currentIo = Get-RevelationProcessIoCounters -Process $sampleProcess
            $readBytesDelta = if ([bool]$currentIo.supported -and [bool]$previousIo.supported -and [uint64]$currentIo.readBytes -ge [uint64]$previousIo.readBytes) {
                [uint64]$currentIo.readBytes - [uint64]$previousIo.readBytes
            } else { [uint64]0 }
            $writeBytesDelta = if ([bool]$currentIo.supported -and [bool]$previousIo.supported -and [uint64]$currentIo.writeBytes -ge [uint64]$previousIo.writeBytes) {
                [uint64]$currentIo.writeBytes - [uint64]$previousIo.writeBytes
            } else { [uint64]0 }
            $previousIo = $currentIo

            $currentThreadCpu = @{}
            $mainThreadCpuDeltaMs = 0.0
            $mainThreadState = ''
            $mainThreadWaitReason = ''
            $topThreadId = 0
            $topThreadCpuDeltaMs = 0.0
            $topThreadState = ''
            foreach ($thread in @($sampleProcess.Threads)) {
                try {
                    $threadId = [int]$thread.Id
                    $threadCpuMs = [double]$thread.TotalProcessorTime.TotalMilliseconds
                    $currentThreadCpu[$threadId] = $threadCpuMs
                    $threadCpuDeltaMs = if ($previousThreadCpu.ContainsKey($threadId)) {
                        [Math]::Max(0.0, $threadCpuMs - [double]$previousThreadCpu[$threadId])
                    } else { 0.0 }
                    $threadState = [string]$thread.ThreadState
                    if ($threadId -eq $mainThreadId) {
                        $mainThreadCpuDeltaMs = $threadCpuDeltaMs
                        $mainThreadState = $threadState
                        if ($thread.ThreadState -eq [System.Diagnostics.ThreadState]::Wait) {
                            try { $mainThreadWaitReason = [string]$thread.WaitReason } catch { }
                        }
                    }
                    if ($threadCpuDeltaMs -gt $topThreadCpuDeltaMs) {
                        $topThreadId = $threadId
                        $topThreadCpuDeltaMs = $threadCpuDeltaMs
                        $topThreadState = $threadState
                    }
                } catch {
                }
            }
            $previousThreadCpu = $currentThreadCpu

                [void]$runtimeSamples.Add([pscustomobject][ordered]@{
                    capturedAtUtc          = [DateTime]::UtcNow.ToString('o')
                    elapsedMs             = [Math]::Round($elapsedMs, 1)
                    intervalMs            = [Math]::Round($intervalMs, 1)
                    processCpuCores       = [Math]::Round($processCpuCores, 3)
                    mainThreadId          = [int]$mainThreadId
                    mainThreadCpuPercent  = [Math]::Round(($mainThreadCpuDeltaMs * 100.0 / $intervalMs), 1)
                    mainThreadState       = $mainThreadState
                    mainThreadWaitReason  = $mainThreadWaitReason
                    topThreadId           = [int]$topThreadId
                    topThreadCpuPercent   = [Math]::Round(($topThreadCpuDeltaMs * 100.0 / $intervalMs), 1)
                    topThreadState        = $topThreadState
                    threadCount           = [int]$sampleProcess.Threads.Count
                    readMegabytesPerSecond = [Math]::Round(($readBytesDelta / 1MB) / ($intervalMs / 1000.0), 3)
                    writeMegabytesPerSecond = [Math]::Round(($writeBytesDelta / 1MB) / ($intervalMs / 1000.0), 3)
                    workingSetMegabytes   = [Math]::Round(($sampleProcess.WorkingSet64 / 1MB), 1)
                    privateMegabytes      = [Math]::Round(($sampleProcess.PrivateMemorySize64 / 1MB), 1)
                    })
            } catch {
                break
            }
        }
        $stopwatch.Stop()

        if (-not $capture.HasExited) {
            if (-not $capture.WaitForExit(15000)) {
                try { $capture.Kill() } catch { }
                throw 'PresentMon не завершил тест за отведённое время.'
            }
        }
        $capture.WaitForExit()
        if ($runtimeSamples.Count -gt 0) {
            $runtimeSamples | Export-Csv -LiteralPath $runtimeSamplesPath -NoTypeInformation -Encoding UTF8
        }
    } finally {
        if ($stopwatch -and $stopwatch.IsRunning) {
            $stopwatch.Stop()
        }
        if ($wprStarted) {
            try {
                $wprStopOutput = @(& $wprPath -stop $wprTracePath 'Revelation PvP stutter audit' -skipPdbGen -instancename $wprInstanceName 2>&1)
                $wprStopOutput | Set-Content -LiteralPath $wprStopLogPath -Encoding UTF8
                if ($LASTEXITCODE -ne 0) {
                    $wprError = 'WPR stop failed with exit code ' + [string]$LASTEXITCODE
                    [void](& $wprPath -cancel -instancename $wprInstanceName 2>&1)
                }
            } catch {
                $wprError = $_.Exception.Message
                try { [void](& $wprPath -cancel -instancename $wprInstanceName 2>&1) } catch { }
            }
        }
    }
    if ($capture.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $csvPath)) {
        [string]$details = ''
        if (Test-Path -LiteralPath $stderrPath) {
            $details = [string](Get-Content -LiteralPath $stderrPath -Raw -ErrorAction SilentlyContinue)
        }
        $details = $details.Trim()
        if ($details.Length -gt 240) {
            $details = $details.Substring(0, 240)
        }
        throw ('PresentMon не смог выполнить тест.' + $(if ($details) { ' ' + $details } else { '' }))
    }

    $rows = @(Import-Csv -LiteralPath $csvPath)
    $targetRows = @($rows | Where-Object { [string]$_.ProcessID -eq $target.Id.ToString() })
    if ($targetRows.Count -eq 0) {
        throw 'PresentMon не получил кадры игрового процесса.'
    }

    $dominantSwapChain = $targetRows | Group-Object SwapChainAddress | Sort-Object Count -Descending | Select-Object -First 1
    $frameTimes = [System.Collections.Generic.List[double]]::new()
    foreach ($row in @($dominantSwapChain.Group)) {
        [double]$frameMs = 0
        $parsed = [double]::TryParse(
            [string]$row.MsBetweenPresents,
            [Globalization.NumberStyles]::Float,
            [Globalization.CultureInfo]::InvariantCulture,
            [ref]$frameMs
        )
        # Keep long stalls: dropping intervals above one second hides the freezes this audit measures.
        if ($parsed -and $frameMs -gt 0 -and -not [double]::IsInfinity($frameMs) -and -not [double]::IsNaN($frameMs)) {
            $frameTimes.Add($frameMs)
        }
    }
    if ($frameTimes.Count -lt 120) {
        throw 'Для расчёта получено слишком мало кадров. Повторите тест в активном окне игры.'
    }

    $metrics = Get-FrameTimeAuditMetrics -FrameTimes $frameTimes
    $processCpuCoreValues = [double[]]@($runtimeSamples | ForEach-Object { [double]$_.processCpuCores } | Sort-Object)
    $mainThreadCpuValues = [double[]]@($runtimeSamples | ForEach-Object { [double]$_.mainThreadCpuPercent } | Sort-Object)
    $readRateValues = [double[]]@($runtimeSamples | ForEach-Object { [double]$_.readMegabytesPerSecond } | Sort-Object)
    $writeRateValues = [double[]]@($runtimeSamples | ForEach-Object { [double]$_.writeMegabytesPerSecond } | Sort-Object)
    $processCpuCoresP95 = if ($processCpuCoreValues.Count -gt 0) { [Math]::Round((Get-FrameTimePercentile -SortedValues $processCpuCoreValues -Percentile 95), 2) } else { 0.0 }
    $mainThreadCpuP95 = if ($mainThreadCpuValues.Count -gt 0) { [Math]::Round((Get-FrameTimePercentile -SortedValues $mainThreadCpuValues -Percentile 95), 1) } else { 0.0 }
    $readRatePeak = if ($readRateValues.Count -gt 0) { [Math]::Round($readRateValues[-1], 2) } else { 0.0 }
    $writeRatePeak = if ($writeRateValues.Count -gt 0) { [Math]::Round($writeRateValues[-1], 2) } else { 0.0 }

    $result = [ordered]@{
        ok                   = $true
        processId            = [int]$target.Id
        processName          = [string]$target.ProcessName
        requestedSeconds     = [int]$DurationSeconds
        frameCount           = [int]$metrics.frameCount
        averageFps           = [double]$metrics.averageFps
        onePercentLowFps     = [double]$metrics.onePercentLowFps
        p95FrameMs           = [double]$metrics.p95FrameMs
        p99FrameMs           = [double]$metrics.p99FrameMs
        over33msPercent      = [double]$metrics.over33msPercent
        over50msPercent      = [double]$metrics.over50msPercent
        capturedAtUtc        = (Get-Date).ToUniversalTime().ToString('o')
        csvPath              = $csvPath
        runtimeSamplesPath   = $runtimeSamplesPath
        runtimeSampleCount   = [int]$runtimeSamples.Count
        mainThreadId         = [int]$mainThreadId
        processCpuCoresP95   = [double]$processCpuCoresP95
        mainThreadCpuP95     = [double]$mainThreadCpuP95
        readMegabytesPerSecondPeak = [double]$readRatePeak
        writeMegabytesPerSecondPeak = [double]$writeRatePeak
        wprStarted             = [bool]$wprStarted
        wprTracePath           = $(if (Test-Path -LiteralPath $wprTracePath) { $wprTracePath } else { '' })
        wprError               = $wprError
        summaryPath          = $summaryPath
    }
    $result['message'] = ('Тест завершён: {0} FPS, 1% low {1} FPS, p99 {2} мс; main-thread p95 {3}%, чтение peak {4} MB/s.' -f $result.averageFps, $result.onePercentLowFps, $result.p99FrameMs, $result.mainThreadCpuP95, $result.readMegabytesPerSecondPeak)

    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $summaryPath -Encoding UTF8
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $auditRoot 'latest.json') -Encoding UTF8
    return $result
}

function New-BridgeHealthFileCheck {
    param(
        [string]$Root,
        [string]$RelativePath,
        [string]$Label,
        [bool]$Required = $true,
        [ValidateSet('file', 'directory')]
        [string]$Kind = 'file'
    )

    $path = Join-Path $Root $RelativePath
    $exists = Test-Path -LiteralPath $path
    $sizeBytes = 0
    if ($exists -and $Kind -eq 'file') {
        try {
            $sizeBytes = [int64](Get-Item -LiteralPath $path -ErrorAction Stop).Length
        } catch {
            $sizeBytes = 0
        }
    }

    $ok = [bool]($exists -and ($Kind -eq 'directory' -or $sizeBytes -gt 0))
    return [ordered]@{
        label        = $Label
        relativePath = $RelativePath
        path         = $path
        kind         = $Kind
        required     = [bool]$Required
        ok           = $ok
        exists       = [bool]$exists
        sizeBytes    = [int64]$sizeBytes
        message      = $(if ($ok) { 'ok' } elseif ($Required) { 'missing_or_empty' } else { 'not_found' })
    }
}

function Get-BridgeDumpcapPath {
    foreach ($candidate in @(
            'C:\Program Files\Wireshark\dumpcap.exe',
            'C:\Program Files (x86)\Wireshark\dumpcap.exe'
        )) {
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
    }
    return ''
}

function Test-BridgeNpcapInstalled {
    foreach ($candidate in @(
            'C:\Program Files\Npcap\NPFInstall.exe',
            'C:\Program Files\Npcap\Packet.dll',
            'C:\Program Files (x86)\Npcap\NPFInstall.exe',
            'C:\Program Files (x86)\Npcap\Packet.dll',
            'C:\Windows\System32\Npcap\Packet.dll',
            'C:\Windows\SysWOW64\Npcap\Packet.dll'
        )) {
        if (Test-Path -LiteralPath $candidate) {
            return $true
        }
    }
    return $false
}

function Get-BridgeLibreHardwareMonitorExe {
    param([hashtable]$Config)

    $configured = ''
    if (Test-BridgeMapHasKey -Map $Config -Key 'libreHardwareMonitorPath') {
        $configured = [string]$Config['libreHardwareMonitorPath']
    }
    foreach ($candidate in @(
            $configured,
            (Join-Path $env:LOCALAPPDATA 'RevelationLauncher\LibreHardwareMonitor\LibreHardwareMonitor.exe')
        )) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }
    return ''
}

function Test-BridgeLauncherHealth {
    param([string]$ResolvedLauncherRoot)

    $config = Read-KeyValueFile -Path (Join-Path $ResolvedLauncherRoot 'launcher-config.ini')
    $checks = New-Object System.Collections.Generic.List[object]
    $osArchitecture = $(if ([Environment]::Is64BitOperatingSystem) { 'x64' } else { 'x86' })
    foreach ($item in @(
            @{ Path = 'RevelationUniversalFull.exe'; Label = 'Интерфейс лаунчера' },
            @{ Path = 'RevelationGuiBridge.ps1'; Label = 'Bridge лаунчера' },
            @{ Path = 'RevelationUpdater.ps1'; Label = 'Модуль обновления' },
            @{ Path = 'RevelationLicense.ps1'; Label = 'Модуль лицензии' },
            @{ Path = 'RevelationReleaseChannel.ps1'; Label = 'Модуль канала' },
            @{ Path = 'RevelationCombat.ps1'; Label = 'Запуск игры' },
            @{ Path = 'RevelationNetwork.ps1'; Label = 'Сетевой профиль' },
            @{ Path = 'RevelationUserConfig.ps1'; Label = 'Пользовательские конфиги' },
            @{ Path = 'RevelationGpuProfiles.ps1'; Label = 'Видеопрофиль' },
            @{ Path = 'license-config.ini'; Label = 'Конфиг лицензии' },
            @{ Path = 'launcher-config.ini'; Label = 'Конфиг лаунчера' },
            @{ Path = 'LauncherIcon-RL.ico'; Label = 'Иконка лаунчера' }
        )) {
        [void]$checks.Add((New-BridgeHealthFileCheck -Root $ResolvedLauncherRoot -RelativePath ([string]$item.Path) -Label ([string]$item.Label)))
    }
    $architectureTools = @(
        @{ Path = $(if ($osArchitecture -eq 'x64') { 'tools\PresentMon-2.5.0-x64.exe' } else { 'tools\PresentMon-2.4.1-x86.exe' }); Label = ('PresentMon ' + $osArchitecture) },
        @{ Path = 'tools\RevelationGameCenterCaptureInjector.exe'; Label = 'GameCenter injector x86' },
        @{ Path = 'tools\RevelationGameCenterCaptureHook.dll'; Label = 'GameCenter hook x86' },
        @{ Path = 'tools\RevelationLatencyProxy.dll'; Label = 'Latency proxy x86' },
        @{ Path = 'tools\pvp-latency-signatures.json'; Label = 'Latency signatures' }
    )
    if ($osArchitecture -eq 'x64') {
        $architectureTools += @(
            @{ Path = 'tools\RevelationLatencyHelper.exe'; Label = 'Latency helper x64' },
            @{ Path = 'tools\RevelationAmdAdlxHelper.exe'; Label = 'AMD ADLX helper x64' }
        )
    }
    foreach ($item in $architectureTools) {
        [void]$checks.Add((New-BridgeHealthFileCheck -Root $ResolvedLauncherRoot -RelativePath ([string]$item.Path) -Label ([string]$item.Label) -Required $false))
    }
    foreach ($item in @(
            @{ Path = 'dxvk'; Label = 'DXVK runtime'; Required = $false },
            @{ Path = '.revelation-lab'; Label = 'Revelation Lab data'; Required = $false },
            @{ Path = 'tools'; Label = 'Инструменты лаунчера'; Required = $true }
        )) {
        [void]$checks.Add((New-BridgeHealthFileCheck -Root $ResolvedLauncherRoot -RelativePath ([string]$item.Path) -Label ([string]$item.Label) -Required ([bool]$item.Required) -Kind 'directory'))
    }

    $resolvedGameRoot = ''
    $resolvedGameDir = ''
    $gameRootOk = $false
    $gameMessage = ''
    try {
        $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
        $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
        $gameRootOk = Test-Path -LiteralPath (Join-Path $resolvedGameDir 'tianyu.exe')
        $gameMessage = $(if ($gameRootOk) { 'ok' } else { 'game_exe_missing' })
    } catch {
        $gameMessage = $_.Exception.Message
    }

    $dumpcapPath = Get-BridgeDumpcapPath
    $npcapInstalled = Test-BridgeNpcapInstalled
    $lhmPath = Get-BridgeLibreHardwareMonitorExe -Config $config
    $gameCenterPath = Get-GameCenterExePath
    $missingRequired = @($checks | Where-Object { [bool]$_.required -and -not [bool]$_.ok })
    $missingBundledOptional = @($checks | Where-Object { -not [bool]$_.required -and -not [bool]$_.ok })
    $optionalIssues = New-Object System.Collections.Generic.List[string]
    foreach ($missing in $missingBundledOptional) {
        [void]$optionalIssues.Add([string]$missing.label)
    }
    if (-not $dumpcapPath) { [void]$optionalIssues.Add('Wireshark/dumpcap') }
    if (-not $npcapInstalled) { [void]$optionalIssues.Add('Npcap') }
    if (-not $lhmPath) { [void]$optionalIssues.Add('LibreHardwareMonitor') }
    if (-not $gameCenterPath) { [void]$optionalIssues.Add('VK Play GameCenter') }

    $ok = [bool]($missingRequired.Count -eq 0 -and $gameRootOk)
    $message = if ($ok -and $optionalIssues.Count -eq 0) {
        'Проверка файлов и дополнительного софта выполнена: всё на месте.'
    } elseif ($ok) {
        'Файлы лаунчера на месте. Дополнительно проверь: ' + (($optionalIssues.ToArray()) -join ', ') + '.'
    } else {
        'Проверка нашла проблемы с комплектом лаунчера. Рекомендуется обновление или переустановка.'
    }

    return [ordered]@{
        ok               = $ok
        message          = $message
        launcherRoot     = $ResolvedLauncherRoot
        checkedAtUtc     = ([DateTime]::UtcNow.ToString('s') + 'Z')
        requiredOk       = [bool]($missingRequired.Count -eq 0)
        requiredMissing  = @($missingRequired | ForEach-Object { [string]$_.relativePath })
        fileChecks       = @($checks.ToArray())
        game             = [ordered]@{
            ok       = [bool]$gameRootOk
            root     = $resolvedGameRoot
            dir      = $resolvedGameDir
            message  = $gameMessage
        }
        dependencies     = [ordered]@{
            osArchitecture          = $osArchitecture
            gameCenterDetected       = [bool]$gameCenterPath
            gameCenterPath           = $gameCenterPath
            dumpcapDetected          = [bool]$dumpcapPath
            dumpcapPath              = $dumpcapPath
            npcapInstalled           = [bool]$npcapInstalled
            libreHardwareMonitorPath = $lhmPath
            libreHardwareMonitorFound = [bool]$lhmPath
            optionalIssues           = @($optionalIssues.ToArray())
        }
    }
}

function Build-StatusPayload {
    param(
        [string]$ResolvedLauncherRoot,
        [switch]$Lightweight,
        [switch]$SkipRuntimeStatus
    )

    $configPath = Join-Path $ResolvedLauncherRoot 'launcher-config.ini'
    $config = Read-KeyValueFile -Path $configPath
    $launcherIdentity = Get-LauncherStatusIdentity -ResolvedLauncherRoot $ResolvedLauncherRoot -Config $config
    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    $networkState = Read-KeyValueFile -Path (Join-Path $stateDir 'network-state.ini')

    $resolvedGameRoot = ''
    $resolvedGameDir = ''
    $gameRootResolved = $false
    $gameRootError = ''
    try {
        $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
        $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
        $gameRootResolved = $true
    } catch {
        $gameRootError = $_.Exception.Message
    }

    $dxvk = $(if ($gameRootResolved) { Get-DxvkStatus -StateDir $stateDir -GameDir $resolvedGameDir } else { New-UnresolvedDxvkStatus })
    $gameCenterExe = Get-GameCenterExePath
    $gameExePath = $(if ($gameRootResolved) { Join-Path $resolvedGameDir 'tianyu.exe' } else { '' })
    $gameRuntime = $(if ($SkipRuntimeStatus) {
            New-EmptyProcessRuntimeStatus
        } elseif ($gameRootResolved) {
            Get-RevelationGameRuntimeStatus -ResolvedGameDir $resolvedGameDir
        } else {
            New-EmptyProcessRuntimeStatus
        })
    $uiGuardRepair = $null # Status is read-only; display changes require an explicit action.
    $uiGuardStatus = $(if ($gameRootResolved -and -not $Lightweight) {
            Get-BridgeUiGuardStatus -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -SettingsEnabled ([bool]$settings.uiSpamGuard) -GameRunning ([bool]$gameRuntime.running)
        } else {
            [ordered]@{
                supported           = $false
                settingsEnabled     = [bool]$settings.uiSpamGuard
                configPath          = ''
                currentApplied       = $false
                baseApplied          = $false
                noisyWidgetsHidden   = $false
                restartRequired      = $false
                activeSessionStale   = $false
                configLastWriteUtc   = ''
                gameStartedUtc       = ''
                hiddenWidgetCount    = 0
                requiredWidgetCount  = 0
                showMonsterName      = ''
                hideOtherEntityName  = ''
                hideOtherEntityTitle = ''
                hideOtherEntityBlood = ''
                disableSkillHover    = ''
                quickRead            = ''
                message              = $(if ($Lightweight) { 'Подробный статус загружается в фоне.' } else { 'Папка игры не найдена.' })
                widgets              = @()
            }
        })
    if ($uiGuardStatus -is [System.Collections.IDictionary]) {
        $uiGuardStatus['repair'] = $uiGuardRepair
    }
    $gameCenterRuntime = $(if ($SkipRuntimeStatus) {
            New-EmptyProcessRuntimeStatus
        } elseif ($gameCenterExe) {
            Get-ProcessRuntimeStatus -ProcessName 'GameCenter.exe' -ExpectedPath $gameCenterExe
        } else {
            New-EmptyProcessRuntimeStatus
        })
    $launcherLogPath = Join-Path $stateDir 'universal-launcher.log'
    if (-not (Test-Path -LiteralPath $launcherLogPath)) {
        $launcherLogPath = Join-Path $stateDir 'last-launch.log'
    }
    $networkLogPath = Join-Path $stateDir 'network.log'
    $watcherPidText = $(if (Test-BridgeMapHasKey -Map $networkState -Key 'watcher_pid') { [string]$networkState['watcher_pid'] } else { '' })
    $lastCapture = $(if ($Lightweight) { '' } else { Get-LastUniversalCapturePath -StateDir $stateDir })
    $license = $(if (Get-Command -Name New-LicenseStatusPayload -ErrorAction SilentlyContinue) { New-LicenseStatusPayload -LauncherRoot $ResolvedLauncherRoot } else { [ordered]@{ status = 'missing'; statusText = 'Лицензия недоступна'; allowRuntime = $false; message = 'Лицензионный модуль не найден.' } })
    $updateStatus = $(if (Get-Command -Name Get-RevelationUpdateStatus -ErrorAction SilentlyContinue) {
            Get-RevelationUpdateStatus -LauncherRoot $ResolvedLauncherRoot -ReleaseChannel ([string]$launcherIdentity.releaseChannel)
        } else {
            [ordered]@{ ok = $false; supported = $false; releaseChannel = [string]$launcherIdentity.releaseChannel; installedVersion = ''; updateAllowed = $false; message = 'Модуль обновления лаунчера не найден.' }
        })
    $pvpRecoveryStatus = [ordered]@{
        supported                 = $false
        enabled                   = $false
        armed                     = $false
        captureMode               = 'safe'
        captureReady              = $false
        classifierVersion         = ''
        gameBuildHash             = ''
        latencyHelperStatus       = 'disabled'
        latencyPatchApplied       = $false
        endpointSuppressionActive = $false
        degradedReason            = $(if ($gameRootResolved) { '' } else { 'game_root_unresolved' })
        lastResearchBundle        = ''
        lastRecoveryMetrics       = $null
        profile                   = 'none'
        processTuneRequested      = 'none'
        processTuneStatus         = 'disabled'
        processTuneApplied        = $false
        processTuneTargets        = ''
        fullLogEnabled            = $true
        fullLogRequired           = $false
        fullLogReady              = $false
        launchBlockedReason       = $(if ($gameRootResolved) { 'none' } else { 'game_root_unresolved' })
        lastSuccessfulProfile     = 'none'
    }
    if ($gameRootResolved -and -not $Lightweight -and (Get-Command -Name Get-LauncherPvpRecoveryStatus -ErrorAction SilentlyContinue)) {
        try {
            $pvpRecoveryStatus = Get-LauncherPvpRecoveryStatus -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
        } catch {
            $pvpRecoveryStatus['degradedReason'] = 'status_error'
        }
    }
    $userConfigStatus = [ordered]@{
        rootPath          = ''
        currentState      = $(if ($gameRootResolved) { 'unknown' } else { 'game_root_unresolved' })
        matchedPresetId   = ''
        matchedPresetName = ''
        recoveryPresetId  = ''
        autosaveCount     = 0
        presets           = @()
    }
    if ($gameRootResolved -and -not $Lightweight -and (Get-Command -Name Get-LauncherUserConfigStatus -ErrorAction SilentlyContinue)) {
        $userConfigStatus = Get-LauncherUserConfigStatus -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
    }
    $gpuProfileStatus = [ordered]@{
        supported         = $false
        refreshRateHz     = 0
        recommendedFpsCap = 0
        effectiveFpsCap   = 0
        capEnabled        = $false
        settings          = [ordered]@{ fpsCapMode = 'off'; manualFpsCap = 0; nvidiaProfileInspectorPath = '' }
        displays          = @()
        adapters          = @()
        nvidia            = [ordered]@{ detected = $false; profileInspectorFound = $false; profileInspectorPath = ''; applyMode = 'missing' }
        amd               = [ordered]@{ detected = $false; applyMode = 'planned' }
        msiMode           = [ordered]@{ mode = 'manual_only'; adapters = @() }
        dxvk              = [ordered]@{ path = ''; exists = $false; currentCap = '' }
        message           = $(if ($gameRootResolved) { '' } else { 'Папка игры не найдена.' })
    }
    if ($gameRootResolved -and -not $Lightweight -and (Get-Command -Name Get-RevelationGpuProfileStatus -ErrorAction SilentlyContinue)) {
        try {
            $gpuProfileStatus = Get-RevelationGpuProfileStatus -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
        } catch {
            $gpuProfileStatus['supported'] = $false
        }
    }
    $baselineDir = Get-PerUserBaselineDir -LauncherRoot $ResolvedLauncherRoot

    $payload = [ordered]@{
        ok                  = $true
        releaseChannel      = [string]$launcherIdentity.releaseChannel
        launcherDisplayName = [string]$launcherIdentity.launcherDisplayName
        launcherRoot        = $ResolvedLauncherRoot
        gameRoot            = $resolvedGameRoot
        gameDir             = $resolvedGameDir
        gameRootResolved    = [bool]$gameRootResolved
        gameRootError       = [string]$gameRootError
        configPath          = $configPath
        stateDir            = $stateDir
        isAdmin             = [bool](Test-IsAdministrator)
        gameCenter   = [ordered]@{
            path         = $gameCenterExe
            detected     = [bool]$gameCenterExe
            running      = [bool]$gameCenterRuntime.running
            processCount = [int]$gameCenterRuntime.processCount
            pid          = [int]$gameCenterRuntime.pid
        }
        game         = [ordered]@{
            path         = $gameExePath
            running      = [bool]$gameRuntime.running
            processCount = [int]$gameRuntime.processCount
            pid          = [int]$gameRuntime.pid
        }
        libreHardwareMonitor = [ordered]@{
            path       = $(if (Test-BridgeMapHasKey -Map $config -Key 'libreHardwareMonitorPath') { [string]$config['libreHardwareMonitorPath'] } else { '' })
            autoStart  = [bool]((Test-BridgeMapHasKey -Map $config -Key 'autoStartLibreHardwareMonitor') -and [string]$config['autoStartLibreHardwareMonitor'] -eq '1')
            configured = [bool]((Test-BridgeMapHasKey -Map $config -Key 'libreHardwareMonitorPath') -and [string]$config['libreHardwareMonitorPath'])
        }
        dxvk         = $dxvk
        network      = [ordered]@{
            applied          = [bool]((Test-BridgeMapHasKey -Map $networkState -Key 'applied') -and [string]$networkState['applied'] -eq '1')
            mode             = $(if (Test-BridgeMapHasKey -Map $networkState -Key 'network_mode') { [string]$networkState['network_mode'] } else { 'safe' })
            modeReason       = $(if (Test-BridgeMapHasKey -Map $networkState -Key 'mode_reason') { [string]$networkState['mode_reason'] } else { '' })
            stageReason      = $(if (Test-BridgeMapHasKey -Map $networkState -Key 'stage_reason') { [string]$networkState['stage_reason'] } else { 'baseline' })
            stagedRequested  = [bool]((Test-BridgeMapHasKey -Map $networkState -Key 'staged_requested') -and [string]$networkState['staged_requested'] -eq '1')
            stagedActivated  = [bool]((Test-BridgeMapHasKey -Map $networkState -Key 'staged_activated') -and [string]$networkState['staged_activated'] -eq '1')
            fallbackSafe     = [bool]((Test-BridgeMapHasKey -Map $networkState -Key 'fallback_safe') -and [string]$networkState['fallback_safe'] -eq '1')
            watcherPid       = $watcherPidText
            watcherHeartbeat = $(if (Test-BridgeMapHasKey -Map $networkState -Key 'watcher_last_heartbeat') { [string]$networkState['watcher_last_heartbeat'] } else { '' })
            watcherRunning   = [bool](Test-ProcessRunning -ProcessIdText $watcherPidText)
        }
        settings     = [ordered]@{
            dxvkMode         = [string]$settings.dxvkMode
            uploadDir        = $settings.uploadDir
            includeLarge     = [bool]$settings.includeLarge
            networkStaged    = [bool]$settings.networkStaged
            networkAutoApply = [bool]$settings.networkAutoApply
            experimentalFullLog = [bool]$settings.experimentalFullLog
            directGameLaunch = [bool]$settings.directGameLaunch
            skipCharacterSelection = [bool]$settings.skipCharacterSelection
            autoCheckUpdatesOnStartup = [bool]$settings.autoCheckUpdatesOnStartup
            closeVkPlayAfterGameExit = [bool]$settings.closeVkPlayAfterGameExit
            uiSpamGuard = [bool]$settings.uiSpamGuard
            clientMitigation = [bool]$settings.clientMitigation
            serverPreflight = [bool]$settings.serverPreflight
            disableIntroMovies = [bool]$settings.disableIntroMovies
            trafficBudgetShield = [bool]$settings.trafficBudgetShield
            trafficBudgetShieldLimitParsec = [bool]$settings.trafficBudgetShieldLimitParsec
        }
        baseline     = [ordered]@{
            path   = $baselineDir
            exists = [bool](Test-Path -LiteralPath $baselineDir)
        }
        pvpRecovery  = $pvpRecoveryStatus
        userConfig   = $userConfigStatus
        gpuProfiles  = $gpuProfileStatus
        uiGuard      = $uiGuardStatus
        license      = $license
        updates      = $updateStatus
        lastCapture        = $(if ($lastCapture) { $lastCapture } else { '' })
        latestCaptureFolder = $(if ($Lightweight) { '' } else { Get-LatestCaptureFolder -LauncherRoot $ResolvedLauncherRoot })
        logs         = [ordered]@{
            launcherLogPath = $launcherLogPath
            launcherTail    = $(if ($Lightweight) { '' } else { Get-FileTailText -Path $launcherLogPath -Lines 120 })
            networkLogPath  = $networkLogPath
            networkTail     = $(if ($Lightweight) { '' } else { Get-FileTailText -Path $networkLogPath -Lines 90 })
        }
    }


    return $payload
}


function Invoke-ProcessAndWait {
    param(
        [string]$FilePath,
        [string[]]$Arguments,
        [switch]$HiddenWindow
    )

    $effectiveArguments = ConvertTo-EncodedPowerShellInvocationArguments -Arguments $Arguments
    $argumentString = ConvertTo-NativeArgumentString -Arguments $effectiveArguments
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $FilePath
    $startInfo.Arguments = $argumentString
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = [bool]$HiddenWindow
    $startInfo.RedirectStandardOutput = $false
    $startInfo.RedirectStandardError = $false

    try {
        $workingDir = Split-Path -Parent $FilePath
        if ($workingDir -and (Test-Path -LiteralPath $workingDir)) {
            $startInfo.WorkingDirectory = $workingDir
        }
    } catch {
    }

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $startInfo
    [void]$proc.Start()
    $proc.WaitForExit()
    return $proc.ExitCode
}

function Invoke-ApplyGpuProfileSettingsIfEnabled {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir,
        [switch]$Force,
        [switch]$ForceHardwareRefresh
    )

    if (-not (Get-Command -Name Apply-RevelationGpuProfileSettings -ErrorAction SilentlyContinue)) {
        return [ordered]@{ ok = $true; applied = $false; message = 'GPU Profile Lab module missing.' }
    }

    try {
        return (Apply-RevelationGpuProfileSettings -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $ResolvedGameDir -Force:$Force -ForceHardwareRefresh:$ForceHardwareRefresh)
    } catch {
        return [ordered]@{ ok = $false; applied = $false; message = $_.Exception.Message }
    }
}

function Add-GpuApplyRestartRequirement {
    param(
        [System.Collections.IDictionary]$Result,
        [string]$ResolvedGameDir
    )

    if ($null -eq $Result) {
        return $Result
    }

    $gameRuntime = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    $status = Get-BridgeObjectPropertyValue -Object $Result -Name 'status' -Default $null
    $dxvk = Get-BridgeObjectPropertyValue -Object $status -Name 'dxvk' -Default $null
    $runtimeCapText = [string](Get-BridgeObjectPropertyValue -Object $dxvk -Name 'runtimeCap' -Default '')
    $runtimeCap = 0
    [void][int]::TryParse($runtimeCapText, [ref]$runtimeCap)
    $runtimeCurrent = [bool](Get-BridgeObjectPropertyValue -Object $dxvk -Name 'runtimeCurrent' -Default $false)
    $capEnabled = [bool](Get-BridgeObjectPropertyValue -Object $status -Name 'capEnabled' -Default $false)
    $limiterProvider = [string](Get-BridgeObjectPropertyValue -Object $status -Name 'limiterProvider' -Default 'legacy')
    $pendingCap = if ($capEnabled) { [int](Get-BridgeObjectPropertyValue -Object $status -Name 'effectiveFpsCap' -Default 0) } else { 0 }
    $pendingDxvkCap = if ($limiterProvider -eq 'dxvk_config') { $pendingCap } else { 0 }
    $dxvkRestartRequired = if (-not [bool]$gameRuntime.running) {
        $false
    } elseif ($limiterProvider -eq 'dxvk_config') {
        [bool]((-not $runtimeCurrent) -or $runtimeCap -ne $pendingDxvkCap)
    } else {
        [bool]($runtimeCurrent -and $runtimeCap -ne 0)
    }
    $externalLimiterChanged = [bool]($gameRuntime.running -and
        $limiterProvider -in @('nvidia_profile_inspector', 'amd_adlx_frtc') -and
        [bool](Get-BridgeObjectPropertyValue -Object $Result -Name 'applied' -Default $false) -and
        -not [bool](Get-BridgeObjectPropertyValue -Object $Result -Name 'cached' -Default $false))
    $engine = Get-BridgeObjectPropertyValue -Object $Result -Name 'engine' -Default $null
    $engineStatus = Get-BridgeObjectPropertyValue -Object $status -Name 'engine' -Default $null
    $engineChanged = [bool](Get-BridgeObjectPropertyValue -Object $engine -Name 'applied' -Default $false)
    $engineSupported = [bool](Get-BridgeObjectPropertyValue -Object $engineStatus -Name 'supported' -Default $false)
    $engineAligned = [bool](Get-BridgeObjectPropertyValue -Object $engineStatus -Name 'aligned' -Default $true)
    $engineTarget = [int](Get-BridgeObjectPropertyValue -Object $engineStatus -Name 'targetCeiling' -Default 300)
    $engineRestartRequired = [bool]($gameRuntime.running -and ($engineChanged -or ($engineSupported -and -not $engineAligned)))
    $restartRequired = [bool]($dxvkRestartRequired -or $externalLimiterChanged -or $engineRestartRequired)

    $Result['restartRequired'] = $restartRequired
    $Result['activeFpsCap'] = $runtimeCap
    $Result['pendingFpsCap'] = $pendingCap
    $Result['engineCeilingChanged'] = $engineChanged
    $Result['engineFpsCeiling'] = $engineTarget
    if ($restartRequired) {
        $message = [string](Get-BridgeObjectPropertyValue -Object $Result -Name 'message' -Default 'GPU-профиль сохранён.')
        $restartNotes = New-Object System.Collections.Generic.List[string]
        if ($engineRestartRequired) {
            $restartNotes.Add('Внутренний потолок игры поднят до ' + [string]$engineTarget + ' FPS; текущая сессия применит его после полного перезапуска.')
        }
        if ($dxvkRestartRequired) {
            $targetText = if ($pendingCap -gt 0) { [string]$pendingCap + ' FPS' } else { 'режим без ограничения' }
            if ($runtimeCurrent) {
                $restartNotes.Add('Текущая игра продолжает использовать DXVK cap ' + [string]$runtimeCap + ' FPS; ' + $targetText + ' включится после релога.')
            } else {
                $restartNotes.Add('Текущая игра уже запущена, поэтому ' + $targetText + ' будет подтверждён после релога.')
            }
        }
        $Result['message'] = $message + ' ' + [string]::Join(' ', $restartNotes)
    }

    return $Result
}

function Get-VkPlayExitWatcherProcesses {
    param([string]$ResolvedLauncherRoot)

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    $escapedStateDir = [regex]::Escape($stateDir)
    try {
        return @(
            Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction Stop |
                Where-Object {
                    $_.Name -in @('powershell.exe', 'pwsh.exe') -and
                    $_.CommandLine -and
                    ($_.CommandLine -match 'vkplay-exit-watch-.*\.ps1') -and
                    ($_.CommandLine -match $escapedStateDir)
                }
        )
    } catch {
        return @()
    }
}

function Stop-VkPlayExitWatcherProcesses {
    param([string]$ResolvedLauncherRoot, [AllowEmptyCollection()][object[]]$Watchers)

    if (-not $PSBoundParameters.ContainsKey('Watchers')) {
        $Watchers = @(Get-VkPlayExitWatcherProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot)
    }
    foreach ($watcher in $Watchers) {
        try {
            Stop-Process -Id $watcher.ProcessId -Force -ErrorAction SilentlyContinue
        } catch {
        }
    }
}

function Stop-VkPlayProcesses {
    param([string]$Reason = '')

    $stopped = New-Object System.Collections.Generic.List[object]
    foreach ($name in @('BrowserProxy', 'GameCenter')) {
        foreach ($proc in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            try {
                Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
                [void]$stopped.Add([ordered]@{
                    name   = $name
                    pid    = [int]$proc.Id
                    reason = [string]$Reason
                })
            } catch {
            }
        }
    }

    return @($stopped.ToArray())
}

function Get-VkPlayProcessSnapshot {
    param([string]$Reason = '')

    $preserved = New-Object System.Collections.Generic.List[object]
    foreach ($name in @('BrowserProxy', 'GameCenter')) {
        foreach ($proc in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            $path = ''
            try {
                $path = [string]$proc.Path
            } catch {
                $path = ''
            }

            [void]$preserved.Add([ordered]@{
                name            = [string]$name
                pid             = [int]$proc.Id
                mainWindowTitle = [string]$proc.MainWindowTitle
                path            = $path
                reason          = [string]$Reason
            })
        }
    }

    return [ordered]@{
        ok             = $true
        skipped        = $true
        gameRunning    = $false
        stopped        = @()
        stoppedCount   = 0
        preserved      = @($preserved.ToArray())
        preservedCount = [int]$preserved.Count
        reason         = [string]$Reason
        message        = $(if ($preserved.Count -gt 0) { 'VK Play оставлен для быстрого повторного запуска.' } else { 'VK Play не найден; relog продолжит повторный запуск.' })
    }
}

function Invoke-StartupVkPlayCleanup {
    param([string]$ResolvedLauncherRoot)

    $resolvedGameRoot = ''
    $resolvedGameDir = ''
    $gameExePath = ''
    try {
        $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
        $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
        $gameExePath = Join-Path $resolvedGameDir 'tianyu.exe'
    } catch {
        $resolvedGameRoot = ''
        $resolvedGameDir = ''
        $gameExePath = ''
    }

    $primaryGameRuntime = if ($gameExePath) {
        Get-ProcessRuntimeStatus -ProcessName 'tianyu.exe' -ExpectedPath $gameExePath
    } else {
        Get-ProcessRuntimeStatus -ProcessName 'tianyu.exe'
    }
    $gameRuntime = if ([bool]$primaryGameRuntime.running) {
        $primaryGameRuntime
    } elseif ($resolvedGameDir) {
        Get-RevelationGameRuntimeStatus -ResolvedGameDir $resolvedGameDir
    } else {
        Get-RevelationGameRuntimeStatus
    }
    $gameRunning = [bool]$gameRuntime.running
    if ($gameRunning) {
        return [ordered]@{
            ok            = $true
            skipped       = $true
            gameRunning   = [bool]$gameRuntime.running
            stopped       = @()
            stoppedCount  = 0
            game          = $gameRuntime
            gameRoot      = $resolvedGameRoot
            gameDir       = $resolvedGameDir
            message       = 'Игра уже запущена. VK Play оставлен.'
        }
    }

    $stopped = @(Stop-VkPlayProcesses -Reason 'launcher_startup_no_game')
    return [ordered]@{
        ok            = $true
        skipped       = $false
        gameRunning   = [bool]$gameRuntime.running
        stopped       = $stopped
        stoppedCount  = [int]$stopped.Count
        game          = $gameRuntime
        gameRoot      = $resolvedGameRoot
        gameDir       = $resolvedGameDir
        message       = $(if ($stopped.Count -gt 0) { 'VK Play закрыт перед стартом лаунчера, игра не была запущена.' } else { 'VK Play не был запущен.' })
    }
}

function Invoke-GameExitVkPlayCleanup {
    param([string]$ResolvedLauncherRoot)

    $resolvedGameRoot = ''
    $resolvedGameDir = ''
    try {
        $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
        $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
    } catch {
        $resolvedGameRoot = ''
        $resolvedGameDir = ''
    }

    $gameRuntime = if ($resolvedGameDir) {
        Get-RevelationGameRuntimeStatus -ResolvedGameDir $resolvedGameDir
    } else {
        Get-RevelationGameRuntimeStatus
    }
    if ([bool]$gameRuntime.running) {
        return [ordered]@{
            ok           = $true
            skipped      = $true
            gameRunning  = $true
            stopped      = @()
            stoppedCount = 0
            game         = $gameRuntime
            gameRoot     = $resolvedGameRoot
            gameDir      = $resolvedGameDir
            message      = 'Игра ещё запущена. VK Play оставлен.'
        }
    }

    $gameBridgeCleanup = [ordered]@{ ok = $true; skipped = $true }
    if ($resolvedGameDir) {
        $gameBridgeHelper = Join-Path $ResolvedLauncherRoot 'tools\RevelationGameBridge.ps1'
        if (Test-Path -LiteralPath $gameBridgeHelper) {
            try {
                . $gameBridgeHelper
                Stop-RevelationGameBridgeSession -LauncherRoot $ResolvedLauncherRoot -GameDir $resolvedGameDir -Restore
                $gameBridgeCleanup = [ordered]@{ ok = $true; skipped = $false }
            } catch {
                $gameBridgeCleanup = [ordered]@{ ok = $false; skipped = $false; message = $_.Exception.Message }
            }
        }
    }

    $uiGuardRepair = [ordered]@{ ok = $true; skipped = $true; changed = $false; message = 'Настройки отображения изменяются только по отдельной команде.' }

    Stop-VkPlayExitWatcherProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
    $stopped = @(Stop-VkPlayProcesses -Reason 'game_exit_no_game')
    return [ordered]@{
        ok           = $true
        skipped      = $false
        gameRunning  = $false
        stopped      = $stopped
        stoppedCount = [int]$stopped.Count
        game         = $gameRuntime
        gameRoot     = $resolvedGameRoot
        gameDir      = $resolvedGameDir
        uiGuardRepair = $uiGuardRepair
        gameBridgeCleanup = $gameBridgeCleanup
        message      = $(if ($stopped.Count -gt 0) { 'VK Play закрыт после выхода из игры.' } else { 'Игра закрыта; процессы VK Play не найдены.' })
    }
}

function Get-BridgeGameProcesses {
    param([string]$ResolvedGameDir = '')

    $processes = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    foreach ($processName in (Get-RevelationGameProcessNames)) {
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension([string]$processName)
        foreach ($proc in @(Get-Process -Name $baseName -ErrorAction SilentlyContinue)) {
            if ($seen.ContainsKey([int]$proc.Id)) {
                continue
            }

            $include = $true
            if ($ResolvedGameDir) {
                try {
                    $processPath = [string]$proc.Path
                    if ($processPath) {
                        $processDir = [System.IO.Path]::GetDirectoryName($processPath)
                        $include = (([System.IO.Path]::GetFullPath($processDir).TrimEnd('\')) -ieq ([System.IO.Path]::GetFullPath($ResolvedGameDir).TrimEnd('\')))
                    }
                } catch {
                    $include = $true
                }
            }

            if ($include) {
                $seen[[int]$proc.Id] = $true
                [void]$processes.Add($proc)
            }
        }
    }

    return @($processes.ToArray())
}

function Get-BridgeGameCenterDisconnectCheckpoint {
    $path = ''
    if ($env:LOCALAPPDATA) {
        $candidate = Join-Path $env:LOCALAPPDATA 'GameCenter\main.log'
        if (Test-Path -LiteralPath $candidate) {
            $path = $candidate
        }
    }

    $length = [int64]0
    $lastWriteTimeUtc = $null
    if ($path) {
        try {
            $item = Get-Item -LiteralPath $path -ErrorAction Stop
            $length = [int64]$item.Length
            $lastWriteTimeUtc = $item.LastWriteTimeUtc.ToString('o')
        } catch {
            $path = ''
            $length = [int64]0
        }
    }

    return [ordered]@{
        path             = [string]$path
        available        = [bool]$path
        offset           = $length
        lastWriteTimeUtc = $lastWriteTimeUtc
        capturedAtUtc    = (Get-Date).ToUniversalTime().ToString('o')
    }
}

function Read-BridgeFileAppendText {
    param(
        [string]$Path,
        [int64]$Offset = 0
    )

    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) {
        return ''
    }

    $stream = $null
    $reader = $null
    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
        )
        $safeOffset = [Math]::Max([int64]0, [int64]$Offset)
        if ($safeOffset -gt [int64]$stream.Length) {
            $safeOffset = [int64]0
        }
        [void]$stream.Seek($safeOffset, [System.IO.SeekOrigin]::Begin)
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8, $true, 4096, $true)
        return [string]$reader.ReadToEnd()
    } catch {
        return ''
    } finally {
        if ($null -ne $reader) {
            $reader.Dispose()
        }
        if ($null -ne $stream) {
            $stream.Dispose()
        }
    }
}

function Wait-BridgeGameSessionRelease {
    param(
        [int[]]$ProcessIds = @(),
        $DisconnectCheckpoint = $null,
        [int]$TimeoutSec = 5,
        [int]$SettleMilliseconds = 1800
    )

    $startedAt = Get-Date
    $disconnectPids = New-Object System.Collections.Generic.List[int]
    $logAvailable = [bool]($null -ne $DisconnectCheckpoint -and [bool]$DisconnectCheckpoint.available -and [string]$DisconnectCheckpoint.path)
    $deadline = (Get-Date).AddSeconds([Math]::Max(1, $TimeoutSec))
    $processGone = $false

    while ((Get-Date) -lt $deadline) {
        $runningPids = @(
            foreach ($pidValue in @($ProcessIds)) {
                if (Get-Process -Id ([int]$pidValue) -ErrorAction SilentlyContinue) {
                    [int]$pidValue
                }
            }
        )
        $processGone = ($runningPids.Count -eq 0)

        if ($logAvailable) {
            $appendedText = Read-BridgeFileAppendText -Path ([string]$DisconnectCheckpoint.path) -Offset ([int64]$DisconnectCheckpoint.offset)
            foreach ($pidValue in @($ProcessIds)) {
                if ($disconnectPids.Contains([int]$pidValue)) {
                    continue
                }
                $disconnectPattern = 'OnClientClientDisconnect called for GameId:\s*0\.1000146 ProcessId:\s*{0}(?:\D|$)' -f [regex]::Escape([string][int]$pidValue)
                if ($appendedText -match $disconnectPattern) {
                    [void]$disconnectPids.Add([int]$pidValue)
                }
            }
        }

        if ($processGone -and ((-not $logAvailable) -or $disconnectPids.Count -gt 0)) {
            break
        }
        Start-Sleep -Milliseconds 200
    }

    if ($processGone -and $SettleMilliseconds -gt 0) {
        Start-Sleep -Milliseconds ([Math]::Min(5000, [Math]::Max(0, $SettleMilliseconds)))
    }

    return [ordered]@{
        ready                = [bool]$processGone
        processGone          = [bool]$processGone
        processIds           = @($ProcessIds)
        logAvailable         = [bool]$logAvailable
        logPath              = $(if ($logAvailable) { [string]$DisconnectCheckpoint.path } else { '' })
        disconnectObserved   = [bool]($disconnectPids.Count -gt 0)
        disconnectPids       = @($disconnectPids.ToArray())
        waitedMs             = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
        settleMilliseconds   = $(if ($processGone) { [int]$SettleMilliseconds } else { 0 })
        message              = $(if (-not $processGone) {
                'Старый игровой процесс всё ещё активен.'
            } elseif ($disconnectPids.Count -gt 0) {
                'GameCenter подтвердил отключение старого игрового процесса.'
            } elseif ($logAvailable) {
                'Старый игровой процесс закрыт; событие GameCenter не появилось до таймаута, выполнена защитная пауза.'
            } else {
                'Старый игровой процесс закрыт; журнал GameCenter недоступен, выполнена защитная пауза.'
            })
    }
}

function Set-BridgeGameProcessForeground {
    param($Process)

    Ensure-BridgeWindowInputType
    $handle = [IntPtr]([int64]$Process.MainWindowHandle)
    if ([int64]$handle -eq 0) {
        return [ordered]@{
            focused         = $false
            foregroundMatch = $false
            foregroundPid   = 0
            handle          = 0
        }
    }

    if ([RevelationLauncher.WindowInput]::IsIconic($handle)) {
        [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 9)
    } else {
        [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 5)
    }
    Start-Sleep -Milliseconds 120
    $focused = [bool][RevelationLauncher.WindowInput]::SetForegroundWindow($handle)
    Start-Sleep -Milliseconds 180
    $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
    $foregroundPid = [uint32]0
    if ([int64]$foreground -ne 0) {
        [void][RevelationLauncher.WindowInput]::GetWindowThreadProcessId($foreground, [ref]$foregroundPid)
    }

    return [ordered]@{
        focused         = [bool]$focused
        foregroundMatch = [bool]([int]$foregroundPid -eq [int]$Process.Id)
        foregroundPid   = [int]$foregroundPid
        foreground      = [int64]$foreground
        handle          = [int64]$Process.MainWindowHandle
    }
}

function Send-BridgeGameInteractiveExitRequest {
    param(
        [string]$ResolvedGameDir = '',
        [int]$MaxConfirmAttempts = 2
    )

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir | Where-Object { [int64]$_.MainWindowHandle -ne 0 })
    $proc = $(if ($processes.Count -gt 0) { $processes[0] } else { $null })
    if ($null -eq $proc) {
        return [ordered]@{
            sent                  = $false
            focused               = $false
            foregroundMatch       = $false
            backgroundMessageSent = $false
            delivery              = 'none'
            reason                = 'graceful_exit_interactive'
            pid                   = 0
            handle                = 0
            altF4InputCount       = 0
            confirmAttempts       = @()
            processExited         = $true
            message               = 'Окно игры уже закрыто или недоступно для штатного выхода.'
        }
    }

    $attempts = New-Object System.Collections.Generic.List[object]
    $initialFocus = $null
    $altF4InputTotal = 0
    $confirmationInputTotal = 0
    try {
        Ensure-BridgeWindowInputType
        $initialFocus = Set-BridgeGameProcessForeground -Process $proc
        if (-not [bool]$initialFocus.foregroundMatch) {
            return [ordered]@{
                sent                  = $false
                focused               = [bool]$initialFocus.focused
                foregroundMatch       = $false
                foregroundPid         = [int]$initialFocus.foregroundPid
                backgroundMessageSent = $false
                delivery              = 'none'
                reason                = 'graceful_exit_interactive'
                pid                   = [int]$proc.Id
                handle                = [int64]$proc.MainWindowHandle
                altF4InputCount       = 0
                confirmAttempts       = @()
                processExited         = $false
                message               = 'Релог остановлен: окно игры не стало активным, команда выхода не отправлена.'
            }
        }

        for ($attemptNumber = 1; $attemptNumber -le [Math]::Max(1, $MaxConfirmAttempts); $attemptNumber++) {
            $currentProcess = Get-Process -Id ([int]$proc.Id) -ErrorAction SilentlyContinue
            if ($null -eq $currentProcess) {
                break
            }

            $focus = Set-BridgeGameProcessForeground -Process $currentProcess
            if (-not [bool]$focus.foregroundMatch) {
                [void]$attempts.Add([ordered]@{
                    attempt          = [int]$attemptNumber
                    foregroundMatch  = $false
                    altF4InputCount  = 0
                    yesInputCount    = 0
                    leftInputCount   = 0
                    enterInputCount  = 0
                    processExited    = $false
                })
                break
            }

            $altF4InputCount = [int][RevelationLauncher.WindowInput]::SendAltF4ScanCode()
            $altF4InputTotal += $altF4InputCount
            Start-Sleep -Milliseconds 900
            $processExited = ($null -eq (Get-Process -Id ([int]$proc.Id) -ErrorAction SilentlyContinue))
            $yesInputCount = 0
            $leftInputCount = 0
            $enterInputCount = 0

            if (-not $processExited -and $altF4InputCount -eq 4) {
                $yesInputCount = [int][RevelationLauncher.WindowInput]::SendScanCodeKey([uint16]0x15, $false)
                $confirmationInputTotal += $yesInputCount
                Start-Sleep -Milliseconds 1100
                $processExited = ($null -eq (Get-Process -Id ([int]$proc.Id) -ErrorAction SilentlyContinue))
            }

            if (-not $processExited -and $altF4InputCount -eq 4) {
                $confirmFocus = Set-BridgeGameProcessForeground -Process (Get-Process -Id ([int]$proc.Id) -ErrorAction SilentlyContinue)
                if ([bool]$confirmFocus.foregroundMatch) {
                    $leftInputCount = [int][RevelationLauncher.WindowInput]::SendScanCodeKey([uint16]0x4B, $true)
                    Start-Sleep -Milliseconds 120
                    $enterInputCount = [int][RevelationLauncher.WindowInput]::SendScanCodeKey([uint16]0x1C, $false)
                    $confirmationInputTotal += ($leftInputCount + $enterInputCount)
                    Start-Sleep -Milliseconds 1400
                    $processExited = ($null -eq (Get-Process -Id ([int]$proc.Id) -ErrorAction SilentlyContinue))
                }
            }

            [void]$attempts.Add([ordered]@{
                attempt          = [int]$attemptNumber
                foregroundMatch  = [bool]$focus.foregroundMatch
                foregroundPid    = [int]$focus.foregroundPid
                altF4InputCount  = [int]$altF4InputCount
                yesInputCount    = [int]$yesInputCount
                leftInputCount   = [int]$leftInputCount
                enterInputCount  = [int]$enterInputCount
                processExited    = [bool]$processExited
            })
            if ($processExited) {
                break
            }
        }

        $processExited = ($null -eq (Get-Process -Id ([int]$proc.Id) -ErrorAction SilentlyContinue))
        $sent = [bool]($altF4InputTotal -ge 4)
        return [ordered]@{
            sent                  = $sent
            focused               = [bool]$initialFocus.focused
            foregroundMatch       = [bool]$initialFocus.foregroundMatch
            foregroundPid         = [int]$initialFocus.foregroundPid
            backgroundMessageSent = $false
            delivery              = $(if ($sent) { 'foreground_sendinput_scancode' } else { 'none' })
            reason                = 'graceful_exit_interactive'
            pid                   = [int]$proc.Id
            handle                = [int64]$proc.MainWindowHandle
            altF4InputCount       = [int]$altF4InputTotal
            confirmationInputCount = [int]$confirmationInputTotal
            confirmAttempts       = @($attempts.ToArray())
            processExited         = [bool]$processExited
            message               = $(if ($processExited) {
                    'Игра приняла штатную команду выхода и завершила процесс.'
                } elseif ($sent) {
                    'Штатная команда выхода отправлена; ожидается завершение игрового процесса.'
                } else {
                    'Windows не доставила полную последовательность Alt+F4 в окно игры.'
                })
        }
    } catch {
        return [ordered]@{
            sent                  = $false
            focused               = [bool]($null -ne $initialFocus -and [bool]$initialFocus.focused)
            foregroundMatch       = [bool]($null -ne $initialFocus -and [bool]$initialFocus.foregroundMatch)
            backgroundMessageSent = $false
            delivery              = 'none'
            reason                = 'graceful_exit_interactive'
            pid                   = [int]$proc.Id
            handle                = [int64]$proc.MainWindowHandle
            altF4InputCount       = [int]$altF4InputTotal
            confirmationInputCount = [int]$confirmationInputTotal
            confirmAttempts       = @($attempts.ToArray())
            processExited         = $false
            error                 = $_.Exception.Message
            message               = 'Не удалось выполнить штатный выход из игры: ' + $_.Exception.Message
        }
    }
}

# Canary replaces the legacy menu driver with the verified game callbacks.
function Invoke-BridgeRecognizedGameExit {
    param([string]$ResolvedLauncherRoot, [string]$ResolvedGameDir)
    . (Join-Path $ResolvedLauncherRoot 'tools/RevelationGameBridge.ps1')
    if (-not (Test-RevelationGameBridgeChannel -LauncherRoot $ResolvedLauncherRoot)) {
        throw 'Не найдены параметры игрового модуля. Повторите установку канарейки.'
    }
    $targets = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir)
    if ($targets.Count -ne 1) { throw 'Для релога должна быть запущена одна игра из выбранной папки.' }
    Set-BridgeOperationPhase -Phase 'waiting_for_game_exit' -Cancellable $true -Message 'Выход через игровой модуль.'
    $result = Invoke-RevelationFastGameExit -LauncherRoot $ResolvedLauncherRoot -GameDir $ResolvedGameDir -GameProcessId ([int]$targets[0].Id) -IsCancelled { Test-BridgeOperationCancelled }
    if (-not $result.ok -and -not $result.cancelled) {
        throw ('Игровой модуль не подтвердил выход. Полностью закройте игру и запустите её через эту канарейку. Причина: ' + $result.reason)
    }
    return $result
}

function Restore-CanaryLegacyModule {
    param([string]$LauncherRoot,[string]$GameDir)
    if (@(Get-RevelationGameBridgeProcesses -GameDir $GameDir).Count) { throw 'legacy_module_client_running' }
    $active=Join-Path $GameDir 'version.dll'
    $legacy=Join-Path $LauncherRoot 'tools/RevelationLatencyProxy.dll'
    if (-not (Test-Path -LiteralPath $active -PathType Leaf) -or -not (Test-Path -LiteralPath $legacy -PathType Leaf)) { return }
    if ((Get-RevelationGameBridgeSha256 -Path $active) -ne (Get-RevelationGameBridgeSha256 -Path $legacy)) { return }
    # Only retire our exact legacy binary. Preserve it for rollback and leave
    # unknown DLLs to the existing ownership/integrity checks.
    $backup=Join-Path $GameDir 'version.dll.revelation-launcher-backup'
    $retired=Join-Path $GameDir ('version.dll.canary-legacy-'+[guid]::NewGuid().ToString('N')+'.backup')
    if (Test-Path -LiteralPath $backup -PathType Leaf) {
        [IO.File]::Replace($backup,$active,$retired)
    } else {
        [IO.File]::Move($active,$retired)
    }
}


function Stop-BridgeGameProcessesGracefully {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir = '',
        [string]$Reason = 'recognized_menu_exit',
        [int]$GracefulTimeoutSec = 90
    )

    $before = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    if (-not [bool]$before.running) {
        return [ordered]@{
            ok                = $true
            runningBefore     = $false
            fastRelog         = $true
            gracefulRequested = $false
            graceful          = $true
            cancelled         = $false
            manualExitRequired = $false
            interactiveExit   = $null
            sessionRelease    = [ordered]@{
                ready              = $true
                processGone        = $true
                disconnectObserved = $false
                skipped            = $true
                message            = 'Старая игровая сессия отсутствует.'
            }
            closeRequests     = @()
            forced            = @()
            forcedCount       = 0
            reason            = [string]$Reason
            after             = $before
            message           = 'Игра не была запущена.'
        }
    }

    $oldProcesses = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir)
    $oldProcessIds = @($oldProcesses | ForEach-Object { [int]$_.Id })
    $disconnectCheckpoint = Get-BridgeGameCenterDisconnectCheckpoint

    $deadline = (Get-Date).AddSeconds([Math]::Max(5, $GracefulTimeoutSec))
    $interactiveExit = Invoke-BridgeRecognizedGameExit -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $ResolvedGameDir
    Write-BridgeOperationJson -Path (Join-Path $ResolvedLauncherRoot '.revelation-combat\last-game-exit.json') -Value $interactiveExit
    $manualExitRequired = [bool]$interactiveExit.manualExitRequired
    if ($manualExitRequired) {
        $fallbackMessage = switch ([string]$interactiveExit.reason) {
            'ocr_language_unavailable' { 'В Windows нет русского распознавания текста. Штатно выйди из игры через игровое меню.' }
            'focus_lost' { 'Фокус игры потерян. Автоматические клики остановлены; штатно выйди через игровое меню.' }
            'user_moved_pointer' { 'Обнаружено управление мышью. Автоматические клики остановлены; штатно выйди через игровое меню.' }
            default { 'Меню выхода не подтверждено. Штатно выйди из игры через игровое меню; принудительного закрытия не будет.' }
        }
        Set-BridgeOperationPhase -Phase 'waiting_for_manual_exit' -Cancellable $true -Message $fallbackMessage
    } elseif ([bool]$interactiveExit.countdownObserved) {
        Set-BridgeOperationPhase -Phase 'waiting_for_exit_countdown' -Cancellable $true
    } else {
        Set-BridgeOperationPhase -Phase 'waiting_for_game_exit' -Cancellable $true
    }
    $after = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    $cancelled = [bool]$interactiveExit.cancelled
    while ([bool]$after.running -and (Get-Date) -lt $deadline) {
        if ($cancelled -or (Test-BridgeOperationCancelled)) {
            $cancelled = $true
            break
        }
        Start-Sleep -Milliseconds 250
        $after = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    }

    if (-not $cancelled -and (Test-BridgeOperationCancelled)) {
        $cancelled = $true
    }

    $graceful = [bool](-not $cancelled -and -not [bool]$after.running)
    $sessionRelease = $null
    if ($graceful) {
        Set-BridgeOperationPhase -Phase 'verifying_session_release' -Cancellable $true
        $sessionRelease = Wait-BridgeGameSessionRelease `
            -ProcessIds $oldProcessIds `
            -DisconnectCheckpoint $disconnectCheckpoint `
            -TimeoutSec 8 `
            -SettleMilliseconds 1800
        if (Test-BridgeOperationCancelled) {
            $cancelled = $true
            $graceful = $false
        }
    } else {
        $sessionRelease = [ordered]@{
            ready              = $false
            processGone        = [bool](-not [bool]$after.running)
            processIds         = @($oldProcessIds)
            logAvailable       = [bool]$disconnectCheckpoint.available
            logPath            = [string]$disconnectCheckpoint.path
            disconnectObserved = $false
            disconnectPids     = @()
            waitedMs           = 0
            settleMilliseconds = 0
            message            = $(if ($cancelled) { 'Ожидание штатного выхода отменено пользователем.' } else { 'Сессия не освобождена: старый игровой процесс всё ещё активен.' })
        }
    }

    return [ordered]@{
        ok                = [bool]($graceful -and -not $cancelled)
        runningBefore     = $true
        fastRelog         = $true
        gracefulRequested = $true
        graceful          = $graceful
        cancelled         = [bool]$cancelled
        manualExitRequired = $manualExitRequired
        interactiveExit   = $interactiveExit
        sessionRelease    = $sessionRelease
        closeRequests     = @()
        forced            = @()
        forcedCount       = 0
        reason            = [string]$Reason
        after             = $after
        message           = $(if ($cancelled) {
                'Релог остановлен пользователем. Повторного запуска не будет. Уже отправленный штатный выход может завершиться.'
            } elseif ($graceful -and [bool]$sessionRelease.disconnectObserved) {
                'Релог: игра завершена штатно, GameCenter подтвердил отключение старого процесса.'
            } elseif ($graceful) {
                'Релог: игра завершена штатно; перед повторным входом выполнена защитная пауза.'
            } else {
                'Релог остановлен: за 90 секунд игра не была закрыта через игровое меню. Принудительное закрытие не выполнялось.'
            })
    }
}

function Stop-BridgeGameProcessesForcefully {
    param(
        [string]$ResolvedGameDir = '',
        [string]$Reason = 'relog_force_game'
    )

    $before = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    if (-not [bool]$before.running) {
        return [ordered]@{
            ok                = $true
            runningBefore     = $false
            fastRelog         = $true
            gracefulRequested = $false
            interactiveExit   = $null
            closeRequests     = @()
            forced            = @()
            forcedCount       = 0
            reason            = [string]$Reason
            after             = $before
            message           = 'Игра не была запущена.'
        }
    }

    $forced = New-Object System.Collections.Generic.List[object]
    foreach ($proc in @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir)) {
        try {
            Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
            [void]$forced.Add([ordered]@{
                pid    = [int]$proc.Id
                name   = [string]$proc.ProcessName
                reason = [string]$Reason
            })
        } catch {
        }
    }

    $deadline = (Get-Date).AddSeconds(10)
    $after = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    while ([bool]$after.running -and (Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 250
        $after = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    }

    return [ordered]@{
        ok                = [bool](-not [bool]$after.running)
        runningBefore     = $true
        fastRelog         = $true
        gracefulRequested = $false
        interactiveExit   = $null
        closeRequests     = @()
        forced            = @($forced.ToArray())
        forcedCount       = [int]$forced.Count
        reason            = [string]$Reason
        after             = $after
        message           = $(if (-not [bool]$after.running) { 'Релог: игровой процесс завершён принудительно.' } else { 'Релог: не удалось завершить игровой процесс.' })
    }
}

function Wait-BridgeGameProcessStart {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 45,
        [int]$PollMilliseconds = 1000
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(1, $TimeoutSec))
    $runtime = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    while (-not [bool]$runtime.running -and (Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds ([Math]::Max(250, $PollMilliseconds))
        $runtime = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
    }

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        running      = [bool]$runtime.running
        pid          = [int]$runtime.pid
        path         = [string]$runtime.path
        processCount = [int]$runtime.processCount
        elapsedMs    = $elapsedMs
        timeoutSec   = [int]$TimeoutSec
        timedOut     = [bool](-not [bool]$runtime.running)
    }
}

function Get-BridgeGameTcpReadySnapshot {
    param([int[]]$Pids = @())

    $connections = New-Object System.Collections.Generic.List[object]
    foreach ($pidValue in @($Pids | Where-Object { $null -ne $_ -and [int]$_ -gt 0 })) {
        try {
            foreach ($tcp in @(Get-NetTCPConnection -OwningProcess ([int]$pidValue) -State Established -ErrorAction SilentlyContinue | Where-Object { [int]$_.RemotePort -eq 8766 })) {
                [void]$connections.Add([ordered]@{
                    pid           = [int]$pidValue
                    localAddress  = [string]$tcp.LocalAddress
                    localPort     = [int]$tcp.LocalPort
                    remoteAddress = [string]$tcp.RemoteAddress
                    remotePort    = [int]$tcp.RemotePort
                    state         = [string]$tcp.State
                })
            }
        } catch {
        }
    }

    return [ordered]@{
        ready           = [bool]($connections.Count -gt 0)
        connectionCount = [int]$connections.Count
        connections     = @($connections.ToArray())
    }
}

function Test-BridgeGameWindowTitleLooksInWorld {
    param([AllowNull()][string]$Title)

    $text = ([string]$Title).Trim()
    if (-not $text) {
        return $false
    }

    $match = [regex]::Match($text, '\[(?<inner>[^\]]+)\]')
    if (-not $match.Success) {
        return $false
    }

    $inner = ([string]$match.Groups['inner'].Value).Trim()
    if (-not $inner) {
        return $false
    }

    # Character select keeps only the server in the title. In-world title includes
    # extra identity fields, separated by ASCII punctuation even on mojibake titles.
    return [bool]($inner -match '[,@;]')
}

function Test-BridgeGameWindowTitleHasSelectionContext {
    param([AllowNull()][string]$Title)

    $text = ([string]$Title).Trim()
    if (-not $text) {
        return $false
    }

    return [bool]([regex]::IsMatch($text, '\[[^\]]+\]'))
}

function Get-BridgeGameCharacterSelectVisualSnapshot {
    param([int64]$Handle = 0)

    $base = [ordered]@{
        ok                           = $false
        reason                       = ''
        foregroundMatch              = $false
        handle                       = [int64]$Handle
        foreground                   = [int64]0
        characterSelectButtonVisible = $false
        goldPixelRatio               = 0.0
        goldPixels                   = 0
        samplePixels                 = 0
        sampleRect                   = $null
        windowRect                   = $null
    }

    if ($Handle -eq 0) {
        $base['reason'] = 'game_window_not_found'
        return $base
    }

    try {
        Ensure-BridgeWindowInputType
        $windowHandle = [IntPtr]$Handle
        $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
        $base['foreground'] = [int64]$foreground
        if ([int64]$foreground -ne [int64]$windowHandle) {
            $base['reason'] = 'game_window_not_foreground'
            return $base
        }
        $base['foregroundMatch'] = $true

        $rect = New-Object RevelationLauncher.WindowInput+RECT
        if (-not [RevelationLauncher.WindowInput]::GetWindowRect($windowHandle, [ref]$rect)) {
            $base['reason'] = 'game_window_rect_unavailable'
            return $base
        }

        $width = [Math]::Max(1, [int]($rect.Right - $rect.Left))
        $height = [Math]::Max(1, [int]($rect.Bottom - $rect.Top))
        $base['windowRect'] = [ordered]@{
            left   = [int]$rect.Left
            top    = [int]$rect.Top
            right  = [int]$rect.Right
            bottom = [int]$rect.Bottom
            width  = [int]$width
            height = [int]$height
        }

        if ($width -lt 240 -or $height -lt 180) {
            $base['reason'] = 'game_window_too_small_for_visual_probe'
            return $base
        }

        Add-Type -AssemblyName System.Drawing -ErrorAction Stop

        $sampleWidth = [int][Math]::Min(360, [Math]::Max(140, [Math]::Round($width * 0.16)))
        $sampleHeight = [int][Math]::Min(96, [Math]::Max(52, [Math]::Round($height * 0.075)))
        $bottomMargin = [int][Math]::Min(22, [Math]::Max(6, [Math]::Round($height * 0.012)))
        $sampleLeft = [int]($rect.Left + [Math]::Round(($width - $sampleWidth) / 2))
        $sampleTop = [int]($rect.Bottom - $bottomMargin - $sampleHeight)
        $base['sampleRect'] = [ordered]@{
            left   = [int]$sampleLeft
            top    = [int]$sampleTop
            width  = [int]$sampleWidth
            height = [int]$sampleHeight
        }

        $bitmap = New-Object System.Drawing.Bitmap -ArgumentList $sampleWidth, $sampleHeight
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        try {
            $graphics.CopyFromScreen($sampleLeft, $sampleTop, 0, 0, (New-Object System.Drawing.Size -ArgumentList $sampleWidth, $sampleHeight))
            $goldPixels = 0
            $samplePixels = 0
            for ($y = 0; $y -lt $sampleHeight; $y += 2) {
                for ($x = 0; $x -lt $sampleWidth; $x += 2) {
                    $pixel = $bitmap.GetPixel($x, $y)
                    $samplePixels++
                    if ($pixel.R -ge 120 -and $pixel.G -ge 75 -and $pixel.G -le 210 -and $pixel.B -le 120 -and $pixel.R -ge $pixel.G) {
                        $goldPixels++
                    }
                }
            }

            $goldRatio = $(if ($samplePixels -gt 0) { [double]$goldPixels / [double]$samplePixels } else { 0.0 })
            $base['ok'] = $true
            $base['reason'] = 'visual_probe_ok'
            $base['goldPixels'] = [int]$goldPixels
            $base['samplePixels'] = [int]$samplePixels
            $base['goldPixelRatio'] = [double]$goldRatio
            $base['characterSelectButtonVisible'] = [bool]($goldPixels -ge 80 -and $goldRatio -ge 0.045)
            return $base
        } finally {
            if ($graphics) { $graphics.Dispose() }
            if ($bitmap) { $bitmap.Dispose() }
        }
    } catch {
        $base['reason'] = 'visual_probe_failed'
        $base['error'] = $_.Exception.Message
        return $base
    }
}

function Get-BridgeGameWorldEntrySnapshot {
    param([string]$ResolvedGameDir = '')

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir)
    $windows = New-Object System.Collections.Generic.List[object]
    $pids = New-Object System.Collections.Generic.List[int]
    foreach ($proc in $processes) {
        try {
            [void]$pids.Add([int]$proc.Id)
            [void]$windows.Add([ordered]@{
                pid              = [int]$proc.Id
                name             = [string]$proc.ProcessName
                mainWindowHandle = [int64]$proc.MainWindowHandle
                mainWindowTitle  = [string]$proc.MainWindowTitle
                path             = $(try { [string]$proc.Path } catch { '' })
            })
        } catch {
        }
    }

    $tcp = Get-BridgeGameTcpReadySnapshot -Pids @($pids.ToArray())
    $firstWindow = $(if ($windows.Count -gt 0) { $windows[0] } else { $null })
    $title = $(if ($firstWindow) { [string]$firstWindow.mainWindowTitle } else { '' })
    $titleReady = Test-BridgeGameWindowTitleLooksInWorld -Title $title
    $visual = Get-BridgeGameCharacterSelectVisualSnapshot -Handle $(if ($firstWindow) { [int64]$firstWindow.mainWindowHandle } else { [int64]0 })
    $visualReady = [bool]([bool]$visual.ok -and -not [bool]$visual.characterSelectButtonVisible)
    $worldReady = [bool]$titleReady
    return [ordered]@{
        running          = [bool]($processes.Count -gt 0)
        processCount     = [int]$processes.Count
        pid              = $(if ($pids.Count -gt 0) { [int]$pids[0] } else { 0 })
        mainWindowHandle = $(if ($firstWindow) { [int64]$firstWindow.mainWindowHandle } else { [int64]0 })
        mainWindowTitle  = $title
        titleReady       = [bool]$titleReady
        visualReady      = [bool]$visualReady
        worldReady       = [bool]$worldReady
        tcpReady         = [bool]$tcp.ready
        tcp              = $tcp
        characterSelectVisual = $visual
        windows          = @($windows.ToArray())
    }
}

function Wait-BridgeGameWorldEntry {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 90,
        [int]$PollMilliseconds = 1000,
        [int]$RequiredReadySamples = 3
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(1, $TimeoutSec))
    $requiredSamples = [Math]::Max(1, $RequiredReadySamples)
    $readySamples = 0
    $snapshot = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
    while ((Get-Date) -lt $deadline) {
        if ([bool]$snapshot.running -and [bool]$snapshot.worldReady) {
            $readySamples++
            $requiredForSnapshot = $(if ([bool]$snapshot.titleReady) { 1 } else { $requiredSamples })
            if ($readySamples -ge $requiredForSnapshot) {
                $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                return [ordered]@{
                    ready        = $true
                    reason       = 'window-title-world-identity'
                    elapsedMs    = $elapsedMs
                    timeoutSec   = [int]$TimeoutSec
                    readySamples = [int]$readySamples
                    snapshot     = $snapshot
                }
            }
        } else {
            $readySamples = 0
        }

        Start-Sleep -Milliseconds ([Math]::Max(250, $PollMilliseconds))
        $snapshot = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
    }

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        ready        = $false
        reason       = $(if ([bool]$snapshot.running) {
                if ([bool]$snapshot.tcpReady -and [bool]$snapshot.characterSelectVisual.ok -and [bool]$snapshot.characterSelectVisual.characterSelectButtonVisible) {
                    'character_select_button_still_visible'
                } elseif ([bool]$snapshot.tcpReady -and [bool]$snapshot.characterSelectVisual.ok -and -not [bool]$snapshot.characterSelectVisual.characterSelectButtonVisible) {
                    'server_or_account_dialog_not_world'
                } elseif ([bool]$snapshot.tcpReady) {
                    'character_select_or_world_visual_not_confirmed'
                } else {
                    'world_entry_not_detected'
                }
            } else {
                'game_process_exited'
            })
        elapsedMs    = $elapsedMs
        timeoutSec   = [int]$TimeoutSec
        readySamples = [int]$readySamples
        snapshot     = $snapshot
    }
}

function Wait-BridgeRelogCharacterSelectInputReady {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 35,
        [int]$PollMilliseconds = 1000
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(1, $TimeoutSec))
    $snapshot = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
    while ((Get-Date) -lt $deadline) {
        if (-not [bool]$snapshot.running) {
            break
        }

        if ([bool]$snapshot.worldReady) {
            $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
            return [ordered]@{
                ready                = $true
                worldEntryConfirmed  = $true
                reason               = 'window-title-world-identity'
                elapsedMs            = $elapsedMs
                timeoutSec           = [int]$TimeoutSec
                snapshot             = $snapshot
            }
        }

        $titleHasSelection = Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$snapshot.mainWindowTitle)
        if ([bool]$titleHasSelection) {
            $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
            return [ordered]@{
                ready                = $true
                worldEntryConfirmed  = $false
                reason               = $(if ([bool]$snapshot.tcpReady) { 'character_select_input_ready' } else { 'character_select_title_input_ready' })
                elapsedMs            = $elapsedMs
                timeoutSec           = [int]$TimeoutSec
                snapshot             = $snapshot
            }
        }

        Start-Sleep -Milliseconds ([Math]::Max(250, $PollMilliseconds))
        $snapshot = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
    }

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        ready                = $false
        worldEntryConfirmed  = $false
        reason               = $(if ([bool]$snapshot.running) {
                if ([bool]$snapshot.tcpReady) {
                    'tcp_ready_selection_title_not_ready'
                } elseif (Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$snapshot.mainWindowTitle)) {
                    'selection_title_ready_tcp_not_ready'
                } else {
                    'character_select_not_ready'
                }
            } else {
                'game_process_exited'
            })
        elapsedMs            = $elapsedMs
        timeoutSec           = [int]$TimeoutSec
        snapshot             = $snapshot
    }
}

function Ensure-BridgeWindowInputType {
    if ('RevelationLauncher.WindowInput' -as [type]) {
        return
    }

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

namespace RevelationLauncher {
    public static class WindowInput {
        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool PostMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern bool IsIconic(IntPtr hWnd);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        public static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll")]
        public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        [DllImport("user32.dll")]
        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct HARDWAREINPUT {
            public uint uMsg;
            public ushort wParamL;
            public ushort wParamH;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct INPUTUNION {
            [FieldOffset(0)]
            public MOUSEINPUT mi;

            [FieldOffset(0)]
            public KEYBDINPUT ki;

            [FieldOffset(0)]
            public HARDWAREINPUT hi;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT {
            public uint type;
            public INPUTUNION data;
        }

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        private const uint INPUT_KEYBOARD = 1;
        private const uint KEYEVENTF_EXTENDEDKEY = 0x0001;
        private const uint KEYEVENTF_KEYUP = 0x0002;
        private const uint KEYEVENTF_SCANCODE = 0x0008;

        private static INPUT MakeScanCodeInput(ushort scanCode, uint extraFlags) {
            INPUT input = new INPUT();
            input.type = INPUT_KEYBOARD;
            input.data.ki.wVk = 0;
            input.data.ki.wScan = scanCode;
            input.data.ki.dwFlags = KEYEVENTF_SCANCODE | extraFlags;
            input.data.ki.time = 0;
            input.data.ki.dwExtraInfo = UIntPtr.Zero;
            return input;
        }

        public static uint SendScanCodeKey(ushort scanCode, bool extended) {
            uint extendedFlag = extended ? KEYEVENTF_EXTENDEDKEY : 0;
            INPUT[] inputs = new INPUT[] {
                MakeScanCodeInput(scanCode, extendedFlag),
                MakeScanCodeInput(scanCode, extendedFlag | KEYEVENTF_KEYUP)
            };
            return SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
        }

        public static uint SendAltF4ScanCode() {
            INPUT[] inputs = new INPUT[] {
                MakeScanCodeInput(0x38, 0),
                MakeScanCodeInput(0x3E, 0),
                MakeScanCodeInput(0x3E, KEYEVENTF_KEYUP),
                MakeScanCodeInput(0x38, KEYEVENTF_KEYUP)
            };
            return SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
        }
    }
}
'@
}

function Send-BridgeClickToGameDialogYesButton {
    param([string]$ResolvedGameDir = '')

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir | Where-Object { [int64]$_.MainWindowHandle -ne 0 })
    $proc = $(if ($processes.Count -gt 0) { $processes[0] } else { $null })
    if ($null -eq $proc) {
        return [ordered]@{
            sent    = $false
            focused = $false
            pid     = 0
            handle  = 0
            reason  = 'dialog_yes_click'
            message = 'Окно игры не найдено для клика по кнопке Да.'
        }
    }

    try {
        Ensure-BridgeWindowInputType
        $handle = [IntPtr]([int64]$proc.MainWindowHandle)
        if ([RevelationLauncher.WindowInput]::IsIconic($handle)) {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 9)
        } else {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 5)
        }
        Start-Sleep -Milliseconds 180
        $focused = [bool][RevelationLauncher.WindowInput]::SetForegroundWindow($handle)
        Start-Sleep -Milliseconds 220
        $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
        $foregroundMatches = ([int64]$foreground -eq [int64]$handle)
        if (-not $foregroundMatches) {
            return [ordered]@{
                sent            = $false
                focused         = [bool]$focused
                foregroundMatch = $false
                reason          = 'dialog_yes_click'
                pid             = [int]$proc.Id
                handle          = [int64]$proc.MainWindowHandle
                foreground      = [int64]$foreground
                mainWindowTitle = [string]$proc.MainWindowTitle
                message         = 'Окно игры не стало активным, клик по кнопке Да не отправлен.'
            }
        }

        $rect = New-Object RevelationLauncher.WindowInput+RECT
        if (-not [RevelationLauncher.WindowInput]::GetWindowRect($handle, [ref]$rect)) {
            return [ordered]@{
                sent            = $false
                focused         = [bool]$focused
                foregroundMatch = [bool]$foregroundMatches
                reason          = 'dialog_yes_click'
                pid             = [int]$proc.Id
                handle          = [int64]$proc.MainWindowHandle
                foreground      = [int64]$foreground
                mainWindowTitle = [string]$proc.MainWindowTitle
                message         = 'Не удалось получить координаты окна игры для клика по кнопке Да.'
            }
        }

        $width = [Math]::Max(1, [int]($rect.Right - $rect.Left))
        $height = [Math]::Max(1, [int]($rect.Bottom - $rect.Top))
        $x = [int]($rect.Left + [Math]::Round($width * 0.459))
        $y = [int]($rect.Top + [Math]::Round($height * 0.580))
        [void][RevelationLauncher.WindowInput]::SetCursorPos($x, $y)
        Start-Sleep -Milliseconds 90
        [RevelationLauncher.WindowInput]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 70
        [RevelationLauncher.WindowInput]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
        return [ordered]@{
            sent            = $true
            focused         = [bool]$focused
            foregroundMatch = $true
            reason          = 'dialog_yes_click'
            pid             = [int]$proc.Id
            handle          = [int64]$proc.MainWindowHandle
            foreground      = [int64]$foreground
            x               = [int]$x
            y               = [int]$y
            mainWindowTitle = [string]$proc.MainWindowTitle
            message         = 'Клик по кнопке Да отправлен в окно игры.'
        }
    } catch {
        return [ordered]@{
            sent            = $false
            focused         = $false
            reason          = 'dialog_yes_click'
            pid             = [int]$proc.Id
            handle          = [int64]$proc.MainWindowHandle
            mainWindowTitle = [string]$proc.MainWindowTitle
            error           = $_.Exception.Message
            message         = 'Не удалось кликнуть по кнопке Да: ' + $_.Exception.Message
        }
    }
}

function Send-BridgeClickToGameDialogOkButton {
    param([string]$ResolvedGameDir = '')

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir | Where-Object { [int64]$_.MainWindowHandle -ne 0 })
    $proc = $(if ($processes.Count -gt 0) { $processes[0] } else { $null })
    if ($null -eq $proc) {
        return [ordered]@{
            sent    = $false
            focused = $false
            reason  = 'dialog_ok_click'
            pid     = 0
            handle  = 0
            message = 'Окно игры не найдено для клика по кнопке OK.'
        }
    }

    try {
        Ensure-BridgeWindowInputType
        $handle = [IntPtr]([int64]$proc.MainWindowHandle)
        if ([RevelationLauncher.WindowInput]::IsIconic($handle)) {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 9)
        } else {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 5)
        }
        Start-Sleep -Milliseconds 180
        $focused = [bool][RevelationLauncher.WindowInput]::SetForegroundWindow($handle)
        Start-Sleep -Milliseconds 220
        $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
        $foregroundMatches = ([int64]$foreground -eq [int64]$handle)
        if (-not $foregroundMatches) {
            return [ordered]@{
                sent            = $false
                focused         = [bool]$focused
                foregroundMatch = $false
                reason          = 'dialog_ok_click'
                pid             = [int]$proc.Id
                handle          = [int64]$proc.MainWindowHandle
                foreground      = [int64]$foreground
                mainWindowTitle = [string]$proc.MainWindowTitle
                message         = 'Окно игры не стало активным, клик по кнопке OK не отправлен.'
            }
        }

        $rect = New-Object RevelationLauncher.WindowInput+RECT
        if (-not [RevelationLauncher.WindowInput]::GetWindowRect($handle, [ref]$rect)) {
            return [ordered]@{
                sent            = $false
                focused         = [bool]$focused
                foregroundMatch = [bool]$foregroundMatches
                reason          = 'dialog_ok_click'
                pid             = [int]$proc.Id
                handle          = [int64]$proc.MainWindowHandle
                foreground      = [int64]$foreground
                mainWindowTitle = [string]$proc.MainWindowTitle
                message         = 'Не удалось получить координаты окна игры для клика по кнопке OK.'
            }
        }

        $width = [Math]::Max(1, [int]($rect.Right - $rect.Left))
        $height = [Math]::Max(1, [int]($rect.Bottom - $rect.Top))
        $x = [int]($rect.Left + [Math]::Round($width * 0.5))
        $y = [int]($rect.Top + [Math]::Round($height * 0.512))
        [void][RevelationLauncher.WindowInput]::SetCursorPos($x, $y)
        Start-Sleep -Milliseconds 90
        [RevelationLauncher.WindowInput]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 70
        [RevelationLauncher.WindowInput]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
        return [ordered]@{
            sent            = $true
            focused         = [bool]$focused
            foregroundMatch = $true
            reason          = 'dialog_ok_click'
            pid             = [int]$proc.Id
            handle          = [int64]$proc.MainWindowHandle
            foreground      = [int64]$foreground
            x               = [int]$x
            y               = [int]$y
            mainWindowTitle = [string]$proc.MainWindowTitle
            message         = 'Клик по кнопке OK отправлен в окно игры.'
        }
    } catch {
        return [ordered]@{
            sent            = $false
            focused         = $false
            reason          = 'dialog_ok_click'
            pid             = [int]$proc.Id
            handle          = [int64]$proc.MainWindowHandle
            mainWindowTitle = [string]$proc.MainWindowTitle
            error           = $_.Exception.Message
            message         = 'Не удалось кликнуть по кнопке OK: ' + $_.Exception.Message
        }
    }
}

function Send-BridgeRelogAccountAlreadyOnlineConfirm {
    param(
        [string]$ResolvedGameDir = '',
        [switch]$AllowBackgroundMessageFallback
    )

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir | Where-Object { [int64]$_.MainWindowHandle -ne 0 })
    $proc = $(if ($processes.Count -gt 0) { $processes[0] } else { $null })
    if ($null -eq $proc) {
        return [ordered]@{
            sent                  = $false
            focused               = $false
            foregroundMatch       = $false
            backgroundMessageSent = $false
            delivery              = 'none'
            reason                = 'account_already_online_confirm'
            pid                   = 0
            handle                = 0
            message               = 'Окно игры не найдено для подтверждения повторного входа.'
        }
    }

    try {
        Ensure-BridgeWindowInputType
        $handle = [IntPtr]([int64]$proc.MainWindowHandle)
        if ([RevelationLauncher.WindowInput]::IsIconic($handle)) {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 9)
        } else {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 5)
        }
        Start-Sleep -Milliseconds 200
        $focused = [bool][RevelationLauncher.WindowInput]::SetForegroundWindow($handle)
        Start-Sleep -Milliseconds 250
        $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
        $foregroundMatches = ([int64]$foreground -eq [int64]$handle)
        if (-not $foregroundMatches) {
            if ($AllowBackgroundMessageFallback) {
                $enterDown = [bool][RevelationLauncher.WindowInput]::PostMessage($handle, [uint32]0x0100, [UIntPtr]0x0D, [IntPtr]0x001C0001)
                Start-Sleep -Milliseconds 80
                $enterUp = [bool][RevelationLauncher.WindowInput]::PostMessage($handle, [uint32]0x0101, [UIntPtr]0x0D, [IntPtr]0xC01C0001)
                Start-Sleep -Milliseconds 140
                $postDown = [bool][RevelationLauncher.WindowInput]::PostMessage($handle, [uint32]0x0100, [UIntPtr]0x59, [IntPtr]0x00150001)
                Start-Sleep -Milliseconds 80
                $postUp = [bool][RevelationLauncher.WindowInput]::PostMessage($handle, [uint32]0x0101, [UIntPtr]0x59, [IntPtr]0xC0150001)
                $enterPosted = [bool]($enterDown -and $enterUp)
                $posted = [bool]($enterPosted -or ($postDown -and $postUp))
                return [ordered]@{
                    sent                  = [bool]$posted
                    focused               = [bool]$focused
                    foregroundMatch       = $false
                    backgroundMessageSent = [bool]$posted
                    delivery              = 'background_hwnd_message'
                    reason                = 'account_already_online_confirm'
                    enterConfirm          = [ordered]@{
                        sent     = [bool]$enterPosted
                        delivery = 'background_hwnd_message'
                    }
                    pid                   = [int]$proc.Id
                    handle                = [int64]$proc.MainWindowHandle
                    foreground            = [int64]$foreground
                    mainWindowTitle       = [string]$proc.MainWindowTitle
                    message               = $(if ($posted) { 'Enter/Y отправлены в окно игры через HWND fallback для подтверждения повторного входа.' } else { 'Окно игры не стало активным, HWND fallback для подтверждения повторного входа не сработал.' })
                }
            }

            return [ordered]@{
                sent                  = $false
                focused               = [bool]$focused
                foregroundMatch       = $false
                backgroundMessageSent = $false
                delivery              = 'none'
                reason                = 'account_already_online_confirm'
                pid                   = [int]$proc.Id
                handle                = [int64]$proc.MainWindowHandle
                foreground            = [int64]$foreground
                mainWindowTitle       = [string]$proc.MainWindowTitle
                message               = 'Окно игры не стало активным, Y для подтверждения повторного входа не отправлен.'
            }
        }

        [RevelationLauncher.WindowInput]::keybd_event(0x0D, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [RevelationLauncher.WindowInput]::keybd_event(0x0D, 0, 2, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 140
        [RevelationLauncher.WindowInput]::keybd_event(0x59, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [RevelationLauncher.WindowInput]::keybd_event(0x59, 0, 2, [UIntPtr]::Zero)
        return [ordered]@{
            sent                  = $true
            focused               = [bool]$focused
            foregroundMatch       = $true
            backgroundMessageSent = $false
            delivery              = 'foreground_sendinput'
            reason                = 'account_already_online_confirm'
            enterConfirm          = [ordered]@{
                sent     = $true
                delivery = 'foreground_sendinput'
            }
            pid                   = [int]$proc.Id
            handle                = [int64]$proc.MainWindowHandle
            foreground            = [int64]$foreground
            mainWindowTitle       = [string]$proc.MainWindowTitle
            message               = 'Enter/Y отправлены в окно игры для подтверждения повторного входа.'
        }
    } catch {
        return [ordered]@{
            sent                  = $false
            focused               = $false
            foregroundMatch       = $false
            backgroundMessageSent = $false
            delivery              = 'none'
            reason                = 'account_already_online_confirm'
            pid                   = [int]$proc.Id
            handle                = [int64]$proc.MainWindowHandle
            mainWindowTitle       = [string]$proc.MainWindowTitle
            error                 = $_.Exception.Message
            message               = 'Не удалось отправить Y для подтверждения повторного входа: ' + $_.Exception.Message
        }
    }
}

function Invoke-BridgeRelogAccountAlreadyOnlineConfirmSweep {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 12,
        [int]$MaxConfirmAttempts = 8
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(1, $TimeoutSec))
    $confirmAttempts = New-Object System.Collections.Generic.List[object]
    $lastInputReady = $null
    $lastConfirm = $null
    $lastDialogYes = $null
    for ($confirmAttempt = 1; $confirmAttempt -le [Math]::Max(1, $MaxConfirmAttempts) -and (Get-Date) -lt $deadline; $confirmAttempt++) {
        $before = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
        if (-not [bool]$before.running) {
            break
        }

        if ([bool]$before.worldReady) {
            $lastInputReady = [ordered]@{
                ready               = $true
                worldEntryConfirmed = $true
                reason              = 'window-title-world-identity'
                elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                timeoutSec          = [int]$TimeoutSec
                snapshot            = $before
            }
            break
        }

        $titleHasSelection = Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$before.mainWindowTitle)
        if ([bool]$titleHasSelection) {
            $lastInputReady = Wait-BridgeRelogCharacterSelectInputReady -ResolvedGameDir $ResolvedGameDir -TimeoutSec 1 -PollMilliseconds 250
            break
        }

        $lastConfirm = Send-BridgeRelogAccountAlreadyOnlineConfirm -ResolvedGameDir $ResolvedGameDir -AllowBackgroundMessageFallback
        Start-Sleep -Milliseconds 160
        $lastDialogYes = Send-BridgeClickToGameDialogYesButton -ResolvedGameDir $ResolvedGameDir
        Start-Sleep -Milliseconds 420
        $lastInputReady = Wait-BridgeRelogCharacterSelectInputReady -ResolvedGameDir $ResolvedGameDir -TimeoutSec 1 -PollMilliseconds 250

        [void]$confirmAttempts.Add([ordered]@{
            confirmAttempt = [int]$confirmAttempt
            before         = $before
            confirm        = $lastConfirm
            dialogYes      = $lastDialogYes
            inputReady     = $lastInputReady
        })

        if ([bool]$lastInputReady.ready -or [bool]$lastInputReady.worldEntryConfirmed) {
            break
        }
    }

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        ok                  = $true
        ready               = [bool]($lastInputReady -and [bool]$lastInputReady.ready)
        worldEntryConfirmed = [bool]($lastInputReady -and [bool]$lastInputReady.worldEntryConfirmed)
        reason              = $(if ($lastInputReady) { [string]$lastInputReady.reason } else { 'account_confirm_sweep_not_ready' })
        elapsedMs           = $elapsedMs
        timeoutSec          = [int]$TimeoutSec
        attemptCount        = [int]$confirmAttempts.Count
        attempts            = @($confirmAttempts.ToArray())
        lastConfirm         = $lastConfirm
        lastDialogYes       = $lastDialogYes
        inputReady          = $lastInputReady
        message             = $(if ($lastInputReady -and ([bool]$lastInputReady.ready -or [bool]$lastInputReady.worldEntryConfirmed)) {
                'Диалог повторного входа подтверждён или клиент перешёл дальше.'
            } else {
                'Диалог повторного входа не подтвердился за короткий sweep.'
            })
    }
}

function Invoke-BridgeRelogServerDialogRetry {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 6
    )

    $startedAt = Get-Date
    $before = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
    $enter = Send-BridgeEnterToGameWindow -ResolvedGameDir $ResolvedGameDir -AllowBackgroundMessageFallback
    Start-Sleep -Milliseconds 220
    $dialogOk = Send-BridgeClickToGameDialogOkButton -ResolvedGameDir $ResolvedGameDir
    Start-Sleep -Milliseconds 550
    $loginClick = Send-BridgeClickToGameLoginButton -ResolvedGameDir $ResolvedGameDir -IncludeServerListFallback
    $confirmation = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec ([Math]::Min(3, [Math]::Max(1, $TimeoutSec))) -PollMilliseconds 500 -RequiredReadySamples 1
    $inputReady = $(if ([bool]$confirmation.ready) {
            [ordered]@{
                ready               = $true
                worldEntryConfirmed = $true
                reason              = [string]$confirmation.reason
                elapsedMs           = [int]$confirmation.elapsedMs
                timeoutSec          = [int]$confirmation.timeoutSec
                snapshot            = $confirmation.snapshot
            }
        } else {
            Wait-BridgeRelogCharacterSelectInputReady -ResolvedGameDir $ResolvedGameDir -TimeoutSec ([Math]::Min(2, [Math]::Max(1, $TimeoutSec))) -PollMilliseconds 500
        })

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        ok                  = $true
        ready               = [bool]($inputReady -and [bool]$inputReady.ready)
        worldEntryConfirmed = [bool](([bool]$confirmation.ready) -or ($inputReady -and [bool]$inputReady.worldEntryConfirmed))
        reason              = $(if ([bool]$confirmation.ready) { [string]$confirmation.reason } elseif ($inputReady) { [string]$inputReady.reason } else { 'server_dialog_retry_not_ready' })
        elapsedMs           = $elapsedMs
        timeoutSec          = [int]$TimeoutSec
        before              = $before
        enter               = $enter
        dialogOk            = $dialogOk
        loginClick          = $loginClick
        confirmation        = $confirmation
        inputReady          = $inputReady
        message             = $(if ([bool]$confirmation.ready -or ($inputReady -and [bool]$inputReady.ready)) {
                'Серверный диалог закрыт, вход повторён или клиент перешёл дальше.'
            } else {
                'Серверный диалог был обработан, но вход в мир ещё не подтверждён.'
            })
    }
}

function Send-BridgeEnterToGameWindow {
    param(
        [string]$ResolvedGameDir = '',
        [switch]$AllowBackgroundMessageFallback
    )

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir | Where-Object { [int64]$_.MainWindowHandle -ne 0 })
    $proc = $(if ($processes.Count -gt 0) { $processes[0] } else { $null })
    if ($null -eq $proc) {
        return [ordered]@{
            sent                  = $false
            focused               = $false
            foregroundMatch       = $false
            backgroundMessageSent = $false
            delivery              = 'none'
            pid                   = 0
            handle                = 0
            message               = 'Окно игры не найдено для подтверждения входа.'
        }
    }

    try {
        Ensure-BridgeWindowInputType
        $handle = [IntPtr]([int64]$proc.MainWindowHandle)
        if ([RevelationLauncher.WindowInput]::IsIconic($handle)) {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 9)
        } else {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 5)
        }
        Start-Sleep -Milliseconds 250
        [RevelationLauncher.WindowInput]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 40
        [RevelationLauncher.WindowInput]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        $focused = [bool][RevelationLauncher.WindowInput]::SetForegroundWindow($handle)
        Start-Sleep -Milliseconds 350
        $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
        $foregroundMatches = ([int64]$foreground -eq [int64]$handle)
        if (-not $foregroundMatches) {
            if ($AllowBackgroundMessageFallback) {
                $postDown = [bool][RevelationLauncher.WindowInput]::PostMessage($handle, [uint32]0x0100, [UIntPtr]0x0D, [IntPtr]0x001C0001)
                Start-Sleep -Milliseconds 80
                $postUp = [bool][RevelationLauncher.WindowInput]::PostMessage($handle, [uint32]0x0101, [UIntPtr]0x0D, [IntPtr]0xC01C0001)
                $posted = [bool]($postDown -and $postUp)
                return [ordered]@{
                    sent                  = [bool]$posted
                    focused               = [bool]$focused
                    foregroundMatch       = $false
                    backgroundMessageSent = [bool]$posted
                    delivery              = 'background_hwnd_message'
                    pid                   = [int]$proc.Id
                    handle                = [int64]$proc.MainWindowHandle
                    foreground            = [int64]$foreground
                    mainWindowTitle       = [string]$proc.MainWindowTitle
                    message               = $(if ($posted) { 'Enter отправлен в окно игры через HWND fallback; результат будет подтверждён по входу в мир.' } else { 'Окно игры не стало активным, HWND fallback для Enter не сработал.' })
                }
            }

            return [ordered]@{
                sent                  = $false
                focused               = [bool]$focused
                foregroundMatch       = $false
                backgroundMessageSent = $false
                delivery              = 'none'
                pid                   = [int]$proc.Id
                handle                = [int64]$proc.MainWindowHandle
                foreground            = [int64]$foreground
                mainWindowTitle       = [string]$proc.MainWindowTitle
                message               = 'Окно игры не стало активным, Enter не отправлен.'
            }
        }

        [RevelationLauncher.WindowInput]::keybd_event(0x0D, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [RevelationLauncher.WindowInput]::keybd_event(0x0D, 0, 2, [UIntPtr]::Zero)
        return [ordered]@{
            sent                  = $true
            focused               = [bool]$focused
            foregroundMatch       = $true
            backgroundMessageSent = $false
            delivery              = 'foreground_sendinput'
            pid                   = [int]$proc.Id
            handle                = [int64]$proc.MainWindowHandle
            foreground            = [int64]$foreground
            mainWindowTitle       = [string]$proc.MainWindowTitle
            message               = 'Enter отправлен в окно игры для входа выбранным персонажем.'
        }
    } catch {
        return [ordered]@{
            sent                  = $false
            focused               = $false
            foregroundMatch       = $false
            backgroundMessageSent = $false
            delivery              = 'none'
            pid                   = [int]$proc.Id
            handle                = [int64]$proc.MainWindowHandle
            mainWindowTitle       = [string]$proc.MainWindowTitle
            error                 = $_.Exception.Message
            message               = 'Не удалось отправить Enter в окно игры: ' + $_.Exception.Message
        }
    }
}

function Send-BridgeClickToGameLoginButton {
    param(
        [string]$ResolvedGameDir = '',
        [switch]$IncludeServerListFallback
    )

    $processes = @(Get-BridgeGameProcesses -ResolvedGameDir $ResolvedGameDir | Where-Object { [int64]$_.MainWindowHandle -ne 0 })
    $proc = $(if ($processes.Count -gt 0) { $processes[0] } else { $null })
    if ($null -eq $proc) {
        return [ordered]@{
            sent    = $false
            focused = $false
            pid     = 0
            handle  = 0
            message = 'Окно игры не найдено для клика по входу персонажа.'
        }
    }

    try {
        Ensure-BridgeWindowInputType
        $handle = [IntPtr]([int64]$proc.MainWindowHandle)
        if ([RevelationLauncher.WindowInput]::IsIconic($handle)) {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 9)
        } else {
            [void][RevelationLauncher.WindowInput]::ShowWindowAsync($handle, 5)
        }
        Start-Sleep -Milliseconds 250
        [RevelationLauncher.WindowInput]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 40
        [RevelationLauncher.WindowInput]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        $focused = [bool][RevelationLauncher.WindowInput]::SetForegroundWindow($handle)
        Start-Sleep -Milliseconds 350
        $foreground = [RevelationLauncher.WindowInput]::GetForegroundWindow()
        $foregroundMatches = ([int64]$foreground -eq [int64]$handle)
        if (-not $foregroundMatches) {
            return [ordered]@{
                sent            = $false
                focused         = [bool]$focused
                foregroundMatch = $false
                pid             = [int]$proc.Id
                handle          = [int64]$proc.MainWindowHandle
                foreground      = [int64]$foreground
                mainWindowTitle = [string]$proc.MainWindowTitle
                message         = 'Окно игры не стало активным, клик входа не отправлен.'
            }
        }

        $rect = New-Object RevelationLauncher.WindowInput+RECT
        if (-not [RevelationLauncher.WindowInput]::GetWindowRect($handle, [ref]$rect)) {
            return [ordered]@{
                sent            = $false
                focused         = [bool]$focused
                foregroundMatch = [bool]$foregroundMatches
                pid             = [int]$proc.Id
                handle          = [int64]$proc.MainWindowHandle
                foreground      = [int64]$foreground
                mainWindowTitle = [string]$proc.MainWindowTitle
                message         = 'Не удалось получить координаты окна игры для клика входа.'
            }
        }

        $width = [Math]::Max(1, [int]($rect.Right - $rect.Left))
        $height = [Math]::Max(1, [int]($rect.Bottom - $rect.Top))
        $x = [int]($rect.Left + [Math]::Round($width * 0.5))
        $bottomOffset = [int][Math]::Min(58, [Math]::Max(20, [Math]::Round($height * 0.032)))
        $y = [int]($rect.Bottom - $bottomOffset)
        [void][RevelationLauncher.WindowInput]::SetCursorPos($x, $y)
        Start-Sleep -Milliseconds 120
        [RevelationLauncher.WindowInput]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [RevelationLauncher.WindowInput]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
        $serverListFallback = $null
        if ($IncludeServerListFallback) {
            Start-Sleep -Milliseconds 160
            $serverX = [int]($rect.Left + [Math]::Round($width * 0.505))
            $serverY = [int]($rect.Top + [Math]::Round($height * 0.698))
            [void][RevelationLauncher.WindowInput]::SetCursorPos($serverX, $serverY)
            Start-Sleep -Milliseconds 90
            [RevelationLauncher.WindowInput]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
            Start-Sleep -Milliseconds 70
            [RevelationLauncher.WindowInput]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
            $serverListFallback = [ordered]@{
                sent   = $true
                reason = 'server_list_login_click_fallback'
                x      = [int]$serverX
                y      = [int]$serverY
                ratioX = 0.505
                ratioY = 0.698
            }
        }
        return [ordered]@{
            sent                      = $true
            focused                   = [bool]$focused
            foregroundMatch           = $true
            pid                       = [int]$proc.Id
            handle                    = [int64]$proc.MainWindowHandle
            foreground                = [int64]$foreground
            x                         = [int]$x
            y                         = [int]$y
            bottomOffset              = [int]$bottomOffset
            includeServerListFallback = [bool]$IncludeServerListFallback
            serverListFallback        = $serverListFallback
            mainWindowTitle           = [string]$proc.MainWindowTitle
            message                   = $(if ($IncludeServerListFallback) { 'Клик по кнопке входа персонажа и fallback-клик по серверному Войти отправлены в окно игры.' } else { 'Клик по кнопке входа персонажа отправлен в окно игры.' })
        }
    } catch {
        return [ordered]@{
            sent            = $false
            focused         = $false
            pid             = [int]$proc.Id
            handle          = [int64]$proc.MainWindowHandle
            mainWindowTitle = [string]$proc.MainWindowTitle
            error           = $_.Exception.Message
            message         = 'Не удалось отправить клик входа в окно игры: ' + $_.Exception.Message
        }
    }
}

function Invoke-BridgeRelogLoginPulseUntilWorldEntry {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 28,
        [int]$MaxPulseAttempts = 8
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(1, $TimeoutSec))
    $pulseAttempts = New-Object System.Collections.Generic.List[object]
    $lastConfirmation = $null

    for ($pulseAttempt = 1; $pulseAttempt -le [Math]::Max(1, $MaxPulseAttempts); $pulseAttempt++) {
        if ((Get-Date) -ge $deadline) {
            break
        }

        $before = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec 1 -PollMilliseconds 250 -RequiredReadySamples 1
        if ([bool]$before.ready) {
            return [ordered]@{
                ready              = $true
                reason             = [string]$before.reason
                elapsedMs          = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                timeoutSec         = [int]$TimeoutSec
                loginPulseAttempts = @($pulseAttempts.ToArray())
                confirmation       = $before
                message            = 'Вход персонажа в игровой мир подтверждён.'
            }
        }

        $snapshot = $before.snapshot
        $buttonVisible = [bool]($snapshot -and $snapshot.characterSelectVisual -and [bool]$snapshot.characterSelectVisual.ok -and [bool]$snapshot.characterSelectVisual.characterSelectButtonVisible)
        $titleHasSelection = [bool](Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$snapshot.mainWindowTitle))
        $shouldPulse = [bool]($snapshot -and [bool]$snapshot.running -and [int64]$snapshot.mainWindowHandle -ne 0 -and ($buttonVisible -or [bool]$snapshot.tcpReady -or $titleHasSelection))
        $enter = $null
        $click = $null
        if ($shouldPulse) {
            $enter = Send-BridgeEnterToGameWindow -ResolvedGameDir $ResolvedGameDir -AllowBackgroundMessageFallback
            Start-Sleep -Milliseconds 350
            $includeServerListFallback = [bool]($snapshot -and [bool]$snapshot.tcpReady -and -not [bool]$titleHasSelection -and -not [bool]$buttonVisible)
            $click = Send-BridgeClickToGameLoginButton -ResolvedGameDir $ResolvedGameDir -IncludeServerListFallback:$includeServerListFallback
            Start-Sleep -Milliseconds 650
        } else {
            Start-Sleep -Milliseconds 500
        }

        $remainingSec = [int][Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds))
        $confirmWaitSec = [Math]::Min(3, $remainingSec)
        $lastConfirmation = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec $confirmWaitSec -PollMilliseconds 500 -RequiredReadySamples 1
        [void]$pulseAttempts.Add([ordered]@{
                pulseAttempt    = [int]$pulseAttempt
                before          = $before
                buttonVisible   = [bool]$buttonVisible
                titleHasSelection = [bool]$titleHasSelection
                shouldPulse     = [bool]$shouldPulse
                enter           = $enter
                click           = $click
                confirmation    = $lastConfirmation
            })

        if ([bool]$lastConfirmation.ready) {
            return [ordered]@{
                ready              = $true
                reason             = [string]$lastConfirmation.reason
                elapsedMs          = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                timeoutSec         = [int]$TimeoutSec
                loginPulseAttempts = @($pulseAttempts.ToArray())
                confirmation       = $lastConfirmation
                message            = 'Вход персонажа в игровой мир подтверждён.'
            }
        }
    }

    if ($null -eq $lastConfirmation) {
        $finalRemainingSec = [int][Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds))
        $lastConfirmation = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec ([Math]::Min(2, $finalRemainingSec)) -PollMilliseconds 500 -RequiredReadySamples 1
    }

    return [ordered]@{
        ready              = [bool]$lastConfirmation.ready
        reason             = $(if ([bool]$lastConfirmation.ready) { [string]$lastConfirmation.reason } else { [string]$lastConfirmation.reason })
        elapsedMs          = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
        timeoutSec         = [int]$TimeoutSec
        loginPulseAttempts = @($pulseAttempts.ToArray())
        confirmation       = $lastConfirmation
        message            = $(if ([bool]$lastConfirmation.ready) { 'Вход персонажа в игровой мир подтверждён.' } else { 'Кнопка входа оставалась видимой после повторных Enter/кликов.' })
    }
}

function Invoke-BridgeRelogWorldEntryAssist {
    param(
        [string]$ResolvedGameDir = '',
        [int]$TimeoutSec = 150,
        [int]$InitialSettleMilliseconds = 2500,
        [int]$MaxEnterAttempts = 4
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(15, $TimeoutSec))
    $attempts = New-Object System.Collections.Generic.List[object]

    if ($InitialSettleMilliseconds -gt 0) {
        Start-Sleep -Milliseconds $InitialSettleMilliseconds
    }

    $initial = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec 2 -PollMilliseconds 500 -RequiredReadySamples 1
    if ([bool]$initial.ready) {
        return [ordered]@{
            ok                  = $true
            worldEntryConfirmed = $true
            reason              = [string]$initial.reason
            attempts            = @()
            attemptCount        = 0
            elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
            confirmation        = $initial
            message             = 'Вход персонажа в игровой мир подтверждён.'
        }
    }

    for ($attempt = 1; $attempt -le [Math]::Max(1, $MaxEnterAttempts); $attempt++) {
        if ((Get-Date) -ge $deadline) {
            break
        }

        $bootstrapBefore = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
        $bootstrapTitleHasSelection = Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$bootstrapBefore.mainWindowTitle)
        $bootstrapClick = $null
        $bootstrapConfirmation = $null
        $accountConfirm = $null
        $accountConfirmInputReady = $null
        $confirmSweep = $null
        $serverDialogRetry = $null
        $preInputServerDialogHandled = $false
        if ([bool]$bootstrapBefore.running -and -not [bool]$bootstrapBefore.worldReady -and -not [bool]$bootstrapTitleHasSelection -and [int64]$bootstrapBefore.mainWindowHandle -ne 0) {
            $bootstrapClick = Send-BridgeClickToGameLoginButton -ResolvedGameDir $ResolvedGameDir -IncludeServerListFallback
            Start-Sleep -Milliseconds 800
            $bootstrapConfirmation = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec 2 -PollMilliseconds 250 -RequiredReadySamples 1
            if ([bool]$bootstrapConfirmation.ready) {
                [void]$attempts.Add([ordered]@{
                    attempt               = [int]$attempt
                    phase                 = 'pre_input_bootstrap_click'
                    bootstrapBefore       = $bootstrapBefore
                    bootstrapClick        = $bootstrapClick
                    bootstrapConfirmation = $bootstrapConfirmation
                    inputReady            = $null
                    before                = $bootstrapBefore
                    input                 = $null
                    click                 = $bootstrapClick
                    confirmation          = $bootstrapConfirmation
                })
                return [ordered]@{
                    ok                  = $true
                    worldEntryConfirmed = $true
                    reason              = [string]$bootstrapConfirmation.reason
                    attempts            = @($attempts.ToArray())
                    attemptCount        = [int]$attempts.Count
                    elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                    confirmation        = $bootstrapConfirmation
                    message             = 'Вход персонажа в игровой мир подтверждён.'
                }
            }
        }

        $accountConfirmBefore = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
        $accountConfirmTitleHasSelection = Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$accountConfirmBefore.mainWindowTitle)
        if ([bool]$accountConfirmBefore.running -and -not [bool]$accountConfirmBefore.worldReady -and -not [bool]$accountConfirmTitleHasSelection -and [int64]$accountConfirmBefore.mainWindowHandle -ne 0) {
            $confirmSweep = Invoke-BridgeRelogAccountAlreadyOnlineConfirmSweep -ResolvedGameDir $ResolvedGameDir
            $accountConfirm = $confirmSweep.lastConfirm
            $accountConfirmInputReady = $confirmSweep.inputReady
            if ([bool]$accountConfirmInputReady.worldEntryConfirmed) {
                [void]$attempts.Add([ordered]@{
                    attempt                  = [int]$attempt
                    phase                    = 'account_already_online_confirm'
                    confirmSweep             = $confirmSweep
                    bootstrapBefore          = $bootstrapBefore
                    bootstrapClick           = $bootstrapClick
                    bootstrapConfirmation    = $bootstrapConfirmation
                    accountConfirmBefore     = $accountConfirmBefore
                    accountConfirm           = $accountConfirm
                    accountConfirmInputReady = $accountConfirmInputReady
                    inputReady               = $accountConfirmInputReady
                    before                   = $accountConfirmInputReady.snapshot
                    input                    = $accountConfirm
                    click                    = $bootstrapClick
                    confirmation             = [ordered]@{
                        ready        = $true
                        reason       = [string]$accountConfirmInputReady.reason
                        elapsedMs    = [int]$accountConfirmInputReady.elapsedMs
                        timeoutSec   = [int]$accountConfirmInputReady.timeoutSec
                        readySamples = 1
                        snapshot     = $accountConfirmInputReady.snapshot
                    }
                })
                return [ordered]@{
                    ok                  = $true
                    worldEntryConfirmed = $true
                    reason              = [string]$accountConfirmInputReady.reason
                    attempts            = @($attempts.ToArray())
                    attemptCount        = [int]$attempts.Count
                    elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                    confirmation        = [ordered]@{
                        ready        = $true
                        reason       = [string]$accountConfirmInputReady.reason
                        elapsedMs    = [int]$accountConfirmInputReady.elapsedMs
                        timeoutSec   = [int]$accountConfirmInputReady.timeoutSec
                        readySamples = 1
                        snapshot     = $accountConfirmInputReady.snapshot
                    }
                    message             = 'Вход персонажа в игровой мир подтверждён.'
                }
            }
        }

        $preInputServerDialogBefore = Get-BridgeGameWorldEntrySnapshot -ResolvedGameDir $ResolvedGameDir
        $preInputServerDialogTitleHasSelection = Test-BridgeGameWindowTitleHasSelectionContext -Title ([string]$preInputServerDialogBefore.mainWindowTitle)
        $preInputServerDialogBlocked = [bool]($preInputServerDialogBefore -and [bool]$preInputServerDialogBefore.running -and -not [bool]$preInputServerDialogBefore.worldReady -and -not [bool]$preInputServerDialogTitleHasSelection -and [int64]$preInputServerDialogBefore.mainWindowHandle -ne 0 -and ([bool]$preInputServerDialogBefore.tcpReady -or ([bool]$preInputServerDialogBefore.characterSelectVisual.ok)))
        if ($preInputServerDialogBlocked) {
            $serverDialogRetry = Invoke-BridgeRelogServerDialogRetry -ResolvedGameDir $ResolvedGameDir
            $preInputServerDialogHandled = $true
            if ([bool]$serverDialogRetry.worldEntryConfirmed) {
                [void]$attempts.Add([ordered]@{
                    attempt                          = [int]$attempt
                    phase                            = 'pre_input_server_dialog_retry'
                    bootstrapBefore                  = $bootstrapBefore
                    bootstrapClick                   = $bootstrapClick
                    bootstrapConfirmation            = $bootstrapConfirmation
                    confirmSweep                     = $confirmSweep
                    accountConfirm                   = $accountConfirm
                    accountConfirmInputReady         = $accountConfirmInputReady
                    preInputServerDialogBefore       = $preInputServerDialogBefore
                    preInputServerDialogTitleHasSelection = [bool]$preInputServerDialogTitleHasSelection
                    preInputServerDialogBlocked      = [bool]$preInputServerDialogBlocked
                    serverDialogRetry                = $serverDialogRetry
                    inputReady                       = $serverDialogRetry.inputReady
                    before                           = $preInputServerDialogBefore
                    input                            = $serverDialogRetry.enter
                    click                            = $serverDialogRetry.loginClick
                    confirmation                     = $serverDialogRetry.confirmation
                })
                return [ordered]@{
                    ok                  = $true
                    worldEntryConfirmed = $true
                    reason              = [string]$serverDialogRetry.reason
                    attempts            = @($attempts.ToArray())
                    attemptCount        = [int]$attempts.Count
                    elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                    confirmation        = $serverDialogRetry.confirmation
                    message             = 'Вход персонажа в игровой мир подтверждён.'
                }
            }

            if ([bool]$serverDialogRetry.ready) {
                $accountConfirmInputReady = $serverDialogRetry.inputReady
            }
        }

        $preInputWaitSec = $(if ($confirmSweep) {
                [int][Math]::Min(3, [Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds)))
            } elseif ($preInputServerDialogHandled) {
                [int][Math]::Min(3, [Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds)))
            } else {
                [int][Math]::Min(35, [Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds)))
            })
        $inputReady = $(if ($accountConfirmInputReady -and ([bool]$accountConfirmInputReady.ready -or [bool]$accountConfirmInputReady.worldEntryConfirmed)) {
                $accountConfirmInputReady
            } else {
                Wait-BridgeRelogCharacterSelectInputReady -ResolvedGameDir $ResolvedGameDir -TimeoutSec $preInputWaitSec -PollMilliseconds 500
            })
        $before = $inputReady.snapshot
        if ([bool]$inputReady.worldEntryConfirmed) {
            return [ordered]@{
                ok                  = $true
                worldEntryConfirmed = $true
                reason              = [string]$inputReady.reason
                attempts            = @($attempts.ToArray())
                attemptCount        = [int]$attempts.Count
                elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                confirmation        = [ordered]@{
                    ready        = $true
                    reason       = [string]$inputReady.reason
                    elapsedMs    = [int]$inputReady.elapsedMs
                    timeoutSec   = [int]$inputReady.timeoutSec
                    readySamples = 1
                    snapshot     = $inputReady.snapshot
                }
                message             = 'Вход персонажа в игровой мир подтверждён.'
            }
        }

        if (-not [bool]$before.running) {
            break
        }

        if (-not [bool]$inputReady.ready) {
            $inputBlockedByServerDialog = [bool]($before -and [bool]$before.running -and [bool]$before.tcpReady -and [bool]$before.characterSelectVisual.ok -and -not [bool]$before.characterSelectVisual.characterSelectButtonVisible)
            if ($inputBlockedByServerDialog) {
                $serverDialogRetry = Invoke-BridgeRelogServerDialogRetry -ResolvedGameDir $ResolvedGameDir
                if ([bool]$serverDialogRetry.worldEntryConfirmed) {
                    [void]$attempts.Add([ordered]@{
                            attempt                  = [int]$attempt
                            phase                    = 'server_dialog_retry'
                            bootstrapBefore          = $bootstrapBefore
                            bootstrapClick           = $bootstrapClick
                            bootstrapConfirmation    = $bootstrapConfirmation
                            confirmSweep             = $confirmSweep
                            accountConfirm           = $accountConfirm
                            accountConfirmInputReady = $accountConfirmInputReady
                            serverDialogRetry        = $serverDialogRetry
                            inputReady               = $serverDialogRetry.inputReady
                            before                   = $before
                            input                    = $serverDialogRetry.enter
                            click                    = $serverDialogRetry.loginClick
                            confirmation             = $serverDialogRetry.confirmation
                        })
                    return [ordered]@{
                        ok                  = $true
                        worldEntryConfirmed = $true
                        reason              = [string]$serverDialogRetry.reason
                        attempts            = @($attempts.ToArray())
                        attemptCount        = [int]$attempts.Count
                        elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                        confirmation        = $serverDialogRetry.confirmation
                        message             = 'Вход персонажа в игровой мир подтверждён.'
                    }
                }

                if ([bool]$serverDialogRetry.ready) {
                    $inputReady = $serverDialogRetry.inputReady
                    $before = $inputReady.snapshot
                }
            }
        }

        if (-not [bool]$inputReady.ready) {
            if ($null -eq $bootstrapClick -and [bool]$before.running -and [int64]$before.mainWindowHandle -ne 0) {
                $bootstrapBefore = $before
                $bootstrapClick = Send-BridgeClickToGameLoginButton -ResolvedGameDir $ResolvedGameDir -IncludeServerListFallback
                Start-Sleep -Milliseconds 800
                $bootstrapConfirmation = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec 2 -PollMilliseconds 250 -RequiredReadySamples 1
                if ([bool]$bootstrapConfirmation.ready) {
                    [void]$attempts.Add([ordered]@{
                        attempt               = [int]$attempt
                        skipped               = $true
                        phase                 = 'input_not_ready_bootstrap_click'
                        bootstrapBefore       = $bootstrapBefore
                        bootstrapClick        = $bootstrapClick
                        bootstrapConfirmation = $bootstrapConfirmation
                        confirmSweep          = $confirmSweep
                        accountConfirm         = $accountConfirm
                        accountConfirmInputReady = $accountConfirmInputReady
                        serverDialogRetry     = $serverDialogRetry
                        inputReady            = $inputReady
                        before                = $before
                        input                 = $null
                        click                 = $bootstrapClick
                        confirmation          = $bootstrapConfirmation
                    })
                    return [ordered]@{
                        ok                  = $true
                        worldEntryConfirmed = $true
                        reason              = [string]$bootstrapConfirmation.reason
                        attempts            = @($attempts.ToArray())
                        attemptCount        = [int]$attempts.Count
                        elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                        confirmation        = $bootstrapConfirmation
                        message             = 'Вход персонажа в игровой мир подтверждён.'
                    }
                }
            }

            [void]$attempts.Add([ordered]@{
                attempt               = [int]$attempt
                skipped               = $true
                phase                 = 'input_not_ready'
                bootstrapBefore       = $bootstrapBefore
                bootstrapClick        = $bootstrapClick
                bootstrapConfirmation = $bootstrapConfirmation
                confirmSweep          = $confirmSweep
                accountConfirm         = $accountConfirm
                accountConfirmInputReady = $accountConfirmInputReady
                serverDialogRetry     = $serverDialogRetry
                inputReady            = $inputReady
                before                = $before
                input                 = $null
                click                 = $bootstrapClick
                confirmation          = [ordered]@{
                    ready      = $false
                    reason     = [string]$inputReady.reason
                    elapsedMs  = [int]$inputReady.elapsedMs
                    timeoutSec = [int]$inputReady.timeoutSec
                    snapshot   = $inputReady.snapshot
                }
            })
            continue
        }

        $send = Send-BridgeEnterToGameWindow -ResolvedGameDir $ResolvedGameDir -AllowBackgroundMessageFallback
        Start-Sleep -Milliseconds 700
        $afterEnterQuick = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec 2 -PollMilliseconds 250 -RequiredReadySamples 1
        $click = $null
        if (-not [bool]$afterEnterQuick.ready) {
            $click = Send-BridgeClickToGameLoginButton -ResolvedGameDir $ResolvedGameDir
        }
        $remainingSec = [int][Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds))
        $waitSec = [Math]::Min(28, $remainingSec)
        $loginPulse = Invoke-BridgeRelogLoginPulseUntilWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec $waitSec
        $after = $loginPulse.confirmation

        [void]$attempts.Add([ordered]@{
            attempt               = [int]$attempt
            phase                 = 'character_select_input'
            bootstrapBefore       = $bootstrapBefore
            bootstrapClick        = $bootstrapClick
            bootstrapConfirmation = $bootstrapConfirmation
            confirmSweep          = $confirmSweep
            accountConfirm         = $accountConfirm
            accountConfirmInputReady = $accountConfirmInputReady
            serverDialogRetry     = $serverDialogRetry
            inputReady            = $inputReady
            before                = $before
            input                 = $send
            afterEnterQuick       = $afterEnterQuick
            click                 = $click
            loginPulse            = $loginPulse
            loginPulseAttempts    = @($loginPulse.loginPulseAttempts)
            confirmation          = $after
        })

        if ([bool]$after.ready) {
            return [ordered]@{
                ok                  = $true
                worldEntryConfirmed = $true
                reason              = [string]$after.reason
                attempts            = @($attempts.ToArray())
                attemptCount        = [int]$attempts.Count
                elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
                confirmation        = $after
                message             = 'Вход персонажа в игровой мир подтверждён.'
            }
        }
    }

    $finalRemainingSec = [int][Math]::Max(1, [Math]::Floor(($deadline - (Get-Date)).TotalSeconds))
    $finalConfirmation = Wait-BridgeGameWorldEntry -ResolvedGameDir $ResolvedGameDir -TimeoutSec ([Math]::Min(8, $finalRemainingSec)) -PollMilliseconds 500 -RequiredReadySamples 3
    return [ordered]@{
        ok                  = $true
        worldEntryConfirmed = [bool]$finalConfirmation.ready
        reason              = $(if ([bool]$finalConfirmation.ready) { [string]$finalConfirmation.reason } else { 'world_entry_not_detected_after_enter_assist' })
        attempts            = @($attempts.ToArray())
        attemptCount        = [int]$attempts.Count
        elapsedMs           = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
        confirmation        = $finalConfirmation
        message             = $(if ([bool]$finalConfirmation.ready) {
                'Вход персонажа в игровой мир подтверждён.'
            } else {
                'Новый клиент дошёл до запуска, но вход персонажа в игровой мир не подтвердился.'
            })
    }
}

function Write-BridgeRelogTrace {
    param(
        [string]$ResolvedLauncherRoot,
        [AllowNull()][object]$Trace
    )

    if (-not $ResolvedLauncherRoot -or $null -eq $Trace) {
        return
    }

    try {
        $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
        Ensure-Directory -Path $stateDir
        $tracePath = Join-Path $stateDir 'last-relog.json'
        $Trace | ConvertTo-Json -Depth 24 | Set-Content -LiteralPath $tracePath -Encoding UTF8
    } catch {
    }
}

function Get-BridgeGameCenterRuntimeStatus {
    $gameCenterExe = Get-GameCenterExePath
    if ($gameCenterExe) {
        return (Get-ProcessRuntimeStatus -ProcessName 'GameCenter.exe' -ExpectedPath $gameCenterExe)
    }

    return [ordered]@{
        running             = $false
        processCount        = 0
        pid                 = 0
        path                = ''
        matchedExpectedPath = $false
    }
}

function Wait-BridgeGameCenterProcessStart {
    param(
        [int]$TimeoutSec = 12,
        [int]$PollMilliseconds = 500
    )

    $startedAt = Get-Date
    $deadline = $startedAt.AddSeconds([Math]::Max(1, $TimeoutSec))
    $runtime = Get-BridgeGameCenterRuntimeStatus
    while (-not [bool]$runtime.running -and (Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds ([Math]::Max(250, $PollMilliseconds))
        $runtime = Get-BridgeGameCenterRuntimeStatus
    }

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        running             = [bool]$runtime.running
        pid                 = [int]$runtime.pid
        path                = [string]$runtime.path
        processCount        = [int]$runtime.processCount
        matchedExpectedPath = [bool]$runtime.matchedExpectedPath
        elapsedMs           = $elapsedMs
        timeoutSec          = [int]$TimeoutSec
        timedOut            = [bool](-not [bool]$runtime.running)
    }
}

function Invoke-BridgeRelogFreshVkPlayLaunchLoop {
    param(
        [string]$ResolvedGameRoot,
        [string]$ResolvedGameDir,
        [int]$MaxLaunchAttempts = 8,
        [int]$PerAttemptTimeoutSec = 8,
        [int]$InitialWarmupMilliseconds = 1500
    )

    $startedAt = Get-Date
    $attempts = New-Object System.Collections.Generic.List[object]
    $openGameCenter = Open-GameCenterLauncher
    $warmup = Wait-BridgeGameCenterProcessStart -TimeoutSec 12 -PollMilliseconds 500
    if ([int]$InitialWarmupMilliseconds -gt 0) {
        Start-Sleep -Milliseconds ([Math]::Min(5000, [int]$InitialWarmupMilliseconds))
    }

    $lastLaunch = $null
    $lastConfirmation = $null
    for ($launchAttemptNumber = 1; $launchAttemptNumber -le [Math]::Max(1, $MaxLaunchAttempts); $launchAttemptNumber++) {
        $beforeRuntime = Get-RevelationGameRuntimeStatus -ResolvedGameDir $ResolvedGameDir
        if ([bool]$beforeRuntime.running) {
            $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
            return [ordered]@{
                ok                         = $true
                started                    = $true
                blocked                    = $false
                openGameCenter             = $openGameCenter
                warmup                     = $warmup
                attempts                   = @($attempts.ToArray())
                launchAttemptCount         = [int]$attempts.Count
                lastLaunch                 = $lastLaunch
                gameStartConfirmation      = [ordered]@{
                    running      = $true
                    pid          = [int]$beforeRuntime.pid
                    path         = [string]$beforeRuntime.path
                    processCount = [int]$beforeRuntime.processCount
                    elapsedMs    = 0
                    timeoutSec   = 0
                    timedOut     = $false
                }
                finalGameCenterRuntime     = Get-BridgeGameCenterRuntimeStatus
                elapsedMs                  = $elapsedMs
                message                    = 'Релог: новый игровой клиент уже появился во время прогрева VK Play.'
            }
        }

        $attemptStartedAt = Get-Date
        $lastLaunch = Start-RevelationViaGameCenter -ResolvedGameRoot $ResolvedGameRoot
        $lastConfirmation = Wait-BridgeGameProcessStart -ResolvedGameDir $ResolvedGameDir -TimeoutSec $PerAttemptTimeoutSec -PollMilliseconds 500
        $attemptElapsedMs = [int][Math]::Max(0, ((Get-Date) - $attemptStartedAt).TotalMilliseconds)
        [void]$attempts.Add([ordered]@{
                attemptNumber     = [int]$launchAttemptNumber
                launch            = $lastLaunch
                gameStart         = $lastConfirmation
                gameCenterRuntime = Get-BridgeGameCenterRuntimeStatus
                elapsedMs         = $attemptElapsedMs
            })

        if ([bool]$lastConfirmation.running) {
            $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
            return [ordered]@{
                ok                         = $true
                started                    = $true
                blocked                    = $false
                openGameCenter             = $openGameCenter
                warmup                     = $warmup
                attempts                   = @($attempts.ToArray())
                launchAttemptCount         = [int]$attempts.Count
                lastLaunch                 = $lastLaunch
                gameStartConfirmation      = $lastConfirmation
                finalGameCenterRuntime     = Get-BridgeGameCenterRuntimeStatus
                elapsedMs                  = $elapsedMs
                message                    = 'Релог: повторная команда запуска через прогретый VK Play сработала.'
            }
        }

        Start-Sleep -Milliseconds 750
    }

    $elapsedMs = [int][Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds)
    return [ordered]@{
        ok                         = $true
        started                    = $false
        blocked                    = $true
        openGameCenter             = $openGameCenter
        warmup                     = $warmup
        attempts                   = @($attempts.ToArray())
        launchAttemptCount         = [int]$attempts.Count
        lastLaunch                 = $lastLaunch
        gameStartConfirmation      = $lastConfirmation
        finalGameCenterRuntime     = Get-BridgeGameCenterRuntimeStatus
        elapsedMs                  = $elapsedMs
        message                    = 'Релог: VK Play запущен и команды запуска отправлены повторно, но tianyu.exe не появился.'
    }
}

function Invoke-BridgeRelogLaunchWithConfirmation {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameRoot,
        [string]$ResolvedGameDir,
        [ValidateSet('normal', 'quick', 'full_log', 'pvp_safe', 'pvp_aggressive')]
        [string]$LaunchMode,
        [switch]$FreshVkPlayStart
    )

    $launch = Invoke-LaunchGame -ResolvedLauncherRoot $ResolvedLauncherRoot -LaunchMode $LaunchMode -SuppressVkPlayExitWatcher
    if ((Test-BridgeMapHasKey -Map $launch -Key 'blocked') -and [bool]$launch.blocked) {
        return [ordered]@{
            ok                    = [bool]$launch.ok
            started               = $false
            blocked               = $true
            launch                = $launch
            retryLaunch           = $null
            gameStartConfirmation = $null
            relogLaunchConfirmed  = $false
            relogRetryUsed        = $false
            freshVkPlayLaunch     = $null
            freshVkPlayLaunchAttempts = @()
            launchBlockedReason   = $(if (Test-BridgeMapHasKey -Map $launch -Key 'launchBlockedReason') { [string]$launch.launchBlockedReason } else { 'launch_blocked' })
            message               = $(if (Test-BridgeMapHasKey -Map $launch -Key 'message') { [string]$launch.message } else { 'Релог остановлен до повторного запуска.' })
        }
    }

    if (-not ((Test-BridgeMapHasKey -Map $launch -Key 'started') -and [bool]$launch.started)) {
        return [ordered]@{
            ok                    = [bool]$launch.ok
            started               = $false
            blocked               = $true
            launch                = $launch
            retryLaunch           = $null
            gameStartConfirmation = $null
            relogLaunchConfirmed  = $false
            relogRetryUsed        = $false
            freshVkPlayLaunch     = $null
            freshVkPlayLaunchAttempts = @()
            launchBlockedReason   = $(if (Test-BridgeMapHasKey -Map $launch -Key 'launchBlockedReason') { [string]$launch.launchBlockedReason } else { 'launch_not_started' })
            message               = $(if (Test-BridgeMapHasKey -Map $launch -Key 'message') { [string]$launch.message } else { 'Команда повторного запуска не была отправлена.' })
        }
    }

    if ([bool]$FreshVkPlayStart) {
        $confirmation = Wait-BridgeGameProcessStart -ResolvedGameDir $ResolvedGameDir -TimeoutSec 8 -PollMilliseconds 500
    } else {
        $confirmation = Wait-BridgeGameProcessStart -ResolvedGameDir $ResolvedGameDir -TimeoutSec 45 -PollMilliseconds 500
    }
    if ([bool]$confirmation.running) {
        return [ordered]@{
            ok                    = $true
            started               = $true
            blocked               = $false
            launch                = $launch
            retryLaunch           = $null
            gameStartConfirmation = $confirmation
            relogLaunchConfirmed  = $true
            relogRetryUsed        = $false
            freshVkPlayLaunch     = $null
            freshVkPlayLaunchAttempts = @()
            launchBlockedReason   = 'none'
            message               = 'Игра закрыта, новый игровой клиент запущен.'
        }
    }

    if ([bool]$FreshVkPlayStart) {
        $freshLaunch = Invoke-BridgeRelogFreshVkPlayLaunchLoop -ResolvedGameRoot $ResolvedGameRoot -ResolvedGameDir $ResolvedGameDir -MaxLaunchAttempts 8 -PerAttemptTimeoutSec 8
        if ([bool]$freshLaunch.started) {
            return [ordered]@{
                ok                    = $true
                started               = $true
                blocked               = $false
                launch                = $launch
                retryLaunch           = $freshLaunch.lastLaunch
                gameStartConfirmation = $freshLaunch.gameStartConfirmation
                relogLaunchConfirmed  = $true
                relogRetryUsed        = $true
                freshVkPlayLaunch     = $freshLaunch
                freshVkPlayLaunchAttempts = @($freshLaunch.attempts)
                launchBlockedReason   = 'none'
                message               = [string]$freshLaunch.message
            }
        }

        return [ordered]@{
            ok                    = $true
            started               = $false
            blocked               = $true
            launch                = $launch
            retryLaunch           = $freshLaunch.lastLaunch
            gameStartConfirmation = $freshLaunch.gameStartConfirmation
            relogLaunchConfirmed  = $false
            relogRetryUsed        = [bool]([int]$freshLaunch.launchAttemptCount -gt 0)
            freshVkPlayLaunch     = $freshLaunch
            freshVkPlayLaunchAttempts = @($freshLaunch.attempts)
            launchBlockedReason   = 'relog_launch_not_detected'
            message               = 'Релог остановлен: VK Play был перезапущен, но новый tianyu.exe не появился после повторных команд запуска.'
        }
    }

    $retryLaunch = Start-RevelationViaGameCenter -ResolvedGameRoot $ResolvedGameRoot
    $retryConfirmation = Wait-BridgeGameProcessStart -ResolvedGameDir $ResolvedGameDir -TimeoutSec 60 -PollMilliseconds 500
    if ([bool]$retryConfirmation.running) {
        return [ordered]@{
            ok                    = $true
            started               = $true
            blocked               = $false
            launch                = $launch
            retryLaunch           = $retryLaunch
            gameStartConfirmation = $retryConfirmation
            relogLaunchConfirmed  = $true
            relogRetryUsed        = $true
            freshVkPlayLaunch     = $null
            freshVkPlayLaunchAttempts = @()
            launchBlockedReason   = 'none'
            message               = 'Игра закрыта, повторная команда запуска сработала: новый игровой клиент запущен.'
        }
    }

    return [ordered]@{
        ok                    = $true
        started               = $false
        blocked               = $true
        launch                = $launch
        retryLaunch           = $retryLaunch
        gameStartConfirmation = $retryConfirmation
        relogLaunchConfirmed  = $false
        relogRetryUsed        = [bool]$retryLaunch.started
        freshVkPlayLaunch     = $null
        freshVkPlayLaunchAttempts = @()
        launchBlockedReason   = 'relog_launch_not_detected'
        message               = 'Релог остановлен: команда запуска отправлена, но новый tianyu.exe не появился после повторной попытки.'
    }
}

function Invoke-BridgeGameRelog {
    param(
        [string]$ResolvedLauncherRoot,
        [switch]$FastMode
    )

    $configPath = Join-Path $ResolvedLauncherRoot 'launcher-config.ini'
    $config = Read-KeyValueFile -Path $configPath
    $launcherIdentity = Get-LauncherStatusIdentity -ResolvedLauncherRoot $ResolvedLauncherRoot -Config $config
    Assert-BridgeLicense -ResolvedLauncherRoot $ResolvedLauncherRoot -Context 'launch' | Out-Null
    $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
    $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    $experimentalLatencyBufferEnabled = [bool]((Get-Command -Name Test-PvpExperimentalRuntimeTuningAllowed -ErrorAction SilentlyContinue) -and
        (Test-PvpExperimentalRuntimeTuningAllowed -ResolvedLauncherRoot $ResolvedLauncherRoot))
    $launchMode = if ($experimentalLatencyBufferEnabled) { 'normal' } else { 'quick' }
    $profile = if ($experimentalLatencyBufferEnabled) { 'latency_buffer_4f' } else { 'scheduler_default' }
    $relogAdminFallbackUsed = $false
    $fullLogEnabled = $false

    $gameInputElevation = Get-BridgeGameInputElevationRequirement -ResolvedGameDir $resolvedGameDir
    if (($experimentalLatencyBufferEnabled -and -not (Test-IsAdministrator)) -or [bool]$gameInputElevation.requiresAdmin) {
        $adminRequiredResult = [ordered]@{
            ok                  = $true
            relog               = $true
            fastRelog           = [bool]$FastMode
            blocked             = $true
            started             = $false
            channel             = [string]$launcherIdentity.releaseChannel
            mode                = $launchMode
            profile             = $profile
            fullLogEnabled      = [bool]$fullLogEnabled
            fullLogRequired     = [bool]$fullLogEnabled
            fullLogReady        = $false
            launchBlockedReason = 'admin_required'
            needsAdminRelaunch  = $true
            relogAdminFallbackUsed = [bool]$relogAdminFallbackUsed
            gameRoot            = $resolvedGameRoot
            gameDir             = $resolvedGameDir
            gameInputElevation  = $gameInputElevation
            message             = 'Для штатного релога нужны права администратора. После подтверждения Windows действие продолжится; игра пока не закрывалась.'
        }
        Write-BridgeRelogTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $adminRequiredResult
        return $adminRequiredResult
    }

    # Invoke-LaunchGame refreshes the display and applies the cap after the old client exits.
    $gpuRelogPreflight = [ordered]@{ ok = $true; applied = $false; skipped = $true; reason = 'deferred_until_relaunch' }

    $oldVkPlayExitWatchers = @(Get-VkPlayExitWatcherProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot)
    Stop-VkPlayExitWatcherProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot -Watchers $oldVkPlayExitWatchers

    $shutdown = Stop-BridgeGameProcessesGracefully `
        -ResolvedLauncherRoot $ResolvedLauncherRoot `
        -ResolvedGameDir $resolvedGameDir `
        -Reason 'recognized_menu_exit' `
        -GracefulTimeoutSec 90
    if (-not [bool]$shutdown.ok) {
        $restoredVkPlayExitWatcher = if ([bool]$shutdown.after.running) {
            Start-VkPlayShutdownAfterGameExitWatcher `
                -ResolvedLauncherRoot $ResolvedLauncherRoot `
                -ResolvedGameDir $resolvedGameDir `
                -Enabled ([bool]$settings.closeVkPlayAfterGameExit)
        } else {
            [ordered]@{
                enabled   = [bool]$settings.closeVkPlayAfterGameExit
                started   = $false
                processId = 0
                message   = 'Игра уже закрыта; VK Play сохранён после отмены релога.'
            }
        }
        $shutdownBlockedResult = [ordered]@{
            ok              = $true
            relog           = $true
            fastRelog       = [bool]$FastMode
            blocked         = $true
            started         = $false
            mode            = $launchMode
            profile         = $profile
            launchBlockedReason = $(if ([bool]$shutdown.cancelled) { 'operation_cancelled' } else { 'relog_graceful_exit_timeout' })
            relogAdminFallbackUsed = [bool]$relogAdminFallbackUsed
            stoppedGame     = $shutdown
            gpuProfile      = $gpuRelogPreflight
            restoredVkPlayExitWatcher = $restoredVkPlayExitWatcher
            gameRoot        = $resolvedGameRoot
            gameDir         = $resolvedGameDir
            oldVkPlayExitWatcherCount = [int]$oldVkPlayExitWatchers.Count
            message         = [string]$shutdown.message
        }
        Write-BridgeRelogTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $shutdownBlockedResult
        return $shutdownBlockedResult
    }

    if (Test-BridgeOperationCancelled) {
        $cancelledResult = [ordered]@{
            ok                  = $true
            relog               = $true
            fastRelog           = [bool]$FastMode
            blocked             = $true
            started             = $false
            mode                = $launchMode
            profile             = $profile
            launchBlockedReason = 'operation_cancelled'
            relogAdminFallbackUsed = [bool]$relogAdminFallbackUsed
            stoppedGame         = $shutdown
            gpuProfile          = $gpuRelogPreflight
            gameRoot            = $resolvedGameRoot
            gameDir             = $resolvedGameDir
            oldVkPlayExitWatcherCount = [int]$oldVkPlayExitWatchers.Count
            message             = 'Релог остановлен пользователем до повторного запуска игры.'
        }
        Write-BridgeRelogTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $cancelledResult
        return $cancelledResult
    }

    if (Get-Command -Name Disable-LauncherPvpRecoveryMode -ErrorAction SilentlyContinue) {
        try {
            [void](Disable-LauncherPvpRecoveryMode -LauncherRoot $ResolvedLauncherRoot)
        } catch {
        }
    }
    [void](Stop-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot)

    $cleanupAction = 'PreserveVkPlayForRelog'
    $cleanup = Get-VkPlayProcessSnapshot -Reason 'relog_preserve_vkplay_for_relaunch'
    Set-BridgeOperationPhase -Phase 'relaunching' -Cancellable $false
    $launchAttempt = Invoke-BridgeRelogLaunchWithConfirmation -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameRoot $resolvedGameRoot -ResolvedGameDir $resolvedGameDir -LaunchMode $launchMode -FreshVkPlayStart:$false
    $worldEntryAssist = $null
    $postWorldVkPlayExitWatcher = $null
    if ((Test-BridgeMapHasKey -Map $launchAttempt -Key 'started') -and [bool]$launchAttempt.started -and -not ((Test-BridgeMapHasKey -Map $launchAttempt -Key 'blocked') -and [bool]$launchAttempt.blocked)) {
        Set-BridgeOperationPhase -Phase 'waiting_for_world_entry' -Cancellable $true
        . (Join-Path $ResolvedLauncherRoot 'tools\RevelationGameBridge.ps1')
        $worldEntryAssist = Wait-RevelationSelectedCharacterEntry -LauncherRoot $ResolvedLauncherRoot -GameDir $resolvedGameDir -ForceSkipCharacterSelection -IsCancelled { Test-BridgeOperationCancelled }
        if (-not [bool]$worldEntryAssist.worldEntryConfirmed -and -not ((Test-BridgeMapHasKey -Map $worldEntryAssist -Key 'skipped') -and [bool]$worldEntryAssist.skipped)) {
            $result = [ordered]@{
                ok                   = [bool]($launchAttempt.ok)
                relog                = $true
                fastRelog            = [bool]$FastMode
                blocked              = $true
                started              = $true
                channel              = [string]$launcherIdentity.releaseChannel
                mode                 = $launchMode
                profile              = $profile
                launchBlockedReason  = 'relog_world_entry_not_confirmed'
                relogAdminFallbackUsed = [bool]$relogAdminFallbackUsed
                worldEntryConfirmed  = $false
                worldEntryAssist     = $worldEntryAssist
                needsAdminRelaunch   = [bool]((Test-BridgeMapHasKey -Map $launchAttempt.launch -Key 'needsAdminRelaunch') -and [bool]$launchAttempt.launch.needsAdminRelaunch)
                gameRoot             = $resolvedGameRoot
                gameDir              = $resolvedGameDir
                oldVkPlayExitWatcherCount = [int]$oldVkPlayExitWatchers.Count
                stoppedGame          = $shutdown
                cleanupAction        = $cleanupAction
                cleanup              = $cleanup
                launch               = $launchAttempt.launch
                retryLaunch          = $launchAttempt.retryLaunch
                gameStartConfirmation = $launchAttempt.gameStartConfirmation
                relogLaunchConfirmed = [bool]$launchAttempt.relogLaunchConfirmed
                relogRetryUsed       = [bool]$launchAttempt.relogRetryUsed
                freshVkPlayLaunch    = $(if (Test-BridgeMapHasKey -Map $launchAttempt -Key 'freshVkPlayLaunch') { $launchAttempt.freshVkPlayLaunch } else { $null })
                freshVkPlayLaunchAttempts = $(if (Test-BridgeMapHasKey -Map $launchAttempt -Key 'freshVkPlayLaunchAttempts') { @($launchAttempt.freshVkPlayLaunchAttempts) } else { @() })
                postWorldVkPlayExitWatcher = $postWorldVkPlayExitWatcher
                message              = ('Релог остановлен: новый клиент запущен, но вход персонажа в игровой мир не подтвердился. Причина: ' + [string]$worldEntryAssist.reason)
            }
            Write-BridgeRelogTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $result
            return $result
        }

        $postWorldVkPlayExitWatcher = Start-VkPlayShutdownAfterGameExitWatcher -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Enabled ([bool]$settings.closeVkPlayAfterGameExit)
    }

    $result = [ordered]@{
        ok                   = [bool]($launchAttempt.ok)
        relog                = $true
        fastRelog            = [bool]$FastMode
        blocked              = [bool]((Test-BridgeMapHasKey -Map $launchAttempt -Key 'blocked') -and [bool]$launchAttempt.blocked)
        started              = [bool]((Test-BridgeMapHasKey -Map $launchAttempt -Key 'started') -and [bool]$launchAttempt.started)
        channel              = [string]$launcherIdentity.releaseChannel
        mode                 = $launchMode
        profile              = $profile
        launchBlockedReason  = $(if (Test-BridgeMapHasKey -Map $launchAttempt -Key 'launchBlockedReason') { [string]$launchAttempt.launchBlockedReason } else { 'none' })
        relogAdminFallbackUsed = [bool]$relogAdminFallbackUsed
        needsAdminRelaunch   = [bool]((Test-BridgeMapHasKey -Map $launchAttempt.launch -Key 'needsAdminRelaunch') -and [bool]$launchAttempt.launch.needsAdminRelaunch)
        gameRoot             = $resolvedGameRoot
        gameDir              = $resolvedGameDir
        oldVkPlayExitWatcherCount = [int]$oldVkPlayExitWatchers.Count
        stoppedGame          = $shutdown
        cleanupAction        = $cleanupAction
        cleanup              = $cleanup
        launch               = $launchAttempt.launch
        retryLaunch          = $launchAttempt.retryLaunch
        gameStartConfirmation = $launchAttempt.gameStartConfirmation
        relogLaunchConfirmed = [bool]$launchAttempt.relogLaunchConfirmed
        relogRetryUsed       = [bool]$launchAttempt.relogRetryUsed
        freshVkPlayLaunch    = $(if (Test-BridgeMapHasKey -Map $launchAttempt -Key 'freshVkPlayLaunch') { $launchAttempt.freshVkPlayLaunch } else { $null })
        freshVkPlayLaunchAttempts = $(if (Test-BridgeMapHasKey -Map $launchAttempt -Key 'freshVkPlayLaunchAttempts') { @($launchAttempt.freshVkPlayLaunchAttempts) } else { @() })
        worldEntryConfirmed  = [bool]($worldEntryAssist -and [bool]$worldEntryAssist.worldEntryConfirmed)
        worldEntryAssist     = $worldEntryAssist
        postWorldVkPlayExitWatcher = $postWorldVkPlayExitWatcher
        message              = $(if (Test-BridgeMapHasKey -Map $launchAttempt -Key 'message') {
                if ($worldEntryAssist -and [bool]$worldEntryAssist.worldEntryConfirmed) {
                    'Релог завершён: персонаж вошёл в игровой мир.'
                } else {
                    [string]$launchAttempt.message
                }
            } else {
                'Релог остановлен до повторного запуска.'
            })
    }
    Write-BridgeRelogTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $result
    return $result
}

function Invoke-BridgeGameFastRelog {
    param([string]$ResolvedLauncherRoot)

    return Invoke-BridgeGameRelog -ResolvedLauncherRoot $ResolvedLauncherRoot -FastMode
}

function Start-GamePerformanceRuntime {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameRoot,
        [string]$ResolvedGameDir
    )

    [void](Stop-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot)
    return [ordered]@{
        started   = $false
        processId = 0
        reason    = 'scheduler_default'
        mode      = 'windows-default'
    }
}

function Stop-GamePerformanceRuntime {
    param([string]$ResolvedLauncherRoot)

    $statePath = Join-Path $ResolvedLauncherRoot '.revelation-combat\game-performance-runtime.json'
    $watcherPid = 0
    if (Test-Path -LiteralPath $statePath) {
        try {
            $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            $watcherPid = [int](Get-BridgeObjectPropertyValue -Object $state -Name 'watcherPid' -Default 0)
        } catch {
            $watcherPid = 0
        }
    }

    if ($watcherPid -gt 0 -and $watcherPid -ne $PID) {
        Stop-Process -Id $watcherPid -Force -ErrorAction SilentlyContinue
    }
    if (Get-Command -Name Restore-PvpRuntimeProcessTune -ErrorAction SilentlyContinue) {
        try {
            [void](Restore-PvpRuntimeProcessTune -ResolvedLauncherRoot $ResolvedLauncherRoot -StateFileName 'game-process-tune-state.json')
        } catch {
        }
    }
    Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue

    return [ordered]@{
        stopped   = [bool]($watcherPid -gt 0)
        processId = $watcherPid
    }
}

function Undo-BridgeCancelledPrelaunchState {
    param([string]$ResolvedLauncherRoot)

    $nativeHelper = Join-Path $ResolvedLauncherRoot 'tools\RevelationGameBridge.ps1'
    if (Test-Path -LiteralPath $nativeHelper) {
        try {
            . $nativeHelper
            $gameDir = Resolve-GameDir -ResolvedGameRoot (Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot)
            Stop-RevelationGameBridgeSession -LauncherRoot $ResolvedLauncherRoot -GameDir $gameDir -Restore
        } catch { }
    }
    [void](Stop-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot)
    if (Get-Command -Name Disable-LauncherPvpRecoveryMode -ErrorAction SilentlyContinue) {
        try {
            [void](Disable-LauncherPvpRecoveryMode -LauncherRoot $ResolvedLauncherRoot)
        } catch {
        }
    }
}

function Start-VkPlayShutdownAfterGameExitWatcher {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$ResolvedGameDir,
        [bool]$Enabled
    )

    if (-not $Enabled) {
        return [ordered]@{ enabled = $false; started = $false; processId = 0; message = 'Авто-закрытие VK Play после выхода из игры выключено.' }
    }

    $tianyuExe = Join-Path $ResolvedGameDir 'tianyu.exe'
    if (-not (Test-Path -LiteralPath $tianyuExe)) {
        return [ordered]@{ enabled = $true; started = $false; processId = 0; message = 'tianyu.exe не найден, watcher закрытия VK Play не запущен.' }
    }

    try {
        Stop-VkPlayExitWatcherProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
        $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
        Ensure-Directory -Path $stateDir
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $wrapperPath = Join-Path $stateDir ('vkplay-exit-watch-' + $stamp + '.ps1')
        $logPath = Join-Path $stateDir 'vkplay-exit-watch.log'
        $tianyuLiteral = ConvertTo-PowerShellSingleQuotedLiteral -Value $tianyuExe
        $logLiteral = ConvertTo-PowerShellSingleQuotedLiteral -Value $logPath
        $bridgeLiteral = ConvertTo-PowerShellSingleQuotedLiteral -Value $PSCommandPath
        $launcherRootLiteral = ConvertTo-PowerShellSingleQuotedLiteral -Value $ResolvedLauncherRoot

        $wrapperLines = @(
            '$ErrorActionPreference = ''SilentlyContinue''',
            ('$tianyuExe = ' + $tianyuLiteral),
            ('$logPath = ' + $logLiteral),
            ('$bridgePath = ' + $bridgeLiteral),
            ('$launcherRoot = ' + $launcherRootLiteral),
            '$gameProcessNames = @(''tianyu.exe'', ''tianyu64.exe'', ''tianyu_dx11.exe'', ''tianyu_beta.exe'', ''tianyu64_beta.exe'', ''tianyu_p.exe'', ''tianyu_rs.exe'')',
            '$pollSec = 2',
            '$waitForGameSec = 900',
            'function Add-WatcherLog {',
            '    param([string]$Message)',
            '    $line = ((Get-Date -Format ''s'') + '' '' + $Message)',
            '    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8',
            '}',
            'function Get-TianyuPids {',
            '    $rows = @()',
            '    foreach ($processName in $gameProcessNames) {',
            '        $escapedName = $processName.Replace("''", "''''")',
            '        $rows += @(Get-CimInstance Win32_Process -Filter ("Name=''" + $escapedName + "''") -ErrorAction SilentlyContinue)',
            '    }',
            '    if ($rows.Count -eq 0) { return @() }',
            '    if ($tianyuExe) {',
            '        try {',
            '            $needle = [System.IO.Path]::GetFullPath($tianyuExe).ToLowerInvariant()',
            '            $matched = @(',
            '                $rows | Where-Object {',
            '                    $_.ExecutablePath -and ([System.IO.Path]::GetFullPath([string]$_.ExecutablePath).ToLowerInvariant() -eq $needle)',
            '                } | Select-Object -ExpandProperty ProcessId',
            '            )',
            '            if ($matched.Count -gt 0) { return @($matched) }',
            '        } catch {',
            '        }',
            '    }',
            '    return @($rows | Select-Object -ExpandProperty ProcessId)',
            '}',
            'function Stop-VkPlayProcesses {',
            '    $stopped = New-Object System.Collections.Generic.List[string]',
            '    foreach ($name in @(''BrowserProxy'', ''GameCenter'')) {',
            '        foreach ($proc in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {',
            '            try {',
            '                Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue',
            '                [void]$stopped.Add(($name + '':'' + [string]$proc.Id))',
            '            } catch {',
            '            }',
            '        }',
            '    }',
            '    return @($stopped.ToArray())',
            '}',
            'try {',
            '    Add-WatcherLog ''VK Play exit watcher started.''',
            '    $deadline = (Get-Date).AddSeconds($waitForGameSec)',
            '    $seenGame = $false',
            '    while ((Get-Date) -lt $deadline) {',
            '        $pids = @(Get-TianyuPids)',
            '        if ($pids.Count -gt 0) {',
            '            $seenGame = $true',
            '            Add-WatcherLog (''tianyu.exe detected: '' + ($pids -join '',''))',
            '            break',
            '        }',
            '        Start-Sleep -Seconds $pollSec',
            '    }',
            '    if (-not $seenGame) {',
            '        Add-WatcherLog ''tianyu.exe was not detected before timeout. Leaving VK Play running.''',
            '        exit 0',
            '    }',
            '    while ($true) {',
            '        if (@(Get-TianyuPids).Count -eq 0) { break }',
            '        Start-Sleep -Seconds $pollSec',
            '    }',
            '    Start-Sleep -Seconds 3',
            '    if (@(Get-TianyuPids).Count -gt 0) { Add-WatcherLog ''Game restarted; leaving VK Play running.''; exit 0 }',
            '    $stopped = @(Stop-VkPlayProcesses)',
            '    if ($stopped.Count -gt 0) {',
            '        Add-WatcherLog (''VK Play stopped after game exit: '' + ($stopped -join '', ''))',
            '    } else {',
            '        Add-WatcherLog ''Game exited; VK Play processes were not found.''',
            '    }',
            '} catch {',
            '    Add-WatcherLog (''Watcher error: '' + $_.Exception.Message)',
            '}'
        )
        [System.IO.File]::WriteAllText($wrapperPath, [string]::Join([Environment]::NewLine, $wrapperLines), [System.Text.UTF8Encoding]::new($false))

        # ShellExecute starts a detached watcher without inheriting the bridge's
        # stdout/stderr pipes. Start-Process redirection alone still leaks those
        # handles on Windows PowerShell 5.1, keeping ReadToEndAsync pending.
        $watchInfo = New-Object System.Diagnostics.ProcessStartInfo
        $watchInfo.FileName = Get-PreferredPowerShellExe
        $watchInfo.UseShellExecute = $true
        $watchInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $watchInfo.Arguments = ConvertTo-NativeArgumentString -Arguments @(
                '-NoProfile',
                '-ExecutionPolicy', 'Bypass',
                '-WindowStyle', 'Hidden',
                '-File', $wrapperPath
            )
        $proc = [System.Diagnostics.Process]::Start($watchInfo)

        return [ordered]@{
            enabled   = $true
            started   = $true
            processId = [int]$proc.Id
            path      = $wrapperPath
            logPath   = $logPath
            message   = 'VK Play будет закрыт автоматически после выхода из игры.'
        }
    } catch {
        return [ordered]@{
            enabled   = $true
            started   = $false
            processId = 0
            error     = $_.Exception.Message
            message   = 'Не удалось запустить watcher закрытия VK Play: ' + $_.Exception.Message
        }
    }
}

function Invoke-LaunchGame {
    param(
        [string]$ResolvedLauncherRoot,
        [ValidateSet('normal', 'quick', 'full_log', 'pvp_safe', 'pvp_aggressive')]
        [string]$LaunchMode,
        [switch]$SuppressVkPlayExitWatcher
    )

    Set-BridgeOperationPhase -Phase 'preflight'
    Assert-BridgeOperationNotCancelled
    Assert-BridgeLicense -ResolvedLauncherRoot $ResolvedLauncherRoot -Context 'launch' | Out-Null
    $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
    $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    $startVkPlayExitWatcher = [bool]([bool]$settings.closeVkPlayAfterGameExit -and -not [bool]$SuppressVkPlayExitWatcher)
    $combatScript = Join-Path $ResolvedLauncherRoot 'RevelationCombat.ps1'
    $serverPreflightResult = [ordered]@{
        ok      = $true
        enabled = [bool]$settings.serverPreflight
        skipped = [bool](-not [bool]$settings.serverPreflight)
        message = $(if ([bool]$settings.serverPreflight) { 'Preflight not run.' } else { 'Preflight disabled by launcher setting.' })
    }
    if ([bool]$settings.serverPreflight) {
        $serverPreflightResult = Test-RevelationLaunchServerPreflight -ResolvedGameRoot $resolvedGameRoot -ResolvedGameDir $resolvedGameDir -StateDir $stateDir
        if (-not [bool]$serverPreflightResult.ok) {
            return [ordered]@{
                ok                  = $true
                started             = $false
                blocked             = $true
                mode                = $LaunchMode
                launchBlockedReason = 'server_preflight_failed'
                serverPreflight     = $serverPreflightResult
                message             = [string]$serverPreflightResult.message
            }
        }
    }
    Assert-BridgeOperationNotCancelled
    $introPackageResult = Set-RevelationIntroPackageState -ResolvedGameRoot $resolvedGameRoot -DisableIntroMovies:([bool]$settings.disableIntroMovies)
    # Prepare synchronously: never report launch success after a swallowed module failure.
    . (Join-Path $ResolvedLauncherRoot 'tools/RevelationGameBridge.ps1')
    if (-not @(Get-RevelationGameBridgeProcesses -GameDir $resolvedGameDir).Count) {
        Set-BridgeOperationPhase -Phase 'preparing_game_module' -Cancellable $false
        try {
            Restore-CanaryLegacyModule -LauncherRoot $ResolvedLauncherRoot -GameDir $resolvedGameDir
            $preparedModule = Initialize-RevelationGameBridgeSession -LauncherRoot $ResolvedLauncherRoot -GameDir $resolvedGameDir
            if (-not $preparedModule.ready) { throw ([string]$preparedModule.reason) }
        } catch {
            $accessDenied = $_.Exception -is [UnauthorizedAccessException] -or $_.CategoryInfo.Category -eq 'PermissionDenied'
            return [ordered]@{ok=$true;started=$false;blocked=$true;needsAdminRelaunch=$accessDenied;launchBlockedReason='game_module_prepare_failed';message=('Не удалось подготовить игровой модуль. Игра не запущена. Причина: '+$_.Exception.Message)}
        }
    }

    Set-BridgeOperationPhase -Phase 'gpu_profile'
    Assert-BridgeOperationNotCancelled
    $gpuApplyResult = Invoke-ApplyGpuProfileSettingsIfEnabled -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Force -ForceHardwareRefresh
    if ($gpuApplyResult -and (Test-BridgeMapHasKey -Map $gpuApplyResult -Key 'ok') -and -not [bool]$gpuApplyResult.ok) {
        $gpuMessage = if ((Test-BridgeMapHasKey -Map $gpuApplyResult -Key 'message') -and $gpuApplyResult.message) {
            [string]$gpuApplyResult.message
        } else {
            'GPU profile was not applied.'
        }
        return [ordered]@{
            ok                   = $true
            started              = $false
            blocked              = $true
            mode                 = $LaunchMode
            launchBlockedReason  = 'gpu_profile_failed'
            needsAdminRelaunch   = [bool]($gpuMessage -match '(?i)administrator|администратор')
            serverPreflight      = $serverPreflightResult
            gpuProfile           = $gpuApplyResult
            message              = 'Видео-профиль не применён, запуск не начат: ' + $gpuMessage
        }
    }
    Assert-BridgeOperationNotCancelled
    $validatedGpuFpsCap = 0
    $validatedGpuLimiterProvider = 'legacy'
    $gpuStatus = Get-BridgeObjectPropertyValue -Object $gpuApplyResult -Name 'status' -Default $null
    if ($gpuStatus) {
        $gpuCapEnabled = [bool](Get-BridgeObjectPropertyValue -Object $gpuStatus -Name 'capEnabled' -Default $false)
        $effectiveGpuFpsCap = [int](Get-BridgeObjectPropertyValue -Object $gpuStatus -Name 'effectiveFpsCap' -Default 0)
        if ($gpuCapEnabled -and $effectiveGpuFpsCap -gt 0) {
            $validatedGpuFpsCap = $effectiveGpuFpsCap
        }
        $statusLimiterProvider = [string](Get-BridgeObjectPropertyValue -Object $gpuStatus -Name 'limiterProvider' -Default '')
        if ($statusLimiterProvider -in @('none', 'dxvk_config', 'nvidia_profile_inspector', 'amd_adlx_frtc')) {
            $validatedGpuLimiterProvider = $statusLimiterProvider
        }
    }
    $applyLimiterProvider = [string](Get-BridgeObjectPropertyValue -Object $gpuApplyResult -Name 'limiterProvider' -Default '')
    if ($applyLimiterProvider -in @('none', 'dxvk_config', 'nvidia_profile_inspector', 'amd_adlx_frtc')) {
        $validatedGpuLimiterProvider = $applyLimiterProvider
    }

    if ($LaunchMode -eq 'normal') {
        if (-not (Test-Path -LiteralPath $combatScript)) {
            throw 'RevelationCombat.ps1 not found.'
        }

        $experimentalLatencyBufferEnabled = [bool]((Get-Command -Name Test-PvpExperimentalRuntimeTuningAllowed -ErrorAction SilentlyContinue) -and
            (Test-PvpExperimentalRuntimeTuningAllowed -ResolvedLauncherRoot $ResolvedLauncherRoot))
        $latencyBufferEnableResult = $null
        if ($experimentalLatencyBufferEnabled) {
            Assert-BridgePvpRecoveryBackend
            if (-not (Test-IsAdministrator)) {
                return [ordered]@{
                    ok                  = $true
                    started             = $false
                    blocked             = $true
                    mode                = 'normal'
                    launchBlockedReason = 'admin_required'
                    needsAdminRelaunch  = $true
                    serverPreflight     = $serverPreflightResult
                    gpuProfile          = $gpuApplyResult
                    message             = 'Для экспериментального четырёхкадрового сетевого буфера нужен запуск лаунчера от администратора.'
                }
            }

            [void](Stop-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot)
            $latencyBufferEnableResult = Enable-LauncherPvpRecoveryMode -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Profile 'safe'
        } elseif (Get-Command -Name Disable-LauncherPvpRecoveryMode -ErrorAction SilentlyContinue) {
            try {
                [void](Disable-LauncherPvpRecoveryMode -LauncherRoot $ResolvedLauncherRoot)
            } catch {
            }
        }

        $combatArgs = @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', $combatScript,
            'Apply',
            '-GameDir', $resolvedGameRoot,
            '-LauncherRoot', $ResolvedLauncherRoot,
            '-SkipGpuProfileApply',
            '-ValidatedGpuFpsCap', [string]$validatedGpuFpsCap,
            '-ValidatedGpuLimiterProvider', $validatedGpuLimiterProvider,
            '-Silent'
        )
        if (-not $experimentalLatencyBufferEnabled) {
            $combatArgs += '-SkipPvpRecoveryRuntime'
        }
        Set-BridgeOperationPhase -Phase 'applying_profile'
        Assert-BridgeOperationNotCancelled
        $applyExit = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments $combatArgs -HiddenWindow
        if ($applyExit -ne 0) {
            if ($experimentalLatencyBufferEnabled) {
                Undo-BridgeCancelledPrelaunchState -ResolvedLauncherRoot $ResolvedLauncherRoot
            }
            throw ('Combat preset apply failed before VK Play open. Exit code: ' + $applyExit)
        }
        if (Test-BridgeOperationCancelled) {
            if ($experimentalLatencyBufferEnabled) {
                Undo-BridgeCancelledPrelaunchState -ResolvedLauncherRoot $ResolvedLauncherRoot
            }
            throw [System.OperationCanceledException]::new('Запуск остановлен до передачи команды в VK Play.')
        }

        Set-BridgeOperationPhase -Phase 'launch_command_sent' -Cancellable $false
        $launchResult = if ([bool]$settings.directGameLaunch) {
            Start-RevelationViaGameCenter -ResolvedGameRoot $resolvedGameRoot
        } else {
            $vkPlayResult = Open-GameCenterLauncher
            [ordered]@{
                started   = [bool]$vkPlayResult.started
                fallback  = $true
                path      = $vkPlayResult.path
                launchUri = ''
            }
        }
        if (-not $launchResult.started) {
            throw $(if ([bool]$settings.directGameLaunch) { 'Не удалось отправить прямой запуск через VK Play.' } else { 'VK Play was not detected automatically.' })
        }
        $performanceRuntime = if ($experimentalLatencyBufferEnabled) {
            [ordered]@{ started = $false; processId = 0; reason = 'experimental_latency_buffer_runtime'; mode = 'game-buffer-4f' }
        } else {
            Start-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameRoot $resolvedGameRoot -ResolvedGameDir $resolvedGameDir
        }
        $vkPlayExitWatcher = Start-VkPlayShutdownAfterGameExitWatcher -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Enabled $startVkPlayExitWatcher

        return [ordered]@{
            ok           = $true
            started      = $true
            launchAccepted = $true
            commandSent  = $true
            mode         = 'normal'
            vkPlayOpened = [bool]$launchResult.started
            directLaunch = [bool]($launchResult.started -and -not $launchResult.fallback)
            launchUri    = [string]$launchResult.launchUri
            path         = $launchResult.path
            introPackage = $introPackageResult
            gpuProfile   = $gpuApplyResult
            serverPreflight = $serverPreflightResult
            performanceRuntime = $performanceRuntime
            latencyBuffer = $latencyBufferEnableResult
            vkPlayExitWatcher = $vkPlayExitWatcher
            message      = $(if ([bool]$settings.directGameLaunch) {
                    if ($launchResult.fallback) {
                        'Прямой запуск не сработал, поэтому открыт VK Play.'
                    } elseif ($experimentalLatencyBufferEnabled) {
                        'Команда на запуск отправлена; экспериментальный четырёхкадровый сетевой буфер будет проверен после входа в мир.'
                    } else {
                        'Команда на прямой запуск игры отправлена через VK Play.'
                    }
                } else {
                    'VK Play открыт. Теперь можно выбрать аккаунт, обновить игру и запустить Revelation вручную.'
                })
        }
    }

    if ($LaunchMode -eq 'quick') {
        if (-not (Test-Path -LiteralPath $combatScript)) {
            throw 'RevelationCombat.ps1 not found.'
        }

        Assert-BridgeOperationNotCancelled
        $quickArgs = ConvertTo-EncodedPowerShellInvocationArguments -Arguments @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', $combatScript,
            'Launch',
            '-GameDir', $resolvedGameRoot,
            '-LauncherRoot', $ResolvedLauncherRoot,
            '-SkipPvpRecoveryRuntime',
            '-SkipGpuProfileApply',
            '-ValidatedGpuFpsCap', [string]$validatedGpuFpsCap,
            '-ValidatedGpuLimiterProvider', $validatedGpuLimiterProvider,
            '-Silent'
        )
        Set-BridgeOperationPhase -Phase 'launch_command_sent' -Cancellable $false
        Start-Process -FilePath (Get-PreferredPowerShellExe) -ArgumentList (ConvertTo-NativeArgumentString -Arguments $quickArgs) -WindowStyle Hidden | Out-Null
        $performanceRuntime = Start-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameRoot $resolvedGameRoot -ResolvedGameDir $resolvedGameDir
        $vkPlayExitWatcher = Start-VkPlayShutdownAfterGameExitWatcher -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Enabled $startVkPlayExitWatcher

        return [ordered]@{
            ok      = $true
            started = $true
            mode    = 'quick'
            introPackage = $introPackageResult
            gpuProfile = $gpuApplyResult
            serverPreflight = $serverPreflightResult
            performanceRuntime = $performanceRuntime
            vkPlayExitWatcher = $vkPlayExitWatcher
            message = 'Быстрый запуск отправлен через VK Play.'
        }
    }

    if ($LaunchMode -in @('pvp_safe', 'pvp_aggressive')) {
        if (-not (Test-Path -LiteralPath $combatScript)) {
            throw 'RevelationCombat.ps1 not found.'
        }

        Assert-BridgePvpRecoveryBackend
        $profile = if ($LaunchMode -eq 'pvp_aggressive') { 'aggressive' } else { 'safe' }
        $profileLabel = if ($profile -eq 'aggressive') { 'Агрессивный игровой буст' } else { 'Безопасный игровой буст' }
        $pvpStatus = Get-LauncherPvpRecoveryStatus -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
        $fullLogEnabled = $(if (Test-BridgeMapHasKey -Map $pvpStatus -Key 'fullLogEnabled') { [bool]$pvpStatus.fullLogEnabled } else { $true })
        if (-not $pvpStatus.supported) {
            throw 'Игровые профили недоступны в текущем канале лаунчера.'
        }

        $blockedReason = if (Test-BridgeMapHasKey -Map $pvpStatus -Key 'launchBlockedReason') {
            [string]$pvpStatus.launchBlockedReason
        } else {
            'none'
        }
        if ([string]::IsNullOrWhiteSpace($blockedReason)) {
            $blockedReason = 'none'
        }

        if ($blockedReason -eq 'admin_required') {
            return [ordered]@{
                ok                 = $true
                started            = $false
                blocked            = $true
                mode               = $LaunchMode
                profile            = $profile
                fullLogEnabled     = [bool]$fullLogEnabled
                fullLogRequired    = [bool]$fullLogEnabled
                fullLogReady       = [bool]($fullLogEnabled -and $pvpStatus.fullLogReady)
                launchBlockedReason = 'admin_required'
                needsAdminRelaunch = $true
                serverPreflight    = $serverPreflightResult
                message            = $profileLabel + ': нужен запуск лаунчера от администратора.'
            }
        }

        if ($blockedReason -ne 'none') {
            return [ordered]@{
                ok                  = $true
                started             = $false
                blocked             = $true
                mode                = $LaunchMode
                profile             = $profile
                fullLogEnabled      = [bool]$fullLogEnabled
                fullLogRequired     = [bool]$fullLogEnabled
                fullLogReady        = [bool]($fullLogEnabled -and $pvpStatus.fullLogReady)
                launchBlockedReason = $blockedReason
                needsCaptureSetup   = $true
                serverPreflight     = $serverPreflightResult
                message             = $profileLabel + ': полный игровой лог не готов. Нужны Wireshark + Npcap, запуск не начат.'
            }
        }

        Assert-BridgeOperationNotCancelled
        [void](Stop-GamePerformanceRuntime -ResolvedLauncherRoot $ResolvedLauncherRoot)
        $enableResult = Enable-LauncherPvpRecoveryMode -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Profile $profile
        $applyExit = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', $combatScript,
            'Apply',
            '-GameDir', $resolvedGameRoot,
            '-LauncherRoot', $ResolvedLauncherRoot,
            '-SkipGpuProfileApply',
            '-ValidatedGpuFpsCap', [string]$validatedGpuFpsCap,
            '-ValidatedGpuLimiterProvider', $validatedGpuLimiterProvider,
            '-Silent'
        ) -HiddenWindow
        if ($applyExit -ne 0) {
            Undo-BridgeCancelledPrelaunchState -ResolvedLauncherRoot $ResolvedLauncherRoot
            throw ('Combat preset apply failed before boosted game launch. Exit code: ' + $applyExit)
        }
        if (Test-BridgeOperationCancelled) {
            Undo-BridgeCancelledPrelaunchState -ResolvedLauncherRoot $ResolvedLauncherRoot
            throw [System.OperationCanceledException]::new('Запуск остановлен до передачи команды в VK Play.')
        }

        Set-BridgeOperationPhase -Phase 'launch_command_sent' -Cancellable $false
        $launchResult = if ([bool]$settings.directGameLaunch) {
            Start-RevelationViaGameCenter -ResolvedGameRoot $resolvedGameRoot
        } else {
            $vkPlayResult = Open-GameCenterLauncher
            [ordered]@{
                started   = [bool]$vkPlayResult.started
                fallback  = $true
                path      = $vkPlayResult.path
                launchUri = ''
            }
        }
        if (-not $launchResult.started) {
            throw $(if ([bool]$settings.directGameLaunch) { 'Не удалось отправить прямой запуск через VK Play.' } else { 'VK Play was not detected automatically.' })
        }
        $vkPlayExitWatcher = Start-VkPlayShutdownAfterGameExitWatcher -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Enabled $startVkPlayExitWatcher

        if (Get-Command -Name Set-PvpStateValues -ErrorAction SilentlyContinue) {
            try {
                Set-PvpStateValues -ResolvedLauncherRoot $ResolvedLauncherRoot -Values @{ lastSuccessfulProfile = $profile } | Out-Null
            } catch {
            }
        }

        return [ordered]@{
            ok                  = $true
            started             = $true
            launchAccepted      = $true
            commandSent         = $true
            blocked             = $false
            mode                = $LaunchMode
            profile             = $profile
            fullLogEnabled      = [bool]$fullLogEnabled
            fullLogRequired     = [bool]$fullLogEnabled
            fullLogReady        = [bool]($fullLogEnabled -and $pvpStatus.fullLogReady)
            launchBlockedReason = 'none'
            vkPlayOpened        = [bool]$launchResult.started
            directLaunch        = [bool]($settings.directGameLaunch -and -not $launchResult.fallback)
            launchUri           = [string]$launchResult.launchUri
            path                = $launchResult.path
            degradedReason      = $(if ($enableResult.degradedReason) { [string]$enableResult.degradedReason } else { '' })
            introPackage        = $introPackageResult
            gpuProfile          = $gpuApplyResult
            serverPreflight     = $serverPreflightResult
            vkPlayExitWatcher   = $vkPlayExitWatcher
            message             = $(if ($profile -eq 'aggressive') {
                    if ([bool]$settings.directGameLaunch) {
                    if ($launchResult.fallback) {
                    'Агрессивный игровой буст подготовлен. Прямой запуск не сработал, поэтому открыт VK Play.'
                    } else {
                    'Агрессивный игровой буст подготовлен. Команда на прямой запуск игры отправлена через VK Play.'
                    }
                    } elseif ($fullLogEnabled) {
                    'Игровой профиль подготовлен. VK Play открыт: будет записан полный диагностический лог без изменения памяти игры, CPU-приоритета, TCP и настроек сетевого адаптера.'
                    } else {
                    'Игровой профиль подготовлен. VK Play открыт: запуск пойдёт как чистая сессия без тяжёлого захвата и без экспериментального runtime-тюнинга.'
                    }
                } else {
                    if ([bool]$settings.directGameLaunch) {
                    if ($launchResult.fallback) {
                    'Безопасный игровой буст подготовлен. Прямой запуск не сработал, поэтому открыт VK Play.'
                    } else {
                    'Безопасный игровой буст подготовлен. Команда на прямой запуск игры отправлена через VK Play.'
                    }
                    } elseif ($fullLogEnabled) {
                    'Безопасный игровой буст подготовлен. VK Play открыт: будет полный игровой лог и только подтверждённые меры без агрессивного staged suppression.'
                    } else {
                    'Безопасный игровой буст подготовлен. VK Play открыт: тяжёлый игровой лог отключён, запуск пойдёт как чистая игровая сессия без dumpcap, PresentMon и runtime capture; останутся только подтверждённые меры и лёгкие служебные логи.'
                    }
                })
        }
    }

    $captureScript = Join-Path $ResolvedLauncherRoot 'RevelationCapture.ps1'
    if (-not (Test-Path -LiteralPath $captureScript)) {
        throw 'RevelationCapture.ps1 not found.'
    }
    if (-not (Test-Path -LiteralPath $combatScript)) {
        throw 'RevelationCombat.ps1 not found.'
    }

    Set-BridgeOperationPhase -Phase 'applying_profile'
    Assert-BridgeOperationNotCancelled
    $applyExit = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', $combatScript,
        'InternalApply',
        '-GameDir', $resolvedGameRoot,
        '-LauncherRoot', $ResolvedLauncherRoot,
        '-Silent',
        '-SkipPvpRecoveryRuntime',
        '-SkipGpuProfileApply',
        '-ValidatedGpuFpsCap', [string]$validatedGpuFpsCap,
        '-ValidatedGpuLimiterProvider', $validatedGpuLimiterProvider
    ) -HiddenWindow
    if ($applyExit -ne 0) {
        throw ('Combat preset apply failed before full log launch. Exit code: ' + $applyExit)
    }
    Assert-BridgeOperationNotCancelled

    $sessionPathFile = Join-Path $stateDir 'last-universal-capture.txt'
    $captureArgs = ConvertTo-EncodedPowerShellInvocationArguments -Arguments @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-WindowStyle', 'Hidden',
        '-File', $captureScript,
        'Collect',
        '-Mode', 'dumpcap-wide',
        '-GameDir', $resolvedGameDir,
        '-OutputRoot', (Join-Path $ResolvedLauncherRoot 'captures'),
        '-MaxRuntimeMinutes', '180',
        '-PacketMaxMB', '512',
        '-PacketSnapLength', '0',
        '-Tag', 'universal-binaryui-full',
        '-LauncherPresetName', 'Full Capture - Universal Binary UI',
        '-Variant', 'official',
        '-RtssMode', 'exclude',
        '-UiPreset', 'binaryui',
        '-DxvkPreset', 'antistutter',
        '-RendererPreset', 'bundled',
        '-VideoPreset', 'custom',
        '-ProcessTune', 'high',
        '-SessionPathFile', $sessionPathFile,
        '-DisablePresentMon',
        '-DisableControllerWatcher'
    )
    Set-BridgeOperationPhase -Phase 'launch_command_sent' -Cancellable $false
    Start-Process -FilePath (Get-PreferredPowerShellExe) -ArgumentList (ConvertTo-NativeArgumentString -Arguments $captureArgs) -WindowStyle Hidden | Out-Null

    $launchResult = Start-RevelationViaGameCenter -ResolvedGameRoot $resolvedGameRoot
    $vkPlayExitWatcher = Start-VkPlayShutdownAfterGameExitWatcher -ResolvedLauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Enabled $startVkPlayExitWatcher

    return [ordered]@{
        ok              = $true
        started         = $true
        launchAccepted  = $true
        commandSent     = $true
        mode            = 'full_log'
        message         = 'Подготовка запуска с полным логом начата.'
        sessionPathFile = $sessionPathFile
        vkPlayOpened    = [bool]$launchResult.started
        directLaunch    = [bool]($launchResult.started -and -not $launchResult.fallback)
        launchUri       = [string]$launchResult.launchUri
        introPackage    = $introPackageResult
        serverPreflight = $serverPreflightResult
        vkPlayExitWatcher = $vkPlayExitWatcher
    }
}

function Invoke-NetworkApply {
    param(
        [string]$ResolvedLauncherRoot,
        [bool]$UseStaged
    )

    if (-not (Test-IsAdministrator)) {
        throw 'Administrator rights are required for network apply.'
    }

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    Save-SettingsState -StateDir $stateDir -UploadDir $settings.uploadDir -IncludeLarge $settings.includeLarge -NetworkStaged $UseStaged -NetworkAutoApply $settings.networkAutoApply

    if ($UseStaged) {
        $statePath = Join-Path $stateDir 'network-state.ini'
        $currentState = Read-KeyValueFile -Path $statePath
        $watcherPidText = if (Test-BridgeMapHasKey -Map $currentState -Key 'watcher_pid') { [string]$currentState['watcher_pid'] } else { '' }
        $watcherRunning = Test-ProcessRunning -ProcessIdText $watcherPidText
        $stagedRequested = [bool]((Test-BridgeMapHasKey -Map $currentState -Key 'staged_requested') -and [string]$currentState['staged_requested'] -eq '1')
        $stagedActivated = [bool]((Test-BridgeMapHasKey -Map $currentState -Key 'staged_activated') -and [string]$currentState['staged_activated'] -eq '1')
        $fallbackSafe = [bool]((Test-BridgeMapHasKey -Map $currentState -Key 'fallback_safe') -and [string]$currentState['fallback_safe'] -eq '1')
        $stageReason = if (Test-BridgeMapHasKey -Map $currentState -Key 'stage_reason') { [string]$currentState['stage_reason'] } else { '' }

        if ($stagedActivated -and -not $fallbackSafe) {
            return [ordered]@{
                ok             = $true
                applied        = $true
                staged         = $true
                alreadyApplied = $true
                message        = 'Сетевое ускорение уже включено.'
            }
        }

        if ($stagedRequested -and $watcherRunning -and -not $fallbackSafe) {
            $message = if ($stageReason -eq 'ready_confirmed') {
                'Ускорение уже готовится и включится автоматически.'
            } else {
                'Ускорение уже ждёт входа в мир.'
            }

            return [ordered]@{
                ok             = $true
                applied        = $true
                staged         = $true
                alreadyPending = $true
                watcherRunning = $true
                message        = $message
            }
        }
    }

    $networkScript = Join-Path $ResolvedLauncherRoot 'RevelationNetwork.ps1'
    if (-not (Test-Path -LiteralPath $networkScript)) {
        throw 'RevelationNetwork.ps1 not found.'
    }

    $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
    $args = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', $networkScript,
        '-Action', 'Apply',
        '-GameDir', $resolvedGameRoot,
        '-LauncherRoot', $ResolvedLauncherRoot,
        '-Silent'
    )
    if ($UseStaged) {
        $args += @('-NetworkMode', 'staged')
    } else {
        $args += @('-NetworkMode', 'safe')
    }

    $exitCode = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments $args -HiddenWindow
    if ($exitCode -ne 0) {
        throw ('Network apply failed with exit code ' + $exitCode)
    }

    return [ordered]@{
        ok      = $true
        applied = $true
        staged  = [bool]$UseStaged
    }
}

function Invoke-SetNetworkStagedPreference {
    param(
        [string]$ResolvedLauncherRoot,
        [bool]$UseStaged
    )

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    Save-SettingsState -StateDir $stateDir -UploadDir $settings.uploadDir -IncludeLarge $settings.includeLarge -NetworkStaged $UseStaged -NetworkAutoApply $settings.networkAutoApply

    return [ordered]@{
        ok      = $true
        staged  = [bool]$UseStaged
        message = $(if ($UseStaged) {
                'Режим "после входа в мир" сохранён.'
            } else {
                'Безопасный режим сохранён.'
            })
    }
}

function Invoke-SetNetworkAutoApplyPreference {
    param(
        [string]$ResolvedLauncherRoot,
        [bool]$AutoApplyOnLaunch
    )

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    Save-SettingsState -StateDir $stateDir -UploadDir $settings.uploadDir -IncludeLarge $settings.includeLarge -NetworkStaged $settings.networkStaged -NetworkAutoApply $AutoApplyOnLaunch

    return [ordered]@{
        ok        = $true
        autoApply = [bool]$AutoApplyOnLaunch
        message   = $(if ($AutoApplyOnLaunch) {
                'Автоматическое сетевое ускорение для игровых запусков включено.'
            } else {
                'Автоматическое сетевое ускорение для игровых запусков отключено.'
            })
    }
}

function Invoke-SetExperimentalFullLogPreference {
    param(
        [string]$ResolvedLauncherRoot,
        [bool]$Enabled
    )

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $settings = Get-SettingsState -StateDir $stateDir
    Save-SettingsState -StateDir $stateDir -UploadDir $settings.uploadDir -IncludeLarge $settings.includeLarge -NetworkStaged $settings.networkStaged -NetworkAutoApply $settings.networkAutoApply -ExperimentalFullLog $Enabled

    return [ordered]@{
        ok             = $true
        enabled        = [bool]$Enabled
        fullLogEnabled = [bool]$Enabled
        message        = $(if ($Enabled) {
                'Расширенный игровой лог включён: dumpcap, PresentMon и runtime capture снова будут запускаться.'
            } else {
                'Расширенный игровой лог отключён: запуск пойдёт как чистая игровая сессия без dumpcap, PresentMon и runtime capture. Лёгкие служебные логи останутся.'
            })
    }
}

function Invoke-SaveLauncherSettings {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$UploadDir,
        [bool]$IncludeLarge,
        [bool]$NetworkStaged,
        [bool]$NetworkAutoApply,
        [bool]$ExperimentalFullLog,
        [bool]$DirectGameLaunch,
        [bool]$SkipCharacterSelection,
        [bool]$ServerPreflight,
        [bool]$DisableIntroMovies,
        [bool]$TrafficBudgetShield,
        [bool]$TrafficBudgetShieldLimitParsec,
        [string]$DxvkMode,
        [bool]$AutoCheckUpdatesOnStartup,
        [bool]$CloseVkPlayAfterGameExit,
        [bool]$UiSpamGuard,
        [bool]$ClientMitigation
    )

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    Save-SettingsState -StateDir $stateDir -UploadDir $UploadDir -IncludeLarge $IncludeLarge -NetworkStaged $NetworkStaged -NetworkAutoApply $NetworkAutoApply -ExperimentalFullLog $ExperimentalFullLog -DirectGameLaunch $DirectGameLaunch -ServerPreflight $ServerPreflight -DisableIntroMovies $DisableIntroMovies -TrafficBudgetShield $TrafficBudgetShield -TrafficBudgetShieldLimitParsec $TrafficBudgetShieldLimitParsec -DxvkMode $DxvkMode -AutoCheckUpdatesOnStartup $AutoCheckUpdatesOnStartup -CloseVkPlayAfterGameExit $CloseVkPlayAfterGameExit -UiSpamGuard $UiSpamGuard -ClientMitigation $ClientMitigation -SkipCharacterSelection $SkipCharacterSelection
    $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
    $gameBridge = Join-Path $ResolvedLauncherRoot 'tools\RevelationGameBridge.ps1'
    if (Test-Path -LiteralPath $gameBridge) {
        . $gameBridge
        $gameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
        Set-RevelationGameBridgeClientMitigation -LauncherRoot $ResolvedLauncherRoot -GameDir $gameDir -Enabled:$ClientMitigation -SkipCharacterSelection:$SkipCharacterSelection | Out-Null
    }
    $introPackageResult = Set-RevelationIntroPackageState -ResolvedGameRoot $resolvedGameRoot -DisableIntroMovies:$DisableIntroMovies

    return [ordered]@{
        ok = $true
        settings = (Get-SettingsState -StateDir $stateDir)
        introPackage = $introPackageResult
        message = 'Настройки лаунчера сохранены.'
    }
}

function Invoke-NetworkRestore {
    param([string]$ResolvedLauncherRoot)

    if (-not (Test-IsAdministrator)) {
        throw 'Administrator rights are required for network restore.'
    }

    $resetScript = Join-Path $ResolvedLauncherRoot 'RevelationEmergencyNetworkReset.ps1'
    if (Test-Path -LiteralPath $resetScript) {
        $exitCode = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', $resetScript
        ) -HiddenWindow
    } else {
        $networkScript = Join-Path $ResolvedLauncherRoot 'RevelationNetwork.ps1'
        $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
        $exitCode = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', $networkScript,
            '-Action', 'Restore',
            '-GameDir', $resolvedGameRoot,
            '-LauncherRoot', $ResolvedLauncherRoot,
            '-Silent'
        ) -HiddenWindow
    }

    if ($exitCode -ne 0) {
        throw ('Network restore failed with exit code ' + $exitCode)
    }

    return [ordered]@{
        ok       = $true
        restored = $true
    }
}

function Invoke-KillWatcher {
    param([string]$ResolvedLauncherRoot)

    $cleanupScript = Join-Path $ResolvedLauncherRoot 'RevelationCleanup.ps1'
    if (-not (Test-Path -LiteralPath $cleanupScript)) {
        throw 'RevelationCleanup.ps1 not found.'
    }

    $exitCode = Invoke-ProcessAndWait -FilePath (Get-PreferredPowerShellExe) -Arguments @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-WindowStyle', 'Hidden',
        '-File', $cleanupScript,
        '-LauncherRoot', $ResolvedLauncherRoot,
        '-StaleMinutes', '0'
    ) -HiddenWindow
    if ($exitCode -ne 0) {
        throw ('Watcher cleanup failed with exit code ' + $exitCode)
    }

    return [ordered]@{
        ok      = $true
        cleaned = $true
    }
}

function Copy-PathIfExists {
    param(
        [string]$Source,
        [string]$Destination
    )

    if (-not (Test-Path -LiteralPath $Source)) { return $false }
    Ensure-Directory -Path (Split-Path -Parent $Destination)
    if ((Get-Item -LiteralPath $Source).PSIsContainer) {
        Copy-Item -LiteralPath $Source -Destination $Destination -Recurse -Force
    } else {
        Copy-Item -LiteralPath $Source -Destination $Destination -Force
    }
    return $true
}

function Build-DiagnosticsBundle {
    param(
        [string]$ResolvedLauncherRoot,
        [string]$UploadRoot,
        [bool]$CopyToUpload,
        [bool]$IncludeLargeFiles
    )

    $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
    $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    $diagnosticsDir = Join-Path $stateDir 'diagnostics'
    Ensure-Directory -Path $diagnosticsDir
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $bundleDir = Join-Path $diagnosticsDir ('bundle-' + $stamp)
    $logsDir = Join-Path $bundleDir 'logs'
    $gameSnapshotDir = Join-Path $bundleDir 'game'
    Ensure-Directory -Path $logsDir
    Ensure-Directory -Path $gameSnapshotDir

    Copy-PathIfExists -Source (Join-Path $resolvedGameDir 'conf.xml') -Destination (Join-Path $gameSnapshotDir 'conf.xml') | Out-Null
    Copy-PathIfExists -Source (Join-Path $resolvedGameDir 'tianyu.xml') -Destination (Join-Path $gameSnapshotDir 'tianyu.xml') | Out-Null
    Copy-PathIfExists -Source (Join-Path $resolvedGameDir 'dxvk.conf') -Destination (Join-Path $gameSnapshotDir 'dxvk.conf') | Out-Null
    Copy-PathIfExists -Source (Join-Path $stateDir 'dxvk.conf') -Destination (Join-Path $gameSnapshotDir 'managed-dxvk.conf') | Out-Null

    foreach ($name in @('universal-launcher.log', 'last-launch.log', 'network.log', 'install.json', 'bootstrap-last.log', 'pvp-recovery.log', 'pvp-recovery-state.ini')) {
        Copy-PathIfExists -Source (Join-Path $stateDir $name) -Destination (Join-Path $logsDir $name) | Out-Null
    }
    Copy-PathIfExists -Source (Join-Path $stateDir 'gpu-profile-lab') -Destination (Join-Path $logsDir 'gpu-profile-lab') | Out-Null
    foreach ($name in @('exception.log', 'tianyu_d3d9.log', 'tianyu_d3d11.log')) {
        Copy-PathIfExists -Source (Join-Path $resolvedGameDir $name) -Destination (Join-Path $logsDir $name) | Out-Null
    }

    $captureDir = Get-LatestCaptureFolder -LauncherRoot $ResolvedLauncherRoot
    if ($captureDir) {
        $captureTarget = Join-Path $bundleDir 'latest-capture'
        Ensure-Directory -Path $captureTarget

        foreach ($name in @('analysis-summary.txt', 'session.log', 'manifest.txt', 'system-info.txt', 'tools.csv', 'hashes.csv')) {
            Copy-PathIfExists -Source (Join-Path $captureDir $name) -Destination (Join-Path $captureTarget $name) | Out-Null
        }
        foreach ($rel in @('runtime\process-samples.csv', 'runtime\hardware-samples.csv', 'runtime\latency-samples.csv', 'runtime\server-connection-samples.csv', 'runtime\tcp-connections.csv', 'runtime\udp-endpoints.csv', 'runtime\tracked-process-launch.csv', 'runtime\dns-cache-start.csv', 'runtime\dumpcap-stdout.txt', 'runtime\dumpcap-stderr.txt', 'runtime\latency-helper-result.json', 'runtime\latency-helper.log', 'network\packet-summary.json', 'network\pvp-classifier.json', 'pvp-recovery-report.json')) {
            Copy-PathIfExists -Source (Join-Path $captureDir $rel) -Destination (Join-Path $captureTarget $rel) | Out-Null
        }

        if ($IncludeLargeFiles) {
            foreach ($rel in @('network\pktmon.pcapng', 'post', 'pre')) {
                Copy-PathIfExists -Source (Join-Path $captureDir $rel) -Destination (Join-Path $captureTarget $rel) | Out-Null
            }
            $captureNetworkDir = Join-Path $captureDir 'network'
            if (Test-Path -LiteralPath $captureNetworkDir) {
                Get-ChildItem -LiteralPath $captureNetworkDir -Filter 'dumpcap*.pcapng' -File -ErrorAction SilentlyContinue | ForEach-Object {
                    Copy-PathIfExists -Source $_.FullName -Destination (Join-Path $captureTarget (Join-Path 'network' $_.Name)) | Out-Null
                }
            }
        }
    }

    $pvpResearchRoot = Join-Path $stateDir 'pvp-research'
    Copy-PathIfExists -Source (Join-Path $pvpResearchRoot 'index.json') -Destination (Join-Path $bundleDir 'pvp-research\index.json') | Out-Null
    Copy-PathIfExists -Source (Join-Path $pvpResearchRoot 'markers\lag-events.jsonl') -Destination (Join-Path $bundleDir 'pvp-research\lag-events.jsonl') | Out-Null

    $pvpResearchBundle = ''
    if (Get-Command -Name Get-LauncherPvpRecoveryStatus -ErrorAction SilentlyContinue) {
        try {
            $pvpStatus = Get-LauncherPvpRecoveryStatus -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
            if ($pvpStatus.lastResearchBundle -and (Test-Path -LiteralPath $pvpStatus.lastResearchBundle)) {
                $pvpResearchBundle = [string]$pvpStatus.lastResearchBundle
            }
        } catch {
        }
    }
    if ($pvpResearchBundle) {
        $pvpTarget = Join-Path $bundleDir 'latest-pvp-research'
        Ensure-Directory -Path $pvpTarget
        foreach ($name in @('analysis-summary.txt', 'session.log', 'manifest.txt', 'pvp-recovery-report.json')) {
            Copy-PathIfExists -Source (Join-Path $pvpResearchBundle $name) -Destination (Join-Path $pvpTarget $name) | Out-Null
        }
        foreach ($rel in @('runtime\latency-helper-result.json', 'runtime\latency-helper.log', 'runtime\launcher-network-state.ini', 'runtime\launcher-settings.ini', 'runtime\launcher-config.ini', 'runtime\live-conf.xml', 'runtime\live-tianyu.xml', 'runtime\lag-events.jsonl', 'network\packet-summary.json', 'network\pvp-classifier.json')) {
            Copy-PathIfExists -Source (Join-Path $pvpResearchBundle $rel) -Destination (Join-Path $pvpTarget $rel) | Out-Null
        }
        if ($IncludeLargeFiles) {
            foreach ($rel in @('network\pktmon.pcapng')) {
                Copy-PathIfExists -Source (Join-Path $pvpResearchBundle $rel) -Destination (Join-Path $pvpTarget $rel) | Out-Null
            }
            $pvpNetworkDir = Join-Path $pvpResearchBundle 'network'
            if (Test-Path -LiteralPath $pvpNetworkDir) {
                Get-ChildItem -LiteralPath $pvpNetworkDir -Filter 'dumpcap*.pcapng' -File -ErrorAction SilentlyContinue | ForEach-Object {
                    Copy-PathIfExists -Source $_.FullName -Destination (Join-Path $pvpTarget (Join-Path 'network' $_.Name)) | Out-Null
                }
            }
        }
    }

    $manifestLines = @(
        ('created=' + (Get-Date -Format 's')),
        ('launcherRoot=' + $ResolvedLauncherRoot),
        ('gameRoot=' + $resolvedGameRoot),
        ('computer=' + $env:COMPUTERNAME),
        ('user=' + $env:USERNAME),
        ('latestCapture=' + $captureDir)
    )
    Set-Content -LiteralPath (Join-Path $bundleDir 'manifest.txt') -Value $manifestLines -Encoding UTF8

    $finalPath = $bundleDir
    if ($CopyToUpload) {
        $targetRoot = $(if ($UploadRoot) { $UploadRoot } else { Join-Path $stateDir 'developer-outbox' })
        Ensure-Directory -Path $targetRoot
        $remoteDir = Join-Path $targetRoot (Split-Path -Leaf $bundleDir)
        if (Test-Path -LiteralPath $remoteDir) {
            Remove-Item -LiteralPath $remoteDir -Force -Recurse
        }
        Copy-Item -LiteralPath $bundleDir -Destination $remoteDir -Recurse -Force
        $finalPath = $remoteDir
    }

    return [ordered]@{
        ok                 = $true
        bundlePath         = $finalPath
        localBundlePath    = $bundleDir
        latestCaptureFolder = $captureDir
    }
}

function Invoke-RestoreUserConfig {
    param([string]$ResolvedLauncherRoot)

    Assert-BridgeUserConfigBackend

    $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $ResolvedLauncherRoot
    $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
    $result = Restore-LauncherUserConfigRecoveryPreset -LauncherRoot $ResolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
    $result.ok = $true
    $result.restored = $true
    return $result
}

function Get-BridgePendingRelogResumePath {
    param([string]$ResolvedLauncherRoot)

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    return (Join-Path $stateDir 'pending-relog-resume.json')
}

function Save-BridgePendingRelogResume {
    param(
        [string]$ResolvedLauncherRoot,
        [bool]$FastRelog
    )

    $path = Get-BridgePendingRelogResumePath -ResolvedLauncherRoot $ResolvedLauncherRoot
    $createdAtUtc = [DateTime]::UtcNow
    $value = [ordered]@{
        ok           = $true
        pending      = $true
        consumed     = $false
        fast         = [bool]$FastRelog
        fastRelog    = [bool]$FastRelog
        action       = $(if ($FastRelog) { 'fast_relog' } else { 'relog' })
        createdAtUtc = $createdAtUtc.ToString('o')
        expiresAtUtc = $createdAtUtc.AddMinutes(5).ToString('o')
        createdAtUnixMs = [DateTimeOffset]::new($createdAtUtc).ToUnixTimeMilliseconds()
        expiresAtUnixMs = [DateTimeOffset]::new($createdAtUtc.AddMinutes(5)).ToUnixTimeMilliseconds()
        path         = $path
        message      = 'Релог сохранён для автоматического продолжения после admin-рестарта.'
    }

    $value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $path -Encoding UTF8
    return $value
}

function Write-BridgePendingRelogResumeTrace {
    param(
        [string]$ResolvedLauncherRoot,
        [AllowNull()][object]$Trace
    )

    if (-not $ResolvedLauncherRoot -or $null -eq $Trace) {
        return
    }

    try {
        $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
        Ensure-Directory -Path $stateDir
        $tracePath = Join-Path $stateDir 'last-relog-resume.json'
        $Trace | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $tracePath -Encoding UTF8
    } catch {
    }
}

function Consume-BridgePendingRelogResume {
    param([string]$ResolvedLauncherRoot)

    $path = Get-BridgePendingRelogResumePath -ResolvedLauncherRoot $ResolvedLauncherRoot
    if (-not (Test-Path -LiteralPath $path)) {
        return [ordered]@{
            ok       = $true
            pending  = $false
            consumed = $false
            path     = $path
            message  = 'Нет сохранённого релога для продолжения.'
        }
    }

    $raw = $null
    try {
        $raw = Get-Content -LiteralPath $path -Raw -Encoding UTF8
    } finally {
        Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
    }

    $data = $null
    try {
        $data = $raw | ConvertFrom-Json
    } catch {
        $invalidResult = [ordered]@{
            ok       = $true
            pending  = $false
            consumed = $true
            invalid  = $true
            path     = $path
            message  = 'Сохранённый релог повреждён и был сброшен.'
        }
        Write-BridgePendingRelogResumeTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $invalidResult
        return $invalidResult
    }
    if ($null -eq $data) {
        $emptyResult = [ordered]@{
            ok       = $true
            pending  = $false
            consumed = $true
            invalid  = $true
            path     = $path
            message  = 'Сохранённый релог пустой и был сброшен.'
        }
        Write-BridgePendingRelogResumeTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $emptyResult
        return $emptyResult
    }

    $expired = $false
    $expiresAtUtc = ''
    if ($data.PSObject.Properties.Name -contains 'expiresAtUtc') {
        $expiresAtRaw = $data.expiresAtUtc
        $expiresAtUtc = $(if ($expiresAtRaw -is [DateTime]) { ([DateTime]$expiresAtRaw).ToUniversalTime().ToString('o') } else { [string]$expiresAtRaw })
    }
    if ($data.PSObject.Properties.Name -contains 'expiresAtUnixMs') {
        try {
            $expired = [bool]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() -gt [int64]$data.expiresAtUnixMs)
        } catch {
            $expired = $false
        }
    } elseif ($data.PSObject.Properties.Name -contains 'expiresAtUtc') {
        try {
            $expires = if ($data.expiresAtUtc -is [DateTime]) {
                ([DateTime]$data.expiresAtUtc).ToUniversalTime()
            } else {
                ([DateTimeOffset]::Parse([string]$data.expiresAtUtc, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal)).UtcDateTime
            }
            $expired = [bool]([DateTime]::UtcNow -gt $expires)
        } catch {
            $expired = $true
        }
    }

    $fastRelog = $false
    if ($null -ne $data -and $data.PSObject.Properties.Name -contains 'fastRelog') {
        $fastRelog = [bool]$data.fastRelog
    } elseif ($null -ne $data -and $data.PSObject.Properties.Name -contains 'fast') {
        $fastRelog = [bool]$data.fast
    } elseif ($null -ne $data -and $data.PSObject.Properties.Name -contains 'action') {
        $fastRelog = [bool]([string]$data.action -eq 'fast_relog')
    }

    if ($expired) {
        $expiredResult = [ordered]@{
            ok           = $true
            pending      = $false
            consumed     = $true
            expired      = $true
            fast         = [bool]$fastRelog
            fastRelog    = [bool]$fastRelog
            action       = $(if ($fastRelog) { 'fast_relog' } else { 'relog' })
            expiresAtUtc = $expiresAtUtc
            path         = $path
            message      = 'Сохранённый релог устарел и был сброшен.'
        }
        Write-BridgePendingRelogResumeTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $expiredResult
        return $expiredResult
    }

    $resumeResult = [ordered]@{
        ok           = $true
        pending      = $true
        consumed     = $true
        fast         = [bool]$fastRelog
        fastRelog    = [bool]$fastRelog
        action       = $(if ($fastRelog) { 'fast_relog' } else { 'relog' })
        createdAtUtc = $(if ($data.PSObject.Properties.Name -contains 'createdAtUtc') { [string]$data.createdAtUtc } else { '' })
        expiresAtUtc = $expiresAtUtc
        path         = $path
        message      = 'Продолжаю релог после admin-рестарта.'
    }
    Write-BridgePendingRelogResumeTrace -ResolvedLauncherRoot $ResolvedLauncherRoot -Trace $resumeResult
    return $resumeResult
}

function Invoke-PendingRelogAsAdmin {
    param(
        [string]$ResolvedLauncherRoot,
        [uint32]$CurrentLauncherPid = 0
    )

    $bridgePath = Join-Path $ResolvedLauncherRoot 'RevelationGuiBridge.ps1'
    if (-not (Test-Path -LiteralPath $bridgePath)) {
        throw 'Bridge script was not found for elevated relog worker.'
    }

    $stateDir = Join-Path $ResolvedLauncherRoot '.revelation-combat'
    Ensure-Directory -Path $stateDir
    $workerScriptPath = Join-Path $stateDir 'pending-relog-worker.ps1'
    $workerTracePath = Join-Path $stateDir 'last-relog-admin-worker.json'

    $escapedLauncherRoot = $ResolvedLauncherRoot.Replace("'", "''")
    $escapedBridgePath = $bridgePath.Replace("'", "''")
    $escapedWorkerTracePath = $workerTracePath.Replace("'", "''")
    $workerScript = @"
`$ErrorActionPreference = 'Stop'
`$launcherRoot = '$escapedLauncherRoot'
`$bridgePath = '$escapedBridgePath'
`$workerTracePath = '$escapedWorkerTracePath'

function Write-WorkerTrace {
    param([object]`$Trace)
    try {
        `$Trace | ConvertTo-Json -Depth 32 | Set-Content -LiteralPath `$workerTracePath -Encoding UTF8
    } catch {
    }
}

`$trace = [ordered]@{
    ok = `$false
    phase = 'starting'
    startedAtUtc = ([DateTime]::UtcNow.ToString('o'))
    finishedAtUtc = ''
    launcherRoot = `$launcherRoot
    bridgePath = `$bridgePath
    elevated = `$false
    consumed = `$null
    action = ''
    result = `$null
    resultRaw = ''
    exitCode = 0
    error = ''
}

try {
    try {
        `$principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
        `$trace.elevated = [bool]`$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        `$trace.elevated = `$false
    }

    `$trace.phase = 'consuming_pending'
    Write-WorkerTrace -Trace `$trace

    `$consumeRaw = & `$bridgePath -LauncherRoot `$launcherRoot -Action ConsumePendingRelogResume
    `$consumeText = (`$consumeRaw -join "`n")
    `$consume = `$consumeText | ConvertFrom-Json
    `$trace.consumed = `$consume

    if (-not [bool]`$consume.pending) {
        `$trace.ok = `$true
        `$trace.phase = 'no_pending'
        `$trace.finishedAtUtc = ([DateTime]::UtcNow.ToString('o'))
        Write-WorkerTrace -Trace `$trace
        exit 0
    }

    `$action = 'RelogGame'
    `$trace.action = `$action
    `$trace.phase = 'running_relog'
    Write-WorkerTrace -Trace `$trace

    `$resultRaw = & `$bridgePath -LauncherRoot `$launcherRoot -Action `$action
    `$trace.exitCode = [int]`$LASTEXITCODE
    `$trace.resultRaw = (`$resultRaw -join "`n")
    try {
        `$trace.result = `$trace.resultRaw | ConvertFrom-Json
        `$trace.ok = [bool]`$trace.result.ok
    } catch {
        `$trace.ok = `$false
        `$trace.error = 'Failed to parse relog result: ' + `$_.Exception.Message
    }
    `$trace.phase = 'finished'
    `$trace.finishedAtUtc = ([DateTime]::UtcNow.ToString('o'))
    Write-WorkerTrace -Trace `$trace
    if (`$trace.ok) { exit 0 } else { exit 1 }
} catch {
    `$trace.ok = `$false
    `$trace.phase = 'error'
    `$trace.error = `$_.Exception.Message
    `$trace.finishedAtUtc = ([DateTime]::UtcNow.ToString('o'))
    Write-WorkerTrace -Trace `$trace
    exit 1
}
"@

    $workerScript | Set-Content -LiteralPath $workerScriptPath -Encoding UTF8

    $powerShellExe = Get-PreferredPowerShellExe
    Start-Process -FilePath $powerShellExe -WorkingDirectory $ResolvedLauncherRoot -Verb RunAs -WindowStyle Hidden -ArgumentList (ConvertTo-NativeArgumentString -Arguments @(
        '-NoProfile',
        '-WindowStyle', 'Hidden',
        '-ExecutionPolicy', 'Bypass',
        '-File',
        $workerScriptPath
    )) | Out-Null

    return [ordered]@{
        ok             = $true
        elevatedWorker = $true
        workerStarted  = $true
        closeCurrent   = $true
        workerScript   = $workerScriptPath
        workerTrace    = $workerTracePath
        currentLauncherPid = [uint32]$CurrentLauncherPid
        message        = 'Запускаю сохранённый релог с правами администратора…'
    }
}

function Invoke-RelaunchAsAdmin {
    param(
        [string]$ResolvedLauncherRoot,
        [uint32]$CurrentLauncherPid = 0
    )

    $preferredTargets = @(
        (Join-Path $ResolvedLauncherRoot 'RevelationUniversalFull.exe'),
        (Join-Path $ResolvedLauncherRoot 'RevelationUniversal.cmd')
    )

    $targetPath = $preferredTargets | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $targetPath) {
        throw 'Launcher entrypoint was not found.'
    }

    $powerShellExe = Get-PreferredPowerShellExe
    $escapedTarget = $targetPath.Replace("'", "''")
    $escapedRoot = $ResolvedLauncherRoot.Replace("'", "''")
    $helperCommand = @"
`$targetPath = '$escapedTarget'
`$workingDir = '$escapedRoot'
`$launcherPid = $CurrentLauncherPid
if (`$launcherPid -gt 0) {
    Start-Sleep -Milliseconds 1200
    `$oldProc = Get-Process -Id `$launcherPid -ErrorAction SilentlyContinue
    if (`$oldProc) {
        Stop-Process -Id `$launcherPid -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 600
    }
}
Start-Process -FilePath `$targetPath -WorkingDirectory `$workingDir | Out-Null
"@

    Start-Process -FilePath $powerShellExe -WorkingDirectory $ResolvedLauncherRoot -Verb RunAs -ArgumentList (ConvertTo-NativeArgumentString -Arguments @(
        '-NoProfile',
        '-WindowStyle', 'Hidden',
        '-ExecutionPolicy', 'Bypass',
        '-Command',
        $helperCommand
    )) | Out-Null

    return [ordered]@{
        ok           = $true
        relaunched   = $true
        closeCurrent = $true
        targetPath   = $targetPath
        message      = 'Запускаю лаунчер с правами администратора…'
    }
}

function Get-BridgeObjectPropertyValue {
    param(
        [AllowNull()]
        [object]$Object,
        [string]$Name,
        [AllowNull()]
        [object]$Default = $null
    )

    if ($null -eq $Object -or [string]::IsNullOrWhiteSpace($Name)) {
        return $Default
    }

    if ($Object -is [System.Collections.IDictionary] -and $Object.Contains($Name)) {
        return $Object[$Name]
    }

    try {
        $property = $Object.PSObject.Properties[$Name]
        if ($null -ne $property) {
            return $property.Value
        }
    } catch {
    }

    return $Default
}

function Get-RevonlineBrowserStatePath {
    param([string]$ResolvedLauncherRoot)

    return (Join-Path $ResolvedLauncherRoot '.revelation-combat\revonline-browser.json')
}

function Get-RevonlineBrowserProfileDir {
    param([string]$ResolvedLauncherRoot)

    return (Join-Path $ResolvedLauncherRoot '.revelation-combat\revonline-browser')
}

function Get-RevonlineBrowserProfileProcesses {
    param([string]$ResolvedLauncherRoot)

    $profileDir = Get-RevonlineBrowserProfileDir -ResolvedLauncherRoot $ResolvedLauncherRoot
    $processes = @()
    try {
        $processes = @(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
            $name = [string]$_.Name
            $commandLine = [string]$_.CommandLine
            ($name -match '^(?i:chrome|msedge)\.exe$') -and
                $commandLine -and
                ($commandLine.IndexOf($profileDir, [StringComparison]::OrdinalIgnoreCase) -ge 0)
        })
    } catch {
        $processes = @()
    }

    return $processes
}

function Get-RevonlineDebugPortFromCommandLine {
    param([AllowNull()][string]$CommandLine)

    if ($CommandLine -and $CommandLine -match '--remote-debugging-port=(\d+)') {
        return [int]$Matches[1]
    }

    return 0
}

function Get-RevonlineBrowserSessionFromProcesses {
    param([string]$ResolvedLauncherRoot)

    $profileDir = Get-RevonlineBrowserProfileDir -ResolvedLauncherRoot $ResolvedLauncherRoot
    $processes = @(Get-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot)
    $debugProcesses = @($processes | Where-Object { (Get-RevonlineDebugPortFromCommandLine -CommandLine ([string]$_.CommandLine)) -gt 0 })
    foreach ($process in $debugProcesses) {
        $port = Get-RevonlineDebugPortFromCommandLine -CommandLine ([string]$process.CommandLine)
        if ($port -le 0 -or -not (Test-RevonlineCdpEndpoint -Port $port)) {
            continue
        }

        $browserPath = [string]$process.ExecutablePath
        if (-not $browserPath -or -not (Test-Path -LiteralPath $browserPath)) {
            $browserPath = Get-RevonlineBrowserExePath
        }
        $headless = ([string]$process.CommandLine) -match '(?i)--headless'

        return [ordered]@{
            browserPath = $browserPath
            browserName = $(if ($browserPath -match '(?i)msedge\.exe$') { 'Microsoft Edge' } elseif ($browserPath -match '(?i)chrome\.exe$') { 'Google Chrome' } else { 'browser' })
            profileDir  = $profileDir
            port        = $port
            processId   = [int]$process.ProcessId
            headless    = [bool]$headless
            recovered   = $true
            startedAt   = ''
        }
    }

    return $null
}

function Stop-RevonlineBrowserProfileProcesses {
    param([string]$ResolvedLauncherRoot)

    $processes = @(Get-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot)
    foreach ($process in $processes) {
        $pidValue = [int]$process.ProcessId
        if ($pidValue -gt 0) {
            Stop-Process -Id $pidValue -Force -ErrorAction SilentlyContinue
        }
    }

    if ($processes.Count -gt 0) {
        Start-Sleep -Milliseconds 700
    }
}

function Get-FreeLocalTcpPort {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    try {
        $listener.Start()
        return [int]$listener.LocalEndpoint.Port
    } finally {
        $listener.Stop()
    }
}

function Get-RevonlineBrowserExePath {
    $candidates = @()
    if ($env:ProgramFiles) {
        $candidates += (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
        $candidates += (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe')
    }
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ($programFilesX86) {
        $candidates += (Join-Path $programFilesX86 'Microsoft\Edge\Application\msedge.exe')
        $candidates += (Join-Path $programFilesX86 'Google\Chrome\Application\chrome.exe')
    }
    if ($env:LOCALAPPDATA) {
        $candidates += (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe')
        $candidates += (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    }

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    foreach ($commandName in @('msedge.exe', 'chrome.exe')) {
        $command = Get-Command -Name $commandName -ErrorAction SilentlyContinue
        if ($command -and $command.Source) {
            return [string]$command.Source
        }
    }

    throw 'Microsoft Edge или Google Chrome не найден. Нужен браузер для безопасного входа в ЛК revonline.'
}

function Read-RevonlineBrowserState {
    param([string]$ResolvedLauncherRoot)

    $statePath = Get-RevonlineBrowserStatePath -ResolvedLauncherRoot $ResolvedLauncherRoot
    if (-not (Test-Path -LiteralPath $statePath)) {
        return $null
    }

    try {
        return (Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
        return $null
    }
}

function Write-RevonlineBrowserState {
    param(
        [string]$ResolvedLauncherRoot,
        [object]$State
    )

    $statePath = Get-RevonlineBrowserStatePath -ResolvedLauncherRoot $ResolvedLauncherRoot
    Ensure-Directory -Path (Split-Path -Parent $statePath)
    $json = $State | ConvertTo-Json -Depth 8
    [System.IO.File]::WriteAllText($statePath, $json, [System.Text.UTF8Encoding]::new($false))
}

function Test-RevonlineCdpEndpoint {
    param([int]$Port)

    if ($Port -le 0) {
        return $false
    }

    try {
        $null = Invoke-RestMethod -Method Get -Uri ('http://127.0.0.1:{0}/json/version' -f $Port) -TimeoutSec 1 -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

function Wait-RevonlineCdpEndpoint {
    param(
        [int]$Port,
        [int]$TimeoutMs = 12000
    )

    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
    while ([DateTime]::UtcNow -lt $deadline) {
        if (Test-RevonlineCdpEndpoint -Port $Port) {
            return $true
        }
        Start-Sleep -Milliseconds 250
    }

    return $false
}

function Start-RevonlineBrowserTab {
    param(
        [object]$Session,
        [string]$Url = 'https://revonline.ru/user',
        [switch]$Headless,
        [switch]$NewWindow,
        [switch]$PassThru
    )

    $browserPath = [string](Get-BridgeObjectPropertyValue -Object $Session -Name 'browserPath' -Default '')
    $profileDir = [string](Get-BridgeObjectPropertyValue -Object $Session -Name 'profileDir' -Default '')
    $port = [int](Get-BridgeObjectPropertyValue -Object $Session -Name 'port' -Default 0)
    if (-not $browserPath -or -not (Test-Path -LiteralPath $browserPath)) {
        $browserPath = Get-RevonlineBrowserExePath
    }

    $arguments = @(
        ('--remote-debugging-port=' + $port),
        '--remote-debugging-address=127.0.0.1',
        ('--user-data-dir=' + $profileDir),
        '--no-first-run',
        '--no-default-browser-check'
    )
    if ($Headless) {
        $arguments += @(
            '--headless=new',
            '--window-position=-32000,-32000',
            '--window-size=1,1',
            '--disable-gpu',
            '--disable-software-rasterizer',
            '--disable-background-networking'
        )
    } elseif ($NewWindow) {
        $arguments += '--new-window'
    }
    $arguments += $Url

    $startParams = @{
        FilePath     = $browserPath
        ArgumentList = (ConvertTo-NativeArgumentString -Arguments $arguments)
    }
    if ($Headless) {
        $startParams['WindowStyle'] = 'Hidden'
    }
    if ($PassThru) {
        $startParams['PassThru'] = $true
    }

    $process = Start-Process @startParams
    if ($PassThru) {
        return $process
    }
}

function Get-ExistingRevonlineBrowserSession {
    param([string]$ResolvedLauncherRoot)

    $state = Read-RevonlineBrowserState -ResolvedLauncherRoot $ResolvedLauncherRoot
    $statePort = [int](Get-BridgeObjectPropertyValue -Object $state -Name 'port' -Default 0)
    if ($statePort -gt 0 -and (Test-RevonlineCdpEndpoint -Port $statePort)) {
        return $state
    }

    $processSession = Get-RevonlineBrowserSessionFromProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
    if ($null -ne $processSession) {
        Write-RevonlineBrowserState -ResolvedLauncherRoot $ResolvedLauncherRoot -State $processSession
        return $processSession
    }

    return $null
}

function New-RevonlineHeadlessBrowserSession {
    param([string]$ResolvedLauncherRoot)

    $browserPath = Get-RevonlineBrowserExePath
    $profileDir = Get-RevonlineBrowserProfileDir -ResolvedLauncherRoot $ResolvedLauncherRoot
    Stop-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
    Ensure-Directory -Path $profileDir
    $port = Get-FreeLocalTcpPort
    $session = [ordered]@{
        browserPath = $browserPath
        browserName = $(if ($browserPath -match '(?i)msedge\.exe$') { 'Microsoft Edge' } elseif ($browserPath -match '(?i)chrome\.exe$') { 'Google Chrome' } else { 'browser' })
        profileDir  = $profileDir
        port        = $port
        headless    = $true
        transient   = $true
        startedAt   = (Get-Date).ToUniversalTime().ToString('o')
        processId   = 0
    }

    $process = Start-RevonlineBrowserTab -Session $session -Url 'about:blank' -Headless -PassThru
    if ($process) {
        $session['processId'] = [int]$process.Id
    }

    if (-not (Wait-RevonlineCdpEndpoint -Port $port)) {
        throw 'Не удалось открыть фоновую сессию браузера для ЛК revonline. Если окно ЛК сейчас открыто, закрой его и попробуй снова.'
    }

    return $session
}

function Stop-RevonlineHeadlessBrowserSession {
    param(
        [AllowNull()][object]$Session,
        [string]$ResolvedLauncherRoot
    )

    if ($null -eq $Session) {
        return
    }

    $processId = [int](Get-BridgeObjectPropertyValue -Object $Session -Name 'processId' -Default 0)
    if ($processId -gt 0) {
        Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
    }

    if ($ResolvedLauncherRoot) {
        Stop-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
    }
}

function Get-RevonlineBrowserSession {
    param(
        [string]$ResolvedLauncherRoot,
        [switch]$OpenUserPage
    )

    $state = Read-RevonlineBrowserState -ResolvedLauncherRoot $ResolvedLauncherRoot
    $statePort = [int](Get-BridgeObjectPropertyValue -Object $state -Name 'port' -Default 0)
    if ($statePort -gt 0 -and (Test-RevonlineCdpEndpoint -Port $statePort)) {
        $stateIsHeadless = [bool](Get-BridgeObjectPropertyValue -Object $state -Name 'headless' -Default $false)
        if ($OpenUserPage -and $stateIsHeadless) {
            Stop-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
        } else {
            if ($OpenUserPage) {
                Open-RevonlineCdpPage -Session $state -Url 'https://revonline.ru/user'
                Start-RevonlineBrowserTab -Session $state -Url 'https://revonline.ru/user' -NewWindow
                Start-Sleep -Milliseconds 600
                $target = Get-RevonlineUserPageTarget -Session $state
                if ($null -eq $target) {
                    throw 'Не удалось открыть страницу ЛК revonline в управляемом браузере.'
                }
            }
            return $state
        }
    }

    $processSession = Get-RevonlineBrowserSessionFromProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
    if ($null -ne $processSession) {
        if ($OpenUserPage -and [bool](Get-BridgeObjectPropertyValue -Object $processSession -Name 'headless' -Default $false)) {
            Stop-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot
        } else {
            if ($OpenUserPage) {
                Open-RevonlineCdpPage -Session $processSession -Url 'https://revonline.ru/user'
                Start-RevonlineBrowserTab -Session $processSession -Url 'https://revonline.ru/user' -NewWindow
                Start-Sleep -Milliseconds 600
                $target = Get-RevonlineUserPageTarget -Session $processSession
                if ($null -eq $target) {
                    throw 'Не удалось открыть страницу ЛК revonline в управляемом браузере.'
                }
            }
            Write-RevonlineBrowserState -ResolvedLauncherRoot $ResolvedLauncherRoot -State $processSession
            return $processSession
        }
    }

    Stop-RevonlineBrowserProfileProcesses -ResolvedLauncherRoot $ResolvedLauncherRoot

    $browserPath = Get-RevonlineBrowserExePath
    $profileDir = Get-RevonlineBrowserProfileDir -ResolvedLauncherRoot $ResolvedLauncherRoot
    Ensure-Directory -Path $profileDir
    $port = Get-FreeLocalTcpPort
    $session = [ordered]@{
        browserPath = $browserPath
        browserName = $(if ($browserPath -match '(?i)msedge\.exe$') { 'Microsoft Edge' } elseif ($browserPath -match '(?i)chrome\.exe$') { 'Google Chrome' } else { 'browser' })
        profileDir  = $profileDir
        port        = $port
        startedAt   = (Get-Date).ToUniversalTime().ToString('o')
    }

    Start-RevonlineBrowserTab -Session $session -Url 'https://revonline.ru/user' -NewWindow
    if (-not (Wait-RevonlineCdpEndpoint -Port $port)) {
        throw 'Не удалось открыть управляемое окно браузера для ЛК revonline.'
    }
    $target = Get-RevonlineUserPageTarget -Session $session
    if ($null -eq $target) {
        throw 'Управляемый браузер запустился, но страница ЛК revonline не открылась.'
    }

    Write-RevonlineBrowserState -ResolvedLauncherRoot $ResolvedLauncherRoot -State $session
    return $session
}

function Get-RevonlineCdpTargets {
    param([int]$Port)

    try {
        $response = Invoke-WebRequest -Method Get -Uri ('http://127.0.0.1:{0}/json/list' -f $Port) -TimeoutSec 3 -UseBasicParsing -ErrorAction Stop
        $targets = $response.Content | ConvertFrom-Json
        return @($targets)
    } catch {
        return @()
    }
}

function Open-RevonlineCdpPage {
    param(
        [object]$Session,
        [string]$Url = 'https://revonline.ru/user',
        [switch]$NoVisibleFallback
    )

    $port = [int](Get-BridgeObjectPropertyValue -Object $Session -Name 'port' -Default 0)
    $escapedUrl = [System.Uri]::EscapeDataString($Url)
    foreach ($method in @('Put', 'Get')) {
        try {
            $null = Invoke-RestMethod -Method $method -Uri ('http://127.0.0.1:{0}/json/new?{1}' -f $port, $escapedUrl) -TimeoutSec 3 -ErrorAction Stop
            return
        } catch {
        }
    }

    if (-not $NoVisibleFallback) {
        Start-RevonlineBrowserTab -Session $Session -Url $Url
    }
}

function Get-RevonlineUserPageTarget {
    param(
        [object]$Session,
        [switch]$NoVisibleFallback
    )

    $port = [int](Get-BridgeObjectPropertyValue -Object $Session -Name 'port' -Default 0)
    $targets = Get-RevonlineCdpTargets -Port $port
    $revonlineTarget = $targets |
        Where-Object {
            ([string](Get-BridgeObjectPropertyValue -Object $_ -Name 'type' -Default '')) -eq 'page' -and
            ([string](Get-BridgeObjectPropertyValue -Object $_ -Name 'url' -Default '')) -match '^https://revonline\.ru/'
        } |
        Select-Object -First 1

    if ($revonlineTarget) {
        return $revonlineTarget
    }

    $sessionHeadless = [bool](Get-BridgeObjectPropertyValue -Object $Session -Name 'headless' -Default $false)
    if ($NoVisibleFallback -and -not $sessionHeadless) {
        return $null
    }

    Open-RevonlineCdpPage -Session $Session -Url 'https://revonline.ru/user' -NoVisibleFallback:$NoVisibleFallback
    Start-Sleep -Milliseconds 1200
    $targets = Get-RevonlineCdpTargets -Port $port
    return ($targets |
        Where-Object {
            ([string](Get-BridgeObjectPropertyValue -Object $_ -Name 'type' -Default '')) -eq 'page' -and
            ([string](Get-BridgeObjectPropertyValue -Object $_ -Name 'url' -Default '')) -match '^https://revonline\.ru/'
        } |
        Select-Object -First 1)
}

function Send-CdpCommand {
    param(
        [System.Net.WebSockets.ClientWebSocket]$Socket,
        [int]$Id,
        [string]$Method,
        [hashtable]$Params = @{}
    )

    $payload = [ordered]@{
        id     = $Id
        method = $Method
        params = $Params
    }
    $json = $payload | ConvertTo-Json -Depth 16 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $segment = [System.ArraySegment[byte]]::new($bytes)
    $Socket.SendAsync($segment, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
}

function Receive-CdpMessage {
    param([System.Net.WebSockets.ClientWebSocket]$Socket)

    $buffer = New-Object byte[] 65536
    $stream = [System.IO.MemoryStream]::new()
    try {
        do {
            $segment = [System.ArraySegment[byte]]::new($buffer)
            $result = $Socket.ReceiveAsync($segment, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
            if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                throw 'CDP socket closed.'
            }
            if ($result.Count -gt 0) {
                $stream.Write($buffer, 0, $result.Count)
            }
        } while (-not $result.EndOfMessage)

        $text = [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
        return ($text | ConvertFrom-Json)
    } finally {
        $stream.Dispose()
    }
}

function Invoke-CdpCommand {
    param(
        [string]$WebSocketDebuggerUrl,
        [string]$Method,
        [hashtable]$Params = @{},
        [int]$TimeoutMs = 30000
    )

    $socket = [System.Net.WebSockets.ClientWebSocket]::new()
    $id = 1
    try {
        $socket.ConnectAsync([System.Uri]$WebSocketDebuggerUrl, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
        Send-CdpCommand -Socket $socket -Id $id -Method $Method -Params $Params
        $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
        while ([DateTime]::UtcNow -lt $deadline) {
            $message = Receive-CdpMessage -Socket $socket
            $messageId = [int](Get-BridgeObjectPropertyValue -Object $message -Name 'id' -Default 0)
            if ($messageId -ne $id) {
                continue
            }

            $error = Get-BridgeObjectPropertyValue -Object $message -Name 'error' -Default $null
            if ($null -ne $error) {
                $errorMessage = [string](Get-BridgeObjectPropertyValue -Object $error -Name 'message' -Default 'CDP command failed.')
                throw $errorMessage
            }

            return $message
        }

        throw 'CDP command timed out.'
    } finally {
        if ($socket.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $socket.CloseAsync([System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure, 'done', [System.Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
        }
        $socket.Dispose()
    }
}

function Invoke-RevonlineDemonsCdpTask {
    param([string]$WebSocketDebuggerUrl)

    $expression = @'
(async () => {
  const taskUrl = 'https://revonline.ru/user';
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  if (!location.href.startsWith(taskUrl)) {
    location.href = taskUrl;
    await sleep(800);
  }

  for (let i = 0; i < 40; i += 1) {
    if (Array.isArray(window.userInfo) || document.querySelector('.js-list-wrap')) {
      break;
    }
    await sleep(250);
  }

  const installSelectionTracker = () => {
    if (window.__revelationLauncherDemonsSelectionTracker) {
      return;
    }
    window.__revelationLauncherDemonsSelectionTracker = true;
    document.addEventListener('click', (event) => {
      const target = event.target;
      if (!target || typeof target.closest !== 'function') {
        return;
      }
      if (target.closest('.js-server-select')) {
        window.localStorage.setItem('revelationLauncherDemonsServerSelectedAt', String(Date.now()));
      }
      if (target.closest('.js-char-select')) {
        window.localStorage.setItem('revelationLauncherDemonsCharSelectedAt', String(Date.now()));
      }
    }, true);
  };
  installSelectionTracker();

  const info = Array.isArray(window.userInfo) ? window.userInfo : [];
  if (!info.length) {
    const pageText = String(document.body && document.body.innerText || '').toLocaleLowerCase('ru-RU');
    const loginRequired = /\/(?:login|auth|signin)(?:\/|\?|$)/i.test(location.pathname) ||
      Boolean(document.querySelector('input[type="password"]')) ||
      /пожалуйста,\s*авторизуйтесь|войти\s+регистрация/.test(pageText);
    if (loginRequired) {
      return { ok: false, code: 'need_login', message: 'Нужно войти в Личный кабинет revonline.' };
    }
    if (location.pathname.replace(/\/$/, '') === '/user') {
      return {
        ok: false,
        code: 'premium_required',
        message: 'Для «Битвы с демонами» нужна активная премиум-подписка у персонажа. ЛК не показал доступного персонажа; проверь подписку в ЛК.',
      };
    }
    return { ok: false, code: 'cabinet_unavailable', message: 'Сайт не показал данные персонажей. Открой Личный кабинет и проверь его состояние.' };
  }

  const readName = (item, fallback) => {
    if (!item || typeof item !== 'object') {
      return fallback;
    }
    return String(item.name || item.title || item.charname || item.nickname || item.server || item.shardname || fallback);
  };

  const choices = [];
  info.forEach((server, serverIndex) => {
    const shard = server && (server.id || server.shard || server.shard_id);
    const serverName = readName(server, `Сервер ${serverIndex + 1}`);
    const chars = Array.isArray(server && server.chars) ? server.chars : [];
    chars.forEach((character, charIndex) => {
      choices.push({
        serverIndex,
        charIndex,
        shard,
        charId: character && (character.charid || character.char_id || character.id),
        serverName,
        characterName: readName(character, `Персонаж ${charIndex + 1}`),
      });
    });
  });

  if (!choices.length) {
    return { ok: false, code: 'no_characters', message: 'В ЛК не нашёл персонажей для задания «Демоны».' };
  }

  const serverButtons = Array.from(document.querySelectorAll('.js-server-select'));
  const charButtons = Array.from(document.querySelectorAll('.js-char-select'));
  const selectedServerIndex = serverButtons.findIndex((element) => element.classList.contains('current'));
  const selectedCharIndex = charButtons.findIndex((element) => element.classList.contains('current'));
  const selectedFromPage = choices.find((choice) => choice.serverIndex === selectedServerIndex && choice.charIndex === selectedCharIndex) || null;
  const charSelectedAt = Number(window.localStorage.getItem('revelationLauncherDemonsCharSelectedAt') || '0');
  const selectionIsFresh = charSelectedAt > 0 && (Date.now() - charSelectedAt) < 10 * 60 * 1000;

  let selected = null;
  if (choices.length === 1) {
    selected = choices[0];
  } else if (selectionIsFresh && selectedFromPage) {
    selected = selectedFromPage;
  }

  if (!selected) {
    return {
      ok: false,
      code: 'choose_character',
      message: 'В ЛК несколько персонажей. Выбери нужного в открытом окне браузера и нажми «Демоны» ещё раз.',
      choices: choices.map((choice) => ({ serverName: choice.serverName, characterName: choice.characterName })),
    };
  }

  if (!selected.shard || !selected.charId) {
    return { ok: false, code: 'missing_identity', message: 'Сайт не отдал id сервера или персонажа для задания «Демоны».' };
  }

  const body = new URLSearchParams();
  body.set('char_id', String(selected.charId));
  body.set('shard', String(selected.shard));

  const response = await fetch('/user/_questcompleted', {
    method: 'POST',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest',
    },
    body,
  });
  const responseUrl = response.url || '';
  const responseContentType = response.headers.get('content-type') || '';
  const text = await response.text();
  let payload = null;
  try {
    payload = JSON.parse(text);
  } catch {
    payload = null;
  }

  const stripHtml = (value) => String(value || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  let siteMessage = '';
  if (payload && typeof payload === 'object') {
    for (const key of ['message', 'msg', 'error', 'text', 'notice', 'description', 'result']) {
      if (typeof payload[key] === 'string' && payload[key].trim()) {
        siteMessage = stripHtml(payload[key]);
        break;
      }
    }
    if (!siteMessage) {
      const firstString = Object.values(payload).find((value) => typeof value === 'string' && value.trim());
      if (firstString) {
        siteMessage = stripHtml(firstString);
      }
    }
  } else {
    siteMessage = stripHtml(text);
  }
  if (siteMessage.length > 240) {
    siteMessage = `${siteMessage.slice(0, 237)}...`;
  }

  const lowerMessage = siteMessage.toLocaleLowerCase('ru-RU');
  const lowerText = String(text || '').toLocaleLowerCase('ru-RU');
  const loginPageReturned =
    /пожалуйста,\s*авторизуйтесь|войти\s+регистрация|личный кабинет[\s\S]{0,160}пожалуйста,\s*авторизуйтесь/i.test(text) ||
    /\/login|\/user\/login|auth|signin/i.test(responseUrl);
  const alreadyDone = /уже|сегодня|повтор/.test(lowerMessage) && /выполн|получ|заверш/.test(lowerMessage);
  const rejectedByPayload = Boolean(payload && typeof payload === 'object' && (payload.ok === false || payload.success === false || payload.error === true || payload.status === 'error'));
  const payloadConfirmsSuccess = Boolean(payload && typeof payload === 'object' && (
    payload.ok === true ||
    payload.success === true ||
    payload.result === true ||
    /^(ok|success|done|completed)$/i.test(String(payload.status || payload.result || '')) ||
    /выполн|получ|заверш|успеш/.test(lowerMessage)
  ));
  const textConfirmsSuccess = !payload && /выполн|получ|заверш|успеш/.test(lowerMessage || lowerText);
  const completed = response.ok && !loginPageReturned && !rejectedByPayload && (payloadConfirmsSuccess || textConfirmsSuccess);
  const ok = completed || alreadyDone;
  const premiumRejected = !ok && /премиум|premium|премиальн/i.test(lowerMessage);
  const code = loginPageReturned ? 'need_login' : premiumRejected ? 'premium_required' : alreadyDone ? 'already_done' : completed ? 'completed' : 'site_error';
  return {
    ok,
    code,
    httpStatus: response.status,
    contentType: responseContentType,
    responseUrl,
    serverName: selected.serverName,
    characterName: selected.characterName,
    siteMessage,
    message: alreadyDone
      ? 'Задание Битва с демонами уже было выполнено'
      : completed
        ? 'Задание Битва с демонами выполнено успешно'
      : loginPageReturned
        ? 'Нужно войти в ЛК revonline в открытом окне браузера.'
      : premiumRejected
        ? 'Для «Битвы с демонами» нужна активная премиум-подписка у персонажа. ' + siteMessage
      : (siteMessage || 'Сайт не подтвердил выполнение задания «Демоны».'),
  };
})()
'@

    $response = Invoke-CdpCommand -WebSocketDebuggerUrl $WebSocketDebuggerUrl -Method 'Runtime.evaluate' -Params @{
        expression    = $expression
        awaitPromise  = $true
        returnByValue = $true
    } -TimeoutMs 45000

    $outerResult = Get-BridgeObjectPropertyValue -Object $response -Name 'result' -Default $null
    $exceptionDetails = Get-BridgeObjectPropertyValue -Object $outerResult -Name 'exceptionDetails' -Default $null
    if ($null -ne $exceptionDetails) {
        $exceptionText = [string](Get-BridgeObjectPropertyValue -Object $exceptionDetails -Name 'text' -Default 'Ошибка выполнения скрипта в ЛК revonline.')
        throw $exceptionText
    }

    $runtimeResult = Get-BridgeObjectPropertyValue -Object $outerResult -Name 'result' -Default $null
    $value = Get-BridgeObjectPropertyValue -Object $runtimeResult -Name 'value' -Default $null
    if ($null -eq $value) {
        throw 'ЛК revonline не вернул результат выполнения задания.'
    }

    $ok = [bool](Get-BridgeObjectPropertyValue -Object $value -Name 'ok' -Default $false)
    $message = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'message' -Default '')
    if ([string]::IsNullOrWhiteSpace($message)) {
        $message = if ($ok) { 'Демоны выполнены.' } else { 'Не удалось выполнить «Демоны».' }
    }

    return [ordered]@{
        ok            = $ok
        code          = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'code' -Default '')
        httpStatus    = [int](Get-BridgeObjectPropertyValue -Object $value -Name 'httpStatus' -Default 0)
        contentType   = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'contentType' -Default '')
        responseUrl   = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'responseUrl' -Default '')
        serverName    = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'serverName' -Default '')
        characterName = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'characterName' -Default '')
        siteMessage   = [string](Get-BridgeObjectPropertyValue -Object $value -Name 'siteMessage' -Default '')
        message       = $message
    }
}

function Open-RevonlineCabinet {
    param([string]$ResolvedLauncherRoot)

    $session = Get-RevonlineBrowserSession -ResolvedLauncherRoot $ResolvedLauncherRoot -OpenUserPage
    return [ordered]@{
        ok          = $true
        browserName = [string](Get-BridgeObjectPropertyValue -Object $session -Name 'browserName' -Default 'browser')
        profileDir  = [string](Get-BridgeObjectPropertyValue -Object $session -Name 'profileDir' -Default '')
        message     = 'ЛК revonline открыт. Войди там один раз, потом кнопка «Демоны» будет использовать эту сессию.'
    }
}

function Invoke-RevonlineDemonsTask {
    param([string]$ResolvedLauncherRoot)

    $session = Get-ExistingRevonlineBrowserSession -ResolvedLauncherRoot $ResolvedLauncherRoot
    $startedHeadless = $false
    if ($null -eq $session) {
        $session = New-RevonlineHeadlessBrowserSession -ResolvedLauncherRoot $ResolvedLauncherRoot
        $startedHeadless = $true
    }

    try {
        $target = Get-RevonlineUserPageTarget -Session $session -NoVisibleFallback
        if ($null -eq $target) {
            return [ordered]@{
                ok      = $false
                code    = 'browser_not_ready'
                message = 'Не удалось открыть фоновую страницу ЛК. Нажми «ЛК», войди один раз и повтори «Демоны».'
            }
        }

        $webSocketUrl = [string](Get-BridgeObjectPropertyValue -Object $target -Name 'webSocketDebuggerUrl' -Default '')
        if ([string]::IsNullOrWhiteSpace($webSocketUrl)) {
            return [ordered]@{
                ok      = $false
                code    = 'browser_not_ready'
                message = 'Фоновая страница ЛК ещё не готова. Нажми «Демоны» ещё раз через пару секунд.'
            }
        }

        $result = Invoke-RevonlineDemonsCdpTask -WebSocketDebuggerUrl $webSocketUrl
        if ([string](Get-BridgeObjectPropertyValue -Object $result -Name 'code' -Default '') -eq 'need_login') {
            $result['message'] = 'Нужно один раз войти в ЛК через кнопку «ЛК», потом «Демоны» будут выполняться в фоне.'
        }

        return $result
    } finally {
        if ($startedHeadless) {
            Stop-RevonlineHeadlessBrowserSession -Session $session -ResolvedLauncherRoot $ResolvedLauncherRoot
        }
    }
}

try {
    $resolvedLauncherRoot = Resolve-LauncherRoot -ConfiguredRoot $bridgeLauncherRootArgument
    $stagedValue = ConvertTo-BridgeBoolean -Value $Staged -Default:$false
    $autoApplyValue = ConvertTo-BridgeBoolean -Value $AutoApply -Default:$true
    $fullLogValue = ConvertTo-BridgeBoolean -Value $FullLog -Default:$true
    $includeLargeValue = ConvertTo-BridgeBoolean -Value $IncludeLarge -Default:$false
    $disableIntroMoviesValue = ConvertTo-BridgeBoolean -Value $DisableIntroMovies -Default:$false
    $directGameLaunchValue = ConvertTo-BridgeBoolean -Value $DirectGameLaunch -Default:$true
    $skipCharacterSelectionValue = ConvertTo-BridgeBoolean -Value $SkipCharacterSelection -Default:$false
    $serverPreflightValue = ConvertTo-BridgeBoolean -Value $ServerPreflight -Default:$true
    $trafficBudgetShieldValue = ConvertTo-BridgeBoolean -Value $TrafficBudgetShield -Default:$true
    $trafficBudgetShieldLimitParsecValue = ConvertTo-BridgeBoolean -Value $TrafficBudgetShieldLimitParsec -Default:$false
    $autoCheckUpdatesOnStartupValue = ConvertTo-BridgeBoolean -Value $AutoCheckUpdatesOnStartup -Default:$true
    $closeVkPlayAfterGameExitValue = ConvertTo-BridgeBoolean -Value $CloseVkPlayAfterGameExit -Default:$true
    $uiSpamGuardValue = ConvertTo-BridgeBoolean -Value $UiSpamGuard -Default:$false
    $clientMitigationValue = ConvertTo-BridgeBoolean -Value $ClientMitigation -Default:$false
    $pendingRelogFastValue = ConvertTo-BridgeBoolean -Value $PendingRelogFast -Default:$false
    $nvidiaRecommendedPresetEnabledValue = ConvertTo-BridgeBoolean -Value $NvidiaRecommendedPresetEnabled -Default:$false
    $cancellableActions = @('RelogGame', 'FastRelogGame', 'LaunchGame', 'RunFrameTimeAudit')
    if ($Action -in $cancellableActions) {
        [void](Start-BridgeCancellableOperation -ResolvedLauncherRoot $resolvedLauncherRoot -Kind $Action)
    }

    switch ($Action) {
        'GetStatus' {
            Write-JsonResponse -Value (Build-StatusPayload -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'GetStartupStatus' {
            Write-JsonResponse -Value (Build-StatusPayload -ResolvedLauncherRoot $resolvedLauncherRoot -Lightweight -SkipRuntimeStatus:$SkipRuntimeStatus)
        }
        'VerifyLauncherHealth' {
            Write-JsonResponse -Value (Test-BridgeLauncherHealth -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'ApplyUiGuardConfig' {
            Write-JsonResponse -Value ([ordered]@{ ok = $true; skipped = $true; changed = $false; message = 'Автоматическое изменение отображения отключено. Используйте кнопку в настройках канарейки.' })
        }
        'ApplyDisplaySettings' {
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            Write-JsonResponse -Value (Repair-BridgeUiGuardConfig -ResolvedLauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir)
        }
        'GetGameConfigEditor' {
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            Write-JsonResponse -Value (Get-BridgeGameConfigEditor -ResolvedLauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir)
        }
        'SaveGameConfigEditor' {
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            Write-JsonResponse -Value (Save-BridgeGameConfigEditor -ResolvedLauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -PayloadB64 $ConfigEditorPayloadB64)
        }
        'CleanupStartupSession' {
            Write-JsonResponse -Value (Invoke-StartupVkPlayCleanup -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'CleanupGameExitSession' {
            Write-JsonResponse -Value (Invoke-GameExitVkPlayCleanup -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'RelogGame' {
            Write-JsonResponse -Value (Invoke-BridgeGameRelog -ResolvedLauncherRoot $resolvedLauncherRoot -FastMode)
        }
        'FastRelogGame' {
            Write-JsonResponse -Value (Invoke-BridgeGameFastRelog -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'SavePendingRelogResume' {
            Write-JsonResponse -Value (Save-BridgePendingRelogResume -ResolvedLauncherRoot $resolvedLauncherRoot -FastRelog $pendingRelogFastValue)
        }
        'ConsumePendingRelogResume' {
            Write-JsonResponse -Value (Consume-BridgePendingRelogResume -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'RunPendingRelogAsAdmin' {
            Write-JsonResponse -Value (Invoke-PendingRelogAsAdmin -ResolvedLauncherRoot $resolvedLauncherRoot -CurrentLauncherPid $CurrentLauncherPid)
        }
        'CheckServerPreflight' {
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $stateDir = Join-Path $resolvedLauncherRoot '.revelation-combat'
            Ensure-Directory -Path $stateDir
            $preflight = Test-RevelationLaunchServerPreflight -ResolvedGameRoot $resolvedGameRoot -ResolvedGameDir $resolvedGameDir -StateDir $stateDir
            Write-JsonResponse -Value ([ordered]@{
                    ok              = $true
                    available       = $preflight.available
                    checked         = [bool]$preflight.checked
                    blocked         = [bool]([bool]$preflight.checked -and -not [bool]$preflight.ok)
                    warning         = [bool]([bool]$preflight.warning -or -not [bool]$preflight.checked)
                    serverPreflight = $preflight
                    message         = [string]$preflight.message
                })
        }
        'LaunchGame' {
            # Launch reads the authoritative file. Settings are changed only by SaveLauncherSettings.
            Write-JsonResponse -Value (Invoke-LaunchGame -ResolvedLauncherRoot $resolvedLauncherRoot -LaunchMode $Mode)
        }
        'CancelActiveOperation' {
            Write-JsonResponse -Value (Request-BridgeActiveOperationCancel -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'NetworkApply' {
            Write-JsonResponse -Value (Invoke-NetworkApply -ResolvedLauncherRoot $resolvedLauncherRoot -UseStaged $stagedValue)
        }
        'SetNetworkStagedPreference' {
            Write-JsonResponse -Value (Invoke-SetNetworkStagedPreference -ResolvedLauncherRoot $resolvedLauncherRoot -UseStaged $stagedValue)
        }
        'SetNetworkAutoApplyPreference' {
            Write-JsonResponse -Value (Invoke-SetNetworkAutoApplyPreference -ResolvedLauncherRoot $resolvedLauncherRoot -AutoApplyOnLaunch $autoApplyValue)
        }
        'SetExperimentalFullLogPreference' {
            Write-JsonResponse -Value (Invoke-SetExperimentalFullLogPreference -ResolvedLauncherRoot $resolvedLauncherRoot -Enabled $fullLogValue)
        }
        'SaveLauncherSettings' {
            $stateDir = Join-Path $resolvedLauncherRoot '.revelation-combat'
            $settings = Get-SettingsState -StateDir $stateDir
            $effectiveUploadDir = $(if ($UploadDir) { $UploadDir } else { $settings.uploadDir })
            $effectiveNetworkStaged = $(if ($PSBoundParameters.ContainsKey('Staged')) { $stagedValue } else { [bool]$settings.networkStaged })
            $effectiveNetworkAutoApply = $(if ($PSBoundParameters.ContainsKey('AutoApply')) { $autoApplyValue } else { [bool]$settings.networkAutoApply })
            $effectiveFullLog = $(if ($PSBoundParameters.ContainsKey('FullLog')) { $fullLogValue } else { [bool]$settings.experimentalFullLog })
            $effectiveDirectGameLaunch = $(if ($PSBoundParameters.ContainsKey('DirectGameLaunch')) { $directGameLaunchValue } else { [bool]$settings.directGameLaunch })
            $effectiveSkipCharacterSelection = $(if ($PSBoundParameters.ContainsKey('SkipCharacterSelection')) { $skipCharacterSelectionValue } else { [bool]$settings.skipCharacterSelection })
            $effectiveServerPreflight = $(if ($PSBoundParameters.ContainsKey('ServerPreflight')) { $serverPreflightValue } else { [bool]$settings.serverPreflight })
            $effectiveDisableIntroMovies = $(if ($PSBoundParameters.ContainsKey('DisableIntroMovies')) { $disableIntroMoviesValue } else { [bool]$settings.disableIntroMovies })
            $effectiveTrafficBudgetShield = $(if ($PSBoundParameters.ContainsKey('TrafficBudgetShield')) { $trafficBudgetShieldValue } else { [bool]$settings.trafficBudgetShield })
            $effectiveTrafficBudgetShieldLimitParsec = $(if ($PSBoundParameters.ContainsKey('TrafficBudgetShieldLimitParsec')) { $trafficBudgetShieldLimitParsecValue } else { [bool]$settings.trafficBudgetShieldLimitParsec })
            $effectiveDxvkMode = $(if ($PSBoundParameters.ContainsKey('DxvkMode')) { [string]$DxvkMode } else { [string]$settings.dxvkMode })
            $effectiveAutoCheckUpdatesOnStartup = $(if ($PSBoundParameters.ContainsKey('AutoCheckUpdatesOnStartup')) { $autoCheckUpdatesOnStartupValue } else { [bool]$settings.autoCheckUpdatesOnStartup })
            $effectiveCloseVkPlayAfterGameExit = $(if ($PSBoundParameters.ContainsKey('CloseVkPlayAfterGameExit')) { $closeVkPlayAfterGameExitValue } else { [bool]$settings.closeVkPlayAfterGameExit })
            $effectiveUiSpamGuard = $(if ($PSBoundParameters.ContainsKey('UiSpamGuard')) { $uiSpamGuardValue } else { [bool]$settings.uiSpamGuard })
            $effectiveClientMitigation = $(if ($PSBoundParameters.ContainsKey('ClientMitigation')) { $clientMitigationValue } else { [bool]$settings.clientMitigation })
            $effectiveIncludeLarge = $(if ($PSBoundParameters.ContainsKey('IncludeLarge')) { $includeLargeValue } else { [bool]$settings.includeLarge })
            Write-JsonResponse -Value (Invoke-SaveLauncherSettings -ResolvedLauncherRoot $resolvedLauncherRoot -UploadDir $effectiveUploadDir -IncludeLarge $effectiveIncludeLarge -NetworkStaged $effectiveNetworkStaged -NetworkAutoApply $effectiveNetworkAutoApply -ExperimentalFullLog $effectiveFullLog -DirectGameLaunch $effectiveDirectGameLaunch -ServerPreflight $effectiveServerPreflight -DisableIntroMovies $effectiveDisableIntroMovies -TrafficBudgetShield $effectiveTrafficBudgetShield -TrafficBudgetShieldLimitParsec $effectiveTrafficBudgetShieldLimitParsec -DxvkMode $effectiveDxvkMode -AutoCheckUpdatesOnStartup $effectiveAutoCheckUpdatesOnStartup -CloseVkPlayAfterGameExit $effectiveCloseVkPlayAfterGameExit -UiSpamGuard $effectiveUiSpamGuard -ClientMitigation $effectiveClientMitigation -SkipCharacterSelection $effectiveSkipCharacterSelection)
        }
        'NetworkRestore' {
            Write-JsonResponse -Value (Invoke-NetworkRestore -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'KillWatcher' {
            Write-JsonResponse -Value (Invoke-KillWatcher -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'EnablePvpRecoveryMode' {
            Assert-BridgePvpRecoveryBackend
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            Write-JsonResponse -Value (Enable-LauncherPvpRecoveryMode -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir)
        }
        'DisablePvpRecoveryMode' {
            Assert-BridgePvpRecoveryBackend
            Write-JsonResponse -Value (Disable-LauncherPvpRecoveryMode -LauncherRoot $resolvedLauncherRoot)
        }
        'PreparePvpResearchBundle' {
            Assert-BridgePvpRecoveryBackend
            Write-JsonResponse -Value (Prepare-LauncherPvpResearchBundle -LauncherRoot $resolvedLauncherRoot)
        }
        'MarkPvpLagEvent' {
            Assert-BridgePvpRecoveryBackend
            Write-JsonResponse -Value (Add-LauncherPvpLagMarker -LauncherRoot $resolvedLauncherRoot)
        }
        'OpenVkPlay' {
            $launchResult = Open-GameCenterLauncher
            if (-not $launchResult.started) {
                throw 'VK Play was not detected automatically.'
            }
            $stateDir = Join-Path $resolvedLauncherRoot '.revelation-combat'
            Ensure-Directory -Path $stateDir
            $settings = Get-SettingsState -StateDir $stateDir
            $vkPlayExitWatcher = [ordered]@{ enabled = [bool]$settings.closeVkPlayAfterGameExit; started = $false; processId = 0; message = 'Папка игры не найдена, watcher закрытия VK Play не запущен.' }
            try {
                $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
                $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
                $vkPlayExitWatcher = Start-VkPlayShutdownAfterGameExitWatcher -ResolvedLauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Enabled ([bool]$settings.closeVkPlayAfterGameExit)
            } catch {
                $vkPlayExitWatcher['error'] = $_.Exception.Message
            }
            Write-JsonResponse -Value ([ordered]@{
                ok           = $true
                started      = $true
                path         = $launchResult.path
                directLaunch = $false
                launchUri    = ''
                vkPlayExitWatcher = $vkPlayExitWatcher
                message      = 'VK Play открыт.'
            })
        }
        'OpenRevonlineCabinet' {
            Write-JsonResponse -Value (Open-RevonlineCabinet -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'RunDemonsTask' {
            $demonsResult = Invoke-RevonlineDemonsTask -ResolvedLauncherRoot $resolvedLauncherRoot
            $demonsCode = [string](Get-BridgeObjectPropertyValue -Object $demonsResult -Name 'code' -Default '')
            if ($demonsCode -eq 'need_login') {
                Open-RevonlineCabinet -ResolvedLauncherRoot $resolvedLauncherRoot | Out-Null
                $demonsResult['message'] = 'Открыт «Личный кабинет». Войди там один раз, затем повтори выполнение «Демонов».'
                Write-JsonResponse -Value $demonsResult
                break
            }
            if ($demonsCode -eq 'premium_required') {
                Write-JsonResponse -Value $demonsResult
                break
            }
            if (-not [bool]$demonsResult.ok) {
                $demonsResult['error'] = [string]$demonsResult.message
            }
            Write-JsonResponse -Value $demonsResult -ExitCode $(if ([bool]$demonsResult.ok) { 0 } else { 1 })
        }
        'RunFrameTimeAudit' {
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            Write-JsonResponse -Value (Invoke-FrameTimeAudit -ResolvedLauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir)
        }
        'PrepareDiagnostics' {
            $stateDir = Join-Path $resolvedLauncherRoot '.revelation-combat'
            Ensure-Directory -Path $stateDir
            $settings = Get-SettingsState -StateDir $stateDir
            $effectiveUploadDir = $(if ($UploadDir) { $UploadDir } else { $settings.uploadDir })
            $effectiveIncludeLarge = $(if ($PSBoundParameters.ContainsKey('IncludeLarge')) { $includeLargeValue } else { [bool]$settings.includeLarge })
            Save-SettingsState -StateDir $stateDir -UploadDir $effectiveUploadDir -IncludeLarge $effectiveIncludeLarge -NetworkStaged $settings.networkStaged -NetworkAutoApply $settings.networkAutoApply
            Write-JsonResponse -Value (Build-DiagnosticsBundle -ResolvedLauncherRoot $resolvedLauncherRoot -UploadRoot $effectiveUploadDir -CopyToUpload:$false -IncludeLargeFiles $effectiveIncludeLarge)
        }
        'SendDiagnostics' {
            $stateDir = Join-Path $resolvedLauncherRoot '.revelation-combat'
            Ensure-Directory -Path $stateDir
            $settings = Get-SettingsState -StateDir $stateDir
            $effectiveUploadDir = $(if ($UploadDir) { $UploadDir } else { $settings.uploadDir })
            $effectiveIncludeLarge = $(if ($PSBoundParameters.ContainsKey('IncludeLarge')) { $includeLargeValue } else { [bool]$settings.includeLarge })
            Save-SettingsState -StateDir $stateDir -UploadDir $effectiveUploadDir -IncludeLarge $effectiveIncludeLarge -NetworkStaged $settings.networkStaged -NetworkAutoApply $settings.networkAutoApply
            Write-JsonResponse -Value (Build-DiagnosticsBundle -ResolvedLauncherRoot $resolvedLauncherRoot -UploadRoot $effectiveUploadDir -CopyToUpload:$true -IncludeLargeFiles $effectiveIncludeLarge)
        }
        'SaveCurrentUserConfigPreset' {
            Assert-BridgeUserConfigBackend
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $result = Save-LauncherCurrentUserConfigPreset -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -PresetName $PresetName -PresetId $PresetId
            $result.ok = $true
            Write-JsonResponse -Value $result
        }
        'ImportUserConfigPreset' {
            Assert-BridgeUserConfigBackend
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $result = Import-LauncherUserConfigPreset -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -SourceDir $SourceDir -PresetName $PresetName
            $result.ok = $true
            Write-JsonResponse -Value $result
        }
        'ApplyUserConfigPreset' {
            Assert-BridgeUserConfigBackend
            if (-not $PresetId) {
                throw 'PresetId is required.'
            }
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $result = Apply-LauncherUserConfigPreset -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -PresetId $PresetId
            $result.ok = $true
            Write-JsonResponse -Value $result
        }
        'RenameUserConfigPreset' {
            Assert-BridgeUserConfigBackend
            if (-not $PresetId) {
                throw 'PresetId is required.'
            }
            $result = Rename-LauncherUserConfigPreset -LauncherRoot $resolvedLauncherRoot -PresetId $PresetId -PresetName $PresetName
            $result.ok = $true
            Write-JsonResponse -Value $result
        }
        'DeleteUserConfigPreset' {
            Assert-BridgeUserConfigBackend
            if (-not $PresetId) {
                throw 'PresetId is required.'
            }
            $result = Remove-LauncherUserConfigPreset -LauncherRoot $resolvedLauncherRoot -PresetId $PresetId
            $result.ok = $true
            Write-JsonResponse -Value $result
        }
        'SetRecoveryUserConfigPreset' {
            Assert-BridgeUserConfigBackend
            if (-not $PresetId) {
                throw 'PresetId is required.'
            }
            $result = Set-LauncherUserConfigRecoveryPreset -LauncherRoot $resolvedLauncherRoot -PresetId $PresetId
            $result.ok = $true
            Write-JsonResponse -Value $result
        }
        'RestoreUserConfig' {
            Write-JsonResponse -Value (Invoke-RestoreUserConfig -ResolvedLauncherRoot $resolvedLauncherRoot)
        }
        'GetGpuProfileStatus' {
            Assert-BridgeGpuProfileBackend
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $result = Get-RevelationGpuProfileStatus -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -ForceHardwareRefresh
            $result['ok'] = $true
            Write-JsonResponse -Value $result
        }
        'SaveGpuProfileSettings' {
            Assert-BridgeGpuProfileBackend
            $settings = Save-RevelationGpuProfileSettings -LauncherRoot $resolvedLauncherRoot -FpsCapMode $GpuFpsCapMode -ManualFpsCap $GpuManualFpsCap -NvidiaProfileInspectorPath $NvidiaProfileInspectorPath -NvidiaRecommendedPresetEnabled $nvidiaRecommendedPresetEnabledValue
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $apply = Apply-RevelationGpuProfileSettings -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Force
            $apply = Add-GpuApplyRestartRequirement -Result $apply -ResolvedGameDir $resolvedGameDir
            $needsAdminRelaunch = [bool](Get-BridgeObjectPropertyValue -Object $apply -Name 'needsAdminRelaunch' -Default $false)
            Write-JsonResponse -Value ([ordered]@{
                    ok = $true
                    settings = $settings
                    gpuProfiles = $apply.status
                    apply = $apply
                    restartRequired = [bool]$apply.restartRequired
                    activeFpsCap = [int]$apply.activeFpsCap
                    pendingFpsCap = [int]$apply.pendingFpsCap
                    needsAdminRelaunch = $needsAdminRelaunch
                    message = [string]$apply.message
                })
        }
        'ApplyGpuProfileSettings' {
            Assert-BridgeGpuProfileBackend
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $apply = Apply-RevelationGpuProfileSettings -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir -Force
            Write-JsonResponse -Value (Add-GpuApplyRestartRequirement -Result $apply -ResolvedGameDir $resolvedGameDir)
        }
        'InstallNvidiaProfileInspector' {
            Assert-BridgeGpuProfileBackend
            if (-not (Get-Command -Name Install-RevelationNvidiaProfileInspector -ErrorAction SilentlyContinue)) {
                throw 'Установка NVIDIA Profile Inspector недоступна в текущем модуле.'
            }
            $install = Install-RevelationNvidiaProfileInspector -LauncherRoot $resolvedLauncherRoot
            $resolvedGameRoot = Resolve-GameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
            $resolvedGameDir = Resolve-GameDir -ResolvedGameRoot $resolvedGameRoot
            $status = Get-RevelationGpuProfileStatus -LauncherRoot $resolvedLauncherRoot -ResolvedGameDir $resolvedGameDir
            Write-JsonResponse -Value ([ordered]@{
                ok = [bool]$install.ok
                install = $install
                gpuProfiles = $status
                message = [string]$install.message
            }) -ExitCode $(if ([bool]$install.ok) { 0 } else { 1 })
        }
        'RelaunchAsAdmin' {
            Write-JsonResponse -Value (Invoke-RelaunchAsAdmin -ResolvedLauncherRoot $resolvedLauncherRoot -CurrentLauncherPid $CurrentLauncherPid)
        }
        'GetUpdateStatus' {
            Assert-BridgeUpdaterBackend
            Write-JsonResponse -Value ([ordered]@{ ok = $true; updates = (Get-RevelationUpdateStatus -LauncherRoot $resolvedLauncherRoot -ReleaseChannel $UpdateChannel) })
        }
        'CheckLauncherUpdate' {
            Assert-BridgeUpdaterBackend
            Write-JsonResponse -Value ([ordered]@{ ok = $true; updates = (Get-RevelationUpdateStatus -LauncherRoot $resolvedLauncherRoot -ReleaseChannel $UpdateChannel -CheckOnline) })
        }
        'SaveLauncherUpdate' {
            Assert-BridgeUpdaterBackend
            $download = Save-RevelationLauncherUpdate -LauncherRoot $resolvedLauncherRoot -ReleaseChannel $UpdateChannel -PreferDelta:$UpdatePreferDelta
            Write-JsonResponse -Value ([ordered]@{ ok = $true; updates = $download; message = [string]$download.message })
        }
        'InstallLauncherUpdate' {
            Assert-BridgeUpdaterBackend
            $install = Install-RevelationLauncherUpdate -LauncherRoot $resolvedLauncherRoot -ReleaseChannel $UpdateChannel -InstallerPath $UpdateInstallerPath -Sha256 $UpdateSha256
            Write-JsonResponse -Value ([ordered]@{ ok = $true; install = $install; closeRecommended = $true; message = [string]$install.message })
        }
        'GetActivationStatus' {
            Write-JsonResponse -Value ([ordered]@{ ok = $true; license = (New-LicenseStatusPayload -LauncherRoot $resolvedLauncherRoot -ForceRefresh) })
        }
        'ActivateLicense' {
            if (-not $ActivationKey) { throw 'Activation key is required.' }
            Write-JsonResponse -Value (Activate-License -LauncherRoot $resolvedLauncherRoot -ActivationKey $ActivationKey -UnlockCode $UnlockCode)
        }
        'RefreshLicenseStatus' {
            Write-JsonResponse -Value ([ordered]@{ ok = $true; license = (New-LicenseStatusPayload -LauncherRoot $resolvedLauncherRoot -ForceRefresh) })
        }
        'ApplyUnlockCode' {
            if (-not $ActivationKey) { throw 'Activation key is required for unlock code validation.' }
            $unlockResult = Test-UnlockCode -LauncherRoot $resolvedLauncherRoot -ActivationKey $ActivationKey -UnlockCode $UnlockCode
            if (-not $unlockResult.ok) { throw $unlockResult.message }
            $state = Read-LicenseState -LauncherRoot $resolvedLauncherRoot
            $state['activationKey'] = $ActivationKey
            $state['keyDigest'] = Get-Sha256Hex -Value $ActivationKey
            $state['licenseId'] = [string]$unlockResult.licenseId
            $state['mode'] = [string]$unlockResult.mode
            $state['status'] = 'manually-allowed'
            $state['manualOverrideUntilUtc'] = [string]$unlockResult.expiresAtUtc
            $state['message'] = 'Временная разблокировка администратора применена.'
            $state['lastValidatedUtc'] = Get-UtcNowString
            Write-LicenseState -LauncherRoot $resolvedLauncherRoot -State $state
            Write-JsonResponse -Value ([ordered]@{ ok = $true; message = 'Аварийный код применён.'; license = (New-LicenseStatusPayload -LauncherRoot $resolvedLauncherRoot) })
        }
        'DeactivateLocalCache' {
            Write-JsonResponse -Value (Clear-LicenseLocalState -LauncherRoot $resolvedLauncherRoot)
        }
        'GetMachineRequestCode' {
            $fingerprint = Get-MachineFingerprintData
            Write-JsonResponse -Value ([ordered]@{ ok = $true; requestCode = [string]$fingerprint.requestCode; fingerprintHash = [string]$fingerprint.fingerprintHash; signals = $fingerprint.signals })
        }
        default {
            throw ('Unsupported action: ' + $Action)
        }
    }
} catch [System.OperationCanceledException] {
    $script:BridgeOperationFailed = $false
    Write-JsonResponse -Value ([ordered]@{
            ok                  = $true
            cancelled           = $true
            started             = $false
            blocked             = $true
            launchBlockedReason = 'operation_cancelled'
            message              = [string]$_.Exception.Message
        })
} catch {
    $script:BridgeOperationFailed = $true
    $bridgeErrorMessage = [string]$_.Exception.Message
    Fail-Bridge -Message $bridgeErrorMessage
}

