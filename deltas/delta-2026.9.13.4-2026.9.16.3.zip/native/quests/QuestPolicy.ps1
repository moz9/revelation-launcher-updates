function Test-DeveloperQuestAccess {
    param([System.Collections.IDictionary]$License)
    return $null -ne $License -and $License['allowRuntime'] -eq $true -and ([string]$License['licenseType']) -ieq 'developer'
}
function Test-QuestFacingDeferred {
    param([object[]]$Rows)
    $failure=@($Rows | Where-Object {$_.event -match 'rejected|no_action|_error$|_failed$|disabled|unavailable|not_ready|no_owned'})
    $facing=@($Rows | Where-Object {$_.event -eq 'combat_target_facing_complete'})
    $began=@($Rows | Where-Object {$_.event -eq 'combat_hotbar_step_begin'})
    $selected=@($Rows | Where-Object {$_.event -eq 'quest_skill_selected'})
    $target=@($Rows | Where-Object {$_.event -eq 'quest_target_complete'})
    $selectedAttack=$selected.Count -eq 1 -and $target.Count -eq 1 -and $began.Count -eq 1 -and $facing.Count -eq 1 -and
        $selected[0].skillId -eq $began[0].skillId -and $selected[0].slot -eq $began[0].index -and
        $selected[0].route -in @('target','untargeted') -and $target[0].targetId -gt 0 -and
        $target[0].targetId -eq $facing[0].targetId
    # Pinned native branch returns before key-down when it has just changed facing.
    return $failure.Count -eq 1 -and $failure[0].event -eq 'combat_hotbar_step_error' -and
        $facing.Count -eq 1 -and $facing[0].turned -eq $true -and $facing[0].aligned -eq $true -and
        $facing[0].reason -eq 'facing_confirmed' -and $began.Count -eq 1 -and
        (($began[0].index -eq 0 -and $began[0].skillId -eq 1201) -or ($began[0].index -ge 0 -and $began[0].index -lt 12 -and ($selectedAttack -or $began[0].skillId -in @(1401,1402,1406,1602)))) -and $began[0].aimRoute -eq 'ordinary'
}
