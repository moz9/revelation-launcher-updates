﻿param([Parameter(Mandatory=$true)][string]$LauncherRoot,[Parameter(Mandatory=$true)][string]$GameRoot,[int]$GameProcessId,[ValidateSet(330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,363,364,365,366,367,368,369,370,371,373,374,375,376,377,378)][int]$Command=330,[switch]$AllowAbandonCurrentQuest,[long]$ExpectedQuestId=0)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
if($Command -eq 337 -and (-not $AllowAbandonCurrentQuest -or $ExpectedQuestId -le 0)){throw 'quest_abandon_explicit_current_quest_required'}
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
trap { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }
. (Join-Path $PSScriptRoot 'QuestPolicy.ps1')
. (Join-Path $LauncherRoot 'RevelationLicense.ps1')
# Stopping an existing action remains possible after license revocation.
if($Command -notin @(354,373)){
    $questLicense=New-LicenseStatusPayload -LauncherRoot $LauncherRoot
    if(-not (Test-DeveloperQuestAccess -License $questLicense)){throw 'quest_developer_license_required'}
}
. (Join-Path $LauncherRoot 'tools\RevelationGameBridge.ps1')
# Extend the existing serialized transport only for the probe's fixed read handler.
$definition=(Get-Command Send-RevelationGameBridgeCommandUnlocked).Definition
$allow='@(0, 1, 2, 21, 110, 300, 301, 302, 303, 304, 305, 306)'
if(-not $definition.Contains($allow)){throw 'transport_contract_changed'}
$definition=$definition.Replace($allow,'@(0, 1, 2, 21, 110, 300, 301, 302, 303, 304, 305, 306, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 363, 364, 365, 366, 367, 368, 369, 370, 371, 373, 374, 375, 376, 377, 378)')
$terminal="switch (`$Command) { 0 { 'state_probe' }"
if(-not $definition.Contains($terminal)){throw 'transport_terminal_contract_changed'}
$definition=$definition.Replace($terminal,"switch (`$Command) { 378 { 'quest_continue_warning_confirmed' } 330 { 'quest_read_complete' } 331 { 'quest_route_complete' } 332 { 'quest_target_complete' } 333 { 'combat_hotbar_step_complete' } 334 { 'quest_login_read_complete' } 335 { 'quest_login_retry_complete' } 336 { 'quest_login_dismiss_complete' } 337 { 'quest_abandon_sent' } 338 { 'quest_reaccept_route_sent' } 339 { 'quest_accept_selected' } 340 { 'quest_accept_sent' } 341 { 'quest_menu_opened' } 342 { 'quest_shop_read_complete' } 343 { 'quest_shop_opened' } 344 { 'quest_shop_buy_sent' } 345 { 'quest_repeat_accepted' } 346 { 'quest_auto_stopped' } 347 { 'quest_chess_read_complete' } 348 { 'quest_chess_route_sent' } 349 { 'quest_chess_skill_sent' } 350 { 'quest_chess_route_sent' } 351 { 'quest_chess_submit_selected' } 352 { 'quest_chess_submit_sent' } 353 { 'quest_runner_state' } 354 { 'quest_runner_paused' } 355 { 'quest_extra_selected' } 356 { 'quest_extra_accepted' } 357 { 'quest_runner_closed' } 358 { 'quest_runner_resumed' } 359 { 'quest_daily_submit_sent' } 363 { 'quest_puzzle_answer_sent' } 364 { 'quest_interaction_sent' } 365 { 'quest_dismount_sent' } 366 { 'quest_dialog_sent' } 367 { 'quest_shop_page_sent' } 368 { 'quest_skill_catalog_complete' } 369 { 'quest_recovery_read_complete' } 370 { 'quest_revive_sent' } 371 { 'quest_spirit_summon_sent' } 373 { 'quest_tracking_policy_complete' } 374 { 'quest_marker_route_sent' } 375 { 'quest_marker_interaction_sent' } 376 { 'quest_marker_route_sent' } 377 { 'quest_marker_route_sent' } 0 { 'state_probe' }")
$failureLine='if ($failure) { throw (''game_bridge_'' + $failure.event) }'
if(-not $definition.Contains($failureLine)){throw 'transport_failure_contract_changed'}
$definition=$definition.Replace($failureLine,'if ($Command -eq 333 -and (Test-QuestFacingDeferred -Rows $rows)) { return [pscustomobject]@{sequence=$sequence;event="quest_attack_deferred"} }; '+$failureLine)
$definition=$definition.Replace($failureLine,'if ($Command -eq 333 -and @($rows | Where-Object {$_.event -eq "quest_dismount_sent"}).Count -eq 1) { return [pscustomobject]@{sequence=$sequence;event="quest_dismount_sent"} }; '+$failureLine)
$definition=$definition.Replace($failureLine,'if ($Command -eq 333 -and @($rows | Where-Object {$_.event -eq "quest_attack_waiting"}).Count -eq 1) { return [pscustomobject]@{sequence=$sequence;event="quest_attack_waiting"} }; '+$failureLine)
$definition=$definition.Replace($failureLine,'if ($Command -eq 333 -and @($rows | Where-Object {$_.event -eq "quest_combat_approach_failed"}).Count -eq 1) { return [pscustomobject]@{sequence=$sequence;event="quest_combat_approach_failed"} }; '+$failureLine)
$definition=$definition.Replace($failureLine,'if ($Command -eq 333 -and -not $failure -and @($rows | Where-Object {$_.event -eq "quest_combat_approach_sent"}).Count -eq 1) { return [pscustomobject]@{sequence=$sequence;event="quest_combat_approach_sent"} }; '+$failureLine)
Set-Item Function:Send-RevelationGameBridgeCommandUnlocked ([scriptblock]::Create($definition))
$session=Get-RevelationGameBridgeSession -LauncherRoot $LauncherRoot -GameDir (Join-Path $GameRoot 'game')
if(-not $session){throw 'quest_session_missing'}
$expected=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot '..\tower\TowerCanaryProbe.dll') -Algorithm SHA256).Hash
if($session.bridgeHash -ne $expected){throw 'quest_probe_not_loaded'}
if(-not $GameProcessId){$targets=@(Get-RevelationGameBridgeProcesses -GameDir $session.gameDir);if($targets.Count -ne 1){throw 'quest_requires_one_client'};$GameProcessId=$targets[0].Id}
if($Command -in @(331,332,333,335,336,337,338,339,340,341,343,344,345,346,348,349,350,351,352,354,355,356,357,358,359,363,364,365,366,367,370,371,373,374,375,376,377,378)){
    $readCommand=if($Command -in @(335,336)){334}elseif($Command -in @(344,367)){342}elseif($Command -eq 378){353}else{330}
    $fresh=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command $readCommand
    if($Command -eq 337){
        $observed=@(Get-RevelationGameBridgeEvents -Session $session -TailBytes 131072 | Where-Object {[int]$_.pid -eq $GameProcessId -and [int]$_.sequence -eq $fresh.sequence -and $_.event -eq 'quest_loop_actual'})
        if($observed.Count -ne 1 -or [long]$observed[0].actualQuestId -ne $ExpectedQuestId){throw 'quest_abandon_current_quest_changed'}
    }
    Set-RevelationGameBridgeArm -Session $session -AllowEnter:$session.skipCharacterSelection -AllowCombatMove $true -AllowCombatTest:($Command -eq 333)
}
try {
    $ack=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command $Command
    # A short series of distinct F actions, with a native scope check before every action.
    # Keep one transport process: starting PowerShell for each F breaks the game's timing.
    if($Command -eq 364){
        $interactionWatch=[Diagnostics.Stopwatch]::StartNew()
        for($press=1;$press -lt 100 -and $interactionWatch.Elapsed.TotalSeconds -lt 20;$press++){
            Start-Sleep -Milliseconds 30
            Set-RevelationGameBridgeArm -Session $session -AllowEnter:$session.skipCharacterSelection -AllowCombatMove $true
            try{$ack=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command 364}
            catch{if($_.Exception.Message -eq 'game_bridge_quest_interaction_rejected'){break};throw}
        }
    }
    # Only the proven no-cast facing response permits a bounded later-frame attempt.
    for($laterFrame=0;$ack.event -eq 'quest_attack_deferred' -and $laterFrame -lt 2;$laterFrame++){
        Start-Sleep -Milliseconds 80
        $fresh=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command 330
        Set-RevelationGameBridgeArm -Session $session -AllowEnter:$session.skipCharacterSelection -AllowCombatMove $true -AllowCombatTest $true
        $ack=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command 333
    }
}
finally {if($Command -in @(331,332,333,335,336,337,338,339,340,341,343,344,345,346,348,349,350,351,352,354,355,356,357,358,359,363,364,365,366,367,370,371,373,374,375,376,377,378)){Set-RevelationGameBridgeArm -Session $session -AllowEnter:$session.skipCharacterSelection}}
$rows=@(Get-RevelationGameBridgeEvents -Session $session -TailBytes 131072 | Where-Object {[int]$_.pid -eq $GameProcessId -and [int]$_.sequence -eq $ack.sequence})
if($ack.event -eq 'quest_attack_deferred'){$rows+= $ack}
[Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress))

