param([Parameter(Mandatory=$true)][string]$LauncherRoot,[Parameter(Mandatory=$true)][string]$GameRoot,[Parameter(Mandatory=$true)][string]$ExpectedModulePath,[Parameter(Mandatory=$true)][int]$GameProcessId,[Parameter(Mandatory=$true)][int]$ExpectedPlayerId,[switch]$ProbeOnly,[switch]$MessagesOnly,[switch]$DialogOnly)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
trap{[Console]::Error.WriteLine($_.Exception.Message);exit 1}
 $core=$LauncherRoot
 $game=$GameRoot
 $app=Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $ExpectedModulePath))
$raw=& powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File (Join-Path $app 'native\guild\GuildCommand.ps1') -LauncherRoot $core -GameRoot $game -ExpectedModulePath $ExpectedModulePath -GameProcessId $GameProcessId -Command 385
if($LASTEXITCODE -ne 0){throw 'guild_entry_read_failed'}
$state=@(($raw|ConvertFrom-Json)|Where-Object event -eq 'guild_entry_state')
if($state.Count -ne 1 -or $state[0].playerId -ne $ExpectedPlayerId -or -not $state[0].worldSafe){throw 'guild_entry_character_busy_or_changed'}
if(-not $state[0].membershipKnown){throw 'guild_membership_unknown'}
if(-not $state[0].member){Write-Output 'GUILD_NOT_MEMBER';exit 0}
. (Join-Path $core 'tools\RevelationGameBridge.ps1')
$definition=(Get-Command Send-RevelationGameBridgeCommandUnlocked).Definition
$allow='@(0, 1, 2, 21, 110, 300, 301, 302, 303, 304, 305, 306)'
$hashLine='$hash = if ($Command -eq 110)'
$terminal="switch (`$Command) { 0 { 'state_probe' }"
if(-not $definition.Contains($allow) -or -not $definition.Contains($hashLine) -or -not $definition.Contains($terminal)){throw 'guild_entry_transport_contract_changed'}
$definition=$definition.Replace($allow,'@(0, 1, 2, 21, 110, 230, 231, 282, 284, 289, 300, 301, 302, 303, 304, 305, 306)').Replace($hashLine,'$hash = if ($Command -eq 230) { ''4dda50929f9fa42caf2ac575b668f339604c10d38bece7e24e63149f4f2e704d'' } elseif ($Command -eq 231) { ''65f273e8bf416215ee0226c1352c02d9734dfe437b66b22a1bc3969a75629952'' } elseif ($Command -eq 282) { ''d77a0e8492005f88468d7b0a329899ed50c7733e1df4d45b1307ed24fc746c44'' } elseif ($Command -eq 289) { ''65f273e8bf416215ee0226c1352c02d9734dfe437b66b22a1bc3969a75629952'' } elseif ($Command -eq 284) { ''c43c1c410bb5360148ff902c660a2ec657ac5a52e452397a22095a5d64caa5dc'' } elseif ($Command -eq 110)').Replace($terminal,"switch (`$Command) { 230 { 'function_call_returned' } 231 { 'function_call_returned' } 282 { 'world_map_message_probe_complete' } 284 { 'world_map_guild_exit_probe_complete' } 289 { 'world_map_teleport_confirmation_probe_complete' } 0 { 'state_probe' }")
Set-Item Function:Send-RevelationGameBridgeCommandUnlocked ([scriptblock]::Create($definition))
$session=Get-RevelationGameBridgeSession -LauncherRoot $core -GameDir (Join-Path $game 'game')
$iniPath=Join-Path $session.gameDir 'revelation-game-bridge.ini'
$original=[IO.File]::ReadAllText($iniPath)
if($original -notmatch '(?m)^allowFunctions=0\r?$'){throw 'guild_entry_other_function_owner'}
function Read-EntryCommand([int]$number){
 $ack=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command $number
 return @(Get-RevelationGameBridgeEvents -Session $session -TailBytes 131072|Where-Object{[int]$_.pid -eq $GameProcessId -and [int]$_.sequence -eq $ack.sequence})
}
try {
 Write-RevelationGameBridgeFile -Path $iniPath -Text ($original.Replace('allowFunctions=0','allowFunctions=1')) -Ini
 if($DialogOnly){$rows=Read-EntryCommand 289;[Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress));exit 0}
 if($MessagesOnly){$rows=Read-EntryCommand 282;[Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress));exit 0}
 $rows=Read-EntryCommand 284
 [Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress))
 $location=@($rows|Where-Object event -eq 'world_map_exit_route')
 $world=@($rows|Where-Object event -eq 'world_map_state')
 if($location.Count -ne 1 -or -not $location[0].classifiers_match){throw 'guild_entry_location_unknown'}
 if($ProbeOnly){exit 0}
 if($location[0].guild_space -eq 1){Write-Output 'GUILD_BASE_ALREADY_PRESENT';exit 0}
 if($world.Count -ne 1 -or -not $world[0].in_world -or $world[0].life -ne $world[0].life_alive -or $world[0].combat -ne 0 -or $world[0].modal -ne 0 -or $world[0].loaded -ne 1){throw 'guild_entry_world_busy'}
 $rows=Read-EntryCommand 230
 [Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress))
 $rows=Read-EntryCommand 231
 [Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress))
 Write-Output 'GUILD_BASE_TELEPORT_SUBMITTED'
} finally {
 if((Get-RevelationGameBridgeIni -Path $iniPath)['nonce'] -eq $session.nonce){Write-RevelationGameBridgeFile -Path $iniPath -Text $original -Ini}
}
