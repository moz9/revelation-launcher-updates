param([Parameter(Mandatory=$true)][string]$LauncherRoot,[Parameter(Mandatory=$true)][string]$GameRoot,[Parameter(Mandatory=$true)][string]$ExpectedModulePath,[int]$GameProcessId,[ValidateSet(380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404)][int]$Command=380,[switch]$AllowRegroupScroll,[switch]$AllowGuildMaterialPurchase,[switch]$AllowGuildAnnouncement,[switch]$AllowGuildQuestItemNpc,[int]$ExpectedQuestItemId=0,[int]$ExpectedTargetNpcId=0,[int]$ExpectedLotId=0,[int]$PurchaseQuantity=0,[int]$MaxPurchasePrice=0,[long]$ExpectedQuestId=-1,[string]$ExpectedObjectiveKey="")
$ErrorActionPreference='Stop'
if($AllowGuildQuestItemNpc -and ($Command -notin @(389,390,403) -or $ExpectedQuestId -le 0 -or $ExpectedQuestItemId -le 0 -or $ExpectedTargetNpcId -le 0)){throw 'guild_item_npc_scope_required'}
if($Command -eq 403 -and -not $AllowGuildQuestItemNpc){throw 'guild_item_npc_opt_in_required'}
if($AllowGuildAnnouncement -and ($Command -notin @(389,390,391) -or $ExpectedQuestId -le 0)){throw 'guild_announcement_scope_required'}
if($Command -in @(400,401,402) -and (-not $AllowGuildMaterialPurchase -or $ExpectedQuestId -le 0 -or $ExpectedLotId -le 0 -or $PurchaseQuantity -le 0 -or $MaxPurchasePrice -le 0)){throw 'guild_purchase_explicit_quote_required'}
if($Command -eq 386 -and -not $AllowRegroupScroll){throw 'guild_scroll_opt_in_required'}
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
trap{[Console]::Error.WriteLine($_.Exception.Message);exit 1}
. (Join-Path $LauncherRoot 'RevelationLicense.ps1')
$license=New-LicenseStatusPayload -LauncherRoot $LauncherRoot
if(-not($license['allowRuntime'] -eq $true -and ([string]$license['licenseType']) -ieq 'developer')){throw 'guild_developer_license_required'}
. (Join-Path $LauncherRoot 'tools\RevelationGameBridge.ps1')
$definition=(Get-Command Send-RevelationGameBridgeCommandUnlocked).Definition
$allow='@(0, 1, 2, 21, 110, 300, 301, 302, 303, 304, 305, 306)'
$terminal="switch (`$Command) { 0 { 'state_probe' }"
if(-not $definition.Contains($allow) -or -not $definition.Contains($terminal)){throw 'guild_transport_contract_changed'}
$definition=$definition.Replace($allow,'@(0, 1, 2, 21, 110, 300, 301, 302, 303, 304, 305, 306, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404)').Replace($terminal,"switch (`$Command) { 380 { 'guild_quest_state' } 381 { 'guild_quest_route_sent' } 382 { 'guild_quest_menu_opened' } 383 { 'guild_quest_selected' } 384 { 'guild_quest_accept_sent' } 385 { 'guild_entry_state' } 386 { 'guild_scroll_confirm_sent' } 387 { 'guild_dismount_sent' } 388 { 'quest_checkpoint_sent' } 389 { 'guild_progress_state' } 390 { 'guild_progress_route_sent' } 391 { 'guild_progress_interaction_sent' } 392 { 'guild_progress_menu_opened' } 393 { 'guild_progress_submit_sent' } 394 { 'guild_puzzle_answer_sent' } 395 { 'guild_progress_stopped' } 396 { 'guild_combat_step_complete' } 397 { 'guild_monster_interaction_sent' } 398 { 'guild_auction_open_sent' } 399 { 'guild_auction_search_sent' } 400 { 'guild_purchase_preview_sent' } 401 { 'guild_purchase_confirm_sent' } 402 { 'guild_password_submit_sent' } 403 { 'guild_quest_item_step_complete' } 404 { 'guild_treat_step_complete' } 0 { 'state_probe' }")
Set-Item Function:Send-RevelationGameBridgeCommandUnlocked ([scriptblock]::Create($definition))
$session=Get-RevelationGameBridgeSession -LauncherRoot $LauncherRoot -GameDir (Join-Path $GameRoot 'game')
if(-not $session){throw 'guild_session_missing'}
$expected=(Get-FileHash -LiteralPath $ExpectedModulePath -Algorithm SHA256).Hash
if($session.bridgeHash -ne $expected){throw 'guild_probe_not_loaded'}
if(-not $GameProcessId){$targets=@(Get-RevelationGameBridgeProcesses -GameDir $session.gameDir);if($targets.Count -ne 1){throw 'guild_requires_one_client'};$GameProcessId=$targets[0].Id}
$purchasePath=$null
$announcementPath=$null
$itemNpcPath=$null
try {
 if($AllowGuildQuestItemNpc){$itemNpcPath=Join-Path $session.sessionRoot 'guild-item-npc.ini';Write-RevelationGameBridgeFile -Path $itemNpcPath -Text "[item]`r`npid=$GameProcessId`r`nquest=$ExpectedQuestId`r`nitem=$ExpectedQuestItemId`r`nnpc=$ExpectedTargetNpcId`r`n" -Ini}
 if($AllowGuildAnnouncement){$announcementPath=Join-Path $session.sessionRoot 'guild-announcement.ini';Write-RevelationGameBridgeFile -Path $announcementPath -Text "[announcement]`r`npid=$GameProcessId`r`nquest=$ExpectedQuestId`r`n" -Ini}
 if($Command -notin @(380,385,389)){
   $fresh=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command $(if($Command -ge 390){389}elseif($Command -ge 386){385}else{380})
   if($Command -ge 390 -and ($ExpectedQuestId -ge 0 -or $ExpectedObjectiveKey)){
     $plannedRows=@(Get-RevelationGameBridgeEvents -Session $session -TailBytes 131072|Where-Object{[int]$_.pid -eq $GameProcessId -and [int]$_.sequence -eq $fresh.sequence})
     $plannedState=@($plannedRows|Where-Object event -eq 'quest_task_state')
     if($plannedState.Count -ne 1 -or -not $plannedState[0].valid -or ($ExpectedQuestId -ge 0 -and $plannedState[0].questId -ne $ExpectedQuestId)){throw 'guild_planned_quest_changed'}
     # The fresh read must validate execution readiness as well as the goal.
     # Stop (395) must remain available while moving.
     if($Command -ne 395 -and (-not $plannedState[0].inWorld -or -not $plannedState[0].alive -or $plannedState[0].busy)){throw 'guild_planned_state_busy'}
     if($ExpectedObjectiveKey -ceq 'turnin'){
       if(-not $plannedState[0].turnInReady -or $Command -notin @(390,392,393)){throw 'guild_planned_turnin_changed'}
     }elseif($ExpectedObjectiveKey){
       $plannedGoal=@($plannedRows|Where-Object{ $_.event -eq 'quest_task_objective' -and $_.key -ceq $ExpectedObjectiveKey })
       if($plannedGoal.Count -ne 1 -or -not $plannedGoal[0].actionable -or $plannedGoal[0].state -ne 'pending'){throw 'guild_planned_objective_changed'}
       if($Command -eq 390 -and ($plannedGoal[0].kind -notin @('marker','combat','object','item') -or $plannedGoal[0].seekId -le 0)){throw 'guild_planned_route_mismatch'}
       if($Command -eq 391 -and ($plannedGoal[0].kind -ne 'marker' -or -not $plannedGoal[0].ready)){throw 'guild_planned_marker_not_ready'}
       if($Command -eq 397 -and ($plannedGoal[0].kind -ne 'object' -or -not $plannedGoal[0].ready)){throw 'guild_planned_object_not_ready'}
       if($Command -eq 404 -and ($plannedGoal[0].kind -ne 'treat' -or -not $plannedGoal[0].ready)){throw 'guild_planned_treat_not_ready'}
       if($Command -eq 403 -and ($plannedGoal[0].kind -ne 'item' -or -not $plannedGoal[0].ready)){throw 'guild_planned_item_not_ready'}
       if($Command -eq 396 -and ($plannedGoal[0].kind -ne 'combat' -or -not $plannedGoal[0].ready)){throw 'guild_planned_combat_not_ready'}
       if($Command -eq 394 -and ($plannedGoal[0].kind -ne 'puzzle' -or -not $plannedGoal[0].ready)){throw 'guild_planned_puzzle_not_ready'}
     }
   }
   Set-RevelationGameBridgeArm -Session $session -AllowEnter:$session.skipCharacterSelection -AllowCombatMove $true -AllowCombatTest:($Command -eq 396)
   if($Command -in @(400,401,402)){
     $purchasePath=Join-Path $session.sessionRoot 'guild-purchase.ini'
     $purchaseText="[purchase]`r`npid=$GameProcessId`r`nquest=$ExpectedQuestId`r`nlot=$ExpectedLotId`r`nquantity=$PurchaseQuantity`r`nmaxPrice=$MaxPurchasePrice`r`n"
     Write-RevelationGameBridgeFile -Path $purchasePath -Text $purchaseText -Ini
   }
 }
 $ack=Send-RevelationGameBridgeCommand -Session $session -GameProcessId $GameProcessId -Command $Command
} finally {if($itemNpcPath -and (Test-Path -LiteralPath $itemNpcPath)){Remove-Item -LiteralPath $itemNpcPath};if($announcementPath -and (Test-Path -LiteralPath $announcementPath)){Remove-Item -LiteralPath $announcementPath};if($purchasePath -and (Test-Path -LiteralPath $purchasePath)){Remove-Item -LiteralPath $purchasePath};if($Command -notin @(380,385,389)){Set-RevelationGameBridgeArm -Session $session -AllowEnter:$session.skipCharacterSelection}}
$rows=@(Get-RevelationGameBridgeEvents -Session $session -TailBytes 131072|Where-Object{[int]$_.pid -eq $GameProcessId -and [int]$_.sequence -eq $ack.sequence})
$rows += [pscustomobject]@{event="guild_transport_context";gamePid=$GameProcessId;sessionRoot=$session.sessionRoot}
[Console]::WriteLine((ConvertTo-Json -InputObject @($rows) -Depth 8 -Compress))



