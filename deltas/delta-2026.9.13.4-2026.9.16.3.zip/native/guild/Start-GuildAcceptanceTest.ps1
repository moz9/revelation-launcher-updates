param([Parameter(Mandatory=$true)][string]$LauncherRoot,[Parameter(Mandatory=$true)][string]$GameRoot,[Parameter(Mandatory=$true)][string]$ExpectedModulePath,[int]$GameProcessId,[Parameter(Mandatory=$true)][int]$ExpectedPlayerId)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$log=Join-Path $PSScriptRoot ('guild-live-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.jsonl')
$stopFile=Join-Path $PSScriptRoot 'stop.request'
$commandPath=Join-Path $PSScriptRoot 'GuildCommand.ps1'
function Read-GuildCommand([int]$number){
 if(Test-Path -LiteralPath $stopFile){throw 'guild_test_stopped'}
 $args=@('-NoProfile','-ExecutionPolicy','RemoteSigned','-File',$commandPath,'-LauncherRoot',$LauncherRoot,'-GameRoot',$GameRoot,'-ExpectedModulePath',$ExpectedModulePath,'-Command',[string]$number)
 if($GameProcessId){$args+=@('-GameProcessId',[string]$GameProcessId)}
 $raw=& powershell.exe @args 2>&1
 $exit=$LASTEXITCODE
 @{utc=[DateTime]::UtcNow.ToString('o');command=$number;exitCode=$exit;output=($raw -join "`n")}|ConvertTo-Json -Depth 8 -Compress|Add-Content -LiteralPath $log -Encoding UTF8
 if($exit -ne 0){throw ('guild_command_'+$number+'_failed: '+($raw -join "`n"))}
 $rows=($raw -join "`n")|ConvertFrom-Json
 if($number -eq 380){
   $state=@($rows|Where-Object event -eq 'guild_quest_state')
   if($state.Count -ne 1 -or $state[0].playerId -ne $ExpectedPlayerId){throw 'guild_character_identity_changed'}
   $membership=@($rows|Where-Object event -eq 'guild_character_membership')
   if($membership.Count -ne 1 -or -not $membership[0].readValid){throw 'guild_membership_unknown'}
   $state[0]|Add-Member NoteProperty guildMember ([bool]$membership[0].member) -Force
   $state[0]|Add-Member NoteProperty mapId ([int]$membership[0].mapId) -Force
   return $state[0]
 }
 return $rows
}
try {
 $state=Read-GuildCommand 380
 if(-not $state.guildMember){Write-Output 'GUILD_NOT_MEMBER';exit 0}
 if($state.mapId -ne 90){Write-Output 'GUILD_BASE_ENTRY_REQUIRED';exit 0}
 if($state.currentQuestId -gt 0){Write-Output ('ACTIVE_GUILD_QUEST '+$state.currentQuestId);exit 0}
 if($state.maximumLoops -gt 0 -and $state.loopCount -ge $state.maximumLoops){Write-Output 'GUILD_DAILY_ALREADY_COMPLETED';exit 0}
 if(-not($state.loopAbsent -or ($state.loopKnown -and $state.currentReadValid -and $state.currentEmpty))){throw 'guild_current_state_unknown'}
 if($state.inCombat -ne 0 -or $state.moving -ne 0){throw 'guild_character_busy'}
 if(-not($state.npcVisible -and $state.npcId -eq 70246)){
   Read-GuildCommand 381|Out-Null
   $deadline=(Get-Date).AddSeconds(90)
   do{Start-Sleep -Seconds 2;$state=Read-GuildCommand 380;if($state.inCombat -ne 0){throw 'guild_route_entered_combat'};if($state.npcVisible -and $state.npcId -eq 70246 -and $state.moving -eq 0){break}}while((Get-Date) -lt $deadline)
   if(-not($state.npcVisible -and $state.npcId -eq 70246 -and $state.moving -eq 0)){throw 'guild_npc_route_unconfirmed'}
 }
 if($state.offeredMatches -ne 1 -and $state.taskOptionIndex -ge 0){Read-GuildCommand 382|Out-Null;Start-Sleep -Milliseconds 600;$state=Read-GuildCommand 380}
 if($state.offeredMatches -ne 1){Write-Output ('GUILD_OFFER_UNAVAILABLE matches='+$state.offeredMatches);exit 0}
 Read-GuildCommand 383|Out-Null
 $state=Read-GuildCommand 380
 Read-GuildCommand 384|Out-Null
 $deadline=(Get-Date).AddSeconds(20)
 do{Start-Sleep -Seconds 1;$state=Read-GuildCommand 380;if($state.currentQuestId -gt 0){Write-Output ('GUILD_ACCEPT_CONFIRMED questId='+$state.currentQuestId);exit 0}}while((Get-Date) -lt $deadline)
 throw 'guild_accept_result_unconfirmed_no_replay'
} catch {[Console]::Error.WriteLine($_.Exception.Message);exit 1}
