function Get-TowerSkipCharacterSelection([string]$LauncherRoot) {
    $path = Join-Path $LauncherRoot '.revelation-combat\launcher-settings.ini'
    $value = ''
    if (Test-Path -LiteralPath $path) {
        foreach ($line in [IO.File]::ReadAllLines($path)) {
            if ($line -match '^\s*skipCharacterSelection\s*=\s*(.*?)\s*$') { $value = $matches[1] }
        }
    }
    return [int]($value -eq '1')
}
function Get-TowerProcessPath($Process) {
    if (-not ('TowerProcessImage' -as [type])) {
        Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class TowerProcessImage {
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr handle,uint flags,StringBuilder path,ref uint size);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    public static string Read(int pid) {
        var handle=OpenProcess(0x1000,false,pid);
        if(handle==IntPtr.Zero)return null;
        try {uint size=32768;var path=new StringBuilder((int)size);return QueryFullProcessImageName(handle,0,path,ref size)?path.ToString():null;}
        finally {CloseHandle(handle);}
    }
}
'@
    }
    return [TowerProcessImage]::Read([int]$Process.Id)
}
function Get-TowerDigest([string]$Path) {
    if(-not(Test-Path -LiteralPath $Path)){return ''}
    $stream=[IO.File]::OpenRead($Path);$hash=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-','')}
    finally{$hash.Dispose();$stream.Dispose()}
}
function Write-TowerText([string]$Path,[string]$Text,[switch]$Ini) {
    $temp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    $encoding=if($Ini){[Text.Encoding]::Unicode}else{[Text.UTF8Encoding]::new($false)}
    [IO.File]::WriteAllText($temp,$Text,$encoding)
    $deadline=[DateTime]::UtcNow.AddSeconds(1)
    try {
        while($true) {
            try {
                if(Test-Path -LiteralPath $Path){[IO.File]::Replace($temp,$Path,[NullString]::Value)}else{[IO.File]::Move($temp,$Path)}
                break
            } catch [IO.IOException] {if([DateTime]::UtcNow -ge $deadline){throw};Start-Sleep -Milliseconds 25}
        }
    } finally {if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp}}
}
function Restore-TowerFile([string]$Path,[string]$Backup,[string]$OriginalHash,[string]$CandidateHash) {
    if($OriginalHash -and (Get-TowerDigest $Backup)-ne $OriginalHash){throw 'Backup hash mismatch; files preserved.'}
    $current=Get-TowerDigest $Path
    if($current -eq $OriginalHash){return}
    if($current -ne $CandidateHash){throw 'Unknown file preserved; automatic restore stopped.'}
    if($OriginalHash){Copy-Item -LiteralPath $Backup -Destination $Path -Force}else{Remove-Item -LiteralPath $Path}
    if((Get-TowerDigest $Path)-ne $OriginalHash){throw 'Restore verification failed.'}
}
