param(
    [Parameter(Mandatory=$true)][string]$LauncherRoot,
    [string]$GameRoot,
    [ValidateSet('LaunchGame','RelogGame','FastRelogGame','ExitGame','SaveGpuProfileSettings','ApplyGpuProfileSettings','NetworkApply','NetworkRestore')][string]$Action,
    [ValidateSet('normal','quick','full_log','pvp_safe','pvp_aggressive')][string]$Mode='normal',
    [Parameter(Mandatory=$true)][string]$ResultPath,
    [ValidateSet('off','auto','manual')][string]$GpuFpsCapMode='off',
    [ValidateRange(0,500)][int]$GpuManualFpsCap=0,
    [string]$NvidiaProfileInspectorPath='',
    [ValidateSet('true','false')][string]$NvidiaRecommendedPresetEnabled='false',
    [ValidateSet('true','false')][string]$Staged='false'
)
$ErrorActionPreference='Stop'
$env:REVELATION_GAME_ROOT=$GameRoot
$env:REVELATION_GAME_MODULE_DIR=$PSScriptRoot
try {
    $invoke=@{LauncherRoot=$LauncherRoot}
    switch($Action){
        'SaveGpuProfileSettings' {$invoke.GpuFpsCapMode=$GpuFpsCapMode;$invoke.GpuManualFpsCap=$GpuManualFpsCap;$invoke.NvidiaProfileInspectorPath=$NvidiaProfileInspectorPath;$invoke.NvidiaRecommendedPresetEnabled=$NvidiaRecommendedPresetEnabled}
        'NetworkApply' {$invoke.Staged=$Staged}
        {$_ -in @('LaunchGame','RelogGame','FastRelogGame')} {$invoke.Mode=$Mode}
    }
    $bridgePath=if($Action -eq 'ExitGame'){Join-Path (Split-Path -Parent $PSScriptRoot) 'ExitBridge.ps1'}else{Join-Path $LauncherRoot 'RevelationGuiBridge.ps1'}
    $reply=& $bridgePath $Action @invoke
    $text=$reply -join [Environment]::NewLine
    [void]($text|ConvertFrom-Json)
    [IO.File]::WriteAllText($ResultPath,$text,[Text.UTF8Encoding]::new($false))
}catch{
    [IO.File]::WriteAllText($ResultPath,(@{ok=$false;error=$_.Exception.Message}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    exit 1
}
