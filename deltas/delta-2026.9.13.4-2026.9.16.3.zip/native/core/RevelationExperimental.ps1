param(
    [Parameter(Position = 0)]
    [ValidateSet("Launch", "Help")]
    [string]$Action = "Launch",

    [string]$GameDir,
    [string]$LauncherRoot,
    [switch]$EnableAffinityAuto,
    [switch]$RunNetExperiment,
    [int]$WatchSec = 900,
    [int]$PollSec = 3
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Ensure-Directory {
    param([string]$Path)
    if ($Path -and (-not (Test-Path -LiteralPath $Path))) {
        New-Item -ItemType Directory -Path $Path | Out-Null
    }
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Read-KeyValueFile {
    param([string]$Path)
    $map = @{}
    if (-not (Test-Path -LiteralPath $Path)) {
        return $map
    }
    foreach ($line in (Get-Content -LiteralPath $Path -ErrorAction Stop)) {
        $text = [string]$line
        $index = $text.IndexOf("=")
        if ($index -le 0) { continue }
        $map[$text.Substring(0, $index).Trim()] = $text.Substring($index + 1)
    }
    return $map
}

function Get-ConfiguredGameRootFromLauncher {
    param([string]$ResolvedLauncherRoot)
    $configPath = Join-Path $ResolvedLauncherRoot "launcher-config.ini"
    $map = Read-KeyValueFile -Path $configPath
    if ($map.ContainsKey("gameRoot") -and $map["gameRoot"]) {
        return [string]$map["gameRoot"]
    }
    return ""
}

function Get-ResolvedGameRoot {
    param([string]$ConfiguredGameDir, [string]$ResolvedLauncherRoot)
    $candidatePath = $ConfiguredGameDir
    if (-not $candidatePath) {
        $candidatePath = Get-ConfiguredGameRootFromLauncher -ResolvedLauncherRoot $ResolvedLauncherRoot
    }
    if (-not $candidatePath) {
        $candidatePath = $ResolvedLauncherRoot
    }

    $resolved = (Resolve-Path -LiteralPath $candidatePath).Path
    if (Test-Path -LiteralPath (Join-Path $resolved "game\\tianyu.exe")) {
        return $resolved
    }
    if (Test-Path -LiteralPath (Join-Path $resolved "tianyu.exe")) {
        return (Split-Path -Parent $resolved)
    }
    throw "Could not determine Revelation root from path: $candidatePath"
}

function Get-ResolvedGameDir {
    param([string]$ResolvedGameRoot)
    $gameDir = Join-Path $ResolvedGameRoot "game"
    if (-not (Test-Path -LiteralPath (Join-Path $gameDir "tianyu.exe"))) {
        throw "Game directory not found: $ResolvedGameRoot"
    }
    return $gameDir
}

$script:LogPath = ""
function Init-Log {
    param([string]$ResolvedLauncherRoot, [string]$ResolvedGameRoot)
    $stateDir = Join-Path $ResolvedLauncherRoot ".revelation-combat"
    Ensure-Directory -Path $stateDir
    $script:LogPath = Join-Path $stateDir "experimental-last.log"
    Set-Content -LiteralPath $script:LogPath -Encoding UTF8 -Value @(
        ("[{0}] RevelationExperimental start" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
        ("LauncherRoot={0}" -f $ResolvedLauncherRoot)
        ("GameRoot={0}" -f $ResolvedGameRoot)
        ("EnableAffinityAuto={0}" -f [bool]$EnableAffinityAuto)
        ("RunNetExperiment={0}" -f [bool]$RunNetExperiment)
    )
}

function Write-ExpLog {
    param([string]$Message)
    Write-Host "[RevelationExperimental] $Message"
    if ($script:LogPath) {
        Add-Content -LiteralPath $script:LogPath -Encoding UTF8 -Value ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message)
    }
}

function Start-NetExperimentBackground {
    param([string]$ResolvedGameRoot, [string]$ResolvedLauncherRoot)
    $scriptPath = Join-Path $ResolvedLauncherRoot "RevelationNetExperiment.ps1"
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        Write-ExpLog "RevelationNetExperiment.ps1 not found, skipping."
        return
    }
    $args = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", $scriptPath,
        "Run",
        "-GameDir", $ResolvedGameRoot,
        "-LauncherRoot", $ResolvedLauncherRoot,
        "-Profile", "tierb-netease",
        "-GraceAfterReadySec", "20",
        "-ExperimentDurationSec", "180"
    )
    Start-Process -FilePath "powershell.exe" -ArgumentList $args -WindowStyle Hidden | Out-Null
    Write-ExpLog "Background NetExperiment started (tierb-netease, 180s)."
}

function Get-AffinityMaskAuto {
    # Experimental heuristic only:
    # use lower half of logical CPUs (often maps to P-cores first on many systems).
    $logical = [int]$env:NUMBER_OF_PROCESSORS
    if ($logical -lt 8) { return [UInt64]0 }
    if ($logical -gt 64) { $logical = 64 }
    $half = [math]::Floor($logical / 2)
    if ($half -lt 4) { return [UInt64]0 }
    return ([UInt64]1 -shl $half) - 1
}

function Wait-And-TuneGameProcess {
    param([int]$TimeoutSec, [int]$PollSeconds, [switch]$ApplyAffinity)
    $deadline = (Get-Date).AddSeconds([math]::Max(30, $TimeoutSec))
    $poll = [math]::Max(1, $PollSeconds)
    $tuned = $false
    while ((Get-Date) -lt $deadline) {
        $proc = Get-Process -Name "tianyu" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($proc) {
            if (-not $tuned) {
                try {
                    if ($proc.PriorityClass -ne "High") {
                        $proc.PriorityClass = "High"
                        Write-ExpLog ("Set priority High for PID={0}" -f $proc.Id)
                    } else {
                        Write-ExpLog ("Priority already High for PID={0}" -f $proc.Id)
                    }
                } catch {
                    Write-ExpLog ("Failed to set priority: " + $_.Exception.Message)
                }

                if ($ApplyAffinity) {
                    try {
                        $mask = Get-AffinityMaskAuto
                        if ($mask -ne 0) {
                            $proc.ProcessorAffinity = [IntPtr]$mask
                            Write-ExpLog ("Applied affinity mask 0x{0:X}" -f $mask)
                        } else {
                            Write-ExpLog "Affinity auto mask skipped (too few CPUs / unsupported)."
                        }
                    } catch {
                        Write-ExpLog ("Failed to set affinity: " + $_.Exception.Message)
                    }
                }
                $tuned = $true
            }

            try {
                $est = @(
                    Get-NetTCPConnection -OwningProcess $proc.Id -State Established -ErrorAction SilentlyContinue |
                        ForEach-Object { "{0}:{1}" -f $_.RemoteAddress, $_.RemotePort }
                )
                Write-ExpLog ("PID={0} MemMB={1} Established=[{2}]" -f $proc.Id, [math]::Round($proc.WorkingSet64/1MB), ($est -join ", "))
            } catch {
                Write-ExpLog ("Connection snapshot failed: " + $_.Exception.Message)
            }
        } else {
            if ($tuned) {
                Write-ExpLog "tianyu.exe exited. Watch finished."
                return
            }
        }

        Start-Sleep -Seconds $poll
    }
    Write-ExpLog "Watch timeout reached."
}

try {
    if ($Action -eq "Help") {
        Write-Host "Usage:"
        Write-Host "  .\RevelationExperimental.ps1 Launch"
        Write-Host "  .\RevelationExperimental.ps1 Launch -EnableAffinityAuto"
        Write-Host "  .\RevelationExperimental.ps1 Launch -EnableAffinityAuto -RunNetExperiment"
        exit 0
    }

    if (-not (Test-IsAdministrator)) {
        throw "Administrator rights required."
    }

    $resolvedLauncherRoot = if ($LauncherRoot) { (Resolve-Path -LiteralPath $LauncherRoot).Path } else { $PSScriptRoot }
    $resolvedGameRoot = Get-ResolvedGameRoot -ConfiguredGameDir $GameDir -ResolvedLauncherRoot $resolvedLauncherRoot
    $resolvedGameDir = Get-ResolvedGameDir -ResolvedGameRoot $resolvedGameRoot
    Init-Log -ResolvedLauncherRoot $resolvedLauncherRoot -ResolvedGameRoot $resolvedGameRoot

    $combatScript = Join-Path $resolvedLauncherRoot "RevelationCombat.ps1"
    if (-not (Test-Path -LiteralPath $combatScript)) {
        throw "RevelationCombat.ps1 not found."
    }

    Write-ExpLog "Launching standard safe combat flow first..."
    & $combatScript -Action Launch -GameDir $resolvedGameRoot -LauncherRoot $resolvedLauncherRoot -Silent

    if ($RunNetExperiment) {
        Start-NetExperimentBackground -ResolvedGameRoot $resolvedGameRoot -ResolvedLauncherRoot $resolvedLauncherRoot
    }

    Write-ExpLog ("Watching game process for up to {0}s..." -f $WatchSec)
    Wait-And-TuneGameProcess -TimeoutSec $WatchSec -PollSeconds $PollSec -ApplyAffinity:$EnableAffinityAuto
    Write-ExpLog "Experimental launch finished."
    exit 0
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
