# RevelationCaptureNetworkAnalysis.ps1
# Experimental post-capture network analyzer.
# Invoked from RevelationCapture.ps1 after Stop-NetworkCapture.
# Produces diagnostic artifacts alongside the capture:
#   network-peers.csv       - every remote IP seen, with category/owner, packets, bytes, top ports
#   network-buckets.csv     - traffic rollup by Gameplay/RemotePlay/Background bucket
#   game-rx-gap.csv         - primary-shard gap percentiles and active/transition counters
#   game-rx-stalls.csv      - active RX gaps > 500 ms, with timestamp and surrounding context
#   game-shard.txt          - detected game shard (ip:port) for this player
#   network-analysis.log    - log of this pass
#
# No changes to existing files, no changes to capture behavior.
# Safe to skip if tshark is missing.

$ErrorActionPreference = 'Stop'

$script:NetAnalyzeInvCulture = [System.Globalization.CultureInfo]::InvariantCulture
$script:NetAnalyzeNumStyle   = [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands

function Parse-NetAnalyzeDouble {
    param([string]$Value, [ref]$Out)
    return [double]::TryParse($Value, $script:NetAnalyzeNumStyle, $script:NetAnalyzeInvCulture, $Out)
}

function Parse-NetAnalyzeInt {
    param([string]$Value, [ref]$Out)
    return [int]::TryParse($Value, [System.Globalization.NumberStyles]::Integer, $script:NetAnalyzeInvCulture, $Out)
}

$script:NetAnalyzeCapturePathCandidates = @(
    'C:\Program Files\Wireshark\tshark.exe',
    'C:\Program Files (x86)\Wireshark\tshark.exe',
    (Join-Path $env:ProgramFiles 'Wireshark\tshark.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Wireshark\tshark.exe')
)

function Find-NetAnalyzeTshark {
    foreach ($p in $script:NetAnalyzeCapturePathCandidates) {
        if ($p -and (Test-Path -LiteralPath $p)) { return $p }
    }
    $cmd = Get-Command tshark.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Write-NetAnalyzeLog {
    param([string]$Path, [string]$Message)
    try {
        $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
        Add-Content -LiteralPath $Path -Value $line -Encoding UTF8
    } catch {}
}

function Classify-NetAnalyzeIp {
    param([string]$ip)
    if ($ip -match '^92\.38\.245\.')                                     { return @{ Kind='GAME';          Owner='VKP_game_server_tianyu' } }
    if ($ip -match '^92\.38\.244\.')                                     { return @{ Kind='ANTICHEAT';     Owner='VKP_anticheat_astrum' } }
    if ($ip -match '^42\.186\.')                                         { return @{ Kind='CHINA_NETEASE'; Owner='NetEase_cn' } }
    if ($ip -match '^45\.253\.170\.')                                    { return @{ Kind='CHINA_NETEASE'; Owner='NetEase_cn_string' } }
    if ($ip -match '^195\.211\.130\.')                                   { return @{ Kind='CHINA_NOACK';   Owner='NoAck_8989' } }
    if ($ip -match '^77\.88\.')                                          { return @{ Kind='JUNK_YANDEX';   Owner='Yandex' } }
    if ($ip -match '^87\.250\.')                                         { return @{ Kind='JUNK_YANDEX';   Owner='Yandex' } }
    if ($ip -match '^213\.180\.')                                        { return @{ Kind='JUNK_YANDEX';   Owner='Yandex' } }
    if ($ip -match '^95\.108\.')                                         { return @{ Kind='JUNK_YANDEX';   Owner='Yandex' } }
    if ($ip -match '^87\.240\.')                                         { return @{ Kind='JUNK_VK';       Owner='VK' } }
    if ($ip -match '^95\.163\.')                                         { return @{ Kind='JUNK_MAILRU';   Owner='MailRu_VKPlayCloud' } }
    if ($ip -match '^217\.69\.')                                         { return @{ Kind='JUNK_MAILRU';   Owner='MailRu' } }
    if ($ip -match '^90\.156\.')                                         { return @{ Kind='JUNK_MAILRU';   Owner='MailRu' } }
    if ($ip -match '^89\.221\.')                                         { return @{ Kind='JUNK_MAILRU';   Owner='MailRu_VK' } }
    if ($ip -match '^149\.154\.16[0-9]\.' -or $ip -match '^91\.108\.')   { return @{ Kind='MESSENGER';     Owner='Telegram' } }
    if ($ip -match '^155\.133\.')                                        { return @{ Kind='GAMES_OTHER';   Owner='Steam' } }
    if ($ip -match '^13\.107\.')                                         { return @{ Kind='MICROSOFT';     Owner='MS_services' } }
    if ($ip -match '^198\.18\.')                                         { return @{ Kind='PARSEC';        Owner='Parsec_virtual_net' } }
    if ($ip -match '^80\.71\.165\.')                                     { return @{ Kind='META_QUEST';    Owner='MetaQuest_Link' } }
    if ($ip -match '^51\.(75|89|124|83)\.')                              { return @{ Kind='OVH';           Owner='OVH_hosting' } }
    if ($ip -match '^13\.32\.')                                          { return @{ Kind='CDN';           Owner='CloudFront' } }
    if ($ip -match '^104\.(1[68]|2[0-9])\.')                             { return @{ Kind='CDN';           Owner='Cloudflare' } }
    if ($ip -match '^2\.2[2345]\.')                                      { return @{ Kind='CDN';           Owner='Akamai' } }
    if ($ip -match '^23\.(2[12]|3[23])\.')                               { return @{ Kind='CDN';           Owner='Akamai' } }
    if ($ip -match '^93\.186\.237\.')                                    { return @{ Kind='LOGMEIN';       Owner='LogMeIn' } }
    if ($ip -match '^91\.105\.')                                         { return @{ Kind='RU_ISP';        Owner='RuISP' } }
    if ($ip -match '^8\.47\.'  -or $ip -match '^8\.6\.112\.')            { return @{ Kind='CDN';           Owner='Level3_CenturyLink' } }
    if ($ip -match '^185\.223\.94\.')                                    { return @{ Kind='RU_HOST';       Owner='VKPlay_CDN_RU' } }
    if ($ip -match '^(52|54|18|3)\.' -or $ip -match '^34\.(77|107)\.')   { return @{ Kind='CLOUD';         Owner='AWS_GCP' } }
    return @{ Kind='UNKNOWN'; Owner='' }
}

function Get-NetAnalyzePcapFiles {
    param([string]$NetworkDir)
    if (-not $NetworkDir -or -not (Test-Path -LiteralPath $NetworkDir)) { return @() }
    return @(Get-ChildItem -LiteralPath $NetworkDir -Filter 'dumpcap_*.pcapng' -File -ErrorAction SilentlyContinue | Sort-Object Name)
}

function Invoke-NetAnalyzePeerSummary {
    param(
        [Parameter(Mandatory=$true)][string]$TsharkPath,
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$PcapFiles,
        [Parameter(Mandatory=$true)][string]$LogPath
    )
    $ipCounters = @{}
    $udpPortByIp = @{}
    $udpLocalPortByIp = @{}
    $tcpPortByIp = @{}
    $tcpLocalPortByIp = @{}
    $uploadByIp = @{}
    $downloadByIp = @{}
    $firstSeen = @{}
    $lastSeen = @{}
    $fields = @('-T','fields','-e','frame.time_epoch','-e','ip.src','-e','ip.dst','-e','udp.srcport','-e','udp.dstport','-e','tcp.srcport','-e','tcp.dstport','-e','frame.len')
    foreach ($pf in $PcapFiles) {
        Write-NetAnalyzeLog -Path $LogPath -Message ("peer-summary tshark on " + $pf.Name)
        $lines = & $TsharkPath -r $pf.FullName -n @fields 2>$null
        foreach ($ln in $lines) {
            $p = $ln -split "`t"
            if ($p.Count -lt 8) { continue }
            $ts = 0.0
            if (-not (Parse-NetAnalyzeDouble $p[0] ([ref]$ts))) { continue }
            $src = $p[1]; $dst = $p[2]
            if (-not $src -or -not $dst) { continue }
            $remote = $null
            $isOutbound = $false
            if ($src -match '^(192\.168\.|10\.|169\.|172\.(1[6-9]|2[0-9]|3[01])\.|127\.|fe80:|::1)') {
                $remote = $dst
                $isOutbound = $true
            }
            elseif ($dst -match '^(192\.168\.|10\.|169\.|172\.(1[6-9]|2[0-9]|3[01])\.|127\.|fe80:|::1)') {
                $remote = $src
            }
            else { continue }
            if ($remote -match '^(255\.|224\.|239\.|ff0|fe80)' -or $remote -eq '0.0.0.0' -or $remote -eq '::') { continue }
            $len = 0
            [void](Parse-NetAnalyzeInt $p[7] ([ref]$len))
            if (-not $ipCounters.ContainsKey($remote)) {
                $ipCounters[$remote] = @{ Pkts=0; Bytes=0 }
                $udpPortByIp[$remote] = @{}
                $udpLocalPortByIp[$remote] = @{}
                $tcpPortByIp[$remote] = @{}
                $tcpLocalPortByIp[$remote] = @{}
                $uploadByIp[$remote] = 0
                $downloadByIp[$remote] = 0
                $firstSeen[$remote] = $ts
            }
            $ipCounters[$remote].Pkts++
            $ipCounters[$remote].Bytes += $len
            if ($isOutbound) { $uploadByIp[$remote] += $len } else { $downloadByIp[$remote] += $len }
            $lastSeen[$remote] = $ts
            $udpSrc = $p[3]; $udpDst = $p[4]
            $tcpSrc = $p[5]; $tcpDst = $p[6]
            if ($udpSrc -or $udpDst) {
                $port = if ($isOutbound) { $udpDst } else { $udpSrc }
                $localPort = if ($isOutbound) { $udpSrc } else { $udpDst }
                if ($port) {
                    if (-not $udpPortByIp[$remote].ContainsKey($port)) { $udpPortByIp[$remote][$port] = 0 }
                    $udpPortByIp[$remote][$port]++
                }
                if ($localPort) {
                    if (-not $udpLocalPortByIp[$remote].ContainsKey($localPort)) { $udpLocalPortByIp[$remote][$localPort] = 0 }
                    $udpLocalPortByIp[$remote][$localPort]++
                }
            } elseif ($tcpSrc -or $tcpDst) {
                $port = if ($isOutbound) { $tcpDst } else { $tcpSrc }
                $localPort = if ($isOutbound) { $tcpSrc } else { $tcpDst }
                if ($port) {
                    if (-not $tcpPortByIp[$remote].ContainsKey($port)) { $tcpPortByIp[$remote][$port] = 0 }
                    $tcpPortByIp[$remote][$port]++
                }
                if ($localPort) {
                    if (-not $tcpLocalPortByIp[$remote].ContainsKey($localPort)) { $tcpLocalPortByIp[$remote][$localPort] = 0 }
                    $tcpLocalPortByIp[$remote][$localPort]++
                }
            }
        }
    }
    $rows = foreach ($ip in $ipCounters.Keys) {
        $cnt = $ipCounters[$ip]
        $udpTop = ($udpPortByIp[$ip].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { "$($_.Key):$($_.Value)" }) -join ','
        $udpLocalTop = ($udpLocalPortByIp[$ip].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { "$($_.Key):$($_.Value)" }) -join ','
        $tcpTop = ($tcpPortByIp[$ip].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { "$($_.Key):$($_.Value)" }) -join ','
        $tcpLocalTop = ($tcpLocalPortByIp[$ip].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { "$($_.Key):$($_.Value)" }) -join ','
        $cls = Classify-NetAnalyzeIp $ip
        [pscustomobject]@{
            RemoteIP      = $ip
            Kind          = $cls.Kind
            Owner         = $cls.Owner
            Bucket        = ''
            Pkts          = $cnt.Pkts
            Bytes         = $cnt.Bytes
            KB            = [math]::Round($cnt.Bytes / 1024, 1)
            UpKB          = [math]::Round($uploadByIp[$ip] / 1024, 1)
            DownKB        = [math]::Round($downloadByIp[$ip] / 1024, 1)
            DurSec        = [math]::Round($lastSeen[$ip] - $firstSeen[$ip], 1)
            UdpPortsTop3  = $udpTop
            LocalUdpPortsTop3 = $udpLocalTop
            TcpPortsTop3  = $tcpTop
            LocalTcpPortsTop3 = $tcpLocalTop
            LikelyLocalUdpOwners = ''
        }
    }
    return @($rows | Sort-Object Pkts -Descending)
}

function Get-NetAnalyzeObjectProperty {
    param(
        [object]$Object,
        [string]$Name,
        [object]$Default = $null
    )
    if ($null -eq $Object) { return $Default }
    $prop = $Object.PSObject.Properties[$Name]
    if (-not $prop) { return $Default }
    if ($null -eq $prop.Value) { return $Default }
    return $prop.Value
}

function Get-NetAnalyzePeerBucket {
    param([object]$Peer)
    $kind = [string](Get-NetAnalyzeObjectProperty -Object $Peer -Name 'Kind' -Default '')
    $udpPorts = [string](Get-NetAnalyzeObjectProperty -Object $Peer -Name 'UdpPortsTop3' -Default '')
    $up = [double](Get-NetAnalyzeObjectProperty -Object $Peer -Name 'UpKB' -Default 0)
    $down = [double](Get-NetAnalyzeObjectProperty -Object $Peer -Name 'DownKB' -Default 0)
    $pkts = [double](Get-NetAnalyzeObjectProperty -Object $Peer -Name 'Pkts' -Default 0)

    if ($kind -in @('GAME', 'ANTICHEAT', 'CHINA_NETEASE', 'CHINA_NETEASE_STRING', 'CHINA_NOACK')) { return 'Gameplay' }
    if ($kind -in @('PARSEC', 'LOGMEIN', 'META_QUEST')) { return 'RemotePlay' }
    if ($kind -in @('JUNK_YANDEX', 'JUNK_VK', 'JUNK_MAILRU')) { return 'LauncherTelemetry' }
    if ($kind -in @('MESSENGER', 'GAMES_OTHER', 'MICROSOFT', 'CDN', 'CLOUD', 'RU_ISP', 'RU_HOST', 'OVH')) { return 'Background' }

    if ($kind -eq 'UNKNOWN' -and $udpPorts -match '(^|,)9000:' -and $pkts -gt 1000 -and $up -gt 1024 -and $up -gt ([math]::Max(1024, $down * 2.0))) {
        return 'RemotePlayCandidate'
    }

    return 'Unknown'
}

function Get-NetAnalyzeTopPortNumbers {
    param([string]$TopPorts)
    if ([string]::IsNullOrWhiteSpace($TopPorts)) { return @() }
    return @(($TopPorts -split ',') | ForEach-Object {
        if ($_ -match '^([^:]+):\d+$') { $matches[1] }
    } | Where-Object { $_ })
}

function Get-NetAnalyzeUdpOwnerMap {
    param([string]$RuntimeDir)
    $path = Join-Path $RuntimeDir 'udp-endpoints-all.csv'
    if (-not (Test-Path -LiteralPath $path)) {
        $path = Join-Path $RuntimeDir 'udp-endpoints.csv'
    }
    if (-not (Test-Path -LiteralPath $path)) { return @{} }

    $byPort = @{}
    try {
        foreach ($row in (Import-Csv -LiteralPath $path)) {
            $port = [string]$row.LocalPort
            if ([string]::IsNullOrWhiteSpace($port)) { continue }
            $procName = [string]$row.ProcessName
            if ([string]::IsNullOrWhiteSpace($procName)) { $procName = 'PID' + [string]$row.OwningProcess }
            $ownerKey = '{0}({1})' -f $procName, [string]$row.OwningProcess
            if (-not $byPort.ContainsKey($port)) { $byPort[$port] = @{} }
            if (-not $byPort[$port].ContainsKey($ownerKey)) { $byPort[$port][$ownerKey] = 0 }
            $byPort[$port][$ownerKey]++
        }
    } catch {
        return @{}
    }

    $map = @{}
    foreach ($port in $byPort.Keys) {
        $map[$port] = (($byPort[$port].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object {
            '{0}:{1}' -f $_.Key, $_.Value
        }) -join '|')
    }
    return $map
}

function Add-NetAnalyzePeerAnnotations {
    param(
        [object[]]$Peers,
        [hashtable]$UdpOwnerMap
    )
    foreach ($peer in @($Peers)) {
        $owners = @()
        foreach ($port in (Get-NetAnalyzeTopPortNumbers -TopPorts ([string]$peer.LocalUdpPortsTop3))) {
            if ($UdpOwnerMap.ContainsKey($port)) {
                $owners += ('{0}->{1}' -f $port, $UdpOwnerMap[$port])
            }
        }
        $peer.Bucket = Get-NetAnalyzePeerBucket $peer
        $peer.LikelyLocalUdpOwners = ($owners | Select-Object -Unique) -join ';'
    }
    return @($Peers)
}

function Get-NetAnalyzeBucketSummary {
    param([object[]]$Peers)
    $groups = @($Peers | Group-Object Bucket)
    foreach ($group in $groups) {
        $rows = @($group.Group)
        $bytes = ($rows | Measure-Object Bytes -Sum).Sum
        $upKb = ($rows | Measure-Object UpKB -Sum).Sum
        $downKb = ($rows | Measure-Object DownKB -Sum).Sum
        $top = ($rows | Sort-Object KB -Descending | Select-Object -First 5 | ForEach-Object {
            '{0}({1},{2}kB,up={3},down={4})' -f $_.RemoteIP, $_.Kind, $_.KB, $_.UpKB, $_.DownKB
        }) -join '|'
        [pscustomobject]@{
            Bucket   = $group.Name
            Peers    = $rows.Count
            Pkts     = ($rows | Measure-Object Pkts -Sum).Sum
            Bytes    = $bytes
            KB       = [math]::Round($bytes / 1024, 1)
            UpKB     = [math]::Round($upKb, 1)
            DownKB   = [math]::Round($downKb, 1)
            TopPeers = $top
        }
    }
}

function Get-NetAnalyzeRxGapSummary {
    param(
        [Parameter(Mandatory=$true)][object[]]$Packets,
        [double]$ActiveContextSeconds = 2.0,
        [int]$ActiveContextMinPackets = 10
    )

    $allPackets = @($Packets | Where-Object {
            $null -ne $_ -and
            -not [string]::IsNullOrWhiteSpace([string]$_.Flow) -and
            $null -ne $_.Timestamp
        })
    $empty = [pscustomobject]@{
        AllRxCount          = $allPackets.Count
        RxCount             = 0
        Shard               = ''
        ShardPkts           = 0
        p50ms               = 0
        p90ms               = 0
        p99ms               = 0
        p99_9ms             = 0
        p99_99ms            = 0
        Maxms               = 0
        ActiveMaxms         = 0
        ObservedOver500ms   = 0
        TransitionOver500ms = 0
        Over500ms           = 0
        Over1000ms          = 0
        Over2000ms          = 0
        Stalls              = @()
    }
    if ($allPackets.Count -lt 2) { return $empty }

    # Different world/login shards can coexist briefly. Mixing their timestamps creates
    # artificial multi-second gaps at handover, so only the busiest concrete flow is timed.
    $topShard = $allPackets | Group-Object Flow | Sort-Object Count -Descending | Select-Object -First 1
    if (-not $topShard -or $topShard.Count -lt 2) { return $empty }

    $sorted = @($topShard.Group | ForEach-Object { [double]$_.Timestamp } | Sort-Object)
    $gapsMs = for ($i = 1; $i -lt $sorted.Count; $i++) {
        ($sorted[$i] - $sorted[$i - 1]) * 1000.0
    }
    $gapsMsArr = @($gapsMs | Sort-Object)
    function _pct([double[]]$arr, [double]$p) {
        if ($arr.Count -eq 0) { return 0 }
        $idx = [math]::Min([math]::Floor($arr.Count * $p), $arr.Count - 1)
        return $arr[$idx]
    }

    $observedOver500 = 0
    $transitionOver500 = 0
    $stalls = @()
    for ($i = 1; $i -lt $sorted.Count; $i++) {
        $gapMs = ($sorted[$i] - $sorted[$i - 1]) * 1000.0
        if ($gapMs -le 500.0) { continue }
        $observedOver500++

        $beforeCount = 0
        for ($j = $i - 1; $j -ge 0 -and $sorted[$j] -ge ($sorted[$i - 1] - $ActiveContextSeconds); $j--) {
            $beforeCount++
        }
        $afterCount = 0
        for ($j = $i; $j -lt $sorted.Count -and $sorted[$j] -le ($sorted[$i] + $ActiveContextSeconds); $j++) {
            $afterCount++
        }

        if ($beforeCount -lt $ActiveContextMinPackets -or $afterCount -lt $ActiveContextMinPackets) {
            $transitionOver500++
            continue
        }

        $stalls += [pscustomobject]@{
            StallStartEpoch     = $sorted[$i - 1]
            StallEndEpoch       = $sorted[$i]
            StallStartUtc       = ([System.DateTimeOffset]::FromUnixTimeMilliseconds([long]($sorted[$i - 1] * 1000))).UtcDateTime
            StallMs             = [math]::Round($gapMs, 1)
            ContextBeforePkts   = $beforeCount
            ContextAfterPkts    = $afterCount
        }
    }

    $activeGaps = @($stalls | ForEach-Object { [double]$_.StallMs })
    return [pscustomobject]@{
        AllRxCount          = $allPackets.Count
        RxCount             = $sorted.Count
        Shard               = [string]$topShard.Name
        ShardPkts           = $sorted.Count
        p50ms               = [math]::Round((_pct $gapsMsArr 0.50), 1)
        p90ms               = [math]::Round((_pct $gapsMsArr 0.90), 1)
        p99ms               = [math]::Round((_pct $gapsMsArr 0.99), 1)
        p99_9ms             = [math]::Round((_pct $gapsMsArr 0.999), 1)
        p99_99ms            = [math]::Round((_pct $gapsMsArr 0.9999), 1)
        Maxms               = [math]::Round(($gapsMsArr | Measure-Object -Maximum).Maximum, 1)
        ActiveMaxms         = $(if ($activeGaps.Count -gt 0) { [math]::Round(($activeGaps | Measure-Object -Maximum).Maximum, 1) } else { 0 })
        ObservedOver500ms   = $observedOver500
        TransitionOver500ms = $transitionOver500
        Over500ms           = $stalls.Count
        Over1000ms          = @($activeGaps | Where-Object { $_ -gt 1000.0 }).Count
        Over2000ms          = @($activeGaps | Where-Object { $_ -gt 2000.0 }).Count
        Stalls              = $stalls
    }
}

function Invoke-NetAnalyzeGameRxGaps {
    param(
        [Parameter(Mandatory=$true)][string]$TsharkPath,
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$PcapFiles,
        [Parameter(Mandatory=$true)][string]$LogPath
    )

    $packets = New-Object System.Collections.Generic.List[object]
    foreach ($pf in $PcapFiles) {
        Write-NetAnalyzeLog -Path $LogPath -Message ("rx-gaps tshark on " + $pf.Name)
        $out = & $TsharkPath -r $pf.FullName -n -Y 'ip.src == 92.38.245.0/24 and udp' -T fields -e frame.time_epoch -e ip.src -e udp.srcport 2>$null
        foreach ($ln in $out) {
            if (-not $ln) { continue }
            $p = $ln -split "`t"
            if ($p.Count -lt 3) { continue }
            $timestamp = 0.0
            if (-not (Parse-NetAnalyzeDouble $p[0] ([ref]$timestamp))) { continue }
            [void]$packets.Add([pscustomobject]@{
                    Timestamp = $timestamp
                    Flow      = $p[1] + ':' + $p[2]
                })
        }
    }

    return Get-NetAnalyzeRxGapSummary -Packets $packets.ToArray()
}

function Invoke-NetAnalyzeBackgroundContextForStalls {
    param(
        [Parameter(Mandatory=$true)][string]$TsharkPath,
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$PcapFiles,
        [Parameter(Mandatory=$true)][object[]]$Stalls,
        [Parameter(Mandatory=$true)][string]$LogPath,
        [double]$WindowSec = 1.0
    )
    if (-not $Stalls -or $Stalls.Count -eq 0) { return @() }
    # Build stall-window list once, sorted by start.
    $windows = @($Stalls | ForEach-Object {
        [pscustomobject]@{
            StartEpoch   = $_.StallStartEpoch - $WindowSec
            EndEpoch     = $_.StallEndEpoch + $WindowSec
            StallStartUtc= $_.StallStartUtc
            StallMs      = $_.StallMs
            ByRemote     = @{}  # remote -> @{ Pkts; Bytes }
        }
    } | Sort-Object StartEpoch)
    $overallMin = ($windows | Measure-Object StartEpoch -Minimum).Minimum
    $overallMax = ($windows | Measure-Object EndEpoch -Maximum).Maximum

    # Single tshark pass per pcap filtering to overall window envelope + non-game traffic.
    $fields = @('-T','fields','-e','frame.time_epoch','-e','ip.src','-e','ip.dst','-e','udp.srcport','-e','udp.dstport','-e','tcp.srcport','-e','tcp.dstport','-e','frame.len')
    $envelope = "frame.time_epoch >= $overallMin and frame.time_epoch <= $overallMax and not (ip.addr == 92.38.245.0/24)"
    $scanned = 0
    foreach ($pf in $PcapFiles) {
        Write-NetAnalyzeLog -Path $LogPath -Message ("stall-context tshark on " + $pf.Name)
        $out = & $TsharkPath -r $pf.FullName -n -Y $envelope @fields 2>$null
        foreach ($ln in $out) {
            $p = $ln -split "`t"
            if ($p.Count -lt 8) { continue }
            $t = 0.0
            if (-not (Parse-NetAnalyzeDouble $p[0] ([ref]$t))) { continue }
            $src = $p[1]; $dst = $p[2]
            $remote = $null
            if ($src -match '^(192\.168\.|10\.|169\.|172\.(1[6-9]|2[0-9]|3[01])\.|127\.|fe80:|::1)') { $remote = $dst }
            elseif ($dst -match '^(192\.168\.|10\.|169\.|172\.(1[6-9]|2[0-9]|3[01])\.|127\.|fe80:|::1)') { $remote = $src }
            else { continue }
            if ($remote -match '^(255\.|224\.|239\.|ff0|fe80)' -or $remote -eq '0.0.0.0' -or $remote -eq '::') { continue }
            $len = 0; [void](Parse-NetAnalyzeInt $p[7] ([ref]$len))
            $scanned++
            # Binary-search the first window whose EndEpoch >= t. Windows sorted by StartEpoch,
            # but we need to find any window that contains t. Use linear-scan from a pointer
            # since stalls are sparse; given WindowSec is small, windows rarely overlap more than a few.
            foreach ($w in $windows) {
                if ($t -lt $w.StartEpoch) { break }  # sorted by start, no point going further
                if ($t -le $w.EndEpoch) {
                    if (-not $w.ByRemote.ContainsKey($remote)) {
                        $w.ByRemote[$remote] = [pscustomobject]@{ Pkts = 0; Bytes = 0 }
                    }
                    $w.ByRemote[$remote].Pkts++
                    $w.ByRemote[$remote].Bytes += $len
                }
            }
        }
    }
    Write-NetAnalyzeLog -Path $logPath -Message ("stall-context scanned records=" + $scanned)

    # Per window: list top 3 remotes by bytes + aggregate
    $results = foreach ($w in $windows) {
        if ($w.ByRemote.Count -eq 0) {
            [pscustomobject]@{
                StallStartUtc = $w.StallStartUtc
                StallMs       = $w.StallMs
                BgPkts        = 0
                BgKB          = 0
                TopBackground = ''
            }
        } else {
            $top = $w.ByRemote.GetEnumerator() | ForEach-Object {
                [pscustomobject]@{ IP = $_.Key; Pkts = $_.Value.Pkts; Bytes = $_.Value.Bytes }
            } | Sort-Object Bytes -Descending | Select-Object -First 3
            $allBytes = ($w.ByRemote.Values | Measure-Object Bytes -Sum).Sum
            $allPkts = ($w.ByRemote.Values | Measure-Object Pkts -Sum).Sum
            $desc = ($top | ForEach-Object {
                $cls = Classify-NetAnalyzeIp $_.IP
                "{0}({1},{2}p,{3}kB)" -f $_.IP, $cls.Kind, $_.Pkts, [math]::Round($_.Bytes/1024,1)
            }) -join '|'
            [pscustomobject]@{
                StallStartUtc = $w.StallStartUtc
                StallMs       = $w.StallMs
                BgPkts        = $allPkts
                BgKB          = [math]::Round($allBytes/1024,1)
                TopBackground = $desc
            }
        }
    }
    return @($results)
}

function Invoke-RevelationNetworkAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$SessionDir
    )
    if (-not (Test-Path -LiteralPath $SessionDir)) { return }
    $runtimeDir = Join-Path $SessionDir 'runtime'
    if (-not (Test-Path -LiteralPath $runtimeDir)) { [void](New-Item -ItemType Directory -Force -Path $runtimeDir) }
    $networkDir = Join-Path $SessionDir 'network'
    $logPath = Join-Path $runtimeDir 'network-analysis.log'
    Write-NetAnalyzeLog -Path $logPath -Message ("Invoke-RevelationNetworkAnalysis start; sessionDir=" + $SessionDir)

    $tshark = Find-NetAnalyzeTshark
    if (-not $tshark) {
        Write-NetAnalyzeLog -Path $logPath -Message 'tshark not found; skipping.'
        return
    }
    Write-NetAnalyzeLog -Path $logPath -Message ("tshark=" + $tshark)

    $pcapFiles = Get-NetAnalyzePcapFiles -NetworkDir $networkDir
    if (-not $pcapFiles -or $pcapFiles.Count -eq 0) {
        Write-NetAnalyzeLog -Path $logPath -Message 'no dumpcap files found; skipping.'
        return
    }
    $totalMB = [math]::Round((($pcapFiles | Measure-Object Length -Sum).Sum) / 1MB, 1)
    Write-NetAnalyzeLog -Path $logPath -Message ("pcap files=" + $pcapFiles.Count + ', total MB=' + $totalMB)

    try {
        $peers = Invoke-NetAnalyzePeerSummary -TsharkPath $tshark -PcapFiles $pcapFiles -LogPath $logPath
        $udpOwnerMap = Get-NetAnalyzeUdpOwnerMap -RuntimeDir $runtimeDir
        $peers = Add-NetAnalyzePeerAnnotations -Peers $peers -UdpOwnerMap $udpOwnerMap
        if ($peers -and $peers.Count -gt 0) {
            $peers | Export-Csv -LiteralPath (Join-Path $runtimeDir 'network-peers.csv') -NoTypeInformation -Encoding UTF8
            Write-NetAnalyzeLog -Path $logPath -Message ('network-peers.csv rows=' + $peers.Count)
            $buckets = @(Get-NetAnalyzeBucketSummary -Peers $peers | Sort-Object KB -Descending)
            if ($buckets.Count -gt 0) {
                $buckets | Export-Csv -LiteralPath (Join-Path $runtimeDir 'network-buckets.csv') -NoTypeInformation -Encoding UTF8
                Write-NetAnalyzeLog -Path $logPath -Message ('network-buckets.csv rows=' + $buckets.Count)
            }
        } else {
            Write-NetAnalyzeLog -Path $logPath -Message 'no peer rows.'
        }
    } catch {
        Write-NetAnalyzeLog -Path $logPath -Message ('peer-summary failed: ' + $_.Exception.Message)
        $peers = @()
    }

    try {
        $rx = Invoke-NetAnalyzeGameRxGaps -TsharkPath $tshark -PcapFiles $pcapFiles -LogPath $logPath
        if ($rx -and $rx.RxCount -gt 0) {
            $rxRow = [pscustomobject]@{
                AllRxCount          = $rx.AllRxCount
                RxCount             = $rx.RxCount
                Shard               = $rx.Shard
                ShardPkts           = $rx.ShardPkts
                p50ms               = $rx.p50ms
                p90ms               = $rx.p90ms
                p99ms               = $rx.p99ms
                p99_9ms             = $rx.p99_9ms
                p99_99ms            = $rx.p99_99ms
                Maxms               = $rx.Maxms
                ActiveMaxms         = $rx.ActiveMaxms
                ObservedOver500ms   = $rx.ObservedOver500ms
                TransitionOver500ms = $rx.TransitionOver500ms
                Over500ms           = $rx.Over500ms
                Over1000ms          = $rx.Over1000ms
                Over2000ms          = $rx.Over2000ms
            }
            @($rxRow) | Export-Csv -LiteralPath (Join-Path $runtimeDir 'game-rx-gap.csv') -NoTypeInformation -Encoding UTF8
            Set-Content -LiteralPath (Join-Path $runtimeDir 'game-shard.txt') -Value ($rx.Shard + ' pkts=' + $rx.ShardPkts) -Encoding UTF8
            Write-NetAnalyzeLog -Path $logPath -Message ('game-rx-gap.csv allRxCount=' + $rx.AllRxCount + ' shardRxCount=' + $rx.RxCount + ' shard=' + $rx.Shard + ' activeOver500ms=' + $rx.Over500ms + ' observedOver500ms=' + $rx.ObservedOver500ms + ' activeMax=' + $rx.ActiveMaxms + ' observedMax=' + $rx.Maxms)
            if ($rx.Stalls -and $rx.Stalls.Count -gt 0) {
                # Context for stalls: one tshark pass per pcap with envelope filter.
                # Safe up to ~500 stalls and ~2 GB pcap; beyond that we still write the stall list but skip context.
                if ($rx.Stalls.Count -le 500 -and $totalMB -le 2048) {
                    $ctx = Invoke-NetAnalyzeBackgroundContextForStalls -TsharkPath $tshark -PcapFiles $pcapFiles -Stalls $rx.Stalls -LogPath $logPath -WindowSec 1.0
                    if ($ctx -and $ctx.Count -gt 0) {
                        $ctx | Export-Csv -LiteralPath (Join-Path $runtimeDir 'game-rx-stalls.csv') -NoTypeInformation -Encoding UTF8
                        Write-NetAnalyzeLog -Path $logPath -Message ('game-rx-stalls.csv rows=' + $ctx.Count)
                        # Also produce a compact aggregate: which IPs most often accompany stalls
                        $ipFreq = @{}
                        foreach ($row in $ctx) {
                            if (-not $row.TopBackground) { continue }
                            foreach ($item in ($row.TopBackground -split '\|')) {
                                if ($item -match '^([0-9\.]+)\(([A-Z_]+),(\d+)p,([0-9\.\,]+)kB\)$') {
                                    $ip = $matches[1]; $kind = $matches[2]
                                    if (-not $ipFreq.ContainsKey($ip)) { $ipFreq[$ip] = @{ Kind=$kind; Stalls=0 } }
                                    $ipFreq[$ip].Stalls++
                                }
                            }
                        }
                        $agg = $ipFreq.GetEnumerator() | ForEach-Object {
                            [pscustomobject]@{
                                IP = $_.Key
                                Kind = $_.Value.Kind
                                StallsAccompanied = $_.Value.Stalls
                                StallsTotal = $ctx.Count
                                PercentOfStalls = [math]::Round(100.0 * $_.Value.Stalls / $ctx.Count, 1)
                            }
                        } | Sort-Object StallsAccompanied -Descending
                        $agg | Export-Csv -LiteralPath (Join-Path $runtimeDir 'game-rx-stall-correlators.csv') -NoTypeInformation -Encoding UTF8
                    } else {
                        $rx.Stalls | Select-Object StallStartUtc, StallMs | Export-Csv -LiteralPath (Join-Path $runtimeDir 'game-rx-stalls.csv') -NoTypeInformation -Encoding UTF8
                        Write-NetAnalyzeLog -Path $logPath -Message 'stall context empty, wrote stalls list without context.'
                    }
                } else {
                    $rx.Stalls | Select-Object StallStartUtc, StallMs | Export-Csv -LiteralPath (Join-Path $runtimeDir 'game-rx-stalls.csv') -NoTypeInformation -Encoding UTF8
                    Write-NetAnalyzeLog -Path $logPath -Message ('too many stalls (' + $rx.Stalls.Count + ') or large pcap (' + $totalMB + ' MB); wrote stall list without context.')
                }
            }
        } else {
            Write-NetAnalyzeLog -Path $logPath -Message 'no game RX packets in 92.38.245.0/24; player likely did not reach in-game state.'
        }
    } catch {
        Write-NetAnalyzeLog -Path $logPath -Message ('rx-gap analysis failed: ' + $_.Exception.Message)
    }

    Write-NetAnalyzeLog -Path $logPath -Message 'Invoke-RevelationNetworkAnalysis done.'
}
