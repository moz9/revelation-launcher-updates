param(
    [Parameter(Position = 0)]
    [ValidateSet("Run", "Cleanup", "Status", "Help")]
    [string]$Action = "Run",

    [string]$GameDir,
    [string]$LauncherRoot,
    [ValidateSet("tierb-netease", "tierc-only", "none", "custom")]
    [string]$Profile = "tierb-netease",
    [string]$CustomIps = "",
    [int]$WaitForGameSec = 600,
    [int]$GraceAfterReadySec = 20,
    [int]$ExperimentDurationSec = 180,
    [int]$PollSec = 2
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Ensure-Directory {
    param([string]$Path)
    if ($Path -and (-not (Test-Path -LiteralPath $Path))) {
        New-Item -ItemType Directory -Path $Path | Out-Null
    }
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Read-KeyValueFile {
    param([string]$Path)
    $map = @{}
    if (-not (Test-Path -LiteralPath $Path)) {
        return $map
    }
    foreach ($line in (Get-Content -LiteralPath $Path -ErrorAction Stop)) {
        $text = [string]$line
        $index = $text.IndexOf("=")
        if ($index -le 0) { continue }
        $map[$text.Substring(0, $index).Trim()] = $text.Substring($index + 1)
    }
    return $map
}

function Get-ConfiguredGameRootFromLauncher {
    param([string]$ResolvedLauncherRoot)
    $configPath = Join-Path $ResolvedLauncherRoot "launcher-config.ini"
    $map = Read-KeyValueFile -Path $configPath
    if ($map.ContainsKey("gameRoot") -and $map["gameRoot"]) {
        return [string]$map["gameRoot"]
    }
    return ""
}

function Get-ResolvedGameRoot {
    param([string]$ConfiguredGameDir, [string]$ResolvedLauncherRoot)
    $candidatePath = $ConfiguredGameDir
    if (-not $candidatePath) {
        $candidatePath = Get-ConfiguredGameRootFromLauncher -ResolvedLauncherRoot $ResolvedLauncherRoot
    }
    if (-not $candidatePath) {
        $candidatePath = $ResolvedLauncherRoot
    }
    $resolved = (Resolve-Path -LiteralPath $candidatePath).Path
    if (Test-Path -LiteralPath (Join-Path $resolved "game\\tianyu.exe")) {
        return $resolved
    }
    if (Test-Path -LiteralPath (Join-Path $resolved "tianyu.exe")) {
        return (Split-Path -Parent $resolved)
    }
    throw "Could not determine Revelation root from path: $candidatePath"
}

function Get-ResolvedGameDir {
    param([string]$ResolvedGameRoot)
    $gameDir = Join-Path $ResolvedGameRoot "game"
    if (-not (Test-Path -LiteralPath (Join-Path $gameDir "tianyu.exe"))) {
        throw "Game directory not found: $ResolvedGameRoot"
    }
    return $gameDir
}

function Get-ExperimentRuleName {
    return "Revelation Experiment - Temporary Endpoint Block"
}

function Remove-ExperimentRule {
    $name = Get-ExperimentRuleName
    Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue | Out-Null
}

function Ensure-ExperimentRule {
    param([string]$ProgramPath, [string[]]$RemoteIps)
    Remove-ExperimentRule
    if ($RemoteIps.Count -eq 0) { return }
    New-NetFirewallRule `
        -DisplayName (Get-ExperimentRuleName) `
        -Direction Outbound `
        -Action Block `
        -Enabled True `
        -Profile Any `
        -Program $ProgramPath `
        -RemoteAddress $RemoteIps `
        -Description "Temporary rule for controlled net experiment" | Out-Null
}

function Get-ProfileIps {
    param([string]$ProfileName, [string]$CustomIpsText)
    switch ($ProfileName) {
        "tierb-netease" { return @("42.186.107.200", "42.186.120.183") }
        "tierc-only"    { return @("42.186.193.165", "42.186.29.91", "45.253.170.160") }
        "none"          { return @() }
        "custom" {
            if (-not $CustomIpsText) { return @() }
            return @($CustomIpsText.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        }
    }
    return @()
}

function Wait-TianyuReady {
    param([string]$TianyuExe, [int]$TimeoutSec, [int]$PollSec)
    $deadline = (Get-Date).AddSeconds([math]::Max(10, $TimeoutSec))
    $poll = [math]::Max(1, $PollSec)
    while ((Get-Date) -lt $deadline) {
        $proc = Get-Process -Name "tianyu" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($proc) {
            $tcp = Get-NetTCPConnection -OwningProcess $proc.Id -State Established -ErrorAction SilentlyContinue |
                Where-Object { [int]$_.RemotePort -eq 8766 }
            if ($tcp) {
                return [PSCustomObject]@{
                    Ready = $true
                    ProcessId = $proc.Id
                }
            }
        }
        Start-Sleep -Seconds $poll
    }
    return [PSCustomObject]@{
        Ready = $false
        ProcessId = 0
    }
}

function Collect-Sample {
    param([int]$ProcessId)
    $proc = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    $est = @()
    if ($proc) {
        $est = @(
            Get-NetTCPConnection -OwningProcess $ProcessId -State Established -ErrorAction SilentlyContinue |
                Select-Object RemoteAddress, RemotePort, State
        )
    }
    return [PSCustomObject]@{
        Timestamp = (Get-Date).ToString("s")
        ProcessAlive = [bool]$proc
        ProcessMemMB = $(if ($proc) { [math]::Round($proc.WorkingSet64 / 1MB) } else { 0 })
        Established = @($est)
        HasGame8766 = [bool](@($est | Where-Object { [int]$_.RemotePort -eq 8766 }).Count -gt 0)
    }
}

try {
    $resolvedLauncherRoot = if ($LauncherRoot) { (Resolve-Path -LiteralPath $LauncherRoot).Path } else { $PSScriptRoot }
    $resolvedGameRoot = Get-ResolvedGameRoot -ConfiguredGameDir $GameDir -ResolvedLauncherRoot $resolvedLauncherRoot
    $resolvedGameDir = Get-ResolvedGameDir -ResolvedGameRoot $resolvedGameRoot
    $stateDir = Join-Path $resolvedLauncherRoot ".revelation-combat"
    $expDir = Join-Path $stateDir "experiments"
    Ensure-Directory -Path $stateDir
    Ensure-Directory -Path $expDir

    if ($Action -eq "Help") {
        Write-Host "Usage:"
        Write-Host "  .\RevelationNetExperiment.ps1 Run -Profile tierb-netease"
        Write-Host "  .\RevelationNetExperiment.ps1 Run -Profile custom -CustomIps `"1.2.3.4,5.6.7.8`""
        Write-Host "  .\RevelationNetExperiment.ps1 Cleanup"
        Write-Host "  .\RevelationNetExperiment.ps1 Status"
        exit 0
    }

    if (-not (Test-IsAdministrator)) {
        throw "Administrator rights required."
    }

    if ($Action -eq "Cleanup") {
        Remove-ExperimentRule
        Write-Host "[NetExperiment] Temporary rule removed."
        exit 0
    }

    if ($Action -eq "Status") {
        $name = Get-ExperimentRuleName
        $rule = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
        if ($rule) {
            Write-Host "[NetExperiment] Rule is ACTIVE."
            $rule | Format-Table DisplayName, Enabled, Action -AutoSize
        } else {
            Write-Host "[NetExperiment] Rule is NOT active."
        }
        exit 0
    }

    $ips = @(Get-ProfileIps -ProfileName $Profile -CustomIpsText $CustomIps)
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $reportPath = Join-Path $expDir ("net-exp-" + $stamp + ".json")

    Write-Host "[NetExperiment] Waiting for game readiness (tianyu + TCP 8766)..."
    $ready = Wait-TianyuReady -TianyuExe (Join-Path $resolvedGameDir "tianyu.exe") -TimeoutSec $WaitForGameSec -PollSec $PollSec
    if (-not $ready.Ready) {
        throw "Game readiness timeout ($WaitForGameSec sec)."
    }

    if ($GraceAfterReadySec -gt 0) {
        Write-Host "[NetExperiment] Ready. Grace: $GraceAfterReadySec sec."
        Start-Sleep -Seconds $GraceAfterReadySec
    }

    $tianyuExe = Join-Path $resolvedGameDir "tianyu.exe"
    Ensure-ExperimentRule -ProgramPath $tianyuExe -RemoteIps $ips
    Write-Host "[NetExperiment] Rule applied. Profile=$Profile IPs=$($ips -join ', ')"

    $samples = New-Object System.Collections.Generic.List[object]
    $deadline = (Get-Date).AddSeconds([math]::Max(10, $ExperimentDurationSec))
    $poll = [math]::Max(1, $PollSec)
    while ((Get-Date) -lt $deadline) {
        $sample = Collect-Sample -ProcessId $ready.ProcessId
        $samples.Add($sample)
        Start-Sleep -Seconds $poll
    }

    Remove-ExperimentRule
    Write-Host "[NetExperiment] Rule removed. Writing report..."

    $summary = [PSCustomObject]@{
        StartedAt = (Get-Date).ToString("s")
        Profile = $Profile
        Ips = @($ips)
        WaitForGameSec = $WaitForGameSec
        GraceAfterReadySec = $GraceAfterReadySec
        ExperimentDurationSec = $ExperimentDurationSec
        PollSec = $poll
        SampleCount = $samples.Count
        SamplesWithGame8766 = @($samples | Where-Object { $_.HasGame8766 }).Count
        SamplesWithoutGame8766 = @($samples | Where-Object { -not $_.HasGame8766 }).Count
    }
    [PSCustomObject]@{
        Summary = $summary
        Samples = @($samples.ToArray())
    } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    Write-Host "[NetExperiment] Done: $reportPath"
    exit 0
} catch {
    Write-Error $_.Exception.Message
    try { Remove-ExperimentRule } catch {}
    exit 1
}
