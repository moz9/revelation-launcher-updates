param(
    [Parameter(Position = 0)]
    [ValidateSet("Status", "SetVariant", "InstallRtss", "RestoreRtss", "SetUiPreset", "RestoreUiPreset", "SetDxvkPreset", "RestoreDxvkPreset", "SetRendererPreset", "RestoreRendererPreset", "SetVideoPreset", "RestoreVideoPreset", "RestoreAll", "Help")]
    [string]$Action = "Status",

    [Parameter(Position = 1)]
    [string]$Value1 = "",

    [ValidateSet("official", "dx11", "x64", "beta32", "beta64")]
    [string]$Variant = "official",

    [ValidateSet("exclude", "delay")]
    [string]$RtssMode = "exclude",

    [ValidateSet("default", "lite", "declutter", "tooltipfix", "pvp", "masspvp", "pvpselect", "combatclean", "inventorylite", "statusghost", "binaryprobe", "spiritclean", "questcompat")]
    [string]$UiPreset = "default",

    [ValidateSet("off", "pacing", "legacyvram", "legacyvram-latency1", "antistutter", "aggressive")]
    [string]$DxvkPreset = "off",

    [ValidateSet("bundled", "native")]
    [string]$RendererPreset = "bundled",

    [ValidateSet("default", "fullscreen", "latency", "cache", "latency-cache", "game-extreme", "pvp-brutal")]
    [string]$VideoPreset = "default",

    [string]$GameDir,
    [string]$LauncherRoot,
    [string]$RtssProfilesDir,
    [switch]$DryRun,
    [switch]$SkipStatus
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ($Value1) {
    switch ($Action) {
        "SetVariant" {
            $Variant = $Value1
        }
        "InstallRtss" {
            $RtssMode = $Value1
        }
        "SetUiPreset" {
            $UiPreset = $Value1
        }
        "SetDxvkPreset" {
            $DxvkPreset = $Value1
        }
        "SetRendererPreset" {
            $RendererPreset = $Value1
        }
        "SetVideoPreset" {
            $VideoPreset = $Value1
        }
    }
}

function Write-Note {
    param([string]$Message)
    Write-Host "[RevelationLab] $Message"
}

function Resolve-PathOrEmpty {
    param([string]$Path)

    if (-not $Path) {
        return ""
    }

    try {
        if (Test-Path -LiteralPath $Path) {
            return [string](Resolve-Path -LiteralPath $Path).Path
        }
    } catch {
    }

    return ""
}

function Get-ResolvedGameDir {
    param([string]$ConfiguredGameDir)
    if ($ConfiguredGameDir) {
        return (Resolve-Path -LiteralPath $ConfiguredGameDir).Path
    }
    return (Join-Path $PSScriptRoot "game")
}

function Resolve-EffectiveLauncherRoot {
    param(
        [string]$ConfiguredLauncherRoot,
        [string]$ResolvedGameDir
    )

    $candidates = New-Object System.Collections.Generic.List[string]
    if ($ConfiguredLauncherRoot) {
        $candidates.Add($ConfiguredLauncherRoot)
    }

    $installManifestPath = Join-Path $PSScriptRoot ".revelation-combat\install.json"
    if (Test-Path -LiteralPath $installManifestPath) {
        try {
            $manifest = Get-Content -LiteralPath $installManifestPath -Raw | ConvertFrom-Json
            if ($manifest.LauncherRoot) {
                $candidates.Add([string]$manifest.LauncherRoot)
            }
        } catch {
        }
    }

    $candidates.Add($PSScriptRoot)

    if ($ResolvedGameDir) {
        $gameRoot = Split-Path -Parent $ResolvedGameDir
        if ($gameRoot) {
            $candidates.Add((Join-Path $gameRoot "Rvelation Launcher"))
            $parentOfGameRoot = Split-Path -Parent $gameRoot
            if ($parentOfGameRoot) {
                $candidates.Add((Join-Path $parentOfGameRoot "Rvelation Launcher"))
            }
        }
    }

    foreach ($candidate in $candidates) {
        $resolved = Resolve-PathOrEmpty -Path $candidate
        if ($resolved) {
            return $resolved
        }
    }

    return $PSScriptRoot
}

function Get-LauncherReleaseChannel {
    $root = if ($script:EffectiveLauncherRoot) { $script:EffectiveLauncherRoot } else { $PSScriptRoot }
    $candidates = @(
        (Join-Path $root 'installer-channel.json'),
        (Join-Path $root '.revelation-combat\install.json')
    )

    foreach ($path in $candidates) {
        if (-not (Test-Path -LiteralPath $path)) {
            continue
        }

        try {
            $metadata = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($name in @('releaseChannel', 'ReleaseChannel')) {
                if ($metadata.PSObject.Properties.Name -contains $name) {
                    $channel = ([string]$metadata.$name).Trim().ToLowerInvariant()
                    if ($channel -eq 'public') {
                        return 'release'
                    }
                    if ($channel -in @('release', 'experimental')) {
                        return $channel
                    }
                }
            }
        } catch {
        }
    }

    return 'release'
}

function Get-ResolvedRtssProfilesDir {
    param([string]$ConfiguredRtssProfilesDir)
    if ($ConfiguredRtssProfilesDir) {
        return (Resolve-Path -LiteralPath $ConfiguredRtssProfilesDir).Path
    }

    $programFilesX86 = ${env:ProgramFiles(x86)}
    if (-not $programFilesX86) {
        throw "ProgramFiles(x86) is not defined. Pass -RtssProfilesDir explicitly."
    }

    return (Join-Path $programFilesX86 "RivaTuner Statistics Server\Profiles")
}

function Get-LabRoot {
    if ($script:EffectiveLauncherRoot) {
        return (Join-Path $script:EffectiveLauncherRoot ".revelation-lab")
    }
    return (Join-Path $PSScriptRoot ".revelation-lab")
}

function Ensure-Directory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path | Out-Null
    }
}

function Get-UiStatePath {
    return (Join-Path (Get-LabRoot) "ui-state.json")
}

function Get-DxvkStatePath {
    return (Join-Path (Get-LabRoot) "dxvk-state.json")
}

function Get-RendererStatePath {
    return (Join-Path (Get-LabRoot) "renderer-state.json")
}

function Get-VideoStatePath {
    return (Join-Path (Get-LabRoot) "video-state.json")
}

function Get-ConfPath {
    param([string]$ResolvedGameDir)
    return (Join-Path $ResolvedGameDir "conf.xml")
}

function Get-UiBaselineCandidatePaths {
    param([string]$ResolvedGameDir)

    $paths = New-Object System.Collections.Generic.List[string]
    foreach ($entry in (Get-ChildItem -LiteralPath $ResolvedGameDir -File -Filter "conf*.xml" | Sort-Object Name)) {
        if ($entry.Name -in @("conf.xml", "conf.xml.default")) {
            continue
        }
        $paths.Add($entry.FullName)
    }
    $paths.Add((Join-Path $ResolvedGameDir "conf.xml.default"))
    return @($paths.ToArray())
}

function Get-TianyuConfigPath {
    param([string]$ResolvedGameDir)
    return (Join-Path $ResolvedGameDir "tianyu.xml")
}

function Get-DxvkConfigPath {
    param([string]$ResolvedGameDir)
    return (Join-Path $ResolvedGameDir "dxvk.conf")
}

function Get-ManagedDxvkRoot {
    if ($script:EffectiveLauncherRoot) {
        return (Join-Path $script:EffectiveLauncherRoot ".revelation-combat")
    }
    return (Join-Path $PSScriptRoot ".revelation-combat")
}

function Get-ManagedDxvkConfigPath {
    return (Join-Path (Get-ManagedDxvkRoot) "dxvk.conf")
}

function Get-DxvkConfigEnvName {
    return "DXVK_CONFIG_FILE"
}

function Get-CurrentDxvkEnvValue {
    $name = Get-DxvkConfigEnvName
    $userValue = [Environment]::GetEnvironmentVariable($name, "User")
    if ($userValue) {
        return [string]$userValue
    }

    $processValue = [Environment]::GetEnvironmentVariable($name, "Process")
    if ($processValue) {
        return [string]$processValue
    }

    return ""
}

function Set-CanonicalDxvkEnvironment {
    param([string]$ManagedDxvkPath)

    $name = Get-DxvkConfigEnvName
    $currentUserValue = [Environment]::GetEnvironmentVariable($name, "User")
    if (-not [string]::Equals([string]$currentUserValue, $ManagedDxvkPath, [System.StringComparison]::OrdinalIgnoreCase)) {
        [Environment]::SetEnvironmentVariable($name, $ManagedDxvkPath, "User")
    }
    $currentProcessValue = [Environment]::GetEnvironmentVariable($name, "Process")
    if (-not [string]::Equals([string]$currentProcessValue, $ManagedDxvkPath, [System.StringComparison]::OrdinalIgnoreCase)) {
        [Environment]::SetEnvironmentVariable($name, $ManagedDxvkPath, "Process")
    }
}

function Get-EffectiveDxvkConfigPath {
    param([string]$ResolvedGameDir)

    $configuredPath = Get-CurrentDxvkEnvValue
    if ($configuredPath -and (Test-Path -LiteralPath $configuredPath)) {
        return [string]$configuredPath
    }

    $managedPath = Get-ManagedDxvkConfigPath
    if (Test-Path -LiteralPath $managedPath) {
        return $managedPath
    }

    return (Get-DxvkConfigPath -ResolvedGameDir $ResolvedGameDir)
}

function Get-TargetExePath {
    param([string]$ResolvedGameDir)
    return (Join-Path $ResolvedGameDir "tianyu.exe")
}

function Get-UiPresetDefinition {
    param([string]$Mode = "")

    $lite = @(
        @{ Name = "screen.disableSkillHover"; LegacyPath = "/root/screen/disableSkillHover"; Regex = "(?s)(<screen>.*?<disableSkillHover>)(\s*)([^<]*?)(\s*)(</disableSkillHover>)"; Value = "1" }
        @{ Name = "debug.showMonsterName"; LegacyPath = "/root/Debug/showMonsterName"; Regex = "(?s)(<Debug>.*?<showMonsterName>)(\s*)([^<]*?)(\s*)(</showMonsterName>)"; Value = "1" }
        @{ Name = "debug.showEntityId"; LegacyPath = "/root/Debug/showEntityId"; Regex = "(?s)(<Debug>.*?<showEntityId>)(\s*)([^<]*?)(\s*)(</showEntityId>)"; Value = "0" }
        @{ Name = "debug.showShakeCamera"; LegacyPath = "/root/Debug/showShakeCamera"; Regex = "(?s)(<Debug>.*?<showShakeCamera>)(\s*)([^<]*?)(\s*)(</showShakeCamera>)"; Value = "0" }
        @{ Name = "ui.chatlog.hidden"; LegacyPath = "/root/ui/chatlog/hidden"; Regex = "(?s)(<chatlog>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.chatLog.isHide"; LegacyPath = "/root/ui/chatLog/isHide"; Regex = "(?s)(<chatLog>.*?<isHide>)(\s*)([^<]*?)(\s*)(</isHide>)"; Value = "1" }
        @{ Name = "ui.questtrackwidget.hidden"; LegacyPath = "/root/ui/questtrackwidget/hidden"; Regex = "(?s)(<questtrackwidget>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.playtips.hidden"; LegacyPath = "/root/ui/playtips/hidden"; Regex = "(?s)(<playtips>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.systemtips.hidden"; LegacyPath = "/root/ui/systemtips/hidden"; Regex = "(?s)(<systemtips>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.pushmsg.hidden"; LegacyPath = "/root/ui/pushmsg/hidden"; Regex = "(?s)(<pushmsg>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.systempush.hidden"; LegacyPath = "/root/ui/systempush/hidden"; Regex = "(?s)(<systempush>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.bossblood.hidden"; LegacyPath = "/root/ui/bossblood/hidden"; Regex = "(?s)(<bossblood>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
    )

    $tooltipfix = @(
        @{ Name = "screen.disableSkillHover"; LegacyPath = "/root/screen/disableSkillHover"; Regex = "(?s)(<screen>.*?<disableSkillHover>)(\s*)([^<]*?)(\s*)(</disableSkillHover>)"; Value = "1" }
        @{ Name = "debug.showMonsterName"; LegacyPath = "/root/Debug/showMonsterName"; Regex = "(?s)(<Debug>.*?<showMonsterName>)(\s*)([^<]*?)(\s*)(</showMonsterName>)"; Value = "1" }
        @{ Name = "debug.showEntityId"; LegacyPath = "/root/Debug/showEntityId"; Regex = "(?s)(<Debug>.*?<showEntityId>)(\s*)([^<]*?)(\s*)(</showEntityId>)"; Value = "0" }
        @{ Name = "debug.showShakeCamera"; LegacyPath = "/root/Debug/showShakeCamera"; Regex = "(?s)(<Debug>.*?<showShakeCamera>)(\s*)([^<]*?)(\s*)(</showShakeCamera>)"; Value = "0" }
        @{ Name = "ui.npcV2.quickRead"; LegacyPath = "/root/ui/npcV2/quickRead"; Regex = "(?s)(<npcV2>.*?<quickRead>)(\s*)([^<]*?)(\s*)(</quickRead>)"; Value = "0"; InsertBeforeRegex = "(?s)(</ui>)"; InsertText = "`t`t<npcV2>`r`n`t`t`t<quickRead>`t0`t</quickRead>`r`n`t`t</npcV2>`r`n"; RemoveRegex = "(?ms)^[ \t]*<npcV2>\s*\r?\n[ \t]*<quickRead>\s*[^<]*\s*</quickRead>\s*\r?\n[ \t]*</npcV2>\s*\r?\n?" }
    )

    $declutter = @(
        @{ Name = "personal.hidePlayerName"; LegacyPath = "/root/personal/hidePlayerName"; Regex = "(?s)(<personal>.*?<hidePlayerName>)(\s*)([^<]*?)(\s*)(</hidePlayerName>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hidePlayerName>`t0`t</hidePlayerName>`r`n"; RemoveRegex = "(?m)^[ \t]*<hidePlayerName>\s*[^<]*\s*</hidePlayerName>\s*\r?\n?" }
        @{ Name = "personal.hidePlayerTitle"; LegacyPath = "/root/personal/hidePlayerTitle"; Regex = "(?s)(<personal>.*?<hidePlayerTitle>)(\s*)([^<]*?)(\s*)(</hidePlayerTitle>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hidePlayerTitle>`t0`t</hidePlayerTitle>`r`n"; RemoveRegex = "(?m)^[ \t]*<hidePlayerTitle>\s*[^<]*\s*</hidePlayerTitle>\s*\r?\n?" }
        @{ Name = "personal.hidePlayerBlood"; LegacyPath = "/root/personal/hidePlayerBlood"; Regex = "(?s)(<personal>.*?<hidePlayerBlood>)(\s*)([^<]*?)(\s*)(</hidePlayerBlood>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hidePlayerBlood>`t0`t</hidePlayerBlood>`r`n"; RemoveRegex = "(?m)^[ \t]*<hidePlayerBlood>\s*[^<]*\s*</hidePlayerBlood>\s*\r?\n?" }
        @{ Name = "personal.hidePlayerGuild"; LegacyPath = "/root/personal/hidePlayerGuild"; Regex = "(?s)(<personal>.*?<hidePlayerGuild>)(\s*)([^<]*?)(\s*)(</hidePlayerGuild>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hidePlayerGuild>`t0`t</hidePlayerGuild>`r`n"; RemoveRegex = "(?m)^[ \t]*<hidePlayerGuild>\s*[^<]*\s*</hidePlayerGuild>\s*\r?\n?" }
        @{ Name = "personal.hideAvatarName"; LegacyPath = "/root/personal/hideAvatarName"; Regex = "(?s)(<personal>.*?<hideAvatarName>)(\s*)([^<]*?)(\s*)(</hideAvatarName>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideAvatarName>`t0`t</hideAvatarName>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideAvatarName>\s*[^<]*\s*</hideAvatarName>\s*\r?\n?" }
        @{ Name = "personal.hideAvatarTitle"; LegacyPath = "/root/personal/hideAvatarTitle"; Regex = "(?s)(<personal>.*?<hideAvatarTitle>)(\s*)([^<]*?)(\s*)(</hideAvatarTitle>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideAvatarTitle>`t0`t</hideAvatarTitle>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideAvatarTitle>\s*[^<]*\s*</hideAvatarTitle>\s*\r?\n?" }
        @{ Name = "personal.hideAvatarBlood"; LegacyPath = "/root/personal/hideAvatarBlood"; Regex = "(?s)(<personal>.*?<hideAvatarBlood>)(\s*)([^<]*?)(\s*)(</hideAvatarBlood>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideAvatarBlood>`t0`t</hideAvatarBlood>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideAvatarBlood>\s*[^<]*\s*</hideAvatarBlood>\s*\r?\n?" }
        @{ Name = "personal.hideAvatarGuild"; LegacyPath = "/root/personal/hideAvatarGuild"; Regex = "(?s)(<personal>.*?<hideAvatarGuild>)(\s*)([^<]*?)(\s*)(</hideAvatarGuild>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideAvatarGuild>`t0`t</hideAvatarGuild>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideAvatarGuild>\s*[^<]*\s*</hideAvatarGuild>\s*\r?\n?" }
        @{ Name = "personal.hideOtherEntityName"; LegacyPath = "/root/personal/hideOtherEntityName"; Regex = "(?s)(<personal>.*?<hideOtherEntityName>)(\s*)([^<]*?)(\s*)(</hideOtherEntityName>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideOtherEntityName>`t0`t</hideOtherEntityName>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideOtherEntityName>\s*[^<]*\s*</hideOtherEntityName>\s*\r?\n?" }
        @{ Name = "personal.hideOtherEntityTitle"; LegacyPath = "/root/personal/hideOtherEntityTitle"; Regex = "(?s)(<personal>.*?<hideOtherEntityTitle>)(\s*)([^<]*?)(\s*)(</hideOtherEntityTitle>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideOtherEntityTitle>`t0`t</hideOtherEntityTitle>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideOtherEntityTitle>\s*[^<]*\s*</hideOtherEntityTitle>\s*\r?\n?" }
        @{ Name = "personal.hideOtherEntityBlood"; LegacyPath = "/root/personal/hideOtherEntityBlood"; Regex = "(?s)(<personal>.*?<hideOtherEntityBlood>)(\s*)([^<]*?)(\s*)(</hideOtherEntityBlood>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideOtherEntityBlood>`t0`t</hideOtherEntityBlood>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideOtherEntityBlood>\s*[^<]*\s*</hideOtherEntityBlood>\s*\r?\n?" }
        @{ Name = "personal.hideSpriteBlood"; LegacyPath = "/root/personal/hideSpriteBlood"; Regex = "(?s)(<personal>.*?<hideSpriteBlood>)(\s*)([^<]*?)(\s*)(</hideSpriteBlood>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideSpriteBlood>`t0`t</hideSpriteBlood>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideSpriteBlood>\s*[^<]*\s*</hideSpriteBlood>\s*\r?\n?" }
        @{ Name = "personal.hideOtherSpriteName"; LegacyPath = "/root/personal/hideOtherSpriteName"; Regex = "(?s)(<personal>.*?<hideOtherSpriteName>)(\s*)([^<]*?)(\s*)(</hideOtherSpriteName>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideOtherSpriteName>`t0`t</hideOtherSpriteName>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideOtherSpriteName>\s*[^<]*\s*</hideOtherSpriteName>\s*\r?\n?" }
        @{ Name = "personal.hideOtherSpriteBlood"; LegacyPath = "/root/personal/hideOtherSpriteBlood"; Regex = "(?s)(<personal>.*?<hideOtherSpriteBlood>)(\s*)([^<]*?)(\s*)(</hideOtherSpriteBlood>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<hideOtherSpriteBlood>`t0`t</hideOtherSpriteBlood>`r`n"; RemoveRegex = "(?m)^[ \t]*<hideOtherSpriteBlood>\s*[^<]*\s*</hideOtherSpriteBlood>\s*\r?\n?" }
        @{ Name = "personal.blockFirework"; LegacyPath = "/root/personal/blockFirework"; Regex = "(?s)(<personal>.*?<blockFirework>)(\s*)([^<]*?)(\s*)(</blockFirework>)"; Value = "1"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<blockFirework>`t1`t</blockFirework>`r`n"; RemoveRegex = "(?m)^[ \t]*<blockFirework>\s*[^<]*\s*</blockFirework>\s*\r?\n?" }
    )

    $selectmode = @(
        @{ Name = "personal.targetLockedEff"; LegacyPath = "/root/personal/targetLockedEff"; Regex = "(?s)(<personal>.*?<targetLockedEff>)(\s*)([^<]*?)(\s*)(</targetLockedEff>)"; Value = "1"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<targetLockedEff>`t1`t</targetLockedEff>`r`n"; RemoveRegex = "(?m)^[ \t]*<targetLockedEff>\s*[^<]*\s*</targetLockedEff>\s*\r?\n?" }
        @{ Name = "personal.settingSelectMode"; LegacyPath = "/root/personal/settingSelectMode"; Regex = "(?s)(<personal>.*?<settingSelectMode>)(\s*)([^<]*?)(\s*)(</settingSelectMode>)"; Value = "1"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<settingSelectMode>`t1`t</settingSelectMode>`r`n"; RemoveRegex = "(?m)^[ \t]*<settingSelectMode>\s*[^<]*\s*</settingSelectMode>\s*\r?\n?" }
    )

    $auxdeclutter = foreach ($widgetName in @(
        "singletip",
        "spriteani",
        "bufflistenershow",
        "continuoushit",
        "tianjiachoudi",
        "region",
        "diguotips",
        "bfstats",
        "bfflagstats",
        "caozuomoshi",
        "kuaisujindui",
        "kuaisjiejinduizhong",
        "guanzhangjl",
        "guanzhanxt",
        "zhanlinggmmianban",
        "multicarrier",
        "tempSkill",
        "equipbuy",
        "pushMessageV2",
        "carrierNarrow",
        "warMessage",
        "zuixiaohaoyouliaotian",
        "shengjibizuo"
    )) {
        @{
            Name = "ui.$widgetName.hidden"
            LegacyPath = "/root/ui/$widgetName/hidden"
            Regex = "(?s)(<$widgetName>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"
            Value = "1"
        }
    }

    $petcompat = @(
        @{ Name = "ui.yingling_touxiang.hidden"; LegacyPath = "/root/ui/yingling_touxiang/hidden"; Regex = "(?s)(<yingling_touxiang>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
    )

    $inventorylite = @(
        @{ Name = "ui.itembar2.hidden"; LegacyPath = "/root/ui/itembar2/hidden"; Regex = "(?s)(<itembar2>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.generalcastBar.hidden"; LegacyPath = "/root/ui/generalcastBar/hidden"; Regex = "(?s)(<generalcastBar>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.MultiplemonsterUF.hidden"; LegacyPath = "/root/ui/MultiplemonsterUF/hidden"; Regex = "(?s)(<MultiplemonsterUF>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "game.tempBagCheckBox"; LegacyPath = "/root/game/tempBagCheckBox"; Regex = "(<tempBagCheckBox>)(\s*)([^<]*?)(\s*)(</tempBagCheckBox>)"; Value = "0"; InsertBeforeRegex = "(?s)(</game>)"; InsertText = "`t`t<tempBagCheckBox>`t0`t</tempBagCheckBox>`r`n"; RemoveRegex = "(?m)^[ \t]*<tempBagCheckBox>\s*[^<]*\s*</tempBagCheckBox>\s*\r?\n?" }
    )

    $statusghost = @(
        @{ Name = "personal.ckBoxbuffListener"; LegacyPath = "/root/personal/ckBoxbuffListener"; Regex = "(?s)(<personal>.*?<ckBoxbuffListener>)(\s*)([^<]*?)(\s*)(</ckBoxbuffListener>)"; Value = "0"; InsertBeforeRegex = "(?s)(</personal>)"; InsertText = "`t`t<ckBoxbuffListener>`t0`t</ckBoxbuffListener>`r`n"; RemoveRegex = "(?m)^[ \t]*<ckBoxbuffListener>\s*[^<]*\s*</ckBoxbuffListener>\s*\r?\n?" }
        @{ Name = "ui.bufflistenershow.hidden"; LegacyPath = "/root/ui/bufflistenershow/hidden"; Regex = "(?s)(<bufflistenershow>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
    )

    $questcompat = @(
        @{ Name = "ui.questTrackWidget.hide"; LegacyPath = "/root/ui/questTrackWidget/hide"; Regex = "(?s)(<questTrackWidget>.*?<hide>)(\s*)([^<]*?)(\s*)(</hide>)"; Value = "0" }
        @{ Name = "ui.questtrackwidget.hidden"; LegacyPath = "/root/ui/questtrackwidget/hidden"; Regex = "(?s)(<questtrackwidget>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
        @{ Name = "ui.littlemap.hidden"; LegacyPath = "/root/ui/littlemap/hidden"; Regex = "(?s)(<littlemap>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
        @{ Name = "ui.littleMap.hide"; LegacyPath = "/root/ui/littleMap/hide"; Regex = "(?s)(<littleMap>.*?<hide>)(\s*)([^<]*?)(\s*)(</hide>)"; Value = "0" }
        @{ Name = "ui.playtips.hidden"; LegacyPath = "/root/ui/playtips/hidden"; Regex = "(?s)(<playtips>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
        @{ Name = "ui.systemtips.hidden"; LegacyPath = "/root/ui/systemtips/hidden"; Regex = "(?s)(<systemtips>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
        @{ Name = "ui.topmessage.hidden"; LegacyPath = "/root/ui/topmessage/hidden"; Regex = "(?s)(<topmessage>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
        @{ Name = "ui.pushmsg.hidden"; LegacyPath = "/root/ui/pushmsg/hidden"; Regex = "(?s)(<pushmsg>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
        @{ Name = "ui.systempush.hidden"; LegacyPath = "/root/ui/systempush/hidden"; Regex = "(?s)(<systempush>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "0" }
    )

    $spiritclean = @(
        @{ Name = "ui.wsskillbar.hidden"; LegacyPath = "/root/ui/wsskillbar/hidden"; Regex = "(?s)(<wsskillbar>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.wsskillbar.x"; LegacyPath = "/root/ui/wsskillbar/pos/x"; Regex = "(?s)(<wsskillbar>.*?<x>)(\s*)([^<]*?)(\s*)(</x>)"; Value = "-5000" }
        @{ Name = "ui.wsskillbar.y"; LegacyPath = "/root/ui/wsskillbar/pos/y"; Regex = "(?s)(<wsskillbar>.*?<y>)(\s*)([^<]*?)(\s*)(</y>)"; Value = "-5000" }
        @{ Name = "ui.targetuf.hidden"; LegacyPath = "/root/ui/targetuf/hidden"; Regex = "(?s)(<targetuf>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.targetuf.x"; LegacyPath = "/root/ui/targetuf/pos/x"; Regex = "(?s)(<targetuf>.*?<x>)(\s*)([^<]*?)(\s*)(</x>)"; Value = "-5000" }
        @{ Name = "ui.targetuf.y"; LegacyPath = "/root/ui/targetuf/pos/y"; Regex = "(?s)(<targetuf>.*?<y>)(\s*)([^<]*?)(\s*)(</y>)"; Value = "-5000" }
        @{ Name = "ui.Focustarget.hidden"; LegacyPath = "/root/ui/Focustarget/hidden"; Regex = "(?s)(<Focustarget>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
        @{ Name = "ui.genchongji.hidden"; LegacyPath = "/root/ui/genchongji/hidden"; Regex = "(?s)(<genchongji>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"; Value = "1" }
    )

    $enginerecommended = @(
        @{ Name = "advance.multithreadrender"; LegacyPath = "/root/advance/multithreadrender"; Regex = "(?s)(<advance>.*?<multithreadrender>)(\s*)([^<]*?)(\s*)(</multithreadrender>)"; Value = "1"; InsertBeforeRegex = "(?s)(</advance>)"; InsertText = "`t`t<multithreadrender>`t1`t</multithreadrender>`r`n"; RemoveRegex = "(?m)^[ \t]*<multithreadrender>\s*[^<]*\s*</multithreadrender>\s*\r?\n?" }
        @{ Name = "Debug.debugKeyEnable"; LegacyPath = "/root/Debug/debugKeyEnable"; Regex = "(?s)(<Debug>.*?<debugKeyEnable>)(\s*)([^<]*?)(\s*)(</debugKeyEnable>)"; Value = "0"; InsertBeforeRegex = "(?s)(</Debug>)"; InsertText = "`t`t<debugKeyEnable>`t0`t</debugKeyEnable>`r`n"; RemoveRegex = "(?m)^[ \t]*<debugKeyEnable>\s*[^<]*\s*</debugKeyEnable>\s*\r?\n?" }
    )

    $enginedebug = @(
        @{ Name = "Debug.debugKeyEnable"; LegacyPath = "/root/Debug/debugKeyEnable"; Regex = "(?s)(<Debug>.*?<debugKeyEnable>)(\s*)([^<]*?)(\s*)(</debugKeyEnable>)"; Value = "1"; InsertBeforeRegex = "(?s)(</Debug>)"; InsertText = "`t`t<debugKeyEnable>`t1`t</debugKeyEnable>`r`n"; RemoveRegex = "(?m)^[ \t]*<debugKeyEnable>\s*[^<]*\s*</debugKeyEnable>\s*\r?\n?" }
    )

    $binaryprobe = @($enginerecommended + $enginedebug)

    if (-not $Mode) {
            return @($lite + $tooltipfix + $declutter + $auxdeclutter + $petcompat + $inventorylite + $statusghost + $selectmode)
    }

    switch ($Mode) {
        "lite" {
            return @($lite)
        }
        "tooltipfix" {
            return @($tooltipfix)
        }
        "declutter" {
            return @($lite + $declutter)
        }
        "pvp" {
            return @($tooltipfix + $declutter + $auxdeclutter + $petcompat + $statusghost + $questcompat)
        }
        "masspvp" {
            return @($lite + $tooltipfix + $declutter + $auxdeclutter + $petcompat + $inventorylite + $statusghost + $questcompat)
        }
        "combatclean" {
            return @($tooltipfix + $declutter + $auxdeclutter + $petcompat + $inventorylite + $statusghost + $questcompat + $enginerecommended)
        }
        "inventorylite" {
            return @($inventorylite)
        }
        "statusghost" {
            return @($statusghost)
        }
        "questcompat" {
            return @($questcompat)
        }
        "binaryprobe" {
            return @($binaryprobe)
        }
        "spiritclean" {
            return @($spiritclean)
        }
        "pvpselect" {
            return @($tooltipfix + $declutter + $auxdeclutter + $petcompat + $inventorylite + $statusghost + $selectmode)
        }
        "default" {
            return @()
        }
        default {
            throw "Unknown UI preset mode: $Mode"
        }
    }
}

function Get-VideoPresetDefinition {
    param([string]$Mode = "")

    $definitions = @(
        @{ Name = "tianyu.renderer.fullscreen"; File = "tianyu"; Regex = "(?s)(<renderer>.*?<fullscreen>)(\s*)([^<]*?)(\s*)(</fullscreen>)" }
        @{ Name = "tianyu.renderer.verticalBlankWait"; File = "tianyu"; Regex = "(?s)(<renderer>.*?<verticalBlankWait>)(\s*)([^<]*?)(\s*)(</verticalBlankWait>)" }
        @{ Name = "tianyu.renderer.maxFrameRate"; File = "tianyu"; Regex = "(?s)(<renderer>.*?<maxFrameRate>)(\s*)([^<]*?)(\s*)(</maxFrameRate>)" }
        @{ Name = "tianyu.renderer.cacheEffects"; File = "tianyu"; Regex = "(?s)(<renderer>.*?<cacheEffects>)(\s*)([^<]*?)(\s*)(</cacheEffects>)" }
        @{ Name = "conf.screen.windowed"; File = "conf"; Regex = "(?s)(<screen>.*?<windowed>)(\s*)([^<]*?)(\s*)(</windowed>)" }
        @{ Name = "conf.screen.foregroundFPS"; File = "conf"; Regex = "(?s)(<screen>.*?<foregroundFPS>)(\s*)([^<]*?)(\s*)(</foregroundFPS>)" }
        @{ Name = "conf.screen.DL"; File = "conf"; Regex = "(?s)(<screen>.*?<DL>)(\s*)([^<]*?)(\s*)(</DL>)" }
        @{ Name = "conf.screen.HQLS"; File = "conf"; Regex = "(?s)(<screen>.*?<HQLS>)(\s*)([^<]*?)(\s*)(</HQLS>)" }
        @{ Name = "conf.screen.AVATAREFF"; File = "conf"; Regex = "(?s)(<screen>.*?<AVATAREFF>)(\s*)([^<]*?)(\s*)(</AVATAREFF>)" }
        @{ Name = "conf.screen.MONSTEREFF"; File = "conf"; Regex = "(?s)(<screen>.*?<MONSTEREFF>)(\s*)([^<]*?)(\s*)(</MONSTEREFF>)" }
        @{ Name = "conf.screen.NPCEFF"; File = "conf"; Regex = "(?s)(<screen>.*?<NPCEFF>)(\s*)([^<]*?)(\s*)(</NPCEFF>)" }
        @{ Name = "conf.screen.enableMemorySetting"; File = "conf"; Regex = "(?s)(<screen>.*?<enableMemorySetting>)(\s*)([^<]*?)(\s*)(</enableMemorySetting>)" }
        @{ Name = "conf.screen.setViewFactor"; File = "conf"; Regex = "(?s)(<screen>.*?<setViewFactor>)(\s*)([^<]*?)(\s*)(</setViewFactor>)" }
        @{ Name = "conf.screen.setTerrainRenderLevel"; File = "conf"; Regex = "(?s)(<screen>.*?<setTerrainRenderLevel>)(\s*)([^<]*?)(\s*)(</setTerrainRenderLevel>)" }
        @{ Name = "conf.screen.forceSkipMipMap"; File = "conf"; Regex = "(?s)(<screen>.*?<forceSkipMipMap>)(\s*)([^<]*?)(\s*)(</forceSkipMipMap>)" }
    )

    if (-not $Mode) {
        return $definitions
    }

    $modeValues = @{
        "fullscreen" = @{
            "tianyu.renderer.fullscreen"        = "true"
            "tianyu.renderer.verticalBlankWait" = "false"
            "tianyu.renderer.maxFrameRate"      = "300"
            "tianyu.renderer.cacheEffects"      = "true"
            "conf.screen.windowed"              = "0"
            "conf.screen.foregroundFPS"         = "300"
        }
        "latency" = @{
            "tianyu.renderer.verticalBlankWait" = "false"
            "tianyu.renderer.maxFrameRate"      = "300"
            "conf.screen.foregroundFPS"         = "300"
        }
        "cache" = @{
            "tianyu.renderer.cacheEffects"      = "true"
        }
        "latency-cache" = @{
            "tianyu.renderer.verticalBlankWait" = "false"
            "tianyu.renderer.maxFrameRate"      = "300"
            "tianyu.renderer.cacheEffects"      = "true"
            "conf.screen.foregroundFPS"         = "300"
        }
        "game-extreme" = @{
            "tianyu.renderer.fullscreen"        = "false"
            "tianyu.renderer.verticalBlankWait" = "false"
            "tianyu.renderer.maxFrameRate"      = "300"
            "tianyu.renderer.cacheEffects"      = "true"
            "conf.screen.windowed"              = "1"
            "conf.screen.foregroundFPS"         = "300"
            "conf.screen.DL"                    = "0"
            "conf.screen.HQLS"                  = "2"
            "conf.screen.AVATAREFF"             = "0"
            "conf.screen.MONSTEREFF"            = "0"
            "conf.screen.NPCEFF"                = "0"
            "conf.screen.enableMemorySetting"   = "1"
            "conf.screen.setViewFactor"         = "3"
            "conf.screen.setTerrainRenderLevel" = "3"
            "conf.screen.forceSkipMipMap"       = "3"
        }
        "pvp-brutal" = @{
            "tianyu.renderer.verticalBlankWait" = "false"
            "tianyu.renderer.maxFrameRate"      = "300"
            "tianyu.renderer.cacheEffects"      = "true"
            "conf.screen.foregroundFPS"         = "300"
            "conf.screen.DL"                    = "0"
            "conf.screen.HQLS"                  = "2"
            "conf.screen.AVATAREFF"             = "0"
            "conf.screen.MONSTEREFF"            = "0"
            "conf.screen.NPCEFF"                = "0"
            "conf.screen.enableMemorySetting"   = "1"
            "conf.screen.setViewFactor"         = "3"
            "conf.screen.setTerrainRenderLevel" = "3"
            "conf.screen.forceSkipMipMap"       = "3"
        }
    }

    if (-not $modeValues.ContainsKey($Mode)) {
        throw "Unknown video preset mode: $Mode"
    }

    $selectedValues = $modeValues[$Mode]
    $selectedDefinitions = @()
    foreach ($definition in $definitions) {
        if ($selectedValues.ContainsKey($definition.Name)) {
            $selectedDefinitions += @{
                Name  = $definition.Name
                File  = $definition.File
                Regex = $definition.Regex
                Value = $selectedValues[$definition.Name]
            }
        }
    }

    return @($selectedDefinitions)
}

function Get-DxvkPresetContent {
    param([string]$Mode)

    if ($Mode -eq "pacing") {
        return @"
# RevelationLab minimal frame pacing preset
dxvk.allowFse = True
d3d9.maxFrameLatency = 1
dxgi.maxFrameLatency = 1
"@
    }

    if ($Mode -eq "legacyvram") {
        return @"
# RevelationLab old-D3D9 memory reporting preset
# Helps games that misbehave on modern GPUs with large VRAM budgets.
d3d9.maxAvailableMemory = 4096
"@
    }

    if ($Mode -eq "legacyvram-latency1") {
        return @"
# RevelationLab old-D3D9 memory reporting + low queue depth preset
# Helps some UI-heavy DX9 games on large modern GPUs.
d3d9.maxAvailableMemory = 4096
d3d9.maxFrameLatency = 1
dxgi.maxFrameLatency = 1
"@
    }

    if ($Mode -eq "antistutter") {
        $experimentalQueryMitigation = ""
        if ((Get-LauncherReleaseChannel) -eq "experimental") {
            $experimentalQueryMitigation = @"
# Experimental Revelation D3D9 query-lock mitigation.
d3d9.revelationNonBlockingQueryFlush = True
d3d9.revelationLockTelemetry = True
"@
        }

        return @"
# RevelationLab neutral PvP frame-pacing preset
# Keep the tested VRAM budget, but avoid forcing optional DXVK debug/pacing knobs.
d3d9.maxAvailableMemory = 8192
# Keep one additional frame available so Present does not serialize
# concurrent UI texture uploads behind swapchain image acquisition.
d3d9.maxFrameLatency = 2
dxvk.latencySleep = Auto
dxvk.trackPipelineLifetime = Auto
dxvk.enableMemoryDefrag = Auto
$experimentalQueryMitigation
"@
    }

    if ($Mode -eq "aggressive") {
        return @"
# RevelationLab aggressive boost preset (updated 2026-04-14)
# Maximum low-latency path: shorter queue, forced no-vsync present path, and tighter pacing tolerance.
dxvk.allowFse = True
# Keep the larger VRAM budget that avoided texture eviction on modern GPUs.
d3d9.maxAvailableMemory = 8192
# 1 frame in queue: minimum queue depth before we start destabilizing the client.
d3d9.maxFrameLatency = 1
dxgi.maxFrameLatency = 1
# Force the present path to stay out of VSync-driven latency buildup.
d3d9.presentInterval = 0
dxgi.syncInterval = 0
# Keep DXVK pacing sleep enabled with the stable tolerance proven by prior captures.
dxvk.latencySleep = True
dxvk.latencyTolerance = 3000
# Preserve the stability helpers from the anti-stutter preset.
dxvk.trackPipelineLifetime = True
dxvk.enableMemoryDefrag = True
"@
    }

    return ""
}

function Get-TextFileContent {
    param([string]$Path)

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    return [System.IO.File]::ReadAllText($Path, $utf8NoBom)
}

function Set-TextFileContent {
    param(
        [string]$Path,
        [string]$Content
    )

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function Test-LabManagedTextFileMatches {
    param(
        [string]$Path,
        [string]$ExpectedContent
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $false
    }

    try {
        $actual = [System.IO.File]::ReadAllText($Path)
        $actualNormalized = ($actual -replace "`r`n?", "`n").TrimEnd([char[]]"`r`n")
        $expectedNormalized = ([string]$ExpectedContent -replace "`r`n?", "`n").TrimEnd([char[]]"`r`n")
        return [bool]($actualNormalized -ceq $expectedNormalized)
    } catch {
        return $false
    }
}

function Get-PresetValueFromText {
    param(
        [string]$Text,
        [hashtable]$Entry
    )

    $match = [regex]::Match($Text, $Entry.Regex)
    if (-not $match.Success) {
        throw "UI preset target not found: $($Entry.Name)"
    }

    return $match.Groups[3].Value.Trim()
}

function Try-GetPresetValueFromText {
    param(
        [string]$Text,
        [hashtable]$Entry
    )

    $match = [regex]::Match($Text, $Entry.Regex)
    if (-not $match.Success) {
        return [PSCustomObject]@{
            Found = $false
            Value = ""
        }
    }

    return [PSCustomObject]@{
        Found = $true
        Value = $match.Groups[3].Value.Trim()
    }
}

function Set-PresetValueInText {
    param(
        [string]$Text,
        [hashtable]$Entry,
        [string]$Value
    )

    $regex = [regex]::new($Entry.Regex)
    $match = $regex.Match($Text)
    if (-not $match.Success) {
        throw "UI preset target not found: $($Entry.Name)"
    }

    return $regex.Replace($Text, ('${1}${2}' + $Value + '${4}${5}'), 1)
}

function Upsert-PresetValueInText {
    param(
        [string]$Text,
        [hashtable]$Entry,
        [string]$Value
    )

    $regex = [regex]::new($Entry.Regex)
    $match = $regex.Match($Text)
    if ($match.Success) {
        return $regex.Replace($Text, ('${1}${2}' + $Value + '${4}${5}'), 1)
    }

    if ($Entry.ContainsKey("InsertBeforeRegex") -and $Entry.ContainsKey("InsertText")) {
        $insertRegex = [regex]::new($Entry.InsertBeforeRegex)
        if (-not $insertRegex.IsMatch($Text)) {
            throw "UI preset insertion target not found: $($Entry.Name)"
        }

        return $insertRegex.Replace($Text, ($Entry.InsertText + '${1}'), 1)
    }

    throw "UI preset target not found: $($Entry.Name)"
}

function Remove-PresetEntryInText {
    param(
        [string]$Text,
        [hashtable]$Entry
    )

    if ($Entry.ContainsKey("RemoveRegex")) {
        return ([regex]::new($Entry.RemoveRegex)).Replace($Text, "", 1)
    }

    return $Text
}

function Test-StatusIndicatorPositionSuspicious {
    param(
        [string]$X,
        [string]$Y
    )

    $parsedX = 0
    $parsedY = 0
    if ((-not [int]::TryParse(([string]$X).Trim(), [ref]$parsedX)) -or (-not [int]::TryParse(([string]$Y).Trim(), [ref]$parsedY))) {
        return $true
    }

    if (($parsedX -le -3000) -or ($parsedY -le -3000)) {
        return $true
    }

    return (($parsedX -le 50) -and ($parsedY -le 220))
}

function Protect-StatusIndicatorsInText {
    param([string]$Text)

    foreach ($widget in @(
            [PSCustomObject]@{ Name = "buffmotice"; X = "792"; Y = "748" }
            [PSCustomObject]@{ Name = "debuffmotice"; X = "1561"; Y = "757" }
        )) {
        $hiddenEntry = @{
            Name  = "ui.$($widget.Name).hidden"
            Regex = "(?s)(<$($widget.Name)>.*?<hidden>)(\s*)([^<]*?)(\s*)(</hidden>)"
        }
        $xEntry = @{
            Name  = "ui.$($widget.Name).x"
            Regex = "(?s)(<$($widget.Name)>.*?<x>)(\s*)([^<]*?)(\s*)(</x>)"
        }
        $yEntry = @{
            Name  = "ui.$($widget.Name).y"
            Regex = "(?s)(<$($widget.Name)>.*?<y>)(\s*)([^<]*?)(\s*)(</y>)"
        }

        $currentX = Try-GetPresetValueFromText -Text $Text -Entry $xEntry
        $currentY = Try-GetPresetValueFromText -Text $Text -Entry $yEntry
        if ($currentX.Found -and $currentY.Found -and (Test-StatusIndicatorPositionSuspicious -X $currentX.Value -Y $currentY.Value)) {
            $Text = Upsert-PresetValueInText -Text $Text -Entry $xEntry -Value $widget.X
            $Text = Upsert-PresetValueInText -Text $Text -Entry $yEntry -Value $widget.Y
        }

        $Text = Upsert-PresetValueInText -Text $Text -Entry $hiddenEntry -Value "0"
    }

    return $Text
}

function Find-UiPresetEntry {
    param(
        [object[]]$Definitions,
        [object]$StateEntry
    )

    $nameProperty = $StateEntry.PSObject.Properties["Name"]
    if ($nameProperty -and $nameProperty.Value) {
        foreach ($definition in $Definitions) {
            if ($definition.Name -eq [string]$nameProperty.Value) {
                return $definition
            }
        }
    }

    $pathProperty = $StateEntry.PSObject.Properties["Path"]
    if ($pathProperty -and $pathProperty.Value) {
        foreach ($definition in $Definitions) {
            if ($definition.LegacyPath -eq [string]$pathProperty.Value) {
                return $definition
            }
        }
    }

    return $null
}

function Find-VideoPresetEntry {
    param(
        [object[]]$Definitions,
        [object]$StateEntry
    )

    $nameProperty = $StateEntry.PSObject.Properties["Name"]
    if (-not $nameProperty -or -not $nameProperty.Value) {
        return $null
    }

    foreach ($definition in $Definitions) {
        if ($definition.Name -eq [string]$nameProperty.Value) {
            return $definition
        }
    }

    return $null
}

function Save-StateFile {
    param(
        [string]$Path,
        [object]$StateObject,
        [switch]$DryRunMode
    )

    Ensure-Directory -Path (Split-Path -Path $Path -Parent)
    if (-not $DryRunMode) {
        $StateObject | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Path -Encoding UTF8
    }
}

function Load-StateFile {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return $null
    }

    return (Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json)
}

function Ensure-UiState {
    param(
        [string]$ConfPath,
        [object[]]$Entries,
        [switch]$DryRunMode
    )

    $statePath = Get-UiStatePath
    $existing = Load-StateFile -Path $statePath
    if ($existing) {
        return $existing
    }

    $confText = Get-TextFileContent -Path $ConfPath
    $selectedEntries = @($Entries)
    if ($selectedEntries.Count -eq 0) {
        $selectedEntries = @(Get-UiPresetDefinition)
    }

    $values = foreach ($entry in $selectedEntries) {
        $result = Try-GetPresetValueFromText -Text $confText -Entry $entry
        [PSCustomObject]@{
            Name          = $entry.Name
            OriginalValue = $result.Value
            WasPresent    = [bool]$result.Found
        }
    }

    $state = [PSCustomObject]@{
        ConfPath = $ConfPath
        Values   = @($values)
    }

    Save-StateFile -Path $statePath -StateObject $state -DryRunMode:$DryRunMode
    return $state
}

function Ensure-DxvkState {
    param(
        [string]$DxvkPath,
        [switch]$DryRunMode
    )

    $statePath = Get-DxvkStatePath
    $existing = Load-StateFile -Path $statePath
    if ($existing) {
        return $existing
    }

    $exists = Test-Path -LiteralPath $DxvkPath
    $managedDxvkPath = Get-ManagedDxvkConfigPath
    $state = [PSCustomObject]@{
        Path              = $DxvkPath
        Exists            = $exists
        Content           = $(if ($exists) { Get-Content -LiteralPath $DxvkPath -Raw } else { "" })
        ManagedPath       = $managedDxvkPath
        ManagedExists     = [bool](Test-Path -LiteralPath $managedDxvkPath)
        ManagedContent    = $(if (Test-Path -LiteralPath $managedDxvkPath) { Get-Content -LiteralPath $managedDxvkPath -Raw } else { "" })
        PreviousEnvValue  = (Get-CurrentDxvkEnvValue)
    }

    Save-StateFile -Path $statePath -StateObject $state -DryRunMode:$DryRunMode
    return $state
}

function Get-RendererManagedFiles {
    param([string]$ResolvedGameDir)

    return @(
        [PSCustomObject]@{
            Name         = "d3d9.dll"
            ActivePath   = (Join-Path $ResolvedGameDir "d3d9.dll")
            DisabledPath = (Join-Path $ResolvedGameDir "d3d9.dll.revelationlab-disabled")
        }
        [PSCustomObject]@{
            Name         = "dxgi.dll"
            ActivePath   = (Join-Path $ResolvedGameDir "dxgi.dll")
            DisabledPath = (Join-Path $ResolvedGameDir "dxgi.dll.revelationlab-disabled")
        }
        [PSCustomObject]@{
            Name         = "d3d11.dll"
            ActivePath   = (Join-Path $ResolvedGameDir "d3d11.dll")
            DisabledPath = (Join-Path $ResolvedGameDir "d3d11.dll.revelationlab-disabled")
        }
    )
}

function Ensure-RendererState {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $statePath = Get-RendererStatePath
    $existing = Load-StateFile -Path $statePath
    if ($existing) {
        $existingFiles = @($existing.Files)
        $knownNames = @{}
        foreach ($file in $existingFiles) {
            if ($file.Name) {
                $knownNames[[string]$file.Name] = $true
            }
        }

        $addedFiles = @()
        foreach ($entry in Get-RendererManagedFiles -ResolvedGameDir $ResolvedGameDir) {
            if ($knownNames.ContainsKey([string]$entry.Name)) {
                continue
            }

            $activeExists = Test-Path -LiteralPath $entry.ActivePath
            $disabledExists = Test-Path -LiteralPath $entry.DisabledPath
            $originalState = if ($activeExists -and -not $disabledExists) {
                "active-only"
            } elseif ((-not $activeExists) -and $disabledExists) {
                "disabled-only"
            } elseif ($activeExists -and $disabledExists) {
                "both"
            } else {
                "missing"
            }

            $addedFiles += [PSCustomObject]@{
                Name          = $entry.Name
                ActivePath    = $entry.ActivePath
                DisabledPath  = $entry.DisabledPath
                OriginalState = $originalState
            }
        }

        if ($addedFiles.Count -gt 0) {
            $existing.Files = @($existingFiles + $addedFiles)
            Save-StateFile -Path $statePath -StateObject $existing -DryRunMode:$DryRunMode
        }

        return $existing
    }

    $files = foreach ($entry in Get-RendererManagedFiles -ResolvedGameDir $ResolvedGameDir) {
        $activeExists = Test-Path -LiteralPath $entry.ActivePath
        $disabledExists = Test-Path -LiteralPath $entry.DisabledPath
        $originalState = if ($activeExists -and -not $disabledExists) {
            "active-only"
        } elseif ((-not $activeExists) -and $disabledExists) {
            "disabled-only"
        } elseif ($activeExists -and $disabledExists) {
            "both"
        } else {
            "missing"
        }

        [PSCustomObject]@{
            Name          = $entry.Name
            ActivePath    = $entry.ActivePath
            DisabledPath  = $entry.DisabledPath
            OriginalState = $originalState
        }
    }

    $state = [PSCustomObject]@{
        Files = @($files)
    }

    Save-StateFile -Path $statePath -StateObject $state -DryRunMode:$DryRunMode
    return $state
}

function Ensure-VideoState {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $statePath = Get-VideoStatePath
    $existing = Load-StateFile -Path $statePath
    if ($existing) {
        return $existing
    }

    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    $tianyuPath = Get-TianyuConfigPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $confPath)) {
        throw "conf.xml not found: $confPath"
    }
    if (-not (Test-Path -LiteralPath $tianyuPath)) {
        throw "tianyu.xml not found: $tianyuPath"
    }

    $confText = Get-TextFileContent -Path $confPath
    $tianyuText = Get-TextFileContent -Path $tianyuPath
    $values = foreach ($entry in Get-VideoPresetDefinition) {
        $sourceText = if ($entry.File -eq "tianyu") { $tianyuText } else { $confText }
        [PSCustomObject]@{
            Name          = $entry.Name
            File          = $entry.File
            OriginalValue = (Get-PresetValueFromText -Text $sourceText -Entry $entry)
        }
    }

    $state = [PSCustomObject]@{
        ConfPath   = $confPath
        TianyuPath = $tianyuPath
        Values     = @($values)
    }

    Save-StateFile -Path $statePath -StateObject $state -DryRunMode:$DryRunMode
    return $state
}

function Get-CurrentUiPreset {
    param([string]$ResolvedGameDir)

    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $confPath)) {
        return "missing"
    }

    try {
        $confText = Get-TextFileContent -Path $confPath
        foreach ($mode in @("pvpselect", "masspvp", "binaryprobe", "spiritclean", "combatclean", "questcompat", "pvp", "declutter", "lite", "tooltipfix", "statusghost")) {
            $matches = $true
            foreach ($entry in (Get-UiPresetDefinition -Mode $mode)) {
                $result = Try-GetPresetValueFromText -Text $confText -Entry $entry
                if ((-not $result.Found) -or ($result.Value -ne $entry.Value)) {
                    $matches = $false
                    break
                }
            }

            if ($matches) {
                return $mode
            }
        }
    } catch {
        return "custom"
    }

    return "default"
}

function Get-CurrentDxvkPreset {
    param([string]$ResolvedGameDir)

    $dxvkPath = Get-EffectiveDxvkConfigPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $dxvkPath)) {
        return "off"
    }

    $current = ((Get-Content -LiteralPath $dxvkPath -Raw) -replace "\r\n", "`n").Trim()
    if (-not $current -or ($current -match '^\s*(#.*)?$')) {
        return "off"
    }

    $normalizeDxvkText = {
        param([string]$Text)

        return [string]::Join(
            "`n",
            @(
                foreach ($line in (($Text -replace "\r\n", "`n") -split "`n")) {
                    $trimmed = $line.Trim()
                    if ($trimmed -match '^d3d9\.maxFrameRate\s*=') {
                        continue
                    }
                    if ($trimmed -and (-not $trimmed.StartsWith("#"))) {
                        $trimmed
                    }
                }
            )
        )
    }

    $currentNormalized = & $normalizeDxvkText $current
    if (-not $currentNormalized) {
        return "off"
    }

    $pacing = & $normalizeDxvkText (Get-DxvkPresetContent -Mode "pacing")
    $legacyVram = & $normalizeDxvkText (Get-DxvkPresetContent -Mode "legacyvram")
    $legacyVramLatency1 = & $normalizeDxvkText (Get-DxvkPresetContent -Mode "legacyvram-latency1")
    $antistutter = & $normalizeDxvkText (Get-DxvkPresetContent -Mode "antistutter")
    $aggressive = & $normalizeDxvkText (Get-DxvkPresetContent -Mode "aggressive")
    if ($currentNormalized -eq $pacing) {
        return "pacing"
    }
    if ($currentNormalized -eq $legacyVram) {
        return "legacyvram"
    }
    if ($currentNormalized -eq $legacyVramLatency1) {
        return "legacyvram-latency1"
    }
    if ($currentNormalized -eq $antistutter) {
        return "antistutter"
    }
    if ($currentNormalized -eq $aggressive) {
        return "aggressive"
    }

    return "custom"
}

function Get-CurrentRendererPreset {
    param([string]$ResolvedGameDir)

    $activeCount = 0
    $disabledCount = 0
    foreach ($entry in Get-RendererManagedFiles -ResolvedGameDir $ResolvedGameDir) {
        if (Test-Path -LiteralPath $entry.ActivePath) {
            $activeCount += 1
        }
        if (Test-Path -LiteralPath $entry.DisabledPath) {
            $disabledCount += 1
        }
    }

    $managedCount = @((Get-RendererManagedFiles -ResolvedGameDir $ResolvedGameDir)).Count
    if ($activeCount -eq $managedCount -and $disabledCount -eq 0) {
        return "bundled"
    }
    if ($activeCount -eq 0 -and $disabledCount -eq $managedCount) {
        return "native"
    }
    return "custom"
}

function Get-CurrentVideoPreset {
    param([string]$ResolvedGameDir)

    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    $tianyuPath = Get-TianyuConfigPath -ResolvedGameDir $ResolvedGameDir
    if ((-not (Test-Path -LiteralPath $confPath)) -or (-not (Test-Path -LiteralPath $tianyuPath))) {
        return "missing"
    }

    try {
        $confText = Get-TextFileContent -Path $confPath
        $tianyuText = Get-TextFileContent -Path $tianyuPath
        foreach ($mode in @("game-extreme", "fullscreen", "pvp-brutal", "latency-cache", "latency", "cache")) {
            $matches = $true
            foreach ($entry in Get-VideoPresetDefinition -Mode $mode) {
                $sourceText = if ($entry.File -eq "tianyu") { $tianyuText } else { $confText }
                if ((Get-PresetValueFromText -Text $sourceText -Entry $entry) -ne $entry.Value) {
                    $matches = $false
                    break
                }
            }

            if ($matches) {
                return $mode
            }
        }
    } catch {
        return "custom"
    }

    return "default"
}

function Get-StockExePath {
    param([string]$ResolvedGameDir)
    return (Join-Path $ResolvedGameDir "tianyu.stock.exe")
}

function Get-VariantTable {
    param([string]$ResolvedGameDir)
    return @{
        official = @{
            Path        = (Get-StockExePath -ResolvedGameDir $ResolvedGameDir)
            Description = "Official 32-bit client captured from current tianyu.exe"
        }
        dx11 = @{
            Path        = (Join-Path $ResolvedGameDir "tianyu_dx11.exe")
            Description = "Experimental DX11 x64 client"
        }
        x64 = @{
            Path        = (Join-Path $ResolvedGameDir "tianyu64.exe")
            Description = "Experimental x64 DX9 client"
        }
        beta32 = @{
            Path        = (Join-Path $ResolvedGameDir "tianyu_beta.exe")
            Description = "Experimental 32-bit beta client"
        }
        beta64 = @{
            Path        = (Join-Path $ResolvedGameDir "tianyu64_beta.exe")
            Description = "Experimental x64 beta client"
        }
    }
}

function Get-FileSha256 {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        return $null
    }

    $stream = [System.IO.File]::Open(
        $Path,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::ReadWrite
    )
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([System.BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', ''))
    } finally {
        $sha.Dispose()
        $stream.Dispose()
    }
}

function New-RendererConflictBackupPath {
    param([string]$ActivePath)

    $dir = Split-Path -Parent $ActivePath
    $name = Split-Path -Leaf $ActivePath
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    for ($i = 0; $i -lt 100; $i += 1) {
        $suffix = if ($i -eq 0) { "" } else { "-" + $i }
        $candidate = Join-Path $dir ($name + ".revelationlab-conflict-" + $stamp + $suffix)
        if (-not (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }

    return (Join-Path $dir ($name + ".revelationlab-conflict-" + $stamp + "-" + [Guid]::NewGuid().ToString("N")))
}

function Ensure-StockBackup {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $targetExe = Get-TargetExePath -ResolvedGameDir $ResolvedGameDir
    $stockExe = Get-StockExePath -ResolvedGameDir $ResolvedGameDir

    if (-not (Test-Path -LiteralPath $targetExe)) {
        throw "Target executable not found: $targetExe"
    }

    if (Test-Path -LiteralPath $stockExe) {
        return
    }

    Write-Note "Creating stock backup: $stockExe"
    if (-not $DryRunMode) {
        Copy-Item -LiteralPath $targetExe -Destination $stockExe -Force
    }
}

function Get-CurrentVariant {
    param([string]$ResolvedGameDir)

    $targetExe = Get-TargetExePath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $targetExe)) {
        return "missing"
    }

    $targetHash = Get-FileSha256 -Path $targetExe
    $variants = Get-VariantTable -ResolvedGameDir $ResolvedGameDir

    foreach ($name in @("dx11", "x64", "beta32", "beta64", "official")) {
        $variantPath = $variants[$name].Path
        $variantHash = Get-FileSha256 -Path $variantPath
        if ($variantHash -and $variantHash -eq $targetHash) {
            return $name
        }
    }

    $stockExe = Get-StockExePath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $stockExe)) {
        return "official-like"
    }

    return "custom"
}

function Set-VariantImpl {
    param(
        [string]$ResolvedGameDir,
        [string]$RequestedVariant,
        [switch]$DryRunMode
    )

    $targetExe = Get-TargetExePath -ResolvedGameDir $ResolvedGameDir
    $stockExe = Get-StockExePath -ResolvedGameDir $ResolvedGameDir
    $variants = Get-VariantTable -ResolvedGameDir $ResolvedGameDir

    if ($RequestedVariant -ne "official") {
        Ensure-StockBackup -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode
    }

    $sourcePath = $variants[$RequestedVariant].Path
    if ($RequestedVariant -eq "official" -and -not (Test-Path -LiteralPath $sourcePath)) {
        Write-Note "No stock backup is present; keeping current tianyu.exe as the official baseline."
        return
    }

    if (-not (Test-Path -LiteralPath $sourcePath)) {
        throw "Requested variant is unavailable: $sourcePath"
    }

    Write-Note "Switching active tianyu.exe to '$RequestedVariant' from '$sourcePath'"
    if (-not $DryRunMode) {
        Copy-Item -LiteralPath $sourcePath -Destination $targetExe -Force
    }

    if ($RequestedVariant -eq "official" -and -not (Test-Path -LiteralPath $stockExe)) {
        Write-Note "No stock backup was present; current tianyu.exe remains the official baseline."
    }
}

function Get-RtssProfileTargets {
    return @(
        "tianyu.exe",
        "tianyu64.exe",
        "tianyu_dx11.exe",
        "tianyu_beta.exe",
        "tianyu64_beta.exe",
        "BrowserProxy.exe"
    )
}

function Set-UiPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [string]$Mode,
        [switch]$DryRunMode
    )

    if ($Mode -eq "default") {
        Restore-UiPresetImpl -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode
        return
    }

    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $confPath)) {
        throw "conf.xml not found: $confPath"
    }

    $definitions = @(Get-UiPresetDefinition -Mode $Mode)
    [void](Ensure-UiState -ConfPath $confPath -Entries $definitions -DryRunMode:$DryRunMode)

    $confText = Get-TextFileContent -Path $confPath
    foreach ($entry in $definitions) {
        $confText = Upsert-PresetValueInText -Text $confText -Entry $entry -Value $entry.Value
    }
    $confText = Protect-StatusIndicatorsInText -Text $confText

    Write-Note "Applying UI preset '$Mode' to $confPath"
    if (-not $DryRunMode) {
        Set-TextFileContent -Path $confPath -Content $confText
    }
}

function Restore-UiPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $statePath = Get-UiStatePath
    $state = Load-StateFile -Path $statePath
    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $confPath)) {
        throw "conf.xml not found: $confPath"
    }

    $definitions = @(Get-UiPresetDefinition)
    $confText = Get-TextFileContent -Path $confPath

    if (-not $state) {
        $baselinePath = $null
        foreach ($candidate in (Get-UiBaselineCandidatePaths -ResolvedGameDir $ResolvedGameDir)) {
            if (Test-Path -LiteralPath $candidate) {
                $baselinePath = $candidate
                break
            }
        }

        if (-not $baselinePath) {
            Write-Note "No UI preset state found and no UI baseline copy is available; nothing to restore."
            return
        }

        $baselineText = Get-TextFileContent -Path $baselinePath
        foreach ($definition in $definitions) {
            $baseline = Try-GetPresetValueFromText -Text $baselineText -Entry $definition
            if ($baseline.Found) {
                $confText = Upsert-PresetValueInText -Text $confText -Entry $definition -Value $baseline.Value
            } elseif ($definition.ContainsKey("RemoveRegex")) {
                $confText = Remove-PresetEntryInText -Text $confText -Entry $definition
            }
        }
        $confText = Protect-StatusIndicatorsInText -Text $confText

        Write-Note "Restoring UI preset changes in $confPath using baseline copy $baselinePath"
        if (-not $DryRunMode) {
            Set-TextFileContent -Path $confPath -Content $confText
        }
        return
    }

    foreach ($entry in @($state.Values)) {
        $definition = Find-UiPresetEntry -Definitions $definitions -StateEntry $entry
        if (-not $definition) {
            Write-Note "Skipping unknown UI preset state entry during restore."
            continue
        }

        $wasPresentProperty = $entry.PSObject.Properties["WasPresent"]
        $wasPresent = $true
        if ($wasPresentProperty) {
            $wasPresent = [bool]$wasPresentProperty.Value
        }

        if ($wasPresent) {
            $confText = Set-PresetValueInText -Text $confText -Entry $definition -Value ([string]$entry.OriginalValue)
        } else {
            $confText = Remove-PresetEntryInText -Text $confText -Entry $definition
        }
    }
    $confText = Protect-StatusIndicatorsInText -Text $confText

    Write-Note "Restoring UI preset changes in $confPath"
    if (-not $DryRunMode) {
        Set-TextFileContent -Path $confPath -Content $confText
        Remove-Item -LiteralPath $statePath -Force
    }
}

function Set-DxvkPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [string]$Mode,
        [switch]$DryRunMode
    )

    if ($Mode -eq "off") {
        Restore-DxvkPresetImpl -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode
        return
    }

    $dxvkPath = Get-DxvkConfigPath -ResolvedGameDir $ResolvedGameDir
    $managedDxvkPath = Get-ManagedDxvkConfigPath
    $content = Get-DxvkPresetContent -Mode $Mode
    $contentMatches = Test-LabManagedTextFileMatches -Path $managedDxvkPath -ExpectedContent $content
    Write-Note $(if ($contentMatches) { "DXVK preset '$Mode' already matches managed path $managedDxvkPath" } else { "Writing DXVK preset '$Mode' to managed path $managedDxvkPath" })
    if (-not $DryRunMode) {
        Ensure-Directory -Path (Split-Path -Parent $managedDxvkPath)
        if (-not $contentMatches) {
            Set-TextFileContent -Path $managedDxvkPath -Content $content
        }
        Set-CanonicalDxvkEnvironment -ManagedDxvkPath $managedDxvkPath
        $legacyStatePath = Get-DxvkStatePath
        if (Test-Path -LiteralPath $legacyStatePath) {
            Remove-Item -LiteralPath $legacyStatePath -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Note ("DXVK runtime path active via " + (Get-DxvkConfigEnvName) + ": " + $managedDxvkPath)
}

function Restore-DxvkPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $statePath = Get-DxvkStatePath
    $dxvkPath = Get-DxvkConfigPath -ResolvedGameDir $ResolvedGameDir
    $managedDxvkPath = Get-ManagedDxvkConfigPath
    $managedContent = "# RevelationLab managed DXVK config`r`n# baseline/off state`r`n"
    $contentMatches = Test-LabManagedTextFileMatches -Path $managedDxvkPath -ExpectedContent $managedContent

    Write-Note $(if ($contentMatches) { "DXVK runtime already matches baseline/off at managed path $managedDxvkPath." } else { "Restoring DXVK runtime to baseline/off at managed path $managedDxvkPath." })
    if (-not $DryRunMode) {
        Ensure-Directory -Path (Split-Path -Parent $managedDxvkPath)
        if (-not $contentMatches) {
            Set-TextFileContent -Path $managedDxvkPath -Content $managedContent
        }
        Set-CanonicalDxvkEnvironment -ManagedDxvkPath $managedDxvkPath
        if (Test-Path -LiteralPath $statePath) {
            Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Note ("DXVK runtime path synchronized via " + (Get-DxvkConfigEnvName) + ": " + $managedDxvkPath)
}

function Set-RendererPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [string]$Mode,
        [switch]$DryRunMode
    )

    if ($Mode -eq "bundled") {
        Restore-RendererPresetImpl -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode
        return
    }

    [void](Ensure-RendererState -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode)
    foreach ($entry in Get-RendererManagedFiles -ResolvedGameDir $ResolvedGameDir) {
        $activeExists = Test-Path -LiteralPath $entry.ActivePath
        $disabledExists = Test-Path -LiteralPath $entry.DisabledPath

        if ($activeExists -and (-not $disabledExists)) {
            Write-Note "Disabling bundled renderer library: $($entry.ActivePath)"
            if (-not $DryRunMode) {
                Move-Item -LiteralPath $entry.ActivePath -Destination $entry.DisabledPath -Force
            }
            continue
        }

        if ((-not $activeExists) -and $disabledExists) {
            Write-Note "Bundled renderer library already disabled: $($entry.Name)"
            continue
        }

        if ($activeExists -and $disabledExists) {
            $activeHash = Get-FileSha256 -Path $entry.ActivePath
            $disabledHash = Get-FileSha256 -Path $entry.DisabledPath
            if ($activeHash -and $disabledHash -and ($activeHash -eq $disabledHash)) {
                Write-Note "Native renderer self-heal: removing duplicate active renderer library: $($entry.ActivePath)"
                if (-not $DryRunMode) {
                    Remove-Item -LiteralPath $entry.ActivePath -Force
                }
                continue
            }

            $backupPath = New-RendererConflictBackupPath -ActivePath $entry.ActivePath
            Write-Note "Native renderer self-heal: moving conflicting active renderer library to backup: $backupPath"
            if (-not $DryRunMode) {
                try {
                    Move-Item -LiteralPath $entry.ActivePath -Destination $backupPath -Force -ErrorAction Stop
                } catch {
                    throw ("DXVK disabled but active renderer DLL could not be moved aside: " + $entry.ActivePath + ". " + $_.Exception.Message)
                }
            }
            continue
        }

        Write-Note "Renderer library is missing, so native D3D9 will rely on system components: $($entry.Name)"
    }
}

function Restore-RendererPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $statePath = Get-RendererStatePath
    $state = Load-StateFile -Path $statePath
    if (-not $state) {
        Write-Note "No renderer preset state found; nothing to restore."
        return
    }

    foreach ($entry in @($state.Files)) {
        $activePath = [string]$entry.ActivePath
        $disabledPath = [string]$entry.DisabledPath
        $activeExists = Test-Path -LiteralPath $activePath
        $disabledExists = Test-Path -LiteralPath $disabledPath

        switch ([string]$entry.OriginalState) {
            "active-only" {
                if ((-not $activeExists) -and $disabledExists) {
                    Write-Note "Restoring bundled renderer library: $activePath"
                    if (-not $DryRunMode) {
                        Move-Item -LiteralPath $disabledPath -Destination $activePath -Force
                    }
                } elseif ($disabledExists) {
                    Write-Note "Removing extra disabled renderer copy: $disabledPath"
                    if (-not $DryRunMode) {
                        Remove-Item -LiteralPath $disabledPath -Force
                    }
                }
            }
            "disabled-only" {
                if ($activeExists -and (-not $disabledExists)) {
                    Write-Note "Restoring disabled-only renderer state for: $disabledPath"
                    if (-not $DryRunMode) {
                        Move-Item -LiteralPath $activePath -Destination $disabledPath -Force
                    }
                } elseif ($activeExists) {
                    Write-Note "Removing extra active renderer copy: $activePath"
                    if (-not $DryRunMode) {
                        Remove-Item -LiteralPath $activePath -Force
                    }
                }
            }
            "missing" {
                foreach ($path in @($activePath, $disabledPath)) {
                    if (Test-Path -LiteralPath $path) {
                        Write-Note "Removing lab-created renderer file: $path"
                        if (-not $DryRunMode) {
                            Remove-Item -LiteralPath $path -Force
                        }
                    }
                }
            }
        }
    }

    if (-not $DryRunMode) {
        Remove-Item -LiteralPath $statePath -Force
    }
}

function Set-VideoPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [string]$Mode,
        [switch]$DryRunMode
    )

    if ($Mode -eq "default") {
        Restore-VideoPresetImpl -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode
        return
    }

    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    $tianyuPath = Get-TianyuConfigPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $confPath)) {
        throw "conf.xml not found: $confPath"
    }
    if (-not (Test-Path -LiteralPath $tianyuPath)) {
        throw "tianyu.xml not found: $tianyuPath"
    }

    [void](Ensure-VideoState -ResolvedGameDir $ResolvedGameDir -DryRunMode:$DryRunMode)

    $confText = Get-TextFileContent -Path $confPath
    $tianyuText = Get-TextFileContent -Path $tianyuPath
    foreach ($entry in Get-VideoPresetDefinition -Mode $Mode) {
        if ($entry.File -eq "tianyu") {
            $tianyuText = Set-PresetValueInText -Text $tianyuText -Entry $entry -Value $entry.Value
        } else {
            $confText = Set-PresetValueInText -Text $confText -Entry $entry -Value $entry.Value
        }
    }

    Write-Note "Applying video preset '$Mode' to $tianyuPath and $confPath"
    if (-not $DryRunMode) {
        Set-TextFileContent -Path $tianyuPath -Content $tianyuText
        Set-TextFileContent -Path $confPath -Content $confText
    }
}

function Restore-VideoPresetImpl {
    param(
        [string]$ResolvedGameDir,
        [switch]$DryRunMode
    )

    $statePath = Get-VideoStatePath
    $state = Load-StateFile -Path $statePath
    if (-not $state) {
        Write-Note "No video preset state found; nothing to restore."
        return
    }

    $confPath = Get-ConfPath -ResolvedGameDir $ResolvedGameDir
    $tianyuPath = Get-TianyuConfigPath -ResolvedGameDir $ResolvedGameDir
    if (-not (Test-Path -LiteralPath $confPath)) {
        throw "conf.xml not found: $confPath"
    }
    if (-not (Test-Path -LiteralPath $tianyuPath)) {
        throw "tianyu.xml not found: $tianyuPath"
    }

    $definitions = @(Get-VideoPresetDefinition)
    $confText = Get-TextFileContent -Path $confPath
    $tianyuText = Get-TextFileContent -Path $tianyuPath
    foreach ($entry in @($state.Values)) {
        $definition = Find-VideoPresetEntry -Definitions $definitions -StateEntry $entry
        if (-not $definition) {
            Write-Note "Skipping unknown video preset state entry during restore."
            continue
        }

        if ($definition.File -eq "tianyu") {
            $tianyuText = Set-PresetValueInText -Text $tianyuText -Entry $definition -Value ([string]$entry.OriginalValue)
        } else {
            $confText = Set-PresetValueInText -Text $confText -Entry $definition -Value ([string]$entry.OriginalValue)
        }
    }

    Write-Note "Restoring video preset changes in $tianyuPath and $confPath"
    if (-not $DryRunMode) {
        Set-TextFileContent -Path $tianyuPath -Content $tianyuText
        Set-TextFileContent -Path $confPath -Content $confText
        Remove-Item -LiteralPath $statePath -Force
    }
}

function Get-RtssBackupRoot {
    if ($script:EffectiveLauncherRoot) {
        return (Join-Path $script:EffectiveLauncherRoot ".revelation-lab\rtss-backups")
    }
    return (Join-Path $PSScriptRoot ".revelation-lab\rtss-backups")
}

function New-RtssBackupFolder {
    $backupRoot = Get-RtssBackupRoot
    if (-not (Test-Path -LiteralPath $backupRoot)) {
        New-Item -ItemType Directory -Path $backupRoot | Out-Null
    }

    $stamp = Get-Date -Format "yyyyMMdd-HHmmss-fff"
    $backupDir = Join-Path $backupRoot $stamp
    New-Item -ItemType Directory -Path $backupDir | Out-Null
    return $backupDir
}

function Backup-RtssProfiles {
    param(
        [string]$ProfilesDir,
        [switch]$DryRunMode
    )

    $targets = Get-RtssProfileTargets
    $existing = @()
    foreach ($target in $targets) {
        $profilePath = Join-Path $ProfilesDir $target
        if (Test-Path -LiteralPath $profilePath) {
            $existing += $profilePath
        }
    }

    if ($existing.Count -eq 0) {
        return $null
    }

    $backupDir = New-RtssBackupFolder
    Write-Note "Backing up existing RTSS profiles to $backupDir"
    if (-not $DryRunMode) {
        foreach ($profilePath in $existing) {
            Copy-Item -LiteralPath $profilePath -Destination $backupDir -Force
        }
    }
    return $backupDir
}

function Get-RtssProfileContent {
    param([string]$Mode)

    if ($Mode -eq "exclude") {
        return @"
[Hooking]
EnableHooking=0
"@
    }

    return @"
[Hooking]
EnableHooking=1
InjectionDelay=15000
InjectionDelayTriggers=IGO.dll,IGO64.dll,GameOverlayRenderer.dll,GameOverlayRenderer64.dll,overlay32.dll,overlay64.dll,DiscordOverlay.dll,DiscordOverlay64.dll,EOSOVH-Win32-Shipping.dll,EOSOVH-Win64-Shipping.dll,EOSSDK-Win32-Shipping.dll,EOSSDK-Win64-Shipping.dll,GCLay.dll,GCLay64.dll
EnableReinjection=1
GCLayCompatibilityFlags=1
"@
}

function Install-RtssProfilesImpl {
    param(
        [string]$ProfilesDir,
        [string]$Mode,
        [switch]$DryRunMode
    )

    if (-not (Test-Path -LiteralPath $ProfilesDir)) {
        throw "RTSS Profiles directory not found: $ProfilesDir"
    }

    $targets = Get-RtssProfileTargets
    $profileContent = Get-RtssProfileContent -Mode $Mode
    $profilesMatch = $true
    foreach ($target in $targets) {
        $profilePath = Join-Path $ProfilesDir $target
        if (-not (Test-LabManagedTextFileMatches -Path $profilePath -ExpectedContent $profileContent)) {
            $profilesMatch = $false
            break
        }
    }
    if ($profilesMatch) {
        Write-Note "RTSS profiles already match mode '$Mode'; repeated backup and write skipped."
        return
    }

    $backupDir = Backup-RtssProfiles -ProfilesDir $ProfilesDir -DryRunMode:$DryRunMode
    if ($backupDir) {
        Write-Note "RTSS backup created: $backupDir"
    } else {
        Write-Note "No existing Revelation RTSS profiles were found to back up."
    }

    foreach ($target in $targets) {
        $profilePath = Join-Path $ProfilesDir $target
        Write-Note "Writing RTSS profile [$Mode] for $target"
        if (-not $DryRunMode) {
            Set-Content -LiteralPath $profilePath -Value $profileContent -Encoding ASCII
        }
    }
}

function Restore-RtssProfilesImpl {
    param(
        [string]$ProfilesDir,
        [switch]$DryRunMode
    )

    $backupRoot = Get-RtssBackupRoot
    if (-not (Test-Path -LiteralPath $backupRoot)) {
        Write-Note "No RTSS backup root found; nothing to restore."
        return
    }

    $latestBackup = Get-ChildItem -LiteralPath $backupRoot -Directory |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if (-not $latestBackup) {
        Write-Note "No RTSS backup folders were found; nothing to restore."
        return
    }

    Write-Note "Restoring RTSS profiles from $($latestBackup.FullName)"

    foreach ($target in Get-RtssProfileTargets) {
        $profilePath = Join-Path $ProfilesDir $target
        $backupProfilePath = Join-Path $latestBackup.FullName $target

        if (-not $DryRunMode) {
            if (Test-Path -LiteralPath $profilePath) {
                Remove-Item -LiteralPath $profilePath -Force
            }
            if (Test-Path -LiteralPath $backupProfilePath) {
                Copy-Item -LiteralPath $backupProfilePath -Destination $profilePath -Force
            }
        }

        if (Test-Path -LiteralPath $backupProfilePath) {
            Write-Note "Restored $target"
        } else {
            Write-Note "Removed lab profile for $target"
        }
    }
}

function Show-Status {
    param(
        [string]$ResolvedGameDir,
        [string]$ProfilesDir
    )

    $targetExe = Get-TargetExePath -ResolvedGameDir $ResolvedGameDir
    $stockExe = Get-StockExePath -ResolvedGameDir $ResolvedGameDir
    $variants = Get-VariantTable -ResolvedGameDir $ResolvedGameDir
    $currentVariant = Get-CurrentVariant -ResolvedGameDir $ResolvedGameDir
    $currentUiPreset = Get-CurrentUiPreset -ResolvedGameDir $ResolvedGameDir
    $currentDxvkPreset = Get-CurrentDxvkPreset -ResolvedGameDir $ResolvedGameDir
    $currentRendererPreset = Get-CurrentRendererPreset -ResolvedGameDir $ResolvedGameDir
    $currentVideoPreset = Get-CurrentVideoPreset -ResolvedGameDir $ResolvedGameDir
    $managedDxvkPath = Get-ManagedDxvkConfigPath
    $effectiveDxvkPath = Get-EffectiveDxvkConfigPath -ResolvedGameDir $ResolvedGameDir
    $currentDxvkEnvValue = Get-CurrentDxvkEnvValue

    Write-Note "LauncherRoot: $(if ($script:EffectiveLauncherRoot) { $script:EffectiveLauncherRoot } else { $PSScriptRoot })"
    Write-Note "GameDir: $ResolvedGameDir"
    Write-Note "Active target: $targetExe"
    Write-Note "Current active variant: $currentVariant"
    Write-Note "Stock backup present: $(Test-Path -LiteralPath $stockExe)"
    Write-Note "Current UI preset: $currentUiPreset"
    Write-Note "Current DXVK preset: $currentDxvkPreset"
    Write-Note "DXVK managed path: $managedDxvkPath"
    Write-Note "DXVK effective path: $effectiveDxvkPath"
    Write-Note "DXVK_CONFIG_FILE: $(if ($currentDxvkEnvValue) { $currentDxvkEnvValue } else { "<unset>" })"
    Write-Note "Current renderer preset: $currentRendererPreset"
    Write-Note "Current video preset: $currentVideoPreset"

    foreach ($name in @("official", "dx11", "x64", "beta32", "beta64")) {
        $path = $variants[$name].Path
        $exists = Test-Path -LiteralPath $path
        Write-Note ("Variant {0,-8} -> {1} [{2}]" -f $name, $path, ($(if ($exists) { "present" } else { "missing" })))
    }

    Write-Note "RTSS ProfilesDir: $ProfilesDir"
    foreach ($target in Get-RtssProfileTargets) {
        $profilePath = Join-Path $ProfilesDir $target
        if (Test-Path -LiteralPath $profilePath) {
            Write-Note "RTSS override present: $profilePath"
        }
    }
}

function Show-StatusIfRequested {
    param(
        [string]$ResolvedGameDir,
        [string]$ProfilesDir
    )

    if (-not $SkipStatus) {
        Show-Status -ResolvedGameDir $ResolvedGameDir -ProfilesDir $ProfilesDir
    }
}

function Show-Help {
    Write-Host @"
RevelationLab.ps1

Usage examples:
  .\RevelationLab.ps1 Status
  .\RevelationLab.ps1 SetVariant dx11
  .\RevelationLab.ps1 SetVariant official
  .\RevelationLab.ps1 InstallRtss exclude
  .\RevelationLab.ps1 InstallRtss delay
  .\RevelationLab.ps1 SetUiPreset lite
  .\RevelationLab.ps1 RestoreUiPreset
  .\RevelationLab.ps1 SetDxvkPreset pacing
  .\RevelationLab.ps1 SetDxvkPreset legacyvram
  .\RevelationLab.ps1 SetDxvkPreset legacyvram-latency1
  .\RevelationLab.ps1 SetDxvkPreset aggressive
  .\RevelationLab.ps1 RestoreDxvkPreset
  .\RevelationLab.ps1 SetRendererPreset native
  .\RevelationLab.ps1 RestoreRendererPreset
  .\RevelationLab.ps1 SetVideoPreset fullscreen
  .\RevelationLab.ps1 SetVideoPreset latency
  .\RevelationLab.ps1 SetVideoPreset cache
  .\RevelationLab.ps1 SetVideoPreset latency-cache
  .\RevelationLab.ps1 SetVideoPreset game-extreme
  .\RevelationLab.ps1 SetVideoPreset pvp-brutal
  .\RevelationLab.ps1 RestoreVideoPreset
  .\RevelationLab.ps1 RestoreRtss
  .\RevelationLab.ps1 RestoreAll

What it does:
  - Switches which binary is exposed as game\tianyu.exe for VK Play launches.
  - Creates per-game RTSS profiles for Revelation executables only.
  - Applies a reversible UI-lite preset to conf.xml.
  - Applies reversible dxvk.conf presets for frame pacing or old-D3D9 VRAM reporting.
  - Can temporarily disable bundled d3d9.dll/d3d11.dll/dxgi.dll to force native system D3D.
  - Can apply low-level video presets to tianyu.xml/conf.xml, including split latency/cache tests.

Notes:
  - The first non-official switch captures the current tianyu.exe as tianyu.stock.exe.
  - After switching, launch the game from VK Play as usual.
  - If the game updates, refresh your stock backup manually before more swaps.
  - RTSS profile install may require elevated rights if Program Files is protected.
"@
}

$resolvedGameDir = Get-ResolvedGameDir -ConfiguredGameDir $GameDir
$script:EffectiveLauncherRoot = Resolve-EffectiveLauncherRoot -ConfiguredLauncherRoot $LauncherRoot -ResolvedGameDir $resolvedGameDir
$resolvedRtssProfilesDir = Get-ResolvedRtssProfilesDir -ConfiguredRtssProfilesDir $RtssProfilesDir

switch ($Action) {
    "Status" {
        Show-Status -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "SetVariant" {
        Set-VariantImpl -ResolvedGameDir $resolvedGameDir -RequestedVariant $Variant -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "InstallRtss" {
        Install-RtssProfilesImpl -ProfilesDir $resolvedRtssProfilesDir -Mode $RtssMode -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "RestoreRtss" {
        Restore-RtssProfilesImpl -ProfilesDir $resolvedRtssProfilesDir -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "SetUiPreset" {
        Set-UiPresetImpl -ResolvedGameDir $resolvedGameDir -Mode $UiPreset -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "RestoreUiPreset" {
        Restore-UiPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "SetDxvkPreset" {
        Set-DxvkPresetImpl -ResolvedGameDir $resolvedGameDir -Mode $DxvkPreset -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "RestoreDxvkPreset" {
        Restore-DxvkPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "SetRendererPreset" {
        Set-RendererPresetImpl -ResolvedGameDir $resolvedGameDir -Mode $RendererPreset -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "RestoreRendererPreset" {
        Restore-RendererPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "SetVideoPreset" {
        Set-VideoPresetImpl -ResolvedGameDir $resolvedGameDir -Mode $VideoPreset -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "RestoreVideoPreset" {
        Restore-VideoPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "RestoreAll" {
        Restore-DxvkPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Restore-RendererPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Restore-VideoPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Restore-UiPresetImpl -ResolvedGameDir $resolvedGameDir -DryRunMode:$DryRun
        Restore-RtssProfilesImpl -ProfilesDir $resolvedRtssProfilesDir -DryRunMode:$DryRun
        Set-VariantImpl -ResolvedGameDir $resolvedGameDir -RequestedVariant "official" -DryRunMode:$DryRun
        Show-StatusIfRequested -ResolvedGameDir $resolvedGameDir -ProfilesDir $resolvedRtssProfilesDir
    }
    "Help" {
        Show-Help
    }
}
