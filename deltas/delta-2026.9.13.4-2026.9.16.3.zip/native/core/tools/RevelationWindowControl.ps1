[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet('Status', 'Restore', 'Minimize')]
    [string]$Action
)

$ErrorActionPreference = 'Stop'

if (-not ('RevelationToolkit.WindowControlNative' -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace RevelationToolkit
{
    public static class WindowControlNative
    {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool BringWindowToTop(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern IntPtr SetFocus(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, IntPtr processId);

        [DllImport("kernel32.dll")]
        public static extern uint GetCurrentThreadId();

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool attach);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxCount);

        public static uint GetWindowProcessId(IntPtr hWnd)
        {
            uint processId;
            GetWindowThreadProcessId(hWnd, out processId);
            return processId;
        }

        public static string GetWindowTitle(IntPtr hWnd)
        {
            if (hWnd == IntPtr.Zero)
                return String.Empty;

            StringBuilder text = new StringBuilder(1024);
            GetWindowText(hWnd, text, text.Capacity);
            return text.ToString();
        }

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool PostMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

        public static bool ForceForegroundWindow(IntPtr target)
        {
            IntPtr foreground = GetForegroundWindow();
            uint currentThread = GetCurrentThreadId();
            uint targetThread = GetWindowThreadProcessId(target, IntPtr.Zero);
            uint foregroundThread = foreground == IntPtr.Zero
                ? 0u
                : GetWindowThreadProcessId(foreground, IntPtr.Zero);
            bool attachedForeground = false;
            bool attachedTarget = false;

            try
            {
                if (foregroundThread != 0u && foregroundThread != currentThread)
                    attachedForeground = AttachThreadInput(currentThread, foregroundThread, true);
                if (targetThread != 0u && targetThread != currentThread)
                    attachedTarget = AttachThreadInput(currentThread, targetThread, true);

                BringWindowToTop(target);
                bool accepted = SetForegroundWindow(target);
                SetFocus(target);
                return accepted || GetForegroundWindow() == target;
            }
            finally
            {
                if (attachedTarget)
                    AttachThreadInput(currentThread, targetThread, false);
                if (attachedForeground)
                    AttachThreadInput(currentThread, foregroundThread, false);
            }
        }
    }
}
"@
}

$currentSessionId = [int][Diagnostics.Process]::GetCurrentProcess().SessionId
$candidates = @(Get-Process -Name 'tianyu' -ErrorAction SilentlyContinue | Where-Object {
        $_.SessionId -eq $currentSessionId -and $_.MainWindowHandle -ne [IntPtr]::Zero
    })

if ($candidates.Count -ne 1) {
    throw "Ожидалось ровно одно окно tianyu.exe, найдено: $($candidates.Count)."
}

$game = $candidates[0]
$handle = [IntPtr]([int64]$game.MainWindowHandle)
$requested = $true
$systemCommandAccepted = $false
$focused = $false

switch ($Action) {
    'Restore' {
        $requested = [RevelationToolkit.WindowControlNative]::ShowWindowAsync($handle, 9)
        $systemCommandAccepted = [RevelationToolkit.WindowControlNative]::PostMessage($handle, 0x0112, [UIntPtr]([UInt64]0xF120), [IntPtr]::Zero)
        $requested = [bool]($requested -or $systemCommandAccepted)
        Start-Sleep -Milliseconds 220
        $focused = [RevelationToolkit.WindowControlNative]::ForceForegroundWindow($handle)
    }
    'Minimize' {
        $requested = [RevelationToolkit.WindowControlNative]::ShowWindowAsync($handle, 6)
        $systemCommandAccepted = [RevelationToolkit.WindowControlNative]::PostMessage($handle, 0x0112, [UIntPtr]([UInt64]0xF020), [IntPtr]::Zero)
        $requested = [bool]($requested -or $systemCommandAccepted)
    }
}

if ($Action -ne 'Status') {
    $deadline = [DateTime]::UtcNow.AddSeconds(3)
    do {
        Start-Sleep -Milliseconds 100
        $isMinimized = [RevelationToolkit.WindowControlNative]::IsIconic($handle)
        $stateMatches = if ($Action -eq 'Minimize') { $isMinimized } else { -not $isMinimized }
    } while (-not $stateMatches -and [DateTime]::UtcNow -lt $deadline)
}

$minimized = [RevelationToolkit.WindowControlNative]::IsIconic($handle)
$foregroundHandle = [RevelationToolkit.WindowControlNative]::GetForegroundWindow()
$foreground = ([int64]$foregroundHandle -eq [int64]$handle)
$foregroundProcessId = [int][RevelationToolkit.WindowControlNative]::GetWindowProcessId($foregroundHandle)
$foregroundProcessName = ''
if ($foregroundProcessId -gt 0) {
    try {
        $foregroundProcessName = [string](Get-Process -Id $foregroundProcessId -ErrorAction Stop).ProcessName
    } catch {
        $foregroundProcessName = ''
    }
}
$success = switch ($Action) {
    'Status' { $true }
    'Restore' { -not $minimized }
    'Minimize' { $minimized }
}

[ordered]@{
    action          = $Action
    success         = [bool]$success
    requestAccepted = [bool]$requested
    systemCommandAccepted = [bool]$systemCommandAccepted
    processId       = [int]$game.Id
    handle          = [int64]$handle
    minimized       = [bool]$minimized
    visible         = [bool][RevelationToolkit.WindowControlNative]::IsWindowVisible($handle)
    foreground      = [bool]$foreground
    foregroundHandle = [int64]$foregroundHandle
    foregroundProcessId = $foregroundProcessId
    foregroundProcessName = $foregroundProcessName
    foregroundWindowTitle = [RevelationToolkit.WindowControlNative]::GetWindowTitle($foregroundHandle)
    focusAccepted   = [bool]$focused
    windowTitle     = [string]$game.MainWindowTitle
} | ConvertTo-Json -Compress

if (-not $success) {
    exit 2
}
