# Native, exact-client world travel. Dot-source after RevelationGameBridge.ps1.
# No process launch, deployment, arbitrary script execution, input or blind retries.
function Get-RevelationWorldNavigationState {
    param($Probe)
    $states=@($Probe.events | Where-Object { $_.event -eq 'world_map_state' })
    if ($states.Count -ne 1) { throw 'world_navigation_state_missing' }
    $state=$states[0]
    foreach ($field in @('position_ready','position_x','position_y','position_z','in_world','player_present','player_in_world','combat','life','life_alive','modal','player_loading','global_loading','loaded','space_no','map_space_no')) {
        if (-not $state.PSObject.Properties[$field]) { throw 'world_navigation_state_incomplete' }
    }
    if ($state.position_ready -ne $true -or $state.in_world -ne $true -or $state.player_present -ne $true -or
        $state.player_in_world -ne 1 -or $state.combat -ne 0 -or $state.life -ne $state.life_alive -or
        $state.modal -ne 0 -or $state.player_loading -notin @(-1,0) -or $state.global_loading -notin @(-1,0) -or $state.loaded -ne 1) {
        throw 'world_navigation_state_not_safe'
    }
    foreach ($field in @('position_x','position_y','position_z')) {
        $value=[double]$state.$field
        if ([double]::IsNaN($value) -or [double]::IsInfinity($value) -or [Math]::Abs($value) -gt 1000000) { throw 'world_navigation_coordinate_invalid' }
    }
    return $state
}

function Get-RevelationWorldNavigationTarget {
    param($Probe,[Parameter(Mandatory)][ValidateRange(1,2147483647)][int]$NpcId)
    $state=Get-RevelationWorldNavigationState -Probe $Probe
    $candidates=@($Probe.events | Where-Object { $_.event -eq 'world_map_candidate' -and $_.npc_id -eq $NpcId })
    if ($candidates.Count -ne 1) { throw 'world_navigation_destination_ambiguous_or_missing' }
    $candidate=$candidates[0]
    foreach ($field in @('active','visible','ordinal','seek_id','npc_id','seek_space_no','seek_position_ready','seek_x','seek_y','seek_z')) {
        if (-not $candidate.PSObject.Properties[$field]) { throw 'world_navigation_destination_incomplete' }
    }
    if ($candidate.active -ne $true -or $candidate.visible -ne $true -or $candidate.seek_position_ready -ne $true -or [int]$candidate.ordinal -lt 0 -or [int]$candidate.ordinal -gt 255 -or [int]$candidate.seek_id -le 0 -or [int]$candidate.seek_space_no -le 0) { throw 'world_navigation_destination_unavailable' }
    foreach ($field in @('seek_x','seek_y','seek_z')) {
        $value=[double]$candidate.$field
        if ([double]::IsNaN($value) -or [double]::IsInfinity($value) -or [Math]::Abs($value) -gt 1000000) { throw 'world_navigation_coordinate_invalid' }
    }
    return [pscustomobject]@{ npcId=$NpcId; seekId=[int]$candidate.seek_id; index=[int]$candidate.ordinal; x=[double]$candidate.seek_x; y=[double]$candidate.seek_y; z=[double]$candidate.seek_z; spaceNo=[int]$candidate.seek_space_no; sourceSpaceNo=[int]$state.space_no }
}

function Test-RevelationWorldNavigationConfirmation {
    param($Result,$Target)
    try {
        $row=$Result.terminal
        foreach ($field in @('owned','fresh_request','same_space','same_map','state_safe','message_key_match')) { if ($row.$field -ne $true) { return $false } }
        if ($row.requested_npc -ne $Target.npcId -or $row.requested_seek -ne $Target.seekId -or $row.dialog_count_before -ne 0 -or $row.dialog_count_now -ne 1 -or $row.record_count -ne 6 -or $row.button_count -ne 2) { return $false }
        $buttons=@($Result.events | Where-Object { $_.event -eq 'world_map_teleport_confirmation_button' -and $_.index -eq 0 })
        if ($buttons.Count -ne 1) { return $false }
        $button=$buttons[0]
        return ($button.button_type -ceq 'MBButton' -and $button.callback_type -ceq 'Functor' -and
            $button.call_hash -ceq '15d26224f875290247ef06c7d7c30edaae09263c2c7f5dc7fe137f48505d9a52' -and
            $button.fn_type -ceq 'instancemethod' -and $button.fn_name -ceq '_teleportConfirmOK' -and
            $button.fn_hash -ceq 'c0ee2c4beddb2d85a6e622b160b4a79e361c27ea4541ac0a66ded9b24bda936f' -and
            $button.args_type -ceq 'tuple' -and $button.args_count -eq 1 -and $button.arg0_type -ceq 'int' -and
            $button.arg0_int -eq $Target.npcId -and $button.enabled -eq 1 -and $button.dismiss -eq 1 -and
            $button.forbid_key -eq 0 -and $button.fast_key -eq 21)
    } catch { return $false }
}

function Test-RevelationWorldNavigationArrival {
    param($Probe,$Target,[ValidateRange(1,50)][double]$ArrivalRadius=25)
    try {
        $state=Get-RevelationWorldNavigationState -Probe $Probe
        $distance=[Math]::Sqrt([Math]::Pow([double]$state.position_x-$Target.x,2)+[Math]::Pow([double]$state.position_y-$Target.y,2)+[Math]::Pow([double]$state.position_z-$Target.z,2))
        return ([int]$state.space_no -eq $Target.spaceNo -and $distance -le $ArrivalRadius)
    } catch { return $false }
}

function Get-RevelationWorldNavigationSequence {
    param([object[]]$Events,[long]$ControlSequence=0,[long]$StateSequence=0)
    $maximum=[Math]::Max($ControlSequence,$StateSequence)
    foreach ($row in $Events) { if ($row.PSObject.Properties['sequence']) { $maximum=[Math]::Max($maximum,[long]$row.sequence) } }
    if ($maximum -lt 0 -or $maximum -ge [int]::MaxValue) { throw 'world_navigation_sequence_exhausted' }
    return [int]($maximum+1)
}

function Assert-RevelationWorldNavigationIdentity {
    param($Context)
    Sync-RevelationDummyRouteConsumption -Context $Context
    $session=$Context.session
    $processes=@(Get-RevelationGameBridgeProcesses -GameDir $session.gameDir)
    if ($processes.Count -ne 1 -or $processes[0].Id -ne $Context.pid -or $processes[0].StartTime.ToUniversalTime().Ticks -ne $Context.processStartTicks) { throw 'world_navigation_process_identity_changed' }
    $current=Get-RevelationGameBridgeSession -LauncherRoot $Context.launcherRoot -GameDir $session.gameDir
    if (-not $current -or $current.nonce -cne $session.nonce -or $current.bridgeHash -ne $session.bridgeHash -or [IO.Path]::GetFullPath($current.sessionRoot) -ne [IO.Path]::GetFullPath($session.sessionRoot)) { throw 'world_navigation_session_changed' }
    if ((Get-RevelationGameBridgeSha256 -Path (Join-Path $session.gameDir 'version.dll')) -ne $session.bridgeHash) { throw 'world_navigation_module_hash_changed' }
    if ([IO.File]::ReadAllText($Context.iniPath) -cne $Context.expectedIni) { throw 'world_navigation_arming_changed' }
    if (Test-Path -LiteralPath (Join-Path $session.sessionRoot 'run.ini')) { throw 'world_navigation_tower_run_busy' }
}

function New-RevelationWorldNavigationContext {
    param($Session,[int]$GameProcessId,[scriptblock]$IsCancelled)
    if (-not $Session -or $Session.releaseChannel -ne 'experimental' -or $Session.nonce -notmatch '^[a-f0-9]{32}$' -or $Session.bridgeHash -notmatch '^[a-fA-F0-9]{64}$') { throw 'world_navigation_session_invalid' }
    $sessionRoot=[IO.Path]::GetFullPath($Session.sessionRoot).TrimEnd('\')
    $expectedSuffix='\.revelation-combat\game-bridge\'+$Session.nonce
    if (-not $sessionRoot.EndsWith($expectedSuffix,[StringComparison]::OrdinalIgnoreCase)) { throw 'world_navigation_session_path_invalid' }
    if (& $IsCancelled) { throw [OperationCanceledException]::new() }
    $lease=$null
    try {
        try { $lease=[IO.File]::Open((Join-Path $sessionRoot 'command.lock'),'OpenOrCreate','ReadWrite','None') }
        catch [IO.IOException] { throw 'world_navigation_command_busy_no_action' }
        $iniPath=Join-Path $Session.gameDir 'revelation-game-bridge.ini'
        $original=[IO.File]::ReadAllText($iniPath)
        $map=Get-RevelationGameBridgeIni -Path $iniPath
        if ($map['nonce'] -cne $Session.nonce -or $map['enabled'] -ne '1') { throw 'world_navigation_session_changed' }
        foreach ($flag in @('allowExit','allowFunctions','allowSnapshot','allowCombatTest','allowCombatTarget','allowCombatMove','allowTeleport','allowTeleportConfirm','allowMapExit','allowMapUi','allowDummyRoute')) {
            if ($map.ContainsKey($flag) -and $map[$flag] -ne '0') { throw 'world_navigation_existing_armed_operation' }
        }
        $processes=@(Get-RevelationGameBridgeProcesses -GameDir $Session.gameDir)
        if ($processes.Count -ne 1 -or $processes[0].Id -ne $GameProcessId) { throw 'world_navigation_process_identity_changed' }
        $context=[pscustomobject]@{ session=$Session; pid=$GameProcessId; processStartTicks=$processes[0].StartTime.ToUniversalTime().Ticks;
            launcherRoot=$sessionRoot.Substring(0,$sessionRoot.Length-$expectedSuffix.Length); iniPath=$iniPath; originalIni=$original; originalBytes=[IO.File]::ReadAllBytes($iniPath); expectedIni=$original; map=$map; lease=$lease; cancelled=$IsCancelled; calls=[Collections.Generic.List[object]]::new(); armingRestored=$false; allowDummyConsumption=$false }
        Assert-RevelationWorldNavigationIdentity -Context $context
        $events=@(Get-RevelationGameBridgeEvents -Session $Session | Where-Object { $_.pid -eq $GameProcessId })
        if (-not @($events | Where-Object { $_.event -eq 'worker_ready_read_only' -and $_.protocol -eq 2 }).Count -or @($events | Where-Object { $_.event -match 'worker_disabled|native_exception_disabled|fingerprint_rejected' }).Count) { throw 'world_navigation_worker_not_ready' }
        Set-RevelationWorldNavigationArm -Context $context
        return $context
    } catch { if ($lease) { $lease.Dispose() }; throw }
}

function Set-RevelationWorldNavigationArm {
    param($Context,[switch]$Teleport,[switch]$Confirm,[switch]$MapUi,[switch]$DummyRoute)
    Assert-RevelationWorldNavigationIdentity -Context $Context
    $map=$Context.map.Clone()
    $map['allowFunctions']='1'; $map['allowEnter']='0'; $map['allowTeleport']=[string][int][bool]$Teleport
    $map['allowTeleportConfirm']=[string][int][bool]$Confirm; $map['allowMapUi']=[string][int][bool]$MapUi
    $map['allowDummyRoute']=[string][int][bool]$DummyRoute
    $text="[lab]`r`n"+(($map.Keys|Sort-Object|ForEach-Object { $_+'='+$map[$_] }) -join "`r`n")+"`r`n"
    Write-RevelationGameBridgeFile -Path $Context.iniPath -Text $text -Ini
    $Context.expectedIni=$text
    $Context.allowDummyConsumption=$false
}

function Sync-RevelationDummyRouteConsumption {
    param($Context,[switch]$RequireConsumed)
    if (-not $Context.allowDummyConsumption) { return }
    $actual=[IO.File]::ReadAllText($Context.iniPath)
    $pattern='(?m)^allowDummyRoute=1(?=\r?$)'
    if ([regex]::Matches($Context.expectedIni,$pattern).Count -ne 1) { throw 'world_navigation_dummy_permission_not_owned' }
    $consumed=[regex]::Replace($Context.expectedIni,$pattern,'allowDummyRoute=0')
    if ($actual -ceq $consumed) { $Context.expectedIni=$actual; $Context.allowDummyConsumption=$false; return }
    if ($actual -cne $Context.expectedIni) { throw 'world_navigation_arming_changed' }
    if ($RequireConsumed) { throw 'world_navigation_dummy_permission_not_consumed' }
}

function Close-RevelationWorldNavigationContext {
    param($Context)
    if (-not $Context) { return }
    try {
        Sync-RevelationDummyRouteConsumption -Context $Context
        if ([IO.File]::ReadAllText($Context.iniPath) -cne $Context.expectedIni) { throw 'world_navigation_cleanup_conflict_preserved' }
        # Preserve the original encoding and bytes, not just equivalent key values.
        $temporary=$Context.iniPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try { [IO.File]::WriteAllBytes($temporary,$Context.originalBytes); [IO.File]::Replace($temporary,$Context.iniPath,[NullString]::Value) }
        finally { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } }
        $Context.armingRestored=[Convert]::ToBase64String([IO.File]::ReadAllBytes($Context.iniPath)) -ceq [Convert]::ToBase64String($Context.originalBytes)
        if (-not $Context.armingRestored) { throw 'world_navigation_cleanup_unconfirmed' }
    } finally { $Context.lease.Dispose() }
}

function Send-RevelationWorldNavigationCommand {
    param($Context,[ValidateSet(280,281,286,287,288,289,290,293,295,296)][int]$Command,[ValidateRange(-1,255)][int]$SelectedIndex=-1,[switch]$IgnoreCancellation)
    if ($IgnoreCancellation -and $Command -ne 296) { throw 'world_navigation_only_owned_stop_may_ignore_cancellation' }
    if (-not $IgnoreCancellation -and (& $Context.cancelled)) { throw [OperationCanceledException]::new() }
    Assert-RevelationWorldNavigationIdentity -Context $Context
    if ($Command -notin @(280,281) -and $SelectedIndex -ne -1) { throw 'world_navigation_unexpected_index' }
    $hash=switch ($Command) {
        286 { '' }
        {$_ -in 280,281} { 'fd14bb806e224d57cc2956c40b875910cd1f6b377ff63de909284478ac442984' }
        {$_ -in 287,288} { '81cff10bc48600e68f8baeb939e921d18f08036872c22fb0a7c34545b4637786' }
        289 { '65f273e8bf416215ee0226c1352c02d9734dfe437b66b22a1bc3969a75629952' }
        290 { 'c0ee2c4beddb2d85a6e622b160b4a79e361c27ea4541ac0a66ded9b24bda936f' }
        {$_ -in 293,295} { '134a974f5c21442da0a63e0ef7011f3d2a2dbe58f6ceb408fb3b98aa0be06c53' }
        296 { '99d36b1262f8e203f494bf4776c23c60a9193f0c0abd33bef4890182438dbfff' }
    }
    $terminal=switch ($Command) { 280 {'world_map_probe_complete'} 281 {'world_map_teleport_returned'} 286 {'world_map_location_exit_probe_complete'} 287 {'world_map_ui_probe_complete'} 288 {'world_map_ui_open_returned'} 289 {'world_map_teleport_confirmation_probe_complete'} 290 {'world_map_teleport_confirmation_returned'} 293 {'dummy_route_probe_complete'} 295 {'dummy_route_start_complete'} 296 {'dummy_route_stop_complete'} }
    $session=$Context.session
    $events=@(Get-RevelationGameBridgeEvents -Session $session | Where-Object { $_.pid -eq $Context.pid })
    $controlPath=Join-Path $session.sessionRoot 'control.ini'
    $control=Get-RevelationGameBridgeIni -Path $controlPath
    $statePath=Join-Path $session.sessionRoot 'state.json'; $state=$null; $stateSequence=0
    if (Test-Path -LiteralPath $statePath) { $state=[IO.File]::ReadAllText($statePath)|ConvertFrom-Json; $stateSequence=[long]$state.sequence }
    $sequence=Get-RevelationWorldNavigationSequence -Events $events -ControlSequence ([long]$control['sequence']) -StateSequence $stateSequence
    if ($state) { $state.sequence=$sequence; Write-RevelationGameBridgeFile -Path $statePath -Text ($state|ConvertTo-Json -Depth 20) }
    if (-not ('RevelationGameBridgeClock' -as [type])) { Add-Type 'using System.Runtime.InteropServices; public static class RevelationGameBridgeClock { [DllImport("kernel32.dll")] public static extern ulong GetTickCount64(); }' }
    $expires=[RevelationGameBridgeClock]::GetTickCount64()+4000
    if ($Command -in 295,296) {
        if ($Context.expectedIni -notmatch '(?m)^allowDummyRoute=1\r?$') { throw 'world_navigation_dummy_permission_not_owned' }
        $Context.allowDummyConsumption=$true
    }
    Write-RevelationGameBridgeFile -Path $controlPath -Text "[lab]`r`npid=$($Context.pid)`r`nnonce=$($session.nonce)`r`nsequence=$sequence`r`ncommand=$Command`r`nexpiresTick=$expires`r`nselectedIndex=$SelectedIndex`r`ncodeHash=$hash`r`n" -Ini
    $watch=[Diagnostics.Stopwatch]::StartNew()
    while ($watch.ElapsedMilliseconds -lt 5000) {
        if (-not $IgnoreCancellation -and (& $Context.cancelled)) { throw [OperationCanceledException]::new() }
        $rows=@(Get-RevelationGameBridgeEvents -Session $session | Where-Object { $_.pid -eq $Context.pid -and $_.sequence -eq $sequence })
        $failure=$rows|Where-Object { $_.event -match 'rejected|no_action|_error$|_failed$|disabled|unavailable|not_ready' }|Select-Object -First 1
        if ($failure) { throw ('world_navigation_'+$failure.event) }
        $acks=@($rows|Where-Object { $_.event -eq $terminal })
        if ($acks.Count -gt 1) { throw 'world_navigation_ambiguous_ack' }
        if ($acks.Count -eq 1) {
            if ($Command -in 295,296) { Sync-RevelationDummyRouteConsumption -Context $Context -RequireConsumed }
            $result=[pscustomobject]@{ command=$Command; sequence=$sequence; terminal=$acks[0]; events=$rows; receivedUtc=[DateTime]::UtcNow.ToString('o') }
            $Context.calls.Add($result)
            return $result
        }
        $processes=@(Get-RevelationGameBridgeProcesses -GameDir $session.gameDir)
        if ($processes.Count -ne 1 -or $processes[0].Id -ne $Context.pid -or $processes[0].StartTime.ToUniversalTime().Ticks -ne $Context.processStartTicks) { throw 'world_navigation_process_identity_changed' }
        Start-Sleep -Milliseconds 30
    }
    throw 'world_navigation_timeout_no_retry'
}

function Assert-RevelationDummyRouteState {
    param($Result)
    $state=$Result.terminal
    foreach ($field in @('schema','safe','capability','armed','active','arrived','started','stopped','stopUnconfirmed','expired','reason','spaceNo','x','y','z','distance','destinationX','destinationY','destinationZ','leaseMs')) {
        if (-not $state.PSObject.Properties[$field]) { throw 'world_navigation_dummy_state_incomplete' }
    }
    if ($state.schema -ne 1 -or $state.leaseMs -ne 20000 -or $state.spaceNo -ne 1) { throw 'world_navigation_dummy_state_invalid' }
    if ($state.stopUnconfirmed -ne $false) { throw 'world_navigation_dummy_stop_unconfirmed' }
    foreach ($field in @('x','y','z','distance','destinationX','destinationY','destinationZ')) {
        $value=[double]$state.$field
        if ([double]::IsNaN($value) -or [double]::IsInfinity($value) -or [Math]::Abs($value) -gt 1000000) { throw 'world_navigation_dummy_coordinate_invalid' }
    }
    if ([Math]::Abs($state.destinationX-936.415649) -gt 0.00001 -or [Math]::Abs($state.destinationY-11.75) -gt 0.00001 -or [Math]::Abs($state.destinationZ+371.665802) -gt 0.00001) { throw 'world_navigation_dummy_destination_changed' }
    if ($state.distance -lt 0 -or $state.safe -ne $true -or $state.capability -ne $true) { throw 'world_navigation_dummy_state_unsafe' }
    if ($state.arrived -eq $true -and $state.distance -gt 2.0) { throw 'world_navigation_dummy_arrival_invalid' }
    return $state
}

function Invoke-RevelationDummyRoute {
    param($Session,[Parameter(Mandatory)][int]$GameProcessId,[scriptblock]$IsCancelled={ $false })
    $context=$null; $startAttempted=$false; $arrived=$false; $stop=$null; $primaryError=$null; $cleanupError=$null; $last=$null
    try {
        $context=New-RevelationWorldNavigationContext -Session $Session -GameProcessId $GameProcessId -IsCancelled $IsCancelled
        $probe=Send-RevelationWorldNavigationCommand -Context $context -Command 293
        $state=Assert-RevelationDummyRouteState -Result $probe
        if ($state.active -ne $false) { throw 'world_navigation_dummy_route_already_owned' }
        if ($state.armed -ne $true) { throw 'world_navigation_dummy_route_not_armed' }
        if ($state.arrived -eq $true) { $arrived=$true; $last=$probe }
        else {
            Set-RevelationWorldNavigationArm -Context $context -DummyRoute
            # Any uncertain native start requires one owned Stop, never another Start.
            $startAttempted=$true
            $start=Send-RevelationWorldNavigationCommand -Context $context -Command 295
            $state=Assert-RevelationDummyRouteState -Result $start
            if ($state.started -ne $true -or $state.active -ne $true) { throw 'world_navigation_dummy_start_not_confirmed' }
            $deadline=[DateTime]::UtcNow.AddMilliseconds(18000)
            do {
                $last=Send-RevelationWorldNavigationCommand -Context $context -Command 293
                $state=Assert-RevelationDummyRouteState -Result $last
                if ($state.expired -eq $true -or $state.active -ne $true) { throw 'world_navigation_dummy_lease_ended' }
                if ($state.arrived -eq $true) { $arrived=$true; break }
                Start-Sleep -Milliseconds 250
            } while ([DateTime]::UtcNow -lt $deadline)
            if (-not $arrived) { throw 'world_navigation_dummy_arrival_not_confirmed_no_retry' }
        }
    } catch { $primaryError=$_ }
    finally {
        if ($context -and $startAttempted) {
            try {
                Sync-RevelationDummyRouteConsumption -Context $context
                Set-RevelationWorldNavigationArm -Context $context -DummyRoute
                $stop=Send-RevelationWorldNavigationCommand -Context $context -Command 296 -IgnoreCancellation
                if ($stop.terminal.stopped -ne $true -or $stop.terminal.active -ne $false -or $stop.terminal.stopUnconfirmed -ne $false) { throw 'world_navigation_dummy_stop_not_confirmed' }
            } catch { $cleanupError=$_ }
        }
        try { Close-RevelationWorldNavigationContext -Context $context } catch { $cleanupError=$_ }
    }
    if ($cleanupError) { throw ('world_navigation_dummy_cleanup_failed: '+$cleanupError.Exception.Message+$(if($primaryError){'; original: '+$primaryError.Exception.Message}else{''})) }
    if ($primaryError) { throw $primaryError }
    return [pscustomobject]@{arrived=$arrived;stopped=($null -eq $stop -or $stop.terminal.stopped -eq $true);stop=$stop;after=$last;calls=$context.calls.ToArray();armingRestored=$context.armingRestored}
}

function Get-RevelationWorldNavigationProbe {
    param($Session,[Parameter(Mandatory)][int]$GameProcessId,[scriptblock]$IsCancelled={ $false })
    $context=$null
    try { $context=New-RevelationWorldNavigationContext -Session $Session -GameProcessId $GameProcessId -IsCancelled $IsCancelled; $result=Send-RevelationWorldNavigationCommand -Context $context -Command 280 }
    finally { Close-RevelationWorldNavigationContext -Context $context }
    $result|Add-Member armingRestored $context.armingRestored -Force
    return $result
}

function Get-RevelationLocationExitProbe {
    param($Session,[Parameter(Mandatory)][int]$GameProcessId,[scriptblock]$IsCancelled={ $false })
    $context=$null
    try {
        $context=New-RevelationWorldNavigationContext -Session $Session -GameProcessId $GameProcessId -IsCancelled $IsCancelled
        # Diagnostic classification only. No exit permission or mutating exit callback.
        $result=Send-RevelationWorldNavigationCommand -Context $context -Command 286
    } finally { Close-RevelationWorldNavigationContext -Context $context }
    $result|Add-Member armingRestored $context.armingRestored -Force
    return $result
}

function Open-RevelationWorldMap {
    param($Session,[Parameter(Mandatory)][int]$GameProcessId,[scriptblock]$IsCancelled={ $false })
    $context=$null
    try {
        $context=New-RevelationWorldNavigationContext -Session $Session -GameProcessId $GameProcessId -IsCancelled $IsCancelled
        Set-RevelationWorldNavigationArm -Context $context -MapUi
        $probe=Send-RevelationWorldNavigationCommand -Context $context -Command 287
        if ($probe.terminal.armed -ne $true) { throw 'world_navigation_map_ui_not_armed' }
        $null=Send-RevelationWorldNavigationCommand -Context $context -Command 288
        $result=Send-RevelationWorldNavigationCommand -Context $context -Command 280
    } finally { Close-RevelationWorldNavigationContext -Context $context }
    $result|Add-Member armingRestored $context.armingRestored -Force
    return $result
}

function Invoke-RevelationWorldTeleport {
    param($Session,[Parameter(Mandatory)][int]$GameProcessId,[Parameter(Mandatory)][ValidateRange(1,2147483647)][int]$NpcId,
        [ValidateRange(1,120)][int]$ArrivalTimeoutSeconds=45,[ValidateRange(1,50)][double]$ArrivalRadius=25,[scriptblock]$IsCancelled={ $false })
    $context=$null
    try {
        $context=New-RevelationWorldNavigationContext -Session $Session -GameProcessId $GameProcessId -IsCancelled $IsCancelled
        $probe=Send-RevelationWorldNavigationCommand -Context $context -Command 280
        $target=Get-RevelationWorldNavigationTarget -Probe $probe -NpcId $NpcId
        Set-RevelationWorldNavigationArm -Context $context -Teleport
        $selected=Send-RevelationWorldNavigationCommand -Context $context -Command 280 -SelectedIndex $target.index
        $verified=Get-RevelationWorldNavigationTarget -Probe $selected -NpcId $NpcId
        if ($selected.terminal.armed -ne $true -or $selected.terminal.npc_id -ne $NpcId -or $selected.terminal.seek_id -ne $target.seekId -or $verified.index -ne $target.index -or $verified.seekId -ne $target.seekId -or $verified.spaceNo -ne $target.spaceNo -or $verified.x -ne $target.x -or $verified.y -ne $target.y -or $verified.z -ne $target.z) { throw 'world_navigation_destination_changed_no_action' }
        $action=Send-RevelationWorldNavigationCommand -Context $context -Command 281 -SelectedIndex $target.index
        if ($action.terminal.allowed -ne $true) { throw 'world_navigation_teleport_not_confirmed' }
        $confirmation=$null; $confirmationAction=$null
        $confirmationDeadline=[DateTime]::UtcNow.AddSeconds(3)
        do {
            $confirmation=Send-RevelationWorldNavigationCommand -Context $context -Command 289
            if ($confirmation.terminal.owned -eq $true) {
                if (-not (Test-RevelationWorldNavigationConfirmation -Result $confirmation -Target $target)) { throw 'world_navigation_foreign_confirmation_preserved' }
                Set-RevelationWorldNavigationArm -Context $context -Teleport -Confirm
                $confirmationAction=Send-RevelationWorldNavigationCommand -Context $context -Command 290
                if ($confirmationAction.terminal.dismissed -ne $true) { throw 'world_navigation_confirmation_not_completed' }
                break
            }
            if ($confirmation.terminal.dialog_count_now -gt 0) { throw 'world_navigation_foreign_confirmation_preserved' }
            Start-Sleep -Milliseconds 150
        } while ([DateTime]::UtcNow -lt $confirmationDeadline)
        Set-RevelationWorldNavigationArm -Context $context
        $deadline=[DateTime]::UtcNow.AddSeconds($ArrivalTimeoutSeconds); $arrived=$false; $post=$null
        do {
            try {
                $post=Send-RevelationWorldNavigationCommand -Context $context -Command 280
                $arrived=Test-RevelationWorldNavigationArrival -Probe $post -Target $target -ArrivalRadius $ArrivalRadius
            } catch {
                # Only fresh READS may be repeated while the client loads. Mutations never replay.
                if ($_.Exception.Message -notmatch '^world_navigation_(function_guard_rejected|world_map_probe_rejected|ui_unavailable|interpreter_not_ready)$') { throw }
            }
            if ($arrived) { break }
            Start-Sleep -Milliseconds 300
        } while ([DateTime]::UtcNow -lt $deadline)
        if (-not $arrived) { throw 'world_navigation_arrival_not_confirmed_no_retry' }
        $result=[pscustomobject]@{ arrived=$true; target=$target; before=$probe; after=$post; action=$action; confirmation=$confirmation; confirmationAction=$confirmationAction; calls=$context.calls.ToArray(); armingRestored=$false }
    } finally { Close-RevelationWorldNavigationContext -Context $context }
    $result.armingRestored=$context.armingRestored
    return $result
}
