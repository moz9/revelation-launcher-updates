param(
    [int]$ProcessId,
    [long]$WindowHandle,
    [long]$ExpectedStartTimeUtcTicks,
    [string]$CancelPath = '',
    [string]$OperationId = '',
    [string]$ProgressPath = '',
    [ValidateRange(5, 30)][int]$TimeoutSec = 20,
    [switch]$Probe
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$timer = [Diagnostics.Stopwatch]::StartNew()
$steps = [Collections.Generic.List[object]]::new()
$result = [ordered]@{
    ok = $false; autoExitRequested = $false; countdownObserved = $false
    manualExitRequired = $true; cancelled = $false; reason = 'initializing'
    language = 'ru-RU'; inputMethod = 'foreground_held_sendinput'; elapsedMs = 0; steps = @()
}

function Test-ExitCancelled {
    if (-not $CancelPath -or -not $OperationId -or -not (Test-Path -LiteralPath $CancelPath)) { return $false }
    try {
        $request = Get-Content -LiteralPath $CancelPath -Raw | ConvertFrom-Json
        return [bool]($request.operationId -eq $OperationId)
    } catch { return $false }
}

function Assert-ExitActive {
    if (Test-ExitCancelled) { throw 'operation_cancelled' }
    if ($timer.Elapsed.TotalSeconds -gt $TimeoutSec) { throw 'automatic_exit_timeout' }
}

function Write-ExitProgress([string]$Phase, [string]$Action = 'observe') {
    $entry = [ordered]@{ phase = $Phase; action = $Action; elapsedMs = $timer.ElapsedMilliseconds }
    $steps.Add($entry)
    if ($ProgressPath) {
        $temp = $ProgressPath + '.tmp'
        try {
            [IO.File]::WriteAllText($temp, ($entry | ConvertTo-Json -Compress), [Text.UTF8Encoding]::new($false))
            if (Test-Path -LiteralPath $ProgressPath) { [IO.File]::Replace($temp, $ProgressPath, [NullString]::Value) }
            else { [IO.File]::Move($temp, $ProgressPath) }
        } finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
    }
}

function Wait-ExitOcr([object]$Operation) {
    $task = $script:asTask.MakeGenericMethod([Windows.Media.Ocr.OcrResult]).Invoke($null, @($Operation))
    while (-not $task.IsCompleted) {
        Assert-ExitActive
        Start-Sleep -Milliseconds 50
    }
    return $task.GetAwaiter().GetResult()
}

function Read-ExitWords($Frame, [int]$FirstLine = 0) {
    $bitmap = $null
    try {
        $buffer = [System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferExtensions]::AsBuffer([byte[]]$frame.Pixels)
        $bitmap = [Windows.Graphics.Imaging.SoftwareBitmap]::CreateCopyFromBuffer(
            $buffer, [Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, $frame.Width, $frame.Height,
            [Windows.Graphics.Imaging.BitmapAlphaMode]::Ignore)
        $ocr = Wait-ExitOcr ($script:engine.RecognizeAsync($bitmap))
        $words = [Collections.Generic.List[RevelationLauncher.GameExit.Word]]::new()
        $lineNumber = $FirstLine
        $angle = if ($null -eq $ocr.TextAngle) { 0.0 } else { [double]$ocr.TextAngle }
        $angle = [RevelationLauncher.GameExit.OcrImage]::NormalizeAngle($angle)
        $script:ocrAngles.Add($angle)
        if ([Math]::Abs($angle) -gt 5) { return @() }
        foreach ($line in $ocr.Lines) {
            foreach ($item in $line.Words) {
                $words.Add([RevelationLauncher.GameExit.OcrImage]::MapWord([string]$item.Text,
                    $item.BoundingRect.X, $item.BoundingRect.Y, $item.BoundingRect.Width, $item.BoundingRect.Height,
                    $lineNumber, $frame, $angle))
            }
            $lineNumber++
        }
        return $words.ToArray()
    } finally { if ($null -ne $bitmap) { $bitmap.Dispose() } }
}

function Read-ExitRecognition($Frame) {
    $refined = $null
    $row = $null
    try {
        $words = @(Read-ExitWords $frame)
        $decision = [RevelationLauncher.GameExit.Recognition]::Decide($words, $frame.ClientWidth, $frame.ClientHeight)
        if ($decision.State -eq 'unknown') {
            $menu = [RevelationLauncher.GameExit.OcrImage]::SearchMenu($frame, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
            if ($null -ne $menu) {
                try { $words += @(Read-ExitWords $menu 40000) }
                finally { $menu.Pixels = $null }
                $decision = [RevelationLauncher.GameExit.Recognition]::Decide($words, $frame.ClientWidth, $frame.ClientHeight)
            }
        }
        foreach ($index in @(0, 4, 2, 1, 3, 5)) {
            if ($decision.State -ne 'unknown') { break }
            $band = [RevelationLauncher.GameExit.OcrImage]::SearchBand($frame, $index, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
            if ($null -eq $band) { continue }
            try { $words += @(Read-ExitWords $band (30000 + $index * 1000)) }
            finally { $band.Pixels = $null }
            $decision = [RevelationLauncher.GameExit.Recognition]::Decide($words, $frame.ClientWidth, $frame.ClientHeight)
        }
        if ($decision.State -eq 'unknown') {
            $header = [RevelationLauncher.GameExit.Recognition]::ReminderHeader($words, $frame.ClientWidth, $frame.ClientHeight)
            $refined = [RevelationLauncher.GameExit.OcrImage]::RefineReminder($frame, $header, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
            if ($null -eq $refined) {
                $anchor = [RevelationLauncher.GameExit.Recognition]::MenuAnchor($words, $frame.ClientWidth, $frame.ClientHeight)
                $refined = [RevelationLauncher.GameExit.OcrImage]::RefineMenu($frame, $anchor, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
            }
            if ($null -ne $refined) {
                $words += @(Read-ExitWords $refined 10000)
                $decision = [RevelationLauncher.GameExit.Recognition]::Decide($words, $frame.ClientWidth, $frame.ClientHeight)
            }
            if ($decision.State -eq 'unknown') {
                $button = [RevelationLauncher.GameExit.Recognition]::ReminderButtonAnchor($words, $frame.ClientWidth, $frame.ClientHeight)
                $row = [RevelationLauncher.GameExit.OcrImage]::RefineButtonRow($frame, $button, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
                if ($null -ne $row) {
                    $words += @(Read-ExitWords $row 20000)
                    $decision = [RevelationLauncher.GameExit.Recognition]::Decide($words, $frame.ClientWidth, $frame.ClientHeight)
                }
            }
        }
        return @{ words = $words; decision = $decision }
    } finally {
        if ($null -ne $row) { $row.Pixels = $null }
        if ($null -ne $refined) { $refined.Pixels = $null }
    }
}

function Read-ExitObservation {
    Assert-ExitActive
    $frame = [RevelationLauncher.GameExit.Native]::Capture([Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
    $script:ocrAngles = [Collections.Generic.List[double]]::new()
    try {
        $recognized = Read-ExitRecognition $frame
        $words = $recognized.words
        $decision = $recognized.decision
        $minimum = 255; $maximum = 0
        for ($sample = 0; $sample -lt 256; $sample++) {
            $offset = [int]([Math]::Floor(($frame.Width * $frame.Height - 1) * $sample / 255)) * 4
            for ($channel = 0; $channel -lt 3; $channel++) {
                $value = [int]$frame.Pixels[$offset + $channel]
                $minimum = [Math]::Min($minimum, $value); $maximum = [Math]::Max($maximum, $value)
            }
        }
        $labels = [regex]::Unescape('^(\u041d\u0430\u0437\u0430\u0434|\u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438|\u0432\u044b\u0445\u043e\u0434|\u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c|\u043e\u0442\u043c\u0435\u043d\u0430|\u0438\u0433\u0440\u044b|\u0438\u0433\u0440\u0443|\u043e\u0441\u0442\u0430\u043b\u043e\u0441\u044c|\u0432\u043e\u0438\u043d\u0430)$')
        # Retain only whitelisted menu labels and numeric capture health, never general OCR text.
        $result.observation = [ordered]@{
            width = $frame.Width; height = $frame.Height; pixelRange = $maximum - $minimum
            wordCount = $words.Count
            angles = @($script:ocrAngles.ToArray())
            labels = @($words | Where-Object { $_.Text.Trim(':.,()') -match $labels } | ForEach-Object {
                @{ text = $_.Text; line = $_.Line; x = [int]$_.X; y = [int]$_.Y }
            })
        }
        return @{ frame = $frame; decision = $decision }
    } finally {
        # No images or arbitrary OCR text are retained in launcher diagnostics.
        $frame.Pixels = $null
    }
}

try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapPixelFormat, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapAlphaMode, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
    $script:engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('ru-RU'))
    if ($null -eq $script:engine) { throw 'ocr_language_unavailable' }
    $script:asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and $_.GetParameters().Count -eq 1
    } | Select-Object -First 1
    if ($null -eq $script:asTask) { throw 'ocr_runtime_unavailable' }
    Add-Type -Path (Join-Path $PSScriptRoot 'RevelationGameExit.cs') -ReferencedAssemblies System.Drawing
    if ($Probe) {
        $result.ok = $true; $result.reason = 'capability_available'; $result.manualExitRequired = $false
    } else {
        if ($ProcessId -le 0 -or $WindowHandle -eq 0 -or $ExpectedStartTimeUtcTicks -le 0) { throw 'invalid_game_target' }
        Assert-ExitActive
        [RevelationLauncher.GameExit.Native]::Bind($ProcessId, $WindowHandle, $ExpectedStartTimeUtcTicks)
        $previous = $null
        $escapeCount = 0
        $lastEscapeAt = -1000
        $recognizedSeen = $false
        $previousAt = 0
        $clicked = @{}
        $stateSince = $timer.ElapsedMilliseconds
        $lastState = ''
        Write-ExitProgress 'recognizing_exit_menu'
        Start-Sleep -Milliseconds 400
        while ($true) {
            Assert-ExitActive
            $game = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
            if ($null -eq $game) {
                $result.ok = $true; $result.manualExitRequired = $false; $result.reason = 'game_closed'
                break
            }
            $observation = Read-ExitObservation
            $decision = $observation.decision
            if ($decision.State -ne 'unknown') { $recognizedSeen = $true }
            if ($decision.State -ne $lastState) {
                $lastState = $decision.State; $stateSince = $timer.ElapsedMilliseconds
                Write-ExitProgress $decision.State
            }
            if ($decision.State -eq 'exit_countdown') {
                $result.ok = $true; $result.autoExitRequested = $true; $result.countdownObserved = $true
                $result.manualExitRequired = $false; $result.reason = 'exit_countdown_observed'
                Write-ExitProgress 'waiting_for_exit_countdown'
                break
            }
            if ($decision.Action -eq 'click' -and $timer.ElapsedMilliseconds - $previousAt -lt 2000 -and
                [RevelationLauncher.GameExit.Recognition]::Stable($previous, $decision)) {
                if (-not $clicked.ContainsKey($decision.State)) {
                    Assert-ExitActive
                    [RevelationLauncher.GameExit.Native]::Click($observation.frame, $decision)
                    $clicked[$decision.State] = $true
                    $result.autoExitRequested = $true
                    Write-ExitProgress $decision.State 'click'
                    if ($decision.State -eq 'daily_reminder') {
                        # The game polls input; do not restore the cursor immediately after mouse-up.
                        Start-Sleep -Milliseconds 450
                        # This is the final button. The parent verifies process exit and session release.
                        $result.ok = $true; $result.manualExitRequired = $false
                        $result.reason = 'exit_button_clicked'
                        Write-ExitProgress 'waiting_for_game_exit'
                        break
                    }
                    $previous = $null
                    Start-Sleep -Milliseconds 450
                    continue
                }
                if ($timer.ElapsedMilliseconds - $stateSince -gt 3000) { throw 'exit_button_no_effect' }
            }
            if ($decision.State -eq 'unknown' -and -not $recognizedSeen -and $escapeCount -lt 3 -and $clicked.Count -eq 0 -and
                $timer.ElapsedMilliseconds - $stateSince -gt 500 -and $timer.ElapsedMilliseconds - $lastEscapeAt -gt 700 -and
                $result.observation.pixelRange -gt 20 -and $result.observation.wordCount -gt 0) {
                Assert-ExitActive
                [RevelationLauncher.GameExit.Native]::Escape($observation.frame)
                $escapeCount++
                $lastEscapeAt = $timer.ElapsedMilliseconds
                Write-ExitProgress 'opening_exit_menu' 'escape'
                $previous = $null
                Start-Sleep -Milliseconds 450
                continue
            }
            if ($decision.State -eq 'unknown' -and $timer.ElapsedMilliseconds - $stateSince -gt 3500) { throw 'exit_menu_not_recognized' }
            if ($decision.State -ne 'unknown') { $previous = $decision; $previousAt = $timer.ElapsedMilliseconds }
            Start-Sleep -Milliseconds 180
        }
    }
} catch {
    $errorText = $_.Exception.GetBaseException().Message
    $codes = 'operation_cancelled|automatic_exit_timeout|ocr_language_unavailable|ocr_runtime_unavailable|invalid_game_target|target_changed|focus_lost|client_unavailable|dpi_api_unavailable|menu_area_occluded|geometry_changed|observation_expired|user_moved_pointer|user_input_active|input_not_delivered|invalid_click|button_occluded|pointer_move_failed|exit_button_no_effect|exit_menu_not_recognized'
    $matched = [regex]::Match($errorText, $codes)
    $result.reason = if ($matched.Success) { $matched.Value } else { 'exit_helper_unavailable' }
    $result.cancelled = $result.reason -eq 'operation_cancelled'
    $result.error = $errorText.Substring(0, [Math]::Min(240, $errorText.Length))
} finally {
    if ('RevelationLauncher.GameExit.Native' -as [type]) { [RevelationLauncher.GameExit.Native]::RestorePointer() }
    $result.elapsedMs = $timer.ElapsedMilliseconds
    $result.steps = @($steps.ToArray())
}
$result | ConvertTo-Json -Depth 6 -Compress
