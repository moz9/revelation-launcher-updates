[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet('Status', 'Capture', 'ProbeSynthesis', 'AgentCapabilities', 'FrameCapture', 'Key', 'KeyBurst', 'CloseRequest', 'Click', 'WindowClick', 'Move')]
    [string]$Action,

    [ValidateSet('B', 'Escape', 'Up', 'Down', 'Enter', 'Y')]
    [string]$KeyName = 'B',

    [ValidateSet('Left', 'Right')]
    [string]$MouseButton = 'Left',

    [ValidateSet('Relative', 'Screen')]
    [string]$PointerMode = 'Relative',

    [ValidateRange(2, 120)]
    [int]$RepeatCount = 20,

    [ValidateRange(20, 500)]
    [int]$IntervalMs = 75,

    [ValidateRange(5, 180)]
    [int]$DurationSeconds = 30,

    [int]$X = -1,
    [int]$Y = -1,
    [int]$ExpectedClientWidth = 0,
    [int]$ExpectedClientHeight = 0,
    [int]$ExpectedDpi = 0,
    [int]$ExpectedProcessId = 0,
    [int64]$ExpectedHandle = 0,
    [int]$ExpectedSessionId = -1,
    [string]$GeometryPath = '',
    [string]$OutputPath = ''
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
if ($null -eq (Get-Variable -Name RevelationElevatedAgentReady -Scope Global -ErrorAction SilentlyContinue)) {
    $global:RevelationElevatedAgentReady = $false
}

if (-not ('RevelationToolkit.GameInspectorNative' -as [type])) {
    $nativeSource = @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace RevelationToolkit
{
    public static class GameInspectorNative
    {
        public sealed class SynthesisProbeResult
        {
            public bool WindowVisible;
            public bool InventoryVisible;
            public int OccupiedInputs;
            public bool[] OccupiedSlots;
            public bool OkActive;
            public bool ConfirmationVisible;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetClientRect(IntPtr hWnd, out RECT rect);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ClientToScreen(IntPtr hWnd, ref POINT point);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetProcessDPIAware();

        [DllImport("user32.dll")]
        private static extern uint GetDpiForWindow(IntPtr hWnd);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool PostMessage(IntPtr hWnd, uint message, UIntPtr wParam, IntPtr lParam);

        public static bool EnablePerMonitorDpiAwareness()
        {
            try
            {
                // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
                if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return true;
            }
            catch (EntryPointNotFoundException) { }
            try { return SetProcessDPIAware(); }
            catch (EntryPointNotFoundException) { return false; }
        }

        public static uint ReadWindowDpi(IntPtr hWnd)
        {
            try
            {
                uint dpi = GetDpiForWindow(hWnd);
                return dpi == 0 ? 96U : dpi;
            }
            catch (EntryPointNotFoundException) { return 96U; }
        }

        private static int MapCoordinate(int value, int baseline, int actual)
        {
            int gap = baseline - actual;
            if (gap >= 0 && gap <= 64)
                return value - (gap / 2);
            return (int)Math.Round(value * (actual / (double)baseline));
        }

        private static Rectangle MapRectangle(int left, int top, int right, int bottom, int width, int height)
        {
            int x1 = Math.Max(0, Math.Min(width - 1, MapCoordinate(left, 2560, width)));
            int y1 = Math.Max(0, Math.Min(height - 1, MapCoordinate(top, 1337, height)));
            int x2 = Math.Max(x1 + 1, Math.Min(width, MapCoordinate(right, 2560, width)));
            int y2 = Math.Max(y1 + 1, Math.Min(height, MapCoordinate(bottom, 1337, height)));
            return Rectangle.FromLTRB(x1, y1, x2, y2);
        }

        private static Rectangle ResolveGeometryRectangle(
            int left,
            int top,
            int right,
            int bottom,
            int width,
            int height,
            bool clientPixels)
        {
            if (!clientPixels)
                return MapRectangle(left, top, right, bottom, width, height);
            int x1 = Math.Max(0, Math.Min(width - 1, left));
            int y1 = Math.Max(0, Math.Min(height - 1, top));
            int x2 = Math.Max(x1 + 1, Math.Min(width, right));
            int y2 = Math.Max(y1 + 1, Math.Min(height, bottom));
            return Rectangle.FromLTRB(x1, y1, x2, y2);
        }

        private static double MeanGray(byte[] pixels, int stride, int height, Rectangle area)
        {
            long sum = 0;
            int count = 0;
            for (int y = area.Top; y < area.Bottom; y++)
            {
                int row = stride >= 0 ? y * stride : (height - 1 - y) * -stride;
                for (int x = area.Left; x < area.Right; x++)
                {
                    int offset = row + (x * 3);
                    int gray = (29 * pixels[offset] + 150 * pixels[offset + 1] + 77 * pixels[offset + 2]) >> 8;
                    sum += gray;
                    count++;
                }
            }
            return count == 0 ? 0.0 : sum / (double)count;
        }

        private static void GrayDistribution(byte[] pixels, int stride, int height, Rectangle area, out double deviation, out int percentile90)
        {
            long sum = 0;
            long sumSquares = 0;
            int count = 0;
            int[] histogram = new int[256];
            for (int y = area.Top; y < area.Bottom; y++)
            {
                int row = stride >= 0 ? y * stride : (height - 1 - y) * -stride;
                for (int x = area.Left; x < area.Right; x++)
                {
                    int offset = row + (x * 3);
                    int gray = (29 * pixels[offset] + 150 * pixels[offset + 1] + 77 * pixels[offset + 2]) >> 8;
                    sum += gray;
                    sumSquares += gray * gray;
                    histogram[gray]++;
                    count++;
                }
            }
            if (count == 0)
            {
                deviation = 0.0;
                percentile90 = 0;
                return;
            }
            double mean = sum / (double)count;
            deviation = Math.Sqrt(Math.Max(0.0, sumSquares / (double)count - mean * mean));
            int target = (int)Math.Ceiling(count * 0.90);
            int cumulative = 0;
            percentile90 = 0;
            for (int value = 0; value < histogram.Length; value++)
            {
                cumulative += histogram[value];
                if (cumulative >= target)
                {
                    percentile90 = value;
                    break;
                }
            }
        }

        private static double GoldFrameRatio(byte[] pixels, int stride, int height, Rectangle area)
        {
            int gold = 0;
            int count = 0;
            int ring = Math.Max(2, Math.Min(area.Width, area.Height) / 8);
            for (int y = area.Top; y < area.Bottom; y++)
            {
                int row = stride >= 0 ? y * stride : (height - 1 - y) * -stride;
                for (int x = area.Left; x < area.Right; x++)
                {
                    if (x >= area.Left + ring && x < area.Right - ring && y >= area.Top + ring && y < area.Bottom - ring) continue;
                    int offset = row + (x * 3);
                    double b = pixels[offset] / 255.0;
                    double g = pixels[offset + 1] / 255.0;
                    double r = pixels[offset + 2] / 255.0;
                    double max = Math.Max(r, Math.Max(g, b));
                    double min = Math.Min(r, Math.Min(g, b));
                    double saturation = max <= 0.0 ? 0.0 : (max - min) / max;
                    double hue = 0.0;
                    if (max > min)
                    {
                        if (max == r) hue = 60.0 * (((g - b) / (max - min)) % 6.0);
                        else if (max == g) hue = 60.0 * (((b - r) / (max - min)) + 2.0);
                        else hue = 60.0 * (((r - g) / (max - min)) + 4.0);
                        if (hue < 0.0) hue += 360.0;
                    }
                    double value = max * 255.0;
                    if (hue >= 16.0 && hue <= 100.0 && saturation >= 0.10 && value >= 30.0 && value <= 220.0) gold++;
                    count++;
                }
            }
            return count == 0 ? 0.0 : gold / (double)count;
        }

        private sealed class SynthesisRegionCapture : IDisposable
        {
            public readonly Bitmap Bitmap;
            public readonly int Left;
            public readonly int Top;

            public SynthesisRegionCapture(Bitmap bitmap, int left, int top)
            {
                Bitmap = bitmap;
                Left = left;
                Top = top;
            }

            public void Dispose()
            {
                Bitmap.Dispose();
            }
        }

        private static Rectangle OffsetRectangle(Rectangle area, int left, int top)
        {
            return new Rectangle(area.Left - left, area.Top - top, area.Width, area.Height);
        }

        private static SynthesisRegionCapture CaptureSynthesisRegions(
            IntPtr hWnd,
            int width,
            int height,
            int[,] centers,
            int okX,
            int okY,
            int closeX,
            int closeY,
            int[] geometry,
            bool clientPixels,
            int[] confirmationGeometry,
            int[] inventoryMarkerGeometry)
        {
            POINT origin = new POINT();
            if (!ClientToScreen(hWnd, ref origin))
                throw new InvalidOperationException("Could not determine the Revelation window screen coordinates.");

            Rectangle bounds = clientPixels && geometry != null && geometry.Length >= 20
                ? ResolveGeometryRectangle(
                    geometry[16],
                    geometry[17],
                    geometry[16] + geometry[18],
                    geometry[17] + geometry[19],
                    width,
                    height,
                    true)
                : MapRectangle(40, 350, 1460, 816, width, height);
            Rectangle ok = ResolveGeometryRectangle(okX - 58, okY - 16, okX + 58, okY + 16, width, height, clientPixels);
            bounds = Rectangle.Union(bounds, ok);
            Rectangle close = ResolveGeometryRectangle(closeX - 10, closeY - 10, closeX + 10, closeY + 10, width, height, clientPixels);
            bounds = Rectangle.Union(bounds, close);
            if (confirmationGeometry != null && confirmationGeometry.Length >= 10)
            {
                Rectangle confirmation = ResolveGeometryRectangle(
                    confirmationGeometry[0],
                    confirmationGeometry[1],
                    confirmationGeometry[0] + confirmationGeometry[2],
                    confirmationGeometry[1] + confirmationGeometry[3],
                    width,
                    height,
                    true);
                bounds = Rectangle.Union(bounds, confirmation);
            }
            if (inventoryMarkerGeometry != null && inventoryMarkerGeometry.Length >= 4)
            {
                Rectangle inventory = ResolveGeometryRectangle(
                    inventoryMarkerGeometry[0],
                    inventoryMarkerGeometry[1],
                    inventoryMarkerGeometry[0] + inventoryMarkerGeometry[2],
                    inventoryMarkerGeometry[1] + inventoryMarkerGeometry[3],
                    width,
                    height,
                    true);
                bounds = Rectangle.Union(bounds, inventory);
            }
            for (int index = 0; index < 5; index++)
            {
                int x = centers[index, 0];
                int y = centers[index, 1];
                bounds = Rectangle.Union(bounds, ResolveGeometryRectangle(x - 29, y - 29, x + 29, y + 29, width, height, clientPixels));
            }
            bounds.Intersect(new Rectangle(0, 0, width, height));

            Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb);
            using (Graphics graphics = Graphics.FromImage(bitmap))
                graphics.CopyFromScreen(
                    origin.X + bounds.Left,
                    origin.Y + bounds.Top,
                    0,
                    0,
                    bitmap.Size,
                    CopyPixelOperation.SourceCopy);
            return new SynthesisRegionCapture(bitmap, bounds.Left, bounds.Top);
        }

        public static SynthesisProbeResult ProbeSynthesis(
            IntPtr hWnd,
            int width,
            int height,
            int[] geometry,
            bool clientPixels,
            int[] confirmationGeometry,
            int[] inventoryMarkerGeometry)
        {
            int[,] centers = new int[,] { { 222, 566 }, { 132, 630 }, { 312, 630 }, { 166, 735 }, { 278, 735 } };
            if (geometry != null && geometry.Length >= 14)
            {
                for (int index = 0; index < 5; index++)
                {
                    centers[index, 0] = geometry[index * 2];
                    centers[index, 1] = geometry[index * 2 + 1];
                }
            }
            int okX = geometry != null && geometry.Length >= 20 ? geometry[10] : 166;
            int okY = geometry != null && geometry.Length >= 20 ? geometry[11] : 929;
            int closeX = geometry != null && geometry.Length >= 20 ? geometry[14] : 400;
            int closeY = geometry != null && geometry.Length >= 20 ? geometry[15] : 405;

            using (SynthesisRegionCapture capture = CaptureSynthesisRegions(
                hWnd,
                width,
                height,
                centers,
                okX,
                okY,
                closeX,
                closeY,
                geometry,
                clientPixels,
                confirmationGeometry,
                inventoryMarkerGeometry))
            {
                Bitmap bitmap = capture.Bitmap;
                BitmapData data = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                try
                {
                    int byteCount = Math.Abs(data.Stride) * bitmap.Height;
                    byte[] pixels = new byte[byteCount];
                    Marshal.Copy(data.Scan0, pixels, 0, byteCount);

                    bool[] occupied = new bool[5];
                    int occupiedCount = 0;
                    int validSlotCount = 0;
                    int framedSlotCount = 0;
                    for (int index = 0; index < occupied.Length; index++)
                    {
                        int x = centers[index, 0];
                        int y = centers[index, 1];
                        Rectangle slot = OffsetRectangle(ResolveGeometryRectangle(x - 18, y - 18, x + 18, y + 18, width, height, clientPixels), capture.Left, capture.Top);
                        double deviation;
                        int percentile90;
                        GrayDistribution(pixels, data.Stride, bitmap.Height, slot, out deviation, out percentile90);
                        occupied[index] = deviation >= 35.0 && percentile90 >= 115;
                        double slotMean = MeanGray(pixels, data.Stride, bitmap.Height, slot);
                        bool empty = slotMean <= 45.0 && percentile90 <= 55;
                        if (occupied[index] || empty) validSlotCount++;
                        Rectangle frame = OffsetRectangle(ResolveGeometryRectangle(x - 29, y - 29, x + 29, y + 29, width, height, clientPixels), capture.Left, capture.Top);
                        if (GoldFrameRatio(pixels, data.Stride, bitmap.Height, frame) >= 0.45) framedSlotCount++;
                        if (occupied[index]) occupiedCount++;
                    }

                    SynthesisProbeResult result = new SynthesisProbeResult();
                    double closeMarkerDeviation;
                    int closeMarkerPercentile90;
                    GrayDistribution(
                        pixels,
                        data.Stride,
                        bitmap.Height,
                        OffsetRectangle(ResolveGeometryRectangle(closeX - 10, closeY - 10, closeX + 10, closeY + 10, width, height, clientPixels), capture.Left, capture.Top),
                        out closeMarkerDeviation,
                        out closeMarkerPercentile90);
                    double panelStripDeviation;
                    int panelStripPercentile90;
                    if (clientPixels && geometry != null && geometry.Length >= 20)
                    {
                        panelStripDeviation = 0.0;
                        panelStripPercentile90 = 0;
                    }
                    else
                    {
                        GrayDistribution(
                            pixels,
                            data.Stride,
                            bitmap.Height,
                            OffsetRectangle(MapRectangle(40, 800, 300, 816, width, height), capture.Left, capture.Top),
                            out panelStripDeviation,
                            out panelStripPercentile90);
                    }
                    result.WindowVisible = clientPixels && geometry != null && geometry.Length >= 20
                        ? framedSlotCount >= 4 && validSlotCount >= 4
                        : closeMarkerDeviation >= 25.0 &&
                          closeMarkerPercentile90 >= 100 &&
                          panelStripPercentile90 >= 25 &&
                          panelStripPercentile90 <= 48;
                    result.InventoryVisible = false;
                    if (inventoryMarkerGeometry != null && inventoryMarkerGeometry.Length >= 4)
                    {
                        double inventoryCloseDeviation;
                        int inventoryClosePercentile90;
                        Rectangle inventoryMarker = ResolveGeometryRectangle(
                            inventoryMarkerGeometry[0],
                            inventoryMarkerGeometry[1],
                            inventoryMarkerGeometry[0] + inventoryMarkerGeometry[2],
                            inventoryMarkerGeometry[1] + inventoryMarkerGeometry[3],
                            width,
                            height,
                            true);
                        GrayDistribution(
                            pixels,
                            data.Stride,
                            bitmap.Height,
                            OffsetRectangle(inventoryMarker, capture.Left, capture.Top),
                            out inventoryCloseDeviation,
                            out inventoryClosePercentile90);
                        result.InventoryVisible =
                            inventoryCloseDeviation >= 25.0 &&
                            inventoryClosePercentile90 >= 100;
                    }
                    result.OccupiedSlots = occupied;
                    result.OccupiedInputs = occupiedCount;
                    result.OkActive = MeanGray(
                        pixels,
                        data.Stride,
                        bitmap.Height,
                        OffsetRectangle(ResolveGeometryRectangle(okX - 58, okY - 16, okX + 58, okY + 16, width, height, clientPixels), capture.Left, capture.Top)) > 82.0;
                    result.ConfirmationVisible = false;
                    if (confirmationGeometry != null && confirmationGeometry.Length >= 10)
                    {
                        int panelX = confirmationGeometry[0];
                        int panelY = confirmationGeometry[1];
                        int panelWidth = confirmationGeometry[2];
                        int panelHeight = confirmationGeometry[3];
                        int checkboxX = confirmationGeometry[4];
                        int checkboxY = confirmationGeometry[5];
                        int confirmationOkX = confirmationGeometry[6];
                        int confirmationOkY = confirmationGeometry[7];
                        int scaleRadius = Math.Max(7, (int)Math.Round(13.0 * panelWidth / 380.0));
                        int buttonHalfWidth = Math.Max(20, (int)Math.Round(45.0 * panelWidth / 380.0));
                        int buttonHalfHeight = Math.Max(7, (int)Math.Round(12.0 * panelHeight / 270.0));
                        Rectangle checkbox = ResolveGeometryRectangle(
                            checkboxX - scaleRadius,
                            checkboxY - scaleRadius,
                            checkboxX + scaleRadius + 1,
                            checkboxY + scaleRadius + 1,
                            width,
                            height,
                            true);
                        Rectangle confirmationButton = ResolveGeometryRectangle(
                            confirmationOkX - buttonHalfWidth,
                            confirmationOkY - buttonHalfHeight,
                            confirmationOkX + buttonHalfWidth + 1,
                            confirmationOkY + buttonHalfHeight + 1,
                            width,
                            height,
                            true);
                        double confirmationButtonDeviation;
                        int confirmationButtonPercentile90;
                        GrayDistribution(
                            pixels,
                            data.Stride,
                            bitmap.Height,
                            OffsetRectangle(confirmationButton, capture.Left, capture.Top),
                            out confirmationButtonDeviation,
                            out confirmationButtonPercentile90);
                        result.ConfirmationVisible =
                            GoldFrameRatio(pixels, data.Stride, bitmap.Height, OffsetRectangle(checkbox, capture.Left, capture.Top)) >= 0.015 &&
                            MeanGray(pixels, data.Stride, bitmap.Height, OffsetRectangle(confirmationButton, capture.Left, capture.Top)) >= 70.0 &&
                            confirmationButtonPercentile90 >= 100;
                    }
                    return result;
                }
                finally
                {
                    bitmap.UnlockBits(data);
                }
            }
        }
    }
}
"@
    # .NET 10 splits Drawing across lazily loaded assemblies. Load the bitmap
    # dependencies before collecting compiler references, also on a cold host.
    foreach ($dependency in [Drawing.Bitmap].Assembly.GetReferencedAssemblies()) {
        [void][Reflection.Assembly]::Load($dependency)
    }
    $nativeReferences = @([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object Location | Select-Object -ExpandProperty Location -Unique)
    Add-Type -TypeDefinition $nativeSource -ReferencedAssemblies $nativeReferences
}
[void][RevelationToolkit.GameInspectorNative]::EnablePerMonitorDpiAwareness()

function Get-RequiredGeometryProperty {
    param(
        [Parameter(Mandatory)]$Value,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Context
    )

    $property = $Value.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        throw ($Context + ' is missing ' + $Name + '.')
    }
    return $property.Value
}

function ConvertTo-ValidatedClientPoint {
    param(
        [Parameter(Mandatory)]$Value,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][int]$TargetWidth,
        [Parameter(Mandatory)][int]$TargetHeight
    )

    $coordinates = @($Value)
    if ($coordinates.Count -ne 2) { throw ($Name + ' must contain exactly two client-pixel coordinates.') }
    $clientX = [int]$coordinates[0]
    $clientY = [int]$coordinates[1]
    if ($clientX -lt 0 -or $clientY -lt 0 -or $clientX -ge $TargetWidth -or $clientY -ge $TargetHeight) {
        throw ($Name + ' is outside the current game client.')
    }
    return @($clientX, $clientY)
}

function ConvertTo-ValidatedClientBounds {
    param(
        [Parameter(Mandatory)]$Value,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][int]$TargetWidth,
        [Parameter(Mandatory)][int]$TargetHeight
    )

    $left = [int](Get-RequiredGeometryProperty -Value $Value -Name 'x' -Context $Name)
    $top = [int](Get-RequiredGeometryProperty -Value $Value -Name 'y' -Context $Name)
    $width = [int](Get-RequiredGeometryProperty -Value $Value -Name 'width' -Context $Name)
    $height = [int](Get-RequiredGeometryProperty -Value $Value -Name 'height' -Context $Name)
    if ($left -lt 0 -or $top -lt 0 -or $width -le 0 -or $height -le 0 -or
        $left + $width -gt $TargetWidth -or $top + $height -gt $TargetHeight) {
        throw ($Name + ' is outside the current game client.')
    }
    return @($left, $top, $width, $height)
}

function Assert-DetectedClientGeometry {
    param(
        [Parameter(Mandatory)]$Geometry,
        [Parameter(Mandatory)][string]$Context,
        [Parameter(Mandatory)][int]$TargetWidth,
        [Parameter(Mandatory)][int]$TargetHeight
    )

    if (-not [bool](Get-RequiredGeometryProperty -Value $Geometry -Name 'detected' -Context $Context) -or
        -not [bool](Get-RequiredGeometryProperty -Value $Geometry -Name 'actionable' -Context $Context)) {
        throw ($Context + ' is not detected and actionable.')
    }
    if ([string](Get-RequiredGeometryProperty -Value $Geometry -Name 'coordinateSpace' -Context $Context) -ne 'client-pixels') {
        throw ($Context + ' coordinate space must be client-pixels.')
    }
    $sourceWidth = [int](Get-RequiredGeometryProperty -Value $Geometry -Name 'sourceWidth' -Context $Context)
    $sourceHeight = [int](Get-RequiredGeometryProperty -Value $Geometry -Name 'sourceHeight' -Context $Context)
    if ($sourceWidth -ne $TargetWidth -or $sourceHeight -ne $TargetHeight) {
        throw ($Context + ' is stale: source client size does not match the current game client.')
    }
    $fingerprint = [string](Get-RequiredGeometryProperty -Value $Geometry -Name 'fingerprint' -Context $Context)
    if ($fingerprint -notmatch '^[0-9a-f]{16}$') {
        throw ($Context + ' fingerprint is malformed.')
    }
}

function ConvertTo-ValidatedSynthesisProbeGeometry {
    param(
        [Parameter(Mandatory)]$Layout,
        [Parameter(Mandatory)][int]$TargetWidth,
        [Parameter(Mandatory)][int]$TargetHeight
    )

    Assert-DetectedClientGeometry -Geometry $Layout -Context 'Synthesis geometry' -TargetWidth $TargetWidth -TargetHeight $TargetHeight
    $inputCenters = @((Get-RequiredGeometryProperty -Value $Layout -Name 'inputCenters' -Context 'Synthesis geometry'))
    if ($inputCenters.Count -ne 5) { throw 'Synthesis geometry must contain exactly five input centers.' }

    $synthesisValues = New-Object 'System.Collections.Generic.List[int]'
    for ($index = 0; $index -lt $inputCenters.Count; $index++) {
        $point = ConvertTo-ValidatedClientPoint -Value $inputCenters[$index] -Name ('Synthesis input center ' + ($index + 1)) -TargetWidth $TargetWidth -TargetHeight $TargetHeight
        [void]$synthesisValues.Add([int]$point[0])
        [void]$synthesisValues.Add([int]$point[1])
    }
    foreach ($pointName in @('okCenter', 'cancelCenter', 'closeCenter')) {
        $point = ConvertTo-ValidatedClientPoint -Value (Get-RequiredGeometryProperty -Value $Layout -Name $pointName -Context 'Synthesis geometry') -Name ('Synthesis ' + $pointName) -TargetWidth $TargetWidth -TargetHeight $TargetHeight
        [void]$synthesisValues.Add([int]$point[0])
        [void]$synthesisValues.Add([int]$point[1])
    }
    $panelBounds = ConvertTo-ValidatedClientBounds -Value (Get-RequiredGeometryProperty -Value $Layout -Name 'panelBounds' -Context 'Synthesis geometry') -Name 'Synthesis panel bounds' -TargetWidth $TargetWidth -TargetHeight $TargetHeight
    foreach ($value in $panelBounds) { [void]$synthesisValues.Add([int]$value) }

    $confirmationValues = $null
    if ($Layout.PSObject.Properties['confirmationGeometry'] -and $null -ne $Layout.confirmationGeometry) {
        $confirmation = $Layout.confirmationGeometry
        if ($confirmation.PSObject.Properties['detected'] -and
            $confirmation.PSObject.Properties['actionable'] -and
            [bool]$confirmation.detected -and [bool]$confirmation.actionable) {
            Assert-DetectedClientGeometry -Geometry $confirmation -Context 'Confirmation geometry' -TargetWidth $TargetWidth -TargetHeight $TargetHeight
            $values = New-Object 'System.Collections.Generic.List[int]'
            $bounds = ConvertTo-ValidatedClientBounds -Value (Get-RequiredGeometryProperty -Value $confirmation -Name 'panelBounds' -Context 'Confirmation geometry') -Name 'Confirmation panel bounds' -TargetWidth $TargetWidth -TargetHeight $TargetHeight
            foreach ($value in $bounds) { [void]$values.Add([int]$value) }
            foreach ($pointName in @('checkboxCenter', 'okCenter', 'cancelCenter')) {
                $point = ConvertTo-ValidatedClientPoint -Value (Get-RequiredGeometryProperty -Value $confirmation -Name $pointName -Context 'Confirmation geometry') -Name ('Confirmation ' + $pointName) -TargetWidth $TargetWidth -TargetHeight $TargetHeight
                [void]$values.Add([int]$point[0])
                [void]$values.Add([int]$point[1])
            }
            $confirmationValues = $values.ToArray()
        }
    }

    $inventoryMarkerValues = $null
    if ($Layout.PSObject.Properties['inventoryMarkerGeometry'] -and $null -ne $Layout.inventoryMarkerGeometry) {
        $inventoryMarker = $Layout.inventoryMarkerGeometry
        if ($inventoryMarker.PSObject.Properties['detected'] -and
            $inventoryMarker.PSObject.Properties['actionable'] -and
            [bool]$inventoryMarker.detected -and [bool]$inventoryMarker.actionable) {
            Assert-DetectedClientGeometry -Geometry $inventoryMarker -Context 'Inventory marker geometry' -TargetWidth $TargetWidth -TargetHeight $TargetHeight
            $inventoryMarkerValues = @(ConvertTo-ValidatedClientBounds -Value (Get-RequiredGeometryProperty -Value $inventoryMarker -Name 'panelBounds' -Context 'Inventory marker geometry') -Name 'Inventory marker bounds' -TargetWidth $TargetWidth -TargetHeight $TargetHeight)
        }
    }

    return [pscustomobject]@{
        ClientPixels = $true
        SynthesisValues = $synthesisValues.ToArray()
        ConfirmationValues = $confirmationValues
        InventoryMarkerValues = $inventoryMarkerValues
    }
}

function Assert-ExpectedTargetMetrics {
    param(
        [Parameter(Mandatory)]$Target,
        [int]$ExpectedWidth = 0,
        [int]$ExpectedHeight = 0,
        [int]$ExpectedWindowDpi = 0
    )

    if (($ExpectedWidth -gt 0) -xor ($ExpectedHeight -gt 0)) {
        throw 'Expected game client width and height must be supplied together.'
    }
    if ($ExpectedWidth -gt 0 -and
        ([int]$Target.Width -ne $ExpectedWidth -or [int]$Target.Height -ne $ExpectedHeight)) {
        throw ('The Revelation client size changed after calibration; expected ' +
            $ExpectedWidth + 'x' + $ExpectedHeight + ', current ' +
            [int]$Target.Width + 'x' + [int]$Target.Height + '.')
    }
    if ($ExpectedWindowDpi -gt 0 -and [int]$Target.Dpi -ne $ExpectedWindowDpi) {
        throw ('The Revelation window DPI changed after calibration; expected ' +
            $ExpectedWindowDpi + ', current ' + [int]$Target.Dpi + '.')
    }
}

function Assert-ExpectedTargetIdentity {
    param(
        [Parameter(Mandatory)]$Target,
        [int]$ExpectedGameProcessId = 0,
        [int64]$ExpectedWindowHandle = 0,
        [int]$ExpectedInteractiveSessionId = -1
    )

    if ($ExpectedGameProcessId -gt 0 -and [int]$Target.Process.Id -ne $ExpectedGameProcessId) {
        throw ('The Revelation game process changed after calibration; expected ' +
            $ExpectedGameProcessId + ', current ' + [int]$Target.Process.Id + '.')
    }
    if ($ExpectedWindowHandle -ne 0 -and [int64]$Target.Handle -ne $ExpectedWindowHandle) {
        throw ('The Revelation game window changed after calibration; expected handle ' +
            $ExpectedWindowHandle + ', current ' + [int64]$Target.Handle + '.')
    }
    if ($ExpectedInteractiveSessionId -ge 0 -and
        [int]$Target.Process.SessionId -ne $ExpectedInteractiveSessionId) {
        throw ('The Revelation game session changed after calibration; expected ' +
            $ExpectedInteractiveSessionId + ', current ' + [int]$Target.Process.SessionId + '.')
    }
}

function Get-GameTarget {
    param([switch]$RequireClientArea)

    $currentSessionId = [int][Diagnostics.Process]::GetCurrentProcess().SessionId
    $candidates = @(Get-Process -Name 'tianyu' -ErrorAction SilentlyContinue | Where-Object {
            $_.MainWindowHandle -ne [IntPtr]::Zero -and $_.SessionId -eq $currentSessionId
        })
    if ($candidates.Count -ne 1) {
        throw "Expected exactly one tianyu.exe window; found $($candidates.Count)."
    }

    $process = $candidates[0]
    $handle = [IntPtr]([int64]$process.MainWindowHandle)
    $rect = New-Object RevelationToolkit.GameInspectorNative+RECT
    $rectAvailable = [RevelationToolkit.GameInspectorNative]::GetClientRect($handle, [ref]$rect)
    $width = if ($rectAvailable) { [Math]::Max(0, [int]($rect.Right - $rect.Left)) } else { 0 }
    $height = if ($rectAvailable) { [Math]::Max(0, [int]($rect.Bottom - $rect.Top)) } else { 0 }
    if ($RequireClientArea -and ($width -le 0 -or $height -le 0)) {
        throw 'The Revelation client area is unavailable. Restore the game before capturing or calibrating a click.'
    }

    return [pscustomobject]@{
        Process = $process
        Handle  = $handle
        Width   = $width
        Height  = $height
        Dpi     = [int][RevelationToolkit.GameInspectorNative]::ReadWindowDpi($handle)
    }
}

function Restore-GameTarget {
    param([Parameter(Mandatory)]$Target)

    if ([RevelationToolkit.GameInspectorNative]::IsIconic($Target.Handle)) {
        [void][RevelationToolkit.GameInspectorNative]::PostMessage($Target.Handle, 0x0112, [UIntPtr]::new([uint32]0xF120), [IntPtr]::Zero)
        Start-Sleep -Milliseconds 250
    }
    [void][RevelationToolkit.GameInspectorNative]::SetForegroundWindow($Target.Handle)
    $deadline = [DateTime]::UtcNow.AddMilliseconds(900)
    do {
        if ([RevelationToolkit.GameInspectorNative]::GetForegroundWindow() -eq $Target.Handle) {
            return $true
        }
        [void][RevelationToolkit.GameInspectorNative]::ShowWindowAsync($Target.Handle, 9)
        Start-Sleep -Milliseconds 45
        [void][RevelationToolkit.GameInspectorNative]::SetForegroundWindow($Target.Handle)
    } while ([DateTime]::UtcNow -lt $deadline)
    return $false
}

function Assert-ElevatedAgentNonce {
    param([Parameter(Mandatory)][string]$Nonce)

    if ($Nonce -notmatch '^[0-9a-f]{32}$') {
        throw 'Inspector mailbox nonce is invalid.'
    }
}

function Get-ElevatedAgentRequestPath {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce
    )

    Assert-ElevatedAgentNonce -Nonce $Nonce
    return (Join-Path $StateDirectory ('request-' + $Nonce + '.json'))
}

function Get-ElevatedAgentProcessingPath {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce
    )

    Assert-ElevatedAgentNonce -Nonce $Nonce
    return (Join-Path $StateDirectory ('processing-' + $Nonce + '.json'))
}

function Get-ElevatedAgentResponsePath {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce
    )

    Assert-ElevatedAgentNonce -Nonce $Nonce
    return (Join-Path $StateDirectory ('response-' + $Nonce + '.json'))
}

function Write-ElevatedAgentRequest {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce,
        [Parameter(Mandatory)][object]$Value
    )

    Assert-ElevatedAgentNonce -Nonce $Nonce
    $valueHasNonce = if ($Value -is [Collections.IDictionary]) {
        $Value.Contains('nonce')
    } else {
        $null -ne $Value.PSObject.Properties['nonce']
    }
    if (-not $valueHasNonce -or [string]$Value.nonce -ne $Nonce) {
        throw 'Inspector request body nonce does not match its mailbox path.'
    }
    if (-not (Test-Path -LiteralPath $StateDirectory)) {
        [void](New-Item -ItemType Directory -Path $StateDirectory -Force)
    }

    $requestPath = Get-ElevatedAgentRequestPath -StateDirectory $StateDirectory -Nonce $Nonce
    $tempPath = Join-Path $StateDirectory ('request-' + $Nonce + '-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $utf8NoBom = New-Object Text.UTF8Encoding($false)
    try {
        $json = $Value | ConvertTo-Json -Depth 8 -Compress
        [IO.File]::WriteAllText($tempPath, $json, $utf8NoBom)
        [IO.File]::Move($tempPath, $requestPath)
        return $requestPath
    } finally {
        Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
    }
}

function Read-ElevatedAgentResponse {
    param(
        [Parameter(Mandatory)][string]$ResponsePath,
        [Parameter(Mandatory)][string]$Nonce
    )

    try {
        try {
            $response = Get-Content -LiteralPath $ResponsePath -Raw | ConvertFrom-Json -ErrorAction Stop
        } catch {
            throw ('GAME_INPUT_OUTCOME_UNKNOWN: elevated agent response is invalid for nonce ' + $Nonce + '.')
        }
        if (-not $response.PSObject.Properties['nonce'] -or [string]$response.nonce -ne $Nonce) {
            throw ('GAME_INPUT_OUTCOME_UNKNOWN: elevated agent response nonce mismatch for ' + $Nonce + '.')
        }
        return $response
    } finally {
        Remove-Item -LiteralPath $ResponsePath -Force -ErrorAction SilentlyContinue
    }
}

function Try-CancelElevatedAgentRequest {
    param(
        [Parameter(Mandatory)][string]$RequestPath,
        [Parameter(Mandatory)][string]$Nonce
    )

    $directory = Split-Path -Parent $RequestPath
    $cancelPath = Join-Path $directory ('cancelled-' + $Nonce + '-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::Move($RequestPath, $cancelPath)
        return $true
    } catch [IO.FileNotFoundException] {
        return $false
    } catch [IO.IOException] {
        if (-not (Test-Path -LiteralPath $RequestPath)) { return $false }
        throw
    } finally {
        Remove-Item -LiteralPath $cancelPath -Force -ErrorAction SilentlyContinue
    }
}

function Wait-ElevatedAgentResponse {
    param(
        [Parameter(Mandatory)][string]$ResponsePath,
        [Parameter(Mandatory)][string]$RequestPath,
        [Parameter(Mandatory)][string]$ProcessingPath,
        [Parameter(Mandatory)][string]$Nonce,
        [int]$TimeoutMilliseconds = 12000,
        [scriptblock]$WakeAgent
    )

    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    $nextWake = [DateTime]::UtcNow.AddMilliseconds(350)
    $lastWakeError = $null
    do {
        if (Test-Path -LiteralPath $ResponsePath) {
            return (Read-ElevatedAgentResponse -ResponsePath $ResponsePath -Nonce $Nonce)
        }
        if ($null -ne $WakeAgent -and [DateTime]::UtcNow -ge $nextWake) {
            try {
                & $WakeAgent
                $lastWakeError = $null
            } catch {
                $lastWakeError = $_
            }
            $nextWake = [DateTime]::UtcNow.AddMilliseconds(400)
        }
        Start-Sleep -Milliseconds 20
    } while ([DateTime]::UtcNow -lt $deadline)

    if (Test-Path -LiteralPath $ResponsePath) {
        return (Read-ElevatedAgentResponse -ResponsePath $ResponsePath -Nonce $Nonce)
    }
    if (Try-CancelElevatedAgentRequest -RequestPath $RequestPath -Nonce $Nonce) {
        if ($null -ne $lastWakeError) {
            throw ('The elevated agent could not be started: ' + $lastWakeError.Exception.Message)
        }
        throw 'The elevated agent did not claim the input request within 12 seconds.'
    }
    if (Test-Path -LiteralPath $ResponsePath) {
        return (Read-ElevatedAgentResponse -ResponsePath $ResponsePath -Nonce $Nonce)
    }
    $claimState = if (Test-Path -LiteralPath $ProcessingPath) { 'processing evidence exists' } else { 'request was claimed' }
    throw ('GAME_INPUT_OUTCOME_UNKNOWN: elevated agent ' + $claimState + ' for nonce ' + $Nonce + ', but no response was received.')
}

function ConvertTo-MouseLParam {
    param([int]$ClientX, [int]$ClientY)
    $value = (($ClientY -band 0xFFFF) -shl 16) -bor ($ClientX -band 0xFFFF)
    return [IntPtr]([int64]$value)
}

function Start-ElevatedInspectorAgent {
    param([switch]$ForceCheck)

    if (-not $ForceCheck -and $global:RevelationElevatedAgentReady) { return }
    $taskName = 'RevelationGameInspectorAgent'
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($null -eq $task) {
        throw 'The elevated agent is not installed. Run Install-RevelationGameInspectorAgent.ps1 as administrator.'
    }
    if ([string]$task.State -ne 'Running') {
        Start-ScheduledTask -TaskName $taskName
    }
    $global:RevelationElevatedAgentReady = $true
}

function Invoke-ElevatedInspectorAgent {
    param(
        [Parameter(Mandatory)][ValidateSet('Capabilities', 'FrameCapture', 'Key', 'KeyBurst', 'CloseRequest', 'Click', 'WindowClick', 'Move')][string]$AgentAction,
        [string]$AgentKeyName = 'B',
        [string]$AgentMouseButton = 'Left',
        [int]$AgentX = -1,
        [int]$AgentY = -1,
        [int]$AgentRepeatCount = 1,
        [int]$AgentIntervalMs = 75,
        [int]$AgentDurationSeconds = 30,
        [int]$AgentTimeoutMilliseconds = 12000,
        $AgentTarget = $null
    )

    $agentStateDir = Join-Path $env:LOCALAPPDATA 'RevelationToolkit\GameInspector'
    if (-not (Test-Path -LiteralPath $agentStateDir)) {
        [void](New-Item -ItemType Directory -Path $agentStateDir -Force)
    }
    $nonce = [Guid]::NewGuid().ToString('N')
    $requestPath = Get-ElevatedAgentRequestPath -StateDirectory $agentStateDir -Nonce $nonce
    $processingPath = Get-ElevatedAgentProcessingPath -StateDirectory $agentStateDir -Nonce $nonce
    $responsePath = Get-ElevatedAgentResponsePath -StateDirectory $agentStateDir -Nonce $nonce
    $request = [ordered]@{
        nonce       = $nonce
        action      = $AgentAction
        keyName     = $AgentKeyName
        mouseButton = $AgentMouseButton
        x           = $AgentX
        y           = $AgentY
        repeatCount = $AgentRepeatCount
        intervalMs  = $AgentIntervalMs
        durationSeconds = $AgentDurationSeconds
        targetProcessId = $(if ($null -ne $AgentTarget) { [int]$AgentTarget.Process.Id } else { 0 })
        targetHandle = $(if ($null -ne $AgentTarget) { [int64]$AgentTarget.Handle } else { 0 })
        targetSessionId = [int][Diagnostics.Process]::GetCurrentProcess().SessionId
        targetClientWidth = $(if ($null -ne $AgentTarget) { [int]$AgentTarget.Width } else { 0 })
        targetClientHeight = $(if ($null -ne $AgentTarget) { [int]$AgentTarget.Height } else { 0 })
        targetDpi = $(if ($null -ne $AgentTarget) { [int]$AgentTarget.Dpi } else { 0 })
        pointerMode = $PointerMode
        createdAt   = [DateTime]::UtcNow.ToString('o')
    }
    [void](Write-ElevatedAgentRequest -StateDirectory $agentStateDir -Nonce $nonce -Value $request)

    try {
        Start-ElevatedInspectorAgent
    } catch {
        if (Try-CancelElevatedAgentRequest -RequestPath $requestPath -Nonce $nonce) { throw }
        throw ('GAME_INPUT_OUTCOME_UNKNOWN: elevated agent claimed nonce ' + $nonce + ' while the task wake failed.')
    }
    $wakeAgent = { Start-ElevatedInspectorAgent -ForceCheck }
    return (Wait-ElevatedAgentResponse -ResponsePath $responsePath -RequestPath $requestPath -ProcessingPath $processingPath -Nonce $nonce -TimeoutMilliseconds $AgentTimeoutMilliseconds -WakeAgent $wakeAgent)
}

function Get-ElevatedAgentForeground {
    param(
        [Parameter(Mandatory)]$AgentResponse,
        [Parameter(Mandatory)][string]$AgentAction,
        $ExpectedTarget = $null
    )

    if (-not $AgentResponse.PSObject.Properties['success']) {
        throw ('Elevated inspector agent ' + $AgentAction + ' response is missing success.')
    }
    if (-not [bool]$AgentResponse.success) {
        $message = if ($AgentResponse.PSObject.Properties['error'] -and
            -not [string]::IsNullOrWhiteSpace([string]$AgentResponse.error)) {
            [string]$AgentResponse.error
        } else {
            'Elevated inspector agent rejected ' + $AgentAction + ' without an error message.'
        }
        throw ('Elevated inspector agent ' + $AgentAction + ' failed: ' + $message)
    }
    if (-not $AgentResponse.PSObject.Properties['foreground']) {
        throw ('Elevated inspector agent ' + $AgentAction + ' response is missing foreground.')
    }
    if ($null -ne $ExpectedTarget) {
        if (-not $AgentResponse.PSObject.Properties['processId'] -or [int]$AgentResponse.processId -ne $ExpectedTarget.Process.Id) {
            throw ('Elevated inspector agent ' + $AgentAction + ' answered for a different game process.')
        }
        if (-not $AgentResponse.PSObject.Properties['handle'] -or [int64]$AgentResponse.handle -ne [int64]$ExpectedTarget.Handle) {
            throw ('Elevated inspector agent ' + $AgentAction + ' answered for a different game window.')
        }
    }
    if (-not [bool]$AgentResponse.foreground) {
        throw ('Elevated inspector agent ' + $AgentAction + ' did not keep Revelation in the foreground.')
    }
    return $true
}

function Get-ElevatedAgentCapabilities {
    param([Parameter(Mandatory)]$AgentResponse)

    if (-not $AgentResponse.PSObject.Properties['success']) {
        throw 'Elevated inspector capability response is missing success.'
    }
    if (-not [bool]$AgentResponse.success) {
        $message = if ($AgentResponse.PSObject.Properties['error']) { [string]$AgentResponse.error } else { 'unknown error' }
        throw ('Elevated inspector capability request failed: ' + $message)
    }
    foreach ($required in @('accountSid', 'sessionId', 'protocolVersion', 'capabilities')) {
        if (-not $AgentResponse.PSObject.Properties[$required]) {
            throw ('Elevated inspector capability response is missing ' + $required + '.')
        }
    }
    return $AgentResponse
}

if ($Action -eq 'AgentCapabilities') {
    $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction Capabilities
    $capabilities = Get-ElevatedAgentCapabilities -AgentResponse $agentResponse
    $expectedAccountSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    [ordered]@{
        action = $Action
        success = $true
        accountSid = [string]$capabilities.accountSid
        expectedAccountSid = [string]$expectedAccountSid
        accountMatches = [string]$capabilities.accountSid -eq [string]$expectedAccountSid
        sessionId = [int]$capabilities.sessionId
        protocolVersion = [int]$capabilities.protocolVersion
        capabilities = @($capabilities.capabilities)
        elevated = [bool]$capabilities.elevated
        inputTransport = [string]$capabilities.inputTransport
        inputHoldMilliseconds = [int]$capabilities.inputHoldMilliseconds
        pointerModes = @($capabilities.pointerModes)
    } | ConvertTo-Json -Depth 4 -Compress
    return
}

$target = Get-GameTarget
$focused = [RevelationToolkit.GameInspectorNative]::GetForegroundWindow() -eq $target.Handle
$accepted = $true
$capturePath = ''
$probeGeometryFingerprint = ''

switch ($Action) {
    'Capture' {
        if ([string]::IsNullOrWhiteSpace($OutputPath)) {
            throw 'Capture requires OutputPath.'
        }
        $focused = Restore-GameTarget -Target $target
        if (-not $focused) {
            throw 'The Revelation window did not become foreground before capture.'
        }
        $target = Get-GameTarget -RequireClientArea

        $originAvailable = $false
        for ($originAttempt = 1; $originAttempt -le 20; $originAttempt++) {
            $origin = New-Object RevelationToolkit.GameInspectorNative+POINT
            $origin.X = 0
            $origin.Y = 0
            if ([RevelationToolkit.GameInspectorNative]::ClientToScreen($target.Handle, [ref]$origin)) {
                $originAvailable = $true
                break
            }
            Start-Sleep -Milliseconds 100
        }
        if (-not $originAvailable) { throw 'Could not determine the Revelation window screen coordinates.' }

        $capturePath = [IO.Path]::GetFullPath($OutputPath)
        $captureDir = Split-Path -Parent $capturePath
        if (-not (Test-Path -LiteralPath $captureDir)) {
            [void](New-Item -ItemType Directory -Path $captureDir -Force)
        }

        Add-Type -AssemblyName System.Drawing
        $bitmap = New-Object Drawing.Bitmap($target.Width, $target.Height, [Drawing.Imaging.PixelFormat]::Format24bppRgb)
        try {
            $graphics = [Drawing.Graphics]::FromImage($bitmap)
            try {
                $graphics.CopyFromScreen($origin.X, $origin.Y, 0, 0, $bitmap.Size, [Drawing.CopyPixelOperation]::SourceCopy)
            } finally {
                $graphics.Dispose()
            }
            $bitmap.Save($capturePath, [Drawing.Imaging.ImageFormat]::Png)
        } finally {
            $bitmap.Dispose()
        }
        $accepted = (Test-Path -LiteralPath $capturePath) -and ((Get-Item -LiteralPath $capturePath).Length -gt 0)
    }
    'ProbeSynthesis' {
        $target = Get-GameTarget -RequireClientArea
        $geometry = $null
        $geometryIsClientPixels = $false
        $confirmationGeometry = $null
        $inventoryMarkerGeometry = $null
        if (-not [string]::IsNullOrWhiteSpace($GeometryPath)) {
            if (-not (Test-Path -LiteralPath $GeometryPath)) {
                throw 'The requested synthesis geometry file does not exist.'
            }
            $layout = Get-Content -LiteralPath $GeometryPath -Raw | ConvertFrom-Json -ErrorAction Stop
            $validatedGeometry = ConvertTo-ValidatedSynthesisProbeGeometry -Layout $layout -TargetWidth $target.Width -TargetHeight $target.Height
            $geometry = $validatedGeometry.SynthesisValues
            $geometryIsClientPixels = [bool]$validatedGeometry.ClientPixels
            $probeGeometryFingerprint = [string]$layout.fingerprint
            $confirmationGeometry = $validatedGeometry.ConfirmationValues
            $inventoryMarkerGeometry = $validatedGeometry.InventoryMarkerValues
        }
        $probe = [RevelationToolkit.GameInspectorNative]::ProbeSynthesis(
            $target.Handle,
            $target.Width,
            $target.Height,
            $geometry,
            $geometryIsClientPixels,
            $confirmationGeometry,
            $inventoryMarkerGeometry)
    }
    'FrameCapture' {
        $captureTimeout = [Math]::Max(12000, ($DurationSeconds + 20) * 1000)
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction FrameCapture -AgentDurationSeconds $DurationSeconds -AgentTimeoutMilliseconds $captureTimeout -AgentTarget $target
        if (-not $agentResponse.PSObject.Properties['success'] -or -not [bool]$agentResponse.success) {
            $message = if ($agentResponse.PSObject.Properties['error']) { [string]$agentResponse.error } else { 'unknown error' }
            throw ('Elevated frame capture failed: ' + $message)
        }
        if (-not $agentResponse.PSObject.Properties['processId'] -or [int]$agentResponse.processId -ne $target.Process.Id) {
            throw 'Elevated frame capture answered for a different game process.'
        }
        foreach ($required in @('csvPath', 'csvLines', 'durationSeconds', 'exitCode')) {
            if (-not $agentResponse.PSObject.Properties[$required]) {
                throw ('Elevated frame capture response is missing ' + $required + '.')
            }
        }
        $capturePath = [string]$agentResponse.csvPath
        if (-not (Test-Path -LiteralPath $capturePath -PathType Leaf) -or (Get-Item -LiteralPath $capturePath).Length -le 0) {
            throw 'Elevated frame capture did not produce a readable CSV file.'
        }
        $focused = [bool]$agentResponse.foreground
        $accepted = $true
    }
    'Key' {
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction Key -AgentKeyName $KeyName -AgentMouseButton Left -AgentTarget $target
        $focused = Get-ElevatedAgentForeground -AgentResponse $agentResponse -AgentAction 'Key' -ExpectedTarget $target
        $accepted = $true
    }
    'KeyBurst' {
        if ($KeyName -ne 'B') {
            throw 'KeyBurst is restricted to the Revelation inventory B key.'
        }
        if (($RepeatCount % 2) -ne 0) {
            throw 'KeyBurst repeat count must be even so the inventory returns to its original state.'
        }
        $burstTimeout = [Math]::Max(12000, ($RepeatCount * ($IntervalMs + 80)) + 3000)
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction KeyBurst -AgentKeyName B -AgentMouseButton Left -AgentRepeatCount $RepeatCount -AgentIntervalMs $IntervalMs -AgentTimeoutMilliseconds $burstTimeout -AgentTarget $target
        $focused = Get-ElevatedAgentForeground -AgentResponse $agentResponse -AgentAction 'KeyBurst' -ExpectedTarget $target
        if (-not $agentResponse.PSObject.Properties['acceptedCount'] -or [int]$agentResponse.acceptedCount -ne $RepeatCount) {
            throw 'KeyBurst did not confirm every requested key press.'
        }
        $accepted = $true
    }
    'CloseRequest' {
        Assert-ExpectedTargetIdentity -Target $target -ExpectedGameProcessId $ExpectedProcessId -ExpectedWindowHandle $ExpectedHandle -ExpectedInteractiveSessionId $ExpectedSessionId
        Assert-ExpectedTargetMetrics -Target $target -ExpectedWidth $ExpectedClientWidth -ExpectedHeight $ExpectedClientHeight -ExpectedWindowDpi $ExpectedDpi
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction CloseRequest -AgentKeyName B -AgentMouseButton Left -AgentTarget $target
        $focused = Get-ElevatedAgentForeground -AgentResponse $agentResponse -AgentAction 'CloseRequest' -ExpectedTarget $target
        $accepted = $true
    }
    'Click' {
        if ($X -lt 0 -or $Y -lt 0 -or $X -ge $target.Width -or $Y -ge $target.Height) {
            throw "Click coordinates are outside the client area ${($target.Width)}x${($target.Height)}: $X,$Y."
        }
        Assert-ExpectedTargetIdentity -Target $target -ExpectedGameProcessId $ExpectedProcessId -ExpectedWindowHandle $ExpectedHandle -ExpectedInteractiveSessionId $ExpectedSessionId
        Assert-ExpectedTargetMetrics -Target $target -ExpectedWidth $ExpectedClientWidth -ExpectedHeight $ExpectedClientHeight -ExpectedWindowDpi $ExpectedDpi
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction Click -AgentKeyName B -AgentMouseButton $MouseButton -AgentX $X -AgentY $Y -AgentTarget $target
        $focused = Get-ElevatedAgentForeground -AgentResponse $agentResponse -AgentAction 'Click' -ExpectedTarget $target
        $accepted = $true
    }
    'WindowClick' {
        if ($X -lt 0 -or $Y -lt 0 -or $X -ge $target.Width -or $Y -ge $target.Height) {
            throw "WindowClick coordinates are outside the client area ${($target.Width)}x${($target.Height)}: $X,$Y."
        }
        Assert-ExpectedTargetIdentity -Target $target -ExpectedGameProcessId $ExpectedProcessId -ExpectedWindowHandle $ExpectedHandle -ExpectedInteractiveSessionId $ExpectedSessionId
        Assert-ExpectedTargetMetrics -Target $target -ExpectedWidth $ExpectedClientWidth -ExpectedHeight $ExpectedClientHeight -ExpectedWindowDpi $ExpectedDpi
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction WindowClick -AgentKeyName B -AgentMouseButton $MouseButton -AgentX $X -AgentY $Y -AgentTarget $target
        $focused = Get-ElevatedAgentForeground -AgentResponse $agentResponse -AgentAction 'WindowClick' -ExpectedTarget $target
        $accepted = $true
    }
    'Move' {
        if ($X -lt 0 -or $Y -lt 0 -or $X -ge $target.Width -or $Y -ge $target.Height) {
            throw "Move coordinates are outside the client area: $X,$Y."
        }
        Assert-ExpectedTargetIdentity -Target $target -ExpectedGameProcessId $ExpectedProcessId -ExpectedWindowHandle $ExpectedHandle -ExpectedInteractiveSessionId $ExpectedSessionId
        Assert-ExpectedTargetMetrics -Target $target -ExpectedWidth $ExpectedClientWidth -ExpectedHeight $ExpectedClientHeight -ExpectedWindowDpi $ExpectedDpi
        $agentResponse = Invoke-ElevatedInspectorAgent -AgentAction Move -AgentKeyName B -AgentMouseButton Left -AgentX $X -AgentY $Y -AgentTarget $target
        $focused = Get-ElevatedAgentForeground -AgentResponse $agentResponse -AgentAction 'Move' -ExpectedTarget $target
        $accepted = $true
    }
}

$result = [ordered]@{
    action     = $Action
    success    = [bool]$accepted
    processId  = [int]$target.Process.Id
    handle     = [int64]$target.Handle
    width      = [int]$target.Width
    height     = [int]$target.Height
    minimized  = [bool][RevelationToolkit.GameInspectorNative]::IsIconic($target.Handle)
    foreground = [bool]$focused
    outputPath = [string]$capturePath
}
$result['dpi'] = [int]$target.Dpi
$result['sessionId'] = [int]$target.Process.SessionId
$result['clientAreaAvailable'] = $target.Width -gt 0 -and $target.Height -gt 0
if ($Action -in @('Key', 'KeyBurst', 'CloseRequest', 'Click', 'WindowClick', 'Move')) {
    $result['effectVerified'] = $false
    $result['inputOutcome'] = 'submitted_unverified'
    $result['pointerMode'] = [string]$agentResponse.pointerMode
}
if ($Action -eq 'KeyBurst') {
    $result['acceptedCount'] = [int]$agentResponse.acceptedCount
    $result['intervalMs'] = $IntervalMs
}

if ($Action -eq 'FrameCapture') {
    $result['durationSeconds'] = [int]$agentResponse.durationSeconds
    $result['csvLines'] = [int]$agentResponse.csvLines
    $result['exitCode'] = [int]$agentResponse.exitCode
}

if ($Action -eq 'ProbeSynthesis') {
    $result['windowVisible'] = [bool]$probe.WindowVisible
    $result['inventoryVisible'] = [bool]$probe.InventoryVisible
    $result['occupiedInputs'] = [int]$probe.OccupiedInputs
    $result['occupiedSlots'] = @($probe.OccupiedSlots)
    $result['okActive'] = [bool]$probe.OkActive
    $result['confirmationVisible'] = [bool]$probe.ConfirmationVisible
    $result['geometryFingerprint'] = [string]$probeGeometryFingerprint
}

$result | ConvertTo-Json -Compress
if (-not $accepted) { exit 2 }
