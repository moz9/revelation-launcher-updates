$ErrorActionPreference = 'Stop'

$stateDir = Join-Path $env:LOCALAPPDATA 'RevelationToolkit\GameInspector'

function Assert-AgentNonce {
    param([Parameter(Mandatory)][string]$Nonce)

    if ($Nonce -notmatch '^[0-9a-f]{32}$') {
        throw 'Inspector mailbox nonce is invalid.'
    }
}

function Get-AgentProcessingPath {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce
    )

    Assert-AgentNonce -Nonce $Nonce
    return (Join-Path $StateDirectory ('processing-' + $Nonce + '.json'))
}

function Get-AgentResponsePath {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce
    )

    Assert-AgentNonce -Nonce $Nonce
    return (Join-Path $StateDirectory ('response-' + $Nonce + '.json'))
}

function Get-AgentRequestNonceFromPath {
    param([Parameter(Mandatory)][string]$RequestPath)

    $name = [IO.Path]::GetFileName($RequestPath)
    if ($name -notmatch '^request-([0-9a-f]{32})\.json$') {
        throw 'Inspector request filename is invalid.'
    }
    return [string]$Matches[1]
}

function Get-AgentPendingRequests {
    param([Parameter(Mandatory)][string]$StateDirectory)

    if (-not (Test-Path -LiteralPath $StateDirectory -PathType Container)) { return @() }
    return @(Get-ChildItem -LiteralPath $StateDirectory -File -Filter 'request-*.json' -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^request-[0-9a-f]{32}\.json$' } |
        Sort-Object -Property LastWriteTimeUtc, Name)
}

function Claim-AgentRequest {
    param(
        [Parameter(Mandatory)][string]$RequestPath,
        [Parameter(Mandatory)][string]$StateDirectory
    )

    $nonce = Get-AgentRequestNonceFromPath -RequestPath $RequestPath
    $processingPath = Get-AgentProcessingPath -StateDirectory $StateDirectory -Nonce $nonce
    try {
        [IO.File]::Move($RequestPath, $processingPath)
    } catch [IO.FileNotFoundException] {
        return $null
    } catch [IO.IOException] {
        if (-not (Test-Path -LiteralPath $RequestPath) -or (Test-Path -LiteralPath $processingPath)) {
            return $null
        }
        throw
    }
    return [pscustomobject]@{
        Nonce = $nonce
        Path = $processingPath
        RequestPath = $RequestPath
    }
}

function Read-AgentRequest {
    param(
        [Parameter(Mandatory)][string]$ProcessingPath,
        [Parameter(Mandatory)][string]$ExpectedNonce
    )

    Assert-AgentNonce -Nonce $ExpectedNonce
    $request = Get-Content -LiteralPath $ProcessingPath -Raw | ConvertFrom-Json -ErrorAction Stop
    if (-not $request.PSObject.Properties['nonce'] -or [string]$request.nonce -ne $ExpectedNonce) {
        throw 'Inspector request body nonce does not match its filename nonce.'
    }
    return $request
}

function Test-AgentRequestExpired {
    param(
        [Parameter(Mandatory)][string]$ProcessingPath,
        [int]$MaxAgeSeconds = 60
    )

    if (-not (Test-Path -LiteralPath $ProcessingPath -PathType Leaf)) { return $false }
    $age = [DateTime]::UtcNow - (Get-Item -LiteralPath $ProcessingPath).LastWriteTimeUtc
    return ($age.TotalSeconds -gt [Math]::Max(1, $MaxAgeSeconds))
}

function Remove-StaleAgentMailboxArtifacts {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [int]$MaxAgeSeconds = 600
    )

    if (-not (Test-Path -LiteralPath $StateDirectory -PathType Container)) { return }
    $deadline = [DateTime]::UtcNow.AddSeconds(-[Math]::Max(60, $MaxAgeSeconds))
    foreach ($file in @(Get-ChildItem -LiteralPath $StateDirectory -File -ErrorAction SilentlyContinue)) {
        $eligible = $file.Name -match '^response-[0-9a-f]{32}\.json$' -or
            $file.Name -match '^(?:request|response|cancelled)-[0-9a-f]{32}-[0-9a-f]{32}\.tmp$'
        if ($eligible -and $file.LastWriteTimeUtc -lt $deadline) {
            Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue
        }
    }
}

function Write-AgentResponse {
    param(
        [Parameter(Mandatory)][object]$Value,
        [string]$StateDirectory = $script:stateDir
    )

    if (-not (Test-Path -LiteralPath $StateDirectory)) {
        [void](New-Item -ItemType Directory -Path $StateDirectory -Force)
    }
    $responseNonce = [string]$Value.nonce
    Assert-AgentNonce -Nonce $responseNonce
    $responsePath = Get-AgentResponsePath -StateDirectory $StateDirectory -Nonce $responseNonce
    $tempPath = Join-Path $StateDirectory ('response-' + $responseNonce + '-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $utf8NoBom = New-Object Text.UTF8Encoding($false)
    try {
        $json = $Value | ConvertTo-Json -Depth 8 -Compress
        [IO.File]::WriteAllText($tempPath, $json, $utf8NoBom)
        [IO.File]::Move($tempPath, $responsePath)
    } finally {
        Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-AgentFrameCapture {
    param(
        [Parameter(Mandatory)][string]$StateDirectory,
        [Parameter(Mandatory)][string]$Nonce,
        [Parameter(Mandatory)][int]$TargetProcessId,
        [Parameter(Mandatory)][int]$DurationSeconds
    )

    Assert-AgentNonce -Nonce $Nonce
    if ($DurationSeconds -lt 5 -or $DurationSeconds -gt 180) {
        throw 'FrameCapture duration must be from 5 through 180 seconds.'
    }

    $presentMonPath = Join-Path $PSScriptRoot 'PresentMon-2.5.0-x64.exe'
    if (-not (Test-Path -LiteralPath $presentMonPath -PathType Leaf)) {
        throw 'The bundled PresentMon executable is missing.'
    }

    $captureDir = Join-Path $StateDirectory ('frame-' + $Nonce)
    [void](New-Item -ItemType Directory -Path $captureDir -Force)
    $csvPath = Join-Path $captureDir 'presentmon.csv'
    $stdoutPath = Join-Path $captureDir 'stdout.txt'
    $stderrPath = Join-Path $captureDir 'stderr.txt'
    $sessionName = 'RevFrame-' + $Nonce.Substring(0, 12)
    $arguments = @(
        '--stop_existing_session',
        '--session_name', $sessionName,
        '--process_id', $TargetProcessId.ToString(),
        '--output_file', $csvPath,
        '--qpc_time_ms',
        '--timed', $DurationSeconds.ToString(),
        '--terminate_after_timed',
        '--no_console_stats'
    )
    $argumentString = [string]::Join(' ', @(
            foreach ($argument in $arguments) {
                $text = [string]$argument
                if ($text -match '[\s"]') {
                    '"' + ($text.Replace('"', '\"')) + '"'
                } else {
                    $text
                }
            }
        ))

    $presentMon = Start-Process -FilePath $presentMonPath -ArgumentList $argumentString -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
    $timeoutMilliseconds = ($DurationSeconds + 15) * 1000
    if (-not $presentMon.WaitForExit($timeoutMilliseconds)) {
        $stopArguments = '--terminate_existing_session --session_name ' + $sessionName
        $stop = Start-Process -FilePath $presentMonPath -ArgumentList $stopArguments -PassThru -WindowStyle Hidden
        [void]$stop.WaitForExit(5000)
        if (-not $presentMon.HasExited) {
            Stop-Process -Id $presentMon.Id -Force -ErrorAction SilentlyContinue
        }
        throw 'PresentMon frame capture did not finish within its bounded timeout.'
    }
    [void]$presentMon.WaitForExit()
    $presentMon.Refresh()
    $rawExitCode = $presentMon.ExitCode
    $exitCode = if ($null -eq $rawExitCode) { 0 } else { [int]$rawExitCode }

    if ($exitCode -ne 0) {
        $details = if (Test-Path -LiteralPath $stderrPath) {
            ((Get-Content -LiteralPath $stderrPath -Tail 12 -ErrorAction SilentlyContinue) -join ' ')
        } else {
            ''
        }
        throw ('PresentMon frame capture failed with exit code ' + $exitCode + $(if ($details) { ': ' + $details } else { '' }))
    }
    if (-not (Test-Path -LiteralPath $csvPath -PathType Leaf) -or (Get-Item -LiteralPath $csvPath).Length -le 0) {
        throw ('FRAME_CAPTURE_NO_FRAMES: PresentMon exited successfully but produced no game frames. Check that the game was rendering during capture. Logs: ' + $captureDir)
    }
    $csvLines = (Get-Content -LiteralPath $csvPath -ErrorAction Stop | Measure-Object -Line).Lines
    if ($csvLines -lt 2) {
        throw ('FRAME_CAPTURE_NO_FRAMES: PresentMon produced only a CSV header. Check that the game was rendering during capture. Logs: ' + $captureDir)
    }

    return [pscustomobject]@{
        CsvPath = $csvPath
        CsvLines = [int]$csvLines
        ExitCode = $exitCode
        DurationSeconds = $DurationSeconds
    }
}

$idleDeadline = [DateTime]::UtcNow.AddMinutes(2)
$nextCleanup = [DateTime]::UtcNow
while ($true) {
    if ([DateTime]::UtcNow -ge $nextCleanup) {
        Remove-StaleAgentMailboxArtifacts -StateDirectory $stateDir
        $nextCleanup = [DateTime]::UtcNow.AddMinutes(1)
    }

    $claim = $null
    foreach ($pendingRequest in @(Get-AgentPendingRequests -StateDirectory $stateDir)) {
        $claim = Claim-AgentRequest -RequestPath ([string]$pendingRequest.FullName) -StateDirectory $stateDir
        if ($null -ne $claim) { break }
    }
    if ($null -eq $claim) {
        if ([DateTime]::UtcNow -ge $idleDeadline) { break }
        Start-Sleep -Milliseconds 20
        continue
    }

    $nonce = [string]$claim.Nonce
    $response = $null
    try {
    if (Test-AgentRequestExpired -ProcessingPath ([string]$claim.Path)) {
        throw 'Inspector request expired before it could be processed; input was not sent.'
    }
    $request = Read-AgentRequest -ProcessingPath ([string]$claim.Path) -ExpectedNonce $nonce

    $action = [string]$request.action
    if ($action -notin @('Capabilities', 'FrameCapture', 'Key', 'KeyBurst', 'CloseRequest', 'Click', 'WindowClick', 'Move')) {
        throw 'Inspector agent action is not allowed.'
    }

    if ($action -eq 'Capabilities') {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        $response = [ordered]@{
            nonce = $nonce
            success = $true
            action = $action
            protocolVersion = 1
            capabilities = @('capture', 'frame_capture', 'input', 'window_control', 'status_mailbox')
            accountSid = [string]$identity.User.Value
            sessionId = [int][Diagnostics.Process]::GetCurrentProcess().SessionId
            elevated = [bool]$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
            inputTransport = 'sendinput'
            inputHoldMilliseconds = 80
            pointerModes = @('Relative', 'Screen')
            finishedAt = [DateTime]::UtcNow.ToString('o')
        }
        try {
            Write-AgentResponse -StateDirectory $stateDir -Value $response
            Remove-Item -LiteralPath ([string]$claim.Path) -Force -ErrorAction Stop
        } catch {
            # Preserve processing evidence when a correlated response cannot be published.
        }
        $idleDeadline = [DateTime]::UtcNow.AddMinutes(2)
        continue
    }

    $keyName = [string]$request.keyName
    if ($keyName -notin @('B', 'Escape', 'Up', 'Down', 'Enter', 'Y')) {
        throw 'Inspector agent key is not allowed.'
    }

    $repeatCount = 1
    $intervalMs = 75
    if ($action -eq 'KeyBurst') {
        if ($keyName -ne 'B') {
            throw 'KeyBurst is restricted to the inventory B key.'
        }
        if (-not $request.PSObject.Properties['repeatCount'] -or -not $request.PSObject.Properties['intervalMs']) {
            throw 'KeyBurst request is missing its bounded repeat settings.'
        }
        $repeatCount = [int]$request.repeatCount
        $intervalMs = [int]$request.intervalMs
        if ($repeatCount -lt 2 -or $repeatCount -gt 120 -or ($repeatCount % 2) -ne 0) {
            throw 'KeyBurst repeat count must be an even value from 2 through 120.'
        }
        if ($intervalMs -lt 20 -or $intervalMs -gt 500) {
            throw 'KeyBurst interval must be from 20 through 500 milliseconds.'
        }
    }

    $durationSeconds = 30
    if ($action -eq 'FrameCapture') {
        if (-not $request.PSObject.Properties['durationSeconds']) {
            throw 'FrameCapture request is missing its bounded duration.'
        }
        $durationSeconds = [int]$request.durationSeconds
        if ($durationSeconds -lt 5 -or $durationSeconds -gt 180) {
            throw 'FrameCapture duration must be from 5 through 180 seconds.'
        }
    }

    $mouseButton = [string]$request.mouseButton
    if ($mouseButton -notin @('Left', 'Right')) {
        throw 'Inspector agent mouse button is not allowed.'
    }
    $pointerMode = if ($request.PSObject.Properties['pointerMode']) { [string]$request.pointerMode } else { 'Relative' }
    if ($pointerMode -notin @('Relative', 'Screen')) {
        throw 'Inspector agent pointer mode is not allowed.'
    }

    if (-not ('RevelationToolkit.ElevatedInspectorInput' -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;

namespace RevelationToolkit
{
    public static class ElevatedInspectorInput
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT { public int X; public int Y; }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct INPUTUNION
        {
            [FieldOffset(0)] public KEYBDINPUT keyboard;
            [FieldOffset(0)] public MOUSEINPUT mouse;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public uint type;
            public INPUTUNION data;
        }

        public const uint INPUT_KEYBOARD = 1;
        public const uint INPUT_MOUSE = 0;
        public const uint KEYEVENTF_EXTENDEDKEY = 0x0001;
        public const uint KEYEVENTF_KEYUP = 0x0002;
        public const uint KEYEVENTF_SCANCODE = 0x0008;
        public const uint MOUSEEVENTF_MOVE = 0x0001;
        public const uint MOUSEEVENTF_VIRTUALDESK = 0x4000;
        public const uint MOUSEEVENTF_ABSOLUTE = 0x8000;

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetClientRect(IntPtr hWnd, out RECT rect);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ClientToScreen(IntPtr hWnd, ref POINT point);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetProcessDPIAware();

        [DllImport("user32.dll")]
        private static extern uint GetDpiForWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int virtualKey);

        [DllImport("user32.dll")]
        private static extern uint MapVirtualKey(uint code, uint mapType);

        [DllImport("user32.dll")]
        public static extern IntPtr WindowFromPoint(POINT point);

        [DllImport("user32.dll")]
        public static extern IntPtr GetAncestor(IntPtr hWnd, uint flags);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool BringWindowToTop(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ShowWindowAsync(IntPtr hWnd, int command);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool PostMessage(IntPtr hWnd, uint message, UIntPtr wParam, IntPtr lParam);

        public static bool PostMouseMessage(IntPtr hWnd, uint message, uint buttonState, int x, int y)
        {
            int packedCoordinates = ((y & 0xFFFF) << 16) | (x & 0xFFFF);
            return PostMessage(hWnd, message, new UIntPtr(buttonState), new IntPtr(packedCoordinates));
        }

        public static bool PostCloseMessage(IntPtr hWnd)
        {
            return PostMessage(hWnd, 0x0010U, UIntPtr.Zero, IntPtr.Zero);
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetCursorPos(out POINT point);

        [DllImport("user32.dll")]
        private static extern int GetSystemMetrics(int index);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint inputCount, INPUT[] inputs, int inputSize);

        public static bool EnablePerMonitorDpiAwareness()
        {
            try
            {
                if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return true;
            }
            catch (EntryPointNotFoundException) { }
            try { return SetProcessDPIAware(); }
            catch (EntryPointNotFoundException) { return false; }
        }

        public static uint ReadWindowDpi(IntPtr hWnd)
        {
            try
            {
                uint dpi = GetDpiForWindow(hWnd);
                return dpi == 0 ? 96U : dpi;
            }
            catch (EntryPointNotFoundException) { return 96U; }
        }

        public static int InputSize { get { return Marshal.SizeOf(typeof(INPUT)); } }

        public static bool IsInputReady(IntPtr target)
        {
            if (target == IntPtr.Zero || GetForegroundWindow() != target) return false;
            foreach (int key in new int[] { 0x01, 0x02, 0x04, 0x10, 0x11, 0x12, 0x5B, 0x5C })
                if ((GetAsyncKeyState(key) & 0x8000) != 0) return false;
            return true;
        }

        private static bool SendHeldInput(INPUT down, INPUT up, IntPtr target, int key)
        {
            if (!IsInputReady(target) || (key != 0 && (GetAsyncKeyState(key) & 0x8000) != 0)) return false;
            if (SendInput(1U, new INPUT[] { down }, InputSize) != 1U) return false;
            bool released = false;
            try
            {
                // The legacy game can poll between frames instead of consuming each message.
                System.Threading.Thread.Sleep(80);
            }
            finally
            {
                released = SendInput(1U, new INPUT[] { up }, InputSize) == 1U;
            }
            return released;
        }

        public static bool PressScanCode(ushort scanCode, bool extended, IntPtr target)
        {
            uint baseFlags = KEYEVENTF_SCANCODE | (extended ? KEYEVENTF_EXTENDEDKEY : 0U);
            INPUT down = new INPUT();
            down.type = INPUT_KEYBOARD;
            down.data.keyboard.wScan = scanCode;
            down.data.keyboard.dwFlags = baseFlags;

            INPUT up = down;
            up.data.keyboard.dwFlags = baseFlags | KEYEVENTF_KEYUP;

            return SendHeldInput(down, up, target, (int)MapVirtualKey(scanCode, 3U));
        }

        public static bool PressVirtualKey(ushort virtualKey, bool extended, IntPtr target)
        {
            uint baseFlags = extended ? KEYEVENTF_EXTENDEDKEY : 0U;
            INPUT down = new INPUT();
            down.type = INPUT_KEYBOARD;
            down.data.keyboard.wVk = virtualKey;
            down.data.keyboard.dwFlags = baseFlags;

            INPUT up = down;
            up.data.keyboard.dwFlags = baseFlags | KEYEVENTF_KEYUP;

            return SendHeldInput(down, up, target, virtualKey);
        }

        public static bool PressMouseButton(bool right, IntPtr target)
        {
            INPUT down = new INPUT();
            down.type = INPUT_MOUSE;
            down.data.mouse.dwFlags = right ? 0x0008U : 0x0002U;
            INPUT up = down;
            up.data.mouse.dwFlags = right ? 0x0010U : 0x0004U;
            return SendHeldInput(down, up, target, 0);
        }

        private static bool SendRelativeMouseStep(int dx, int dy, IntPtr target)
        {
            if (!IsInputReady(target)) return false;
            INPUT movement = new INPUT();
            movement.type = INPUT_MOUSE;
            movement.data.mouse.dx = dx;
            movement.data.mouse.dy = dy;
            movement.data.mouse.dwFlags = MOUSEEVENTF_MOVE;
            INPUT[] input = new INPUT[] { movement };
            return SendInput(1U, input, Marshal.SizeOf(typeof(INPUT))) == 1U;
        }

        public static bool MoveMouseThroughInput(int clientX, int clientY, int screenX, int screenY, IntPtr target)
        {
            for (int anchorStep = 0; anchorStep < 12; anchorStep++)
            {
                if (!SendRelativeMouseStep(-1024, -1024, target)) return false;
                System.Threading.Thread.Sleep(8);
            }

            int remainingX = Math.Max(0, clientX);
            int remainingY = Math.Max(0, clientY);
            while (remainingX > 0 || remainingY > 0)
            {
                int stepX = Math.Min(64, remainingX);
                int stepY = Math.Min(64, remainingY);
                if (!SendRelativeMouseStep(stepX, stepY, target)) return false;
                remainingX -= stepX;
                remainingY -= stepY;
                System.Threading.Thread.Sleep(8);
            }

            return MoveMouseToScreenPoint(screenX, screenY, target);
        }

        public static bool MoveMouseToScreenPoint(int screenX, int screenY, IntPtr target)
        {
            return IsInputReady(target) && SetCursorPos(screenX, screenY);
        }
    }
}
"@
    }
    [void][RevelationToolkit.ElevatedInspectorInput]::EnablePerMonitorDpiAwareness()

    $currentSessionId = [int][Diagnostics.Process]::GetCurrentProcess().SessionId
    if (-not $request.PSObject.Properties['targetProcessId'] -or -not $request.PSObject.Properties['targetHandle'] -or
        -not $request.PSObject.Properties['targetSessionId'] -or -not $request.PSObject.Properties['targetClientWidth'] -or
        -not $request.PSObject.Properties['targetClientHeight'] -or -not $request.PSObject.Properties['targetDpi']) {
        throw 'Inspector input request is missing its guarded game target.'
    }
    if ([int]$request.targetSessionId -ne $currentSessionId) {
        throw 'Inspector input request belongs to another Windows session.'
    }
    $targetProcessId = [int]$request.targetProcessId
    $targetHandle = [int64]$request.targetHandle
    $candidates = @(Get-Process -Name 'tianyu' -ErrorAction SilentlyContinue | Where-Object {
            $_.MainWindowHandle -ne [IntPtr]::Zero -and $_.SessionId -eq $currentSessionId -and $_.Id -eq $targetProcessId
        })
    if ($candidates.Count -ne 1) {
        throw "Expected exactly one tianyu.exe window; found $($candidates.Count)."
    }

    $game = $candidates[0]
    $handle = [IntPtr]([int64]$game.MainWindowHandle)
    if ([int64]$handle -ne $targetHandle) {
        throw 'The guarded Revelation window changed before input; no input was sent.'
    }
    if ($action -eq 'FrameCapture') {
        if ([RevelationToolkit.ElevatedInspectorInput]::IsIconic($handle)) {
            throw 'FRAME_CAPTURE_GAME_MINIMIZED: the game is minimized; no capture was started and the window was not restored.'
        }
        $capture = Invoke-AgentFrameCapture -StateDirectory $stateDir -Nonce $nonce -TargetProcessId $targetProcessId -DurationSeconds $durationSeconds
        $response = [ordered]@{
            nonce = $nonce
            success = $true
            action = $action
            processId = [int]$game.Id
            handle = [int64]$handle
            foreground = [bool]([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -eq $handle)
            csvPath = [string]$capture.CsvPath
            csvLines = [int]$capture.CsvLines
            exitCode = [int]$capture.ExitCode
            durationSeconds = [int]$capture.DurationSeconds
            finishedAt = [DateTime]::UtcNow.ToString('o')
        }
        try {
            Write-AgentResponse -StateDirectory $stateDir -Value $response
            Remove-Item -LiteralPath ([string]$claim.Path) -Force -ErrorAction Stop
        } catch {
            # Preserve processing evidence when a correlated response cannot be published.
        }
        $idleDeadline = [DateTime]::UtcNow.AddMinutes(2)
        continue
    }
    if ([RevelationToolkit.ElevatedInspectorInput]::IsIconic($handle)) {
        [void][RevelationToolkit.ElevatedInspectorInput]::PostMessage($handle, 0x0112, [UIntPtr]::new([uint32]0xF120), [IntPtr]::Zero)
        Start-Sleep -Milliseconds 120
    }

    $focusDeadline = [DateTime]::UtcNow.AddMilliseconds(900)
    do {
        [void][RevelationToolkit.ElevatedInspectorInput]::ShowWindowAsync($handle, 9)
        [void][RevelationToolkit.ElevatedInspectorInput]::BringWindowToTop($handle)
        [void][RevelationToolkit.ElevatedInspectorInput]::SetForegroundWindow($handle)
        Start-Sleep -Milliseconds 45
        $focused = ([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -eq $handle)
    } while (-not $focused -and [DateTime]::UtcNow -lt $focusDeadline)
    if ([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -ne $handle) {
        throw 'The Revelation window did not become foreground before input.'
    }

    $acceptedCount = 0
    if ($action -eq 'CloseRequest') {
        if (-not [RevelationToolkit.ElevatedInspectorInput]::PostCloseMessage($handle)) {
            throw 'Failed to post WM_CLOSE to the verified Revelation window.'
        }
        Start-Sleep -Milliseconds 180
    } elseif ($action -in @('Key', 'KeyBurst')) {
        $keySpec = switch ($keyName) {
            'B' { [pscustomobject]@{ scanCode = 0x30; extended = $false } }
            'Escape' { [pscustomobject]@{ virtualKey = 0x1B; extended = $false } }
            'Up' { [pscustomobject]@{ virtualKey = 0x26; extended = $true } }
            'Down' { [pscustomobject]@{ virtualKey = 0x28; extended = $true } }
            'Enter' { [pscustomobject]@{ virtualKey = 0x0D; extended = $false } }
            'Y' { [pscustomobject]@{ virtualKey = 0x59; extended = $false } }
        }
        for ($keyIndex = 0; $keyIndex -lt $repeatCount; $keyIndex++) {
            if ([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -ne $handle) {
                throw ('The Revelation window lost foreground during KeyBurst; stopped after ' + $acceptedCount + ' presses.')
            }
            $accepted = if ($keyName -eq 'B') {
                [RevelationToolkit.ElevatedInspectorInput]::PressScanCode([uint16]$keySpec.scanCode, [bool]$keySpec.extended, $handle)
            } else {
                [RevelationToolkit.ElevatedInspectorInput]::PressVirtualKey([uint16]$keySpec.virtualKey, [bool]$keySpec.extended, $handle)
            }
            if (-not $accepted) {
                throw 'Keyboard input was not accepted. Check foreground, held keys, and agent elevation; do not blindly retry.'
            }
            $acceptedCount++
            if ($keyIndex + 1 -lt $repeatCount) {
                Start-Sleep -Milliseconds $intervalMs
            }
        }
    } else {
        $rect = New-Object RevelationToolkit.ElevatedInspectorInput+RECT
        if (-not [RevelationToolkit.ElevatedInspectorInput]::GetClientRect($handle, [ref]$rect)) {
            throw 'Failed to read the Revelation client area.'
        }
        $width = [int]($rect.Right - $rect.Left)
        $height = [int]($rect.Bottom - $rect.Top)
        $dpi = [int][RevelationToolkit.ElevatedInspectorInput]::ReadWindowDpi($handle)
        if ($width -ne [int]$request.targetClientWidth -or $height -ne [int]$request.targetClientHeight -or
            $dpi -ne [int]$request.targetDpi) {
            throw 'The Revelation client size or DPI changed after calibration; no input was sent.'
        }
        $x = [int]$request.x
        $y = [int]$request.y
        if ($x -lt 0 -or $y -lt 0 -or $x -ge $width -or $y -ge $height) {
            throw "Inspector click is outside the client area: $x,$y of ${width}x${height}."
        }

        $origin = New-Object RevelationToolkit.ElevatedInspectorInput+POINT
        $origin.X = 0
        $origin.Y = 0
        if (-not [RevelationToolkit.ElevatedInspectorInput]::ClientToScreen($handle, [ref]$origin)) {
            throw 'Failed to translate Revelation client coordinates.'
        }
        $screenPoint = New-Object RevelationToolkit.ElevatedInspectorInput+POINT
        $screenPoint.X = $origin.X + $x
        $screenPoint.Y = $origin.Y + $y
        $pointWindow = [RevelationToolkit.ElevatedInspectorInput]::WindowFromPoint($screenPoint)
        $pointRoot = [RevelationToolkit.ElevatedInspectorInput]::GetAncestor($pointWindow, 2)
        if ($pointRoot -ne $handle) {
            throw 'The calibrated Revelation point is covered by another window; no mouse input was sent.'
        }
        if ([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -ne $handle) {
            throw 'The Revelation window did not remain foreground before mouse input.'
        }
        if (-not [RevelationToolkit.ElevatedInspectorInput]::IsInputReady($handle)) {
            throw 'A mouse button or modifier is held; mouse input was not sent.'
        }
        if ($action -eq 'WindowClick') {
            if (-not [RevelationToolkit.ElevatedInspectorInput]::PostMouseMessage($handle, 0x0200, 0, $x, $y)) {
                throw 'Failed to post WM_MOUSEMOVE to Revelation.'
            }
            Start-Sleep -Milliseconds 45
            if ($mouseButton -eq 'Right') {
                $downPosted = [RevelationToolkit.ElevatedInspectorInput]::PostMouseMessage($handle, 0x0204, 2, $x, $y)
                Start-Sleep -Milliseconds 25
                $upPosted = [RevelationToolkit.ElevatedInspectorInput]::PostMouseMessage($handle, 0x0205, 0, $x, $y)
            } else {
                $downPosted = [RevelationToolkit.ElevatedInspectorInput]::PostMouseMessage($handle, 0x0201, 1, $x, $y)
                Start-Sleep -Milliseconds 25
                $upPosted = [RevelationToolkit.ElevatedInspectorInput]::PostMouseMessage($handle, 0x0202, 0, $x, $y)
            }
            if (-not $downPosted -or -not $upPosted) {
                throw 'Failed to post the guarded mouse click to Revelation.'
            }
            Start-Sleep -Milliseconds 180
        } else {
            $originalCursor = New-Object RevelationToolkit.ElevatedInspectorInput+POINT
            $restoreCursor = $action -eq 'Click'
            if ($restoreCursor -and -not [RevelationToolkit.ElevatedInspectorInput]::GetCursorPos([ref]$originalCursor)) {
                throw 'Failed to preserve the user cursor before Revelation input.'
            }
            try {
            $moved = if ($pointerMode -eq 'Screen') {
                [RevelationToolkit.ElevatedInspectorInput]::MoveMouseToScreenPoint($screenPoint.X, $screenPoint.Y, $handle)
            } else {
                [RevelationToolkit.ElevatedInspectorInput]::MoveMouseThroughInput($x, $y, $screenPoint.X, $screenPoint.Y, $handle)
            }
            if (-not $moved) {
                throw 'Failed to synchronize the internal Revelation cursor.'
            }
            Start-Sleep -Milliseconds 80
            $actualCursor = New-Object RevelationToolkit.ElevatedInspectorInput+POINT
            if (-not [RevelationToolkit.ElevatedInspectorInput]::GetCursorPos([ref]$actualCursor) -or
                $actualCursor.X -ne $screenPoint.X -or $actualCursor.Y -ne $screenPoint.Y) {
                throw 'The cursor moved away from the calibrated point; no mouse button was pressed.'
            }
            if ([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -ne $handle -or
                [RevelationToolkit.ElevatedInspectorInput]::GetAncestor([RevelationToolkit.ElevatedInspectorInput]::WindowFromPoint($screenPoint), 2) -ne $handle) {
                throw 'The Revelation input target changed before mouse input.'
            }
            if ($action -eq 'Click') {
                if (-not [RevelationToolkit.ElevatedInspectorInput]::PressMouseButton(($mouseButton -eq 'Right'), $handle)) {
                    throw 'SendInput did not accept the mouse press and release; verify the game before retrying.'
                }
                Start-Sleep -Milliseconds 180
            }
            } finally {
                $currentCursor = New-Object RevelationToolkit.ElevatedInspectorInput+POINT
                if ($restoreCursor -and [RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -eq $handle -and
                    [RevelationToolkit.ElevatedInspectorInput]::GetCursorPos([ref]$currentCursor) -and
                    $currentCursor.X -eq $screenPoint.X -and $currentCursor.Y -eq $screenPoint.Y) {
                    [void][RevelationToolkit.ElevatedInspectorInput]::SetCursorPos($originalCursor.X, $originalCursor.Y)
                }
            }
        }
    }

    $response = [ordered]@{
            nonce      = $nonce
            success    = $true
            action     = $action
            processId  = [int]$game.Id
            handle     = [int64]$handle
            foreground = [bool]([RevelationToolkit.ElevatedInspectorInput]::GetForegroundWindow() -eq $handle)
            dpi        = [int][RevelationToolkit.ElevatedInspectorInput]::ReadWindowDpi($handle)
            acceptedCount = [int]$acceptedCount
            pointerMode = $pointerMode
            effectVerified = $false
            finishedAt = [DateTime]::UtcNow.ToString('o')
        }
    } catch {
        $response = [ordered]@{
                nonce      = $nonce
                success    = $false
                error      = $_.Exception.Message
                finishedAt = [DateTime]::UtcNow.ToString('o')
            }
    }
    try {
        Write-AgentResponse -StateDirectory $stateDir -Value $response
        Remove-Item -LiteralPath ([string]$claim.Path) -Force -ErrorAction Stop
    } catch {
        # Keep processing-<nonce>.json as evidence of an unknown transport outcome.
    }
    $idleDeadline = [DateTime]::UtcNow.AddMinutes(2)
}
exit 0
