param(
    [string]$ProcessName = "tianyu",
    [int]$ProcessId = 0,
    [int]$IntervalMs = 100,
    [int]$DurationSec = 0,
    [int]$WaitForProcessSec = 180,
    [string]$OutDir = "",
    [switch]$LogAllSamples,
    [switch]$SkipUiAutomation,
    [switch]$DumpWindowTree
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Ensure-MemoryApi {
    if (-not ("RevelationWatch.MemoryApi" -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace RevelationWatch {
    [StructLayout(LayoutKind.Sequential)]
    public struct PROCESS_BASIC_INFORMATION {
        public IntPtr Reserved1;
        public IntPtr PebBaseAddress;
        public IntPtr Reserved2_0;
        public IntPtr Reserved2_1;
        public IntPtr UniqueProcessId;
        public IntPtr Reserved3;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct MODULEENTRY32 {
        public uint dwSize;
        public uint th32ModuleID;
        public uint th32ProcessID;
        public uint GlblcntUsage;
        public uint ProccntUsage;
        public IntPtr modBaseAddr;
        public uint modBaseSize;
        public IntPtr hModule;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string szModule;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szExePath;
    }

    public static class MemoryApi {
        public const uint TH32CS_SNAPMODULE = 0x00000008;
        public const uint TH32CS_SNAPMODULE32 = 0x00000010;
        public const uint LIST_MODULES_ALL = 0x00000003;

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, int dwSize, out IntPtr lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr CreateToolhelp32Snapshot(uint dwFlags, uint th32ProcessID);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool Module32First(IntPtr hSnapshot, ref MODULEENTRY32 lpme);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool Module32Next(IntPtr hSnapshot, ref MODULEENTRY32 lpme);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool CloseHandle(IntPtr hObject);

        [DllImport("psapi.dll", SetLastError = true)]
        public static extern bool EnumProcessModulesEx(
            IntPtr hProcess,
            [Out] IntPtr[] lphModule,
            uint cb,
            out uint lpcbNeeded,
            uint dwFilterFlag
        );

        [DllImport("psapi.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern uint GetModuleBaseName(
            IntPtr hProcess,
            IntPtr hModule,
            StringBuilder lpBaseName,
            uint nSize
        );

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsWow64Process(IntPtr hProcess, out bool wow64Process);

        [DllImport("ntdll.dll")]
        public static extern int NtQueryInformationProcess(
            IntPtr processHandle,
            int processInformationClass,
            out PROCESS_BASIC_INFORMATION processInformation,
            int processInformationLength,
            out int returnLength
        );

        [DllImport("ntdll.dll", EntryPoint = "NtQueryInformationProcess")]
        public static extern int NtQueryInformationProcessIntPtr(
            IntPtr processHandle,
            int processInformationClass,
            out IntPtr processInformation,
            int processInformationLength,
            out int returnLength
        );
    }
}
"@
    }
}

function Ensure-UiProbeApi {
    if (-not ("RevelationUiProbe.NativeUiApi" -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace RevelationUiProbe {
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT {
        public int X;
        public int Y;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    public static class NativeUiApi {
        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr WindowFromPoint(POINT point);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool EnumChildWindows(IntPtr hWndParent, EnumWindowsProc lpEnumFunc, IntPtr lParam);
    }
}
"@
    }
}

function Ensure-UiAutomation {
    if ($SkipUiAutomation) {
        return $false
    }

    try {
        Add-Type -AssemblyName UIAutomationClient -ErrorAction Stop
        Add-Type -AssemblyName UIAutomationTypes -ErrorAction Stop
        Add-Type -AssemblyName WindowsBase -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

function Read-Bytes {
    param(
        [IntPtr]$Handle,
        [UInt64]$Address,
        [int]$Count
    )

    $buffer = New-Object byte[] $Count
    $read = [IntPtr]::Zero
    $ok = [RevelationWatch.MemoryApi]::ReadProcessMemory(
        $Handle,
        [IntPtr]([Int64]$Address),
        $buffer,
        $Count,
        [ref]$read
    )
    if (-not $ok -or $read.ToInt32() -ne $Count) {
        return $null
    }
    return $buffer
}

function Read-U8 {
    param(
        [IntPtr]$Handle,
        [UInt64]$Address
    )
    $bytes = Read-Bytes -Handle $Handle -Address $Address -Count 1
    if ($null -eq $bytes) {
        return $null
    }
    return [int]$bytes[0]
}

function Read-U32 {
    param(
        [IntPtr]$Handle,
        [UInt64]$Address
    )
    $bytes = Read-Bytes -Handle $Handle -Address $Address -Count 4
    if ($null -eq $bytes) {
        return $null
    }
    return [BitConverter]::ToUInt32($bytes, 0)
}

function Resolve-ProcessBaseAddress {
    param(
        [System.Diagnostics.Process]$ProcessObject,
        [string]$ExpectedModuleName,
        [IntPtr]$Handle = [IntPtr]::Zero,
        [hashtable]$Diagnostics = $null
    )

    $expectedFile = ""
    $expectedStem = ""
    if (-not [string]::IsNullOrWhiteSpace($ExpectedModuleName)) {
        $expectedFile = [System.IO.Path]::GetFileName($ExpectedModuleName)
        $expectedStem = [System.IO.Path]::GetFileNameWithoutExtension($expectedFile)
    }

    if ($null -ne $Diagnostics) {
        $Diagnostics["BaseSource"] = "unknown"
        $Diagnostics["PebAddress"] = ""
        $Diagnostics["Wow64PebAddress"] = ""
        $Diagnostics["IsWow64"] = ""
        $Diagnostics["LastMethod"] = ""
    }

    if ($Handle -ne [IntPtr]::Zero) {
        try {
            if ($null -ne $Diagnostics) {
                $Diagnostics["LastMethod"] = "peb"
            }
            $isWow64 = $false
            try {
                [void][RevelationWatch.MemoryApi]::IsWow64Process($Handle, [ref]$isWow64)
            } catch {
                $isWow64 = $false
            }
            if ($null -ne $Diagnostics) {
                $Diagnostics["IsWow64"] = $isWow64
            }

            if ($isWow64) {
                $wow64Peb = [IntPtr]::Zero
                $wow64RetLen = 0
                $wow64Status = [RevelationWatch.MemoryApi]::NtQueryInformationProcessIntPtr(
                    $Handle,
                    26,
                    [ref]$wow64Peb,
                    [IntPtr]::Size,
                    [ref]$wow64RetLen
                )
                if ($wow64Status -eq 0 -and $wow64Peb -ne [IntPtr]::Zero) {
                    if ($null -ne $Diagnostics) {
                        $Diagnostics["Wow64PebAddress"] = ("0x{0:x8}" -f [UInt64]$wow64Peb.ToInt64())
                    }
                    $wow64ImageBaseBytes = Read-Bytes -Handle $Handle -Address ([UInt64]$wow64Peb.ToInt64() + [uint64]0x8) -Count 4
                    if ($null -ne $wow64ImageBaseBytes) {
                        $wow64ImageBase = [BitConverter]::ToUInt32($wow64ImageBaseBytes, 0)
                        if ($wow64ImageBase -ne 0) {
                            if ($null -ne $Diagnostics) {
                                $Diagnostics["BaseSource"] = "wow64-peb"
                            }
                            return [UInt64]$wow64ImageBase
                        }
                    }
                }
            }

            $pbi = New-Object RevelationWatch.PROCESS_BASIC_INFORMATION
            $retLen = 0
            $ntStatus = [RevelationWatch.MemoryApi]::NtQueryInformationProcess(
                $Handle,
                0,
                [ref]$pbi,
                [System.Runtime.InteropServices.Marshal]::SizeOf([type][RevelationWatch.PROCESS_BASIC_INFORMATION]),
                [ref]$retLen
            )

            if ($ntStatus -eq 0 -and $pbi.PebBaseAddress -ne [IntPtr]::Zero) {
                if ($null -ne $Diagnostics) {
                    $Diagnostics["PebAddress"] = ("0x{0:x8}" -f [UInt64]$pbi.PebBaseAddress.ToInt64())
                }
                $pbiAddressValue = [UInt64]$pbi.PebBaseAddress.ToInt64()
                if ($isWow64 -and $pbiAddressValue -gt 0 -and $pbiAddressValue -le [UInt64]0xFFFFFFFF) {
                    $imageBaseOffset = 0x8
                    $imageBaseSize = 4
                } else {
                    $imageBaseOffset = if ([IntPtr]::Size -eq 4) { 0x8 } else { 0x10 }
                    $imageBaseSize = if ([IntPtr]::Size -eq 4) { 4 } else { 8 }
                }
                $imageBaseBytes = Read-Bytes -Handle $Handle -Address ([UInt64]$pbi.PebBaseAddress.ToInt64() + [uint64]$imageBaseOffset) -Count $imageBaseSize
                if ($null -ne $imageBaseBytes) {
                    if ([IntPtr]::Size -eq 4) {
                        $pebBase = [BitConverter]::ToUInt32($imageBaseBytes, 0)
                    } elseif ($isWow64 -and $pbiAddressValue -gt 0 -and $pbiAddressValue -le [UInt64]0xFFFFFFFF) {
                        $pebBase = [BitConverter]::ToUInt32($imageBaseBytes, 0)
                    } else {
                        $pebBase = [BitConverter]::ToUInt64($imageBaseBytes, 0)
                    }
                    if ($pebBase -ne 0) {
                        if ($null -ne $Diagnostics) {
                            $Diagnostics["BaseSource"] = if ($isWow64) { "peb32-fallback" } else { "peb" }
                        }
                        return [UInt64]$pebBase
                    }
                }
            }
        } catch {
        }
    }

    try {
        if ($null -ne $Diagnostics) {
            $Diagnostics["LastMethod"] = "process-modules"
        }
        $modules = @()
        try {
            $modules = @($ProcessObject.Modules)
        } catch {
            $modules = @()
        }

        $firstBase = $null
        foreach ($module in $modules) {
            if ($null -eq $module -or $null -eq $module.BaseAddress) {
                continue
            }
            $moduleBase = [UInt64]$module.BaseAddress.ToInt64()
            if ($null -eq $firstBase) {
                $firstBase = $moduleBase
            }
            if ([string]::IsNullOrWhiteSpace($expectedFile)) {
                return $moduleBase
            }
            $moduleName = ""
            try {
                $moduleName = [string]$module.ModuleName
            } catch {
                $moduleName = ""
            }
            $moduleStem = if ([string]::IsNullOrWhiteSpace($moduleName)) { "" } else { [System.IO.Path]::GetFileNameWithoutExtension($moduleName) }
            if ($moduleName -ieq $expectedFile -or $moduleStem -ieq $expectedStem) {
                if ($null -ne $Diagnostics) {
                    $Diagnostics["BaseSource"] = "process-modules"
                }
                return $moduleBase
            }
        }

        if ($null -ne $firstBase) {
            if ($null -ne $Diagnostics) {
                $Diagnostics["BaseSource"] = "process-modules-first"
            }
            return $firstBase
        }

        try {
            $mainModule = $ProcessObject.MainModule
        } catch {
            $mainModule = $null
        }
        if ($null -ne $mainModule -and $null -ne $mainModule.BaseAddress) {
            if ($null -ne $Diagnostics) {
                $Diagnostics["BaseSource"] = "main-module"
            }
            return [UInt64]$mainModule.BaseAddress.ToInt64()
        }
    } catch {
    }

    try {
        if ($null -ne $Diagnostics) {
            $Diagnostics["LastMethod"] = "toolhelp"
        }
        $flags = [uint32]([RevelationWatch.MemoryApi]::TH32CS_SNAPMODULE -bor [RevelationWatch.MemoryApi]::TH32CS_SNAPMODULE32)
        $snapshot = [RevelationWatch.MemoryApi]::CreateToolhelp32Snapshot($flags, [uint32]$ProcessObject.Id)
        $invalid = [IntPtr](-1)
        if ($snapshot -ne $invalid -and $snapshot -ne [IntPtr]::Zero) {
            try {
                $entry = New-Object RevelationWatch.MODULEENTRY32
                $entry.dwSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf([type][RevelationWatch.MODULEENTRY32])
                $ok = [RevelationWatch.MemoryApi]::Module32First($snapshot, [ref]$entry)
                $firstModuleBase = $null
                while ($ok) {
                    if ($entry.modBaseAddr -ne [IntPtr]::Zero) {
                        $entryBase = [UInt64]$entry.modBaseAddr.ToInt64()
                        if ($null -eq $firstModuleBase) {
                            $firstModuleBase = $entryBase
                        }
                        if ([string]::IsNullOrWhiteSpace($expectedFile)) {
                            return $entryBase
                        }
                        $entryName = if ([string]::IsNullOrWhiteSpace($entry.szModule)) { "" } else { [string]$entry.szModule }
                        $entryStem = if ([string]::IsNullOrWhiteSpace($entryName)) { "" } else { [System.IO.Path]::GetFileNameWithoutExtension($entryName) }
                        if ($entryName -ieq $expectedFile -or $entryStem -ieq $expectedStem) {
                            if ($null -ne $Diagnostics) {
                                $Diagnostics["BaseSource"] = "toolhelp"
                            }
                            return $entryBase
                        }
                    }
                    $ok = [RevelationWatch.MemoryApi]::Module32Next($snapshot, [ref]$entry)
                }
                if ($null -ne $firstModuleBase) {
                    if ($null -ne $Diagnostics) {
                        $Diagnostics["BaseSource"] = "toolhelp-first"
                    }
                    return $firstModuleBase
                }
            } finally {
                [void][RevelationWatch.MemoryApi]::CloseHandle($snapshot)
            }
        }
    } catch {
    }

    if ($Handle -ne [IntPtr]::Zero) {
        try {
            if ($null -ne $Diagnostics) {
                $Diagnostics["LastMethod"] = "psapi"
            }
            $mods = New-Object IntPtr[] 1024
            $bytesNeeded = [uint32]0
            $ok = [RevelationWatch.MemoryApi]::EnumProcessModulesEx(
                $Handle,
                $mods,
                [uint32]($mods.Length * [IntPtr]::Size),
                [ref]$bytesNeeded,
                [RevelationWatch.MemoryApi]::LIST_MODULES_ALL
            )
            if ($ok -and $bytesNeeded -gt 0) {
                $count = [Math]::Min([int]($bytesNeeded / [IntPtr]::Size), $mods.Length)
                $firstModuleBase = $null
                for ($i = 0; $i -lt $count; $i++) {
                    $mod = $mods[$i]
                    if ($mod -eq [IntPtr]::Zero) {
                        continue
                    }
                    $modBase = [UInt64]$mod.ToInt64()
                    if ($null -eq $firstModuleBase) {
                        $firstModuleBase = $modBase
                    }
                    if ([string]::IsNullOrWhiteSpace($expectedFile)) {
                        return $modBase
                    }
                    $nameBuilder = New-Object System.Text.StringBuilder 260
                    [void][RevelationWatch.MemoryApi]::GetModuleBaseName(
                        $Handle,
                        $mod,
                        $nameBuilder,
                        [uint32]$nameBuilder.Capacity
                    )
                    $modName = $nameBuilder.ToString()
                    $modStem = if ([string]::IsNullOrWhiteSpace($modName)) { "" } else { [System.IO.Path]::GetFileNameWithoutExtension($modName) }
                    if ($modName -ieq $expectedFile -or $modStem -ieq $expectedStem) {
                        if ($null -ne $Diagnostics) {
                            $Diagnostics["BaseSource"] = "psapi"
                        }
                        return $modBase
                    }
                }
                if ($null -ne $firstModuleBase) {
                    if ($null -ne $Diagnostics) {
                        $Diagnostics["BaseSource"] = "psapi-first"
                    }
                    return $firstModuleBase
                }
            }
        } catch {
        }
    }

    return $null
}

function Resolve-BaseBySingletonScan {
    param(
        [IntPtr]$Handle,
        [UInt64]$SingletonPtrRva,
        [hashtable]$Diagnostics = $null
    )

    if ($Handle -eq [IntPtr]::Zero) {
        return $null
    }

    $startBase = [UInt64]0x00400000
    $endBase = [UInt64]0x30000000
    $step = [UInt64]0x10000
    $attempts = 0

    for ($base = $startBase; $base -le $endBase; $base += $step) {
        $attempts += 1
        $ptrAddress = $base + $SingletonPtrRva
        $singleton = Read-U32 -Handle $Handle -Address $ptrAddress
        if ($null -eq $singleton) {
            if ($script:LastReadErrorCode -eq 5) {
                break
            }
            continue
        }
        if ($singleton -lt 0x10000 -or $singleton -gt 0x7FFEFFFF) {
            continue
        }

        $probe = Read-Bytes -Handle $Handle -Address ([UInt64]$singleton + 0x358) -Count 8
        if ($null -eq $probe) {
            continue
        }

        if ($null -ne $Diagnostics) {
            $Diagnostics["BaseSource"] = "rva-scan"
            $Diagnostics["ScanAttempts"] = [string]$attempts
            $Diagnostics["ScanBaseAddress"] = ("0x{0:x8}" -f $base)
        }
        return $base
    }

    if ($null -ne $Diagnostics) {
        $Diagnostics["ScanAttempts"] = [string]$attempts
    }
    return $null
}

function Open-ReadableProcessHandle {
    param([int]$TargetProcessId)
    $processAccess = 0x1410
    $handle = [RevelationWatch.MemoryApi]::OpenProcess($processAccess, $false, $TargetProcessId)
    if ($handle -eq [IntPtr]::Zero) {
        $code = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "OpenProcess failed for PID $TargetProcessId, win32=$code."
    }
    return $handle
}

function Get-WindowTextSafe {
    param([IntPtr]$Handle)
    if ($Handle -eq [IntPtr]::Zero) {
        return ""
    }
    $len = [RevelationUiProbe.NativeUiApi]::GetWindowTextLength($Handle)
    $sb = New-Object System.Text.StringBuilder ([Math]::Max(256, $len + 2))
    [void][RevelationUiProbe.NativeUiApi]::GetWindowText($Handle, $sb, $sb.Capacity)
    return $sb.ToString()
}

function Get-WindowClassSafe {
    param([IntPtr]$Handle)
    if ($Handle -eq [IntPtr]::Zero) {
        return ""
    }
    $sb = New-Object System.Text.StringBuilder 260
    [void][RevelationUiProbe.NativeUiApi]::GetClassName($Handle, $sb, $sb.Capacity)
    return $sb.ToString()
}

function Get-WindowDescriptor {
    param([IntPtr]$Handle)

    if ($Handle -eq [IntPtr]::Zero) {
        return [pscustomobject]@{
            Handle = ""
            ProcessId = ""
            ClassName = ""
            Title = ""
            Visible = ""
            Minimized = ""
            Rect = ""
        }
    }

    $pidRaw = [uint32]0
    [void][RevelationUiProbe.NativeUiApi]::GetWindowThreadProcessId($Handle, [ref]$pidRaw)
    $rect = New-Object RevelationUiProbe.RECT
    $rectText = ""
    if ([RevelationUiProbe.NativeUiApi]::GetWindowRect($Handle, [ref]$rect)) {
        $rectText = "{0},{1},{2},{3}" -f $rect.Left, $rect.Top, $rect.Right, $rect.Bottom
    }

    return [pscustomobject]@{
        Handle = ("0x{0}" -f $Handle.ToInt64().ToString("X"))
        ProcessId = [string]$pidRaw
        ClassName = Get-WindowClassSafe -Handle $Handle
        Title = Get-WindowTextSafe -Handle $Handle
        Visible = [string][RevelationUiProbe.NativeUiApi]::IsWindowVisible($Handle)
        Minimized = [string][RevelationUiProbe.NativeUiApi]::IsIconic($Handle)
        Rect = $rectText
    }
}

function Export-WindowTreeSnapshot {
    param(
        [IntPtr]$RootHandle,
        [string]$Path
    )

    $rows = [System.Collections.Generic.List[object]]::new()
    $rootRow = Get-WindowDescriptor -Handle $RootHandle
    $rows.Add([pscustomobject]@{
            Level = 0
            Handle = $rootRow.Handle
            ProcessId = $rootRow.ProcessId
            ClassName = $rootRow.ClassName
            Title = $rootRow.Title
            Visible = $rootRow.Visible
            Minimized = $rootRow.Minimized
            Rect = $rootRow.Rect
        }) | Out-Null

    $callback = [RevelationUiProbe.EnumWindowsProc]{
        param([IntPtr]$ChildHandle, [IntPtr]$LParam)
        $row = Get-WindowDescriptor -Handle $ChildHandle
        $rows.Add([pscustomobject]@{
                Level = 1
                Handle = $row.Handle
                ProcessId = $row.ProcessId
                ClassName = $row.ClassName
                Title = $row.Title
                Visible = $row.Visible
                Minimized = $row.Minimized
                Rect = $row.Rect
            }) | Out-Null
        return $true
    }

    [void][RevelationUiProbe.NativeUiApi]::EnumChildWindows($RootHandle, $callback, [IntPtr]::Zero)
    $rows | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
}

function Get-CursorWindowSnapshot {
    $point = New-Object RevelationUiProbe.POINT
    $cursorOk = [RevelationUiProbe.NativeUiApi]::GetCursorPos([ref]$point)
    if (-not $cursorOk) {
        return [pscustomobject]@{
            CursorX = ""
            CursorY = ""
            Window = (Get-WindowDescriptor -Handle ([IntPtr]::Zero))
        }
    }

    $handle = [RevelationUiProbe.NativeUiApi]::WindowFromPoint($point)
    return [pscustomobject]@{
        CursorX = [string]$point.X
        CursorY = [string]$point.Y
        Window = (Get-WindowDescriptor -Handle $handle)
    }
}

function Get-UiaElementAtPoint {
    param(
        [int]$X,
        [int]$Y,
        [bool]$UiAutomationReady
    )

    if (-not $UiAutomationReady) {
        return [pscustomobject]@{
            Name = ""
            AutomationId = ""
            ClassName = ""
            ControlType = ""
            FrameworkId = ""
            HelpText = ""
        }
    }

    try {
        $point = New-Object System.Windows.Point ([double]$X), ([double]$Y)
        $element = [System.Windows.Automation.AutomationElement]::FromPoint($point)
        if ($null -eq $element) {
            throw "UI Automation returned null."
        }

        $controlType = ""
        try {
            $ct = $element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::ControlTypeProperty)
            if ($null -ne $ct) {
                $controlType = $ct.ProgrammaticName
            }
        } catch {
        }

        return [pscustomobject]@{
            Name = [string]$element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::NameProperty)
            AutomationId = [string]$element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::AutomationIdProperty)
            ClassName = [string]$element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::ClassNameProperty)
            ControlType = $controlType
            FrameworkId = [string]$element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::FrameworkIdProperty)
            HelpText = [string]$element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::HelpTextProperty)
        }
    } catch {
        return [pscustomobject]@{
            Name = ""
            AutomationId = ""
            ClassName = ""
            ControlType = ""
            FrameworkId = ""
            HelpText = ""
        }
    }
}

function Get-MemorySnapshot {
    param(
        [IntPtr]$Handle,
        [UInt64]$BaseAddress
    )

    $cmdBufferActive = Read-U8 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DC0560)
    $cmdBufferOpen = Read-U8 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DC0561)
    $renderer55B = Read-U8 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DBFE40 + [UInt64]0x55B)
    $renderer55E = Read-U8 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DBFE40 + [UInt64]0x55E)
    $renderer55F = Read-U8 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DBFE40 + [UInt64]0x55F)
    $renderer610 = Read-U32 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DBFE40 + [UInt64]0x610)
    $controllerPtr = Read-U32 -Handle $Handle -Address ($BaseAddress + [UInt64]0x1DC09A8)

    $c35a = $null
    $c35b = $null
    $c35c = $null
    $c35d = $null
    $c35e = $null
    $c35f = $null
    $cDword35C = $null
    $controllerDescriptor = $null

    if ($null -ne $controllerPtr -and $controllerPtr -gt 0x10000) {
        $controllerBytes = Read-Bytes -Handle $Handle -Address ([UInt64]$controllerPtr + [UInt64]0x358) -Count 8
        if ($null -ne $controllerBytes) {
            $c35a = [int]$controllerBytes[2]
            $c35b = [int]$controllerBytes[3]
            $c35c = [int]$controllerBytes[4]
            $c35d = [int]$controllerBytes[5]
            $c35e = [int]$controllerBytes[6]
            $c35f = [int]$controllerBytes[7]
            $cDword35C = [BitConverter]::ToUInt32($controllerBytes, 4)
        }
        $controllerDescriptor = Read-U32 -Handle $Handle -Address ([UInt64]$controllerPtr + [UInt64]0x0C)
    }

    return [pscustomobject]@{
        CmdBufferActive = $cmdBufferActive
        CmdBufferOpen = $cmdBufferOpen
        Renderer55B = $renderer55B
        Renderer55E = $renderer55E
        Renderer55F = $renderer55F
        Renderer610 = $renderer610
        ControllerPtr = $controllerPtr
        ControllerDescriptor = $controllerDescriptor
        Controller35A = $c35a
        Controller35B = $c35b
        Controller35C = $c35c
        Controller35D = $c35d
        Controller35E = $c35e
        Controller35F = $c35f
        ControllerDword35C = $cDword35C
    }
}

function Convert-ToCsvField {
    param($Value)

    $text = if ($null -eq $Value) { "" } else { [string]$Value }
    if ($text.Contains('"')) {
        $text = $text.Replace('"', '""')
    }
    if ($text.IndexOfAny(@([char]',', [char]'"', [char]"`r", [char]"`n")) -ge 0) {
        return ('"{0}"' -f $text)
    }
    return $text
}

function Resolve-DefaultOutDir {
    $root = Split-Path -Parent $PSScriptRoot
    $captures = Join-Path $root "captures"
    if (-not (Test-Path -LiteralPath $captures)) {
        New-Item -ItemType Directory -Path $captures -Force | Out-Null
    }
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    return (Join-Path $captures ("ui-runtime-{0}" -f $stamp))
}

function Write-ProbeMeta {
    param(
        [string]$Path,
        [hashtable]$Map
    )

    $lines = [System.Collections.Generic.List[string]]::new()
    foreach ($key in $Map.Keys) {
        $value = $Map[$key]
        if ($null -eq $value) {
            $value = ""
        }
        $lines.Add(("{0}={1}" -f $key, [string]$value)) | Out-Null
    }
    $lines | Set-Content -LiteralPath $Path -Encoding UTF8
}

if ($IntervalMs -lt 25) {
    throw "IntervalMs should be >= 25."
}

Ensure-MemoryApi
Ensure-UiProbeApi
$uiAutomationReady = Ensure-UiAutomation
$resolvedOutDir = if ([string]::IsNullOrWhiteSpace($OutDir)) { Resolve-DefaultOutDir } else { $OutDir }
if (-not (Test-Path -LiteralPath $resolvedOutDir)) {
    New-Item -ItemType Directory -Path $resolvedOutDir -Force | Out-Null
}

$metaPath = Join-Path $resolvedOutDir "ui-runtime.meta.txt"
$errorPath = Join-Path $resolvedOutDir "ui-runtime.error.txt"
$samplesPath = Join-Path $resolvedOutDir "ui-runtime-samples.csv"
$windowTreePath = Join-Path $resolvedOutDir "window-tree.csv"

$meta = [ordered]@{
    Status = "starting"
    ProcessName = $ProcessName
    ProcessId = $ProcessId
    WaitForProcessSec = $WaitForProcessSec
    DurationSec = $DurationSec
    IntervalMs = $IntervalMs
    UiAutomationReady = $uiAutomationReady
    ApartmentState = [Threading.Thread]::CurrentThread.GetApartmentState()
    SamplesPath = $samplesPath
    WindowTreePath = $windowTreePath
    StartedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    FinishedAt = ""
    ExpectedModule = ""
    BaseAddress = ""
    BaseSource = ""
    LastMethod = ""
    IsWow64 = ""
    PebAddress = ""
    Wow64PebAddress = ""
    ScanAttempts = ""
    ScanBaseAddress = ""
    Error = ""
}

Write-ProbeMeta -Path $metaPath -Map $meta

$proc = $null
$waitStart = Get-Date
$handle = [IntPtr]::Zero
$baseDiag = @{}

try {
    while ($null -eq $proc) {
        if ($ProcessId -gt 0) {
            $proc = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue | Select-Object -First 1
        } else {
            $proc = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Select-Object -First 1
        }
        if ($null -ne $proc) {
            break
        }
        if (((Get-Date) - $waitStart).TotalSeconds -ge $WaitForProcessSec) {
            throw "Process was not found within $WaitForProcessSec sec."
        }
        Start-Sleep -Milliseconds 500
    }

    $handle = Open-ReadableProcessHandle -TargetProcessId $proc.Id

    $expectedModule = ""
    try {
        $expectedModule = [string]$proc.MainModule.ModuleName
    } catch {
        $expectedModule = ("{0}.exe" -f $proc.ProcessName)
    }

    $baseAddress = Resolve-ProcessBaseAddress -ProcessObject $proc -ExpectedModuleName $expectedModule -Handle $handle -Diagnostics $baseDiag
    if ($null -eq $baseAddress) {
        $scanBase = Resolve-BaseBySingletonScan -Handle $handle -SingletonPtrRva 0x1DC09A8 -Diagnostics $baseDiag
        if ($null -ne $scanBase) {
            $baseAddress = $scanBase
        }
    }
    if ($null -eq $baseAddress) {
        throw "Failed to resolve process base address for $($proc.ProcessName)."
    }

    $header = @(
        "Timestamp","ProcessName","ProcessId","BaseAddress",
        "MainWindowHandle","MainWindowClass","MainWindowTitle","MainWindowRect","MainWindowVisible","MainWindowMinimized",
        "ForegroundHandle","ForegroundPid","ForegroundClass","ForegroundTitle",
        "CursorX","CursorY","CursorWindowHandle","CursorWindowPid","CursorWindowClass","CursorWindowTitle","CursorWindowRect",
        "CmdBufferActive","CmdBufferOpen","Renderer55B","Renderer55E","Renderer55F","Renderer610",
        "ControllerPtr","ControllerDescriptor","Controller35A","Controller35B","Controller35C","Controller35D","Controller35E","Controller35F","ControllerDword35C",
        "UiaName","UiaAutomationId","UiaClassName","UiaControlType","UiaFrameworkId","UiaHelpText"
    ) -join ","
    Set-Content -LiteralPath $samplesPath -Value $header -Encoding UTF8

    $started = Get-Date
    $deadline = if ($DurationSec -gt 0) { $started.AddSeconds($DurationSec) } else { $null }
    $lastSig = ""
    $windowTreeDumped = $false

    while ($true) {
        $now = Get-Date
        if ($null -ne $deadline -and $now -ge $deadline) {
            break
        }

        $alive = Get-Process -Id $proc.Id -ErrorAction SilentlyContinue
        if ($null -eq $alive) {
            break
        }
        $proc = $alive
        $proc.Refresh()

        $mainWindowDescriptor = Get-WindowDescriptor -Handle $proc.MainWindowHandle
        if ($DumpWindowTree -and -not $windowTreeDumped -and $proc.MainWindowHandle -ne 0) {
            Export-WindowTreeSnapshot -RootHandle $proc.MainWindowHandle -Path $windowTreePath
            $windowTreeDumped = $true
        }

        $foregroundHandle = [RevelationUiProbe.NativeUiApi]::GetForegroundWindow()
        $foregroundDescriptor = Get-WindowDescriptor -Handle $foregroundHandle
        $cursorSnapshot = Get-CursorWindowSnapshot
        $memorySnapshot = Get-MemorySnapshot -Handle $handle -BaseAddress $baseAddress
        $uiaSnapshot = Get-UiaElementAtPoint -X ([int]$cursorSnapshot.CursorX) -Y ([int]$cursorSnapshot.CursorY) -UiAutomationReady $uiAutomationReady

        $sig = @(
            $mainWindowDescriptor.Handle,
            $foregroundDescriptor.Handle,
            $cursorSnapshot.Window.Handle,
            $memorySnapshot.CmdBufferActive,
            $memorySnapshot.CmdBufferOpen,
            $memorySnapshot.Controller35C,
            $memorySnapshot.Controller35D,
            $uiaSnapshot.Name,
            $uiaSnapshot.AutomationId,
            $uiaSnapshot.ClassName
        ) -join "|"

        if ($LogAllSamples -or $sig -ne $lastSig) {
            $fields = @(
                $now.ToString("yyyy-MM-dd HH:mm:ss.fff"),
                $proc.ProcessName,
                $proc.Id,
                ("0x{0:x8}" -f $baseAddress),
                $mainWindowDescriptor.Handle,
                $mainWindowDescriptor.ClassName,
                $mainWindowDescriptor.Title,
                $mainWindowDescriptor.Rect,
                $mainWindowDescriptor.Visible,
                $mainWindowDescriptor.Minimized,
                $foregroundDescriptor.Handle,
                $foregroundDescriptor.ProcessId,
                $foregroundDescriptor.ClassName,
                $foregroundDescriptor.Title,
                $cursorSnapshot.CursorX,
                $cursorSnapshot.CursorY,
                $cursorSnapshot.Window.Handle,
                $cursorSnapshot.Window.ProcessId,
                $cursorSnapshot.Window.ClassName,
                $cursorSnapshot.Window.Title,
                $cursorSnapshot.Window.Rect,
                $memorySnapshot.CmdBufferActive,
                $memorySnapshot.CmdBufferOpen,
                $memorySnapshot.Renderer55B,
                $memorySnapshot.Renderer55E,
                $memorySnapshot.Renderer55F,
                $(if ($null -ne $memorySnapshot.Renderer610) { ("0x{0:x8}" -f $memorySnapshot.Renderer610) } else { "" }),
                $(if ($null -ne $memorySnapshot.ControllerPtr) { ("0x{0:x8}" -f $memorySnapshot.ControllerPtr) } else { "" }),
                $(if ($null -ne $memorySnapshot.ControllerDescriptor) { ("0x{0:x8}" -f $memorySnapshot.ControllerDescriptor) } else { "" }),
                $memorySnapshot.Controller35A,
                $memorySnapshot.Controller35B,
                $memorySnapshot.Controller35C,
                $memorySnapshot.Controller35D,
                $memorySnapshot.Controller35E,
                $memorySnapshot.Controller35F,
                $(if ($null -ne $memorySnapshot.ControllerDword35C) { ("0x{0:x8}" -f $memorySnapshot.ControllerDword35C) } else { "" }),
                $uiaSnapshot.Name,
                $uiaSnapshot.AutomationId,
                $uiaSnapshot.ClassName,
                $uiaSnapshot.ControlType,
                $uiaSnapshot.FrameworkId,
                $uiaSnapshot.HelpText
            )

            (($fields | ForEach-Object { Convert-ToCsvField -Value $_ }) -join ",") | Add-Content -LiteralPath $samplesPath -Encoding UTF8
            $lastSig = $sig
        }

        Start-Sleep -Milliseconds $IntervalMs
    }

    $meta["Status"] = "completed"
    $meta["ProcessName"] = $proc.ProcessName
    $meta["ProcessId"] = $proc.Id
    $meta["ExpectedModule"] = $expectedModule
    $meta["BaseAddress"] = ("0x{0:x8}" -f $baseAddress)
    $meta["BaseSource"] = $baseDiag["BaseSource"]
    $meta["LastMethod"] = $baseDiag["LastMethod"]
    $meta["IsWow64"] = $baseDiag["IsWow64"]
    $meta["PebAddress"] = $baseDiag["PebAddress"]
    $meta["Wow64PebAddress"] = $baseDiag["Wow64PebAddress"]
    $meta["ScanAttempts"] = $baseDiag["ScanAttempts"]
    $meta["ScanBaseAddress"] = $baseDiag["ScanBaseAddress"]
    $meta["StartedAt"] = $started.ToString("yyyy-MM-dd HH:mm:ss")
    $meta["FinishedAt"] = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $meta["Error"] = ""
    Write-ProbeMeta -Path $metaPath -Map $meta

    Write-Host ("UI runtime probe complete: {0}" -f $resolvedOutDir)
} catch {
    $meta["Status"] = "failed"
    if ($null -ne $proc) {
        $meta["ProcessName"] = $proc.ProcessName
        $meta["ProcessId"] = $proc.Id
    }
    if ($null -ne $baseDiag) {
        $meta["BaseSource"] = $baseDiag["BaseSource"]
        $meta["LastMethod"] = $baseDiag["LastMethod"]
        $meta["IsWow64"] = $baseDiag["IsWow64"]
        $meta["PebAddress"] = $baseDiag["PebAddress"]
        $meta["Wow64PebAddress"] = $baseDiag["Wow64PebAddress"]
        $meta["ScanAttempts"] = $baseDiag["ScanAttempts"]
        $meta["ScanBaseAddress"] = $baseDiag["ScanBaseAddress"]
    }
    $meta["FinishedAt"] = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $meta["Error"] = $_.Exception.Message
    Write-ProbeMeta -Path $metaPath -Map $meta
    Set-Content -LiteralPath $errorPath -Encoding UTF8 -Value @(
        ("Error={0}" -f $_.Exception.Message)
        ("Type={0}" -f $_.Exception.GetType().FullName)
        ("ScriptStackTrace={0}" -f $_.ScriptStackTrace)
    )
    throw
} finally {
    if ($handle -ne [IntPtr]::Zero) {
        [void][RevelationWatch.MemoryApi]::CloseHandle($handle)
    }
}
