param(
    [string]$LauncherRoot = "",
    [int]$StaleMinutes = 5
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-NormalizedPathOrEmpty {
    param([string]$Path)
    if (-not $Path) {
        return ""
    }

    try {
        return (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
    } catch {
        return ""
    }
}

function Test-RevelationGameRunning {
    $names = @("tianyu", "tianyu64", "tianyu_dx11", "tianyu_beta", "tianyu64_beta")
    return [bool](Get-Process -ErrorAction SilentlyContinue | Where-Object { $names -contains $_.ProcessName } | Select-Object -First 1)
}

function Test-ManagedCommandLine {
    param([string]$CommandLine)
    if (-not $CommandLine) {
        return $false
    }

    $patterns = @(
        "RevelationCombat\.ps1.*\b(Apply|InternalApply)\b",
        "RevelationCapture\.ps1.*\bCollect\b",
        "RevelationNetwork\.ps1.*\b(NetEaseWatch|AggressiveWatch)\b",
        "RevelationLab\.ps1.*\b(SetDxvkPreset|RestoreDxvkPreset|SetUiPreset|RestoreUiPreset|SetRendererPreset|RestoreRendererPreset|SetVideoPreset|RestoreVideoPreset|RestoreAll)\b",
        "netease-watch-.*\.ps1",
        "tmp-run-lab-setdxvk.*\.ps1",
        "RevelationExperimental\.ps1"
    )

    foreach ($pattern in $patterns) {
        if ($CommandLine -match $pattern) {
            return $true
        }
    }

    return $false
}

function Read-KeyValueFile {
    param([string]$Path)

    $map = @{}
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) {
        return $map
    }

    foreach ($rawLine in (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
        $line = [string]$rawLine
        if (-not $line) {
            continue
        }

        $idx = $line.IndexOf("=")
        if ($idx -lt 1) {
            continue
        }

        $key = $line.Substring(0, $idx).Trim().ToLowerInvariant()
        $value = $line.Substring($idx + 1).Trim()
        if ($key) {
            $map[$key] = $value
        }
    }

    return $map
}

function Stop-ProcessIfRunning {
    param([int]$ProcessId)

    if ($ProcessId -le 0) {
        return $false
    }

    try {
        $proc = Get-Process -Id $ProcessId -ErrorAction Stop
        if ($proc.Id -eq $PID) {
            return $false
        }

        Stop-Process -Id $proc.Id -Force -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

function Get-ConfiguredGameRootOrEmpty {
    param([string]$LauncherRoot)

    if (-not $LauncherRoot) {
        return ""
    }

    try {
        $configPath = Join-Path $LauncherRoot "launcher-config.ini"
        if (-not (Test-Path -LiteralPath $configPath)) {
            return ""
        }

        foreach ($rawLine in (Get-Content -LiteralPath $configPath -ErrorAction SilentlyContinue)) {
            $line = [string]$rawLine
            if ($line -like "gameRoot=*") {
                $value = $line.Substring("gameRoot=".Length).Trim()
                return (Get-NormalizedPathOrEmpty -Path $value)
            }
        }
    } catch {
    }

    return ""
}

$resolvedRoot = Get-NormalizedPathOrEmpty -Path $LauncherRoot
$rootSlash = if ($resolvedRoot) { $resolvedRoot.Replace("\", "/") } else { "" }
$gameRoot = Get-ConfiguredGameRootOrEmpty -LauncherRoot $resolvedRoot
$gameRootSlash = if ($gameRoot) { $gameRoot.Replace("\", "/") } else { "" }
$isGameRunning = Test-RevelationGameRunning
$cutoff = (Get-Date).AddMinutes(-[math]::Max(1, $StaleMinutes))

if (-not $isGameRunning -and $resolvedRoot) {
    try {
        $statePath = Join-Path $resolvedRoot ".revelation-combat\network-state.ini"
        $state = Read-KeyValueFile -Path $statePath
        if ($state.ContainsKey("watcher_pid")) {
            $watcherPidValue = 0
            if ([int]::TryParse([string]$state["watcher_pid"], [ref]$watcherPidValue)) {
                [void](Stop-ProcessIfRunning -ProcessId $watcherPidValue)
            }
        }
    } catch {
        # Best-effort. Ignore malformed state or process races.
    }
}

$candidates = @(
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object {
            ($_.Name -eq "powershell.exe" -or $_.Name -eq "pwsh.exe") -and
            $_.CommandLine -and
            (Test-ManagedCommandLine -CommandLine $_.CommandLine)
        }
)

foreach ($entry in $candidates) {
    try {
        $proc = Get-Process -Id $entry.ProcessId -ErrorAction Stop
        if ($proc.Id -eq $PID) {
            continue
        }

        if ($resolvedRoot) {
            $cmd = [string]$entry.CommandLine
            $matchesRoot = ($cmd -like ("*" + $resolvedRoot + "*")) -or ($cmd -like ("*" + $rootSlash + "*"))
            if (-not $matchesRoot -and $gameRoot) {
                $matchesRoot = ($cmd -like ("*" + $gameRoot + "*")) -or ($cmd -like ("*" + $gameRootSlash + "*"))
            }
            if (-not $matchesRoot) {
                continue
            }
        }

        $shouldStop = $false
        if (-not $isGameRunning) {
            $shouldStop = $true
        } elseif ($proc.StartTime -lt $cutoff) {
            $shouldStop = $true
        }

        if ($shouldStop) {
            Stop-Process -Id $proc.Id -Force -ErrorAction Stop
        }
    } catch {
        # Best-effort cleanup. Ignore access races and already-exited processes.
    }
}
