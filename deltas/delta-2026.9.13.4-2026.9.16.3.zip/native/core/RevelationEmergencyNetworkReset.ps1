param(
    [switch]$DeepReset
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Remove-FirewallByPattern {
    param([string]$Pattern)
    Get-NetFirewallRule -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like $Pattern } |
        Remove-NetFirewallRule -ErrorAction SilentlyContinue | Out-Null
}

function Remove-QosByPattern {
    param([string]$Pattern)
    Get-NetQosPolicy -PolicyStore ActiveStore -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like $Pattern } |
        ForEach-Object { Remove-NetQosPolicy -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue | Out-Null }
}

if (-not (Test-IsAdministrator)) {
    Write-Host "[EmergencyReset] Skipped: no administrator rights."
    return
}

Write-Host "[EmergencyReset] Stopping launcher watcher processes..."
$launcherWorkerPattern = '(?i)(?:^|["\s\\/])(?:RevelationNetwork|RevelationCombat|RevelationCapture|RevelationExperimental)\.ps1(?:"|\s|$)'
$watchRuntimePattern = '(?i)netease-watch-.*\.ps1'
$watchers = Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object {
        $_.ProcessId -ne $PID -and
        $_.CommandLine -and (
            $_.CommandLine -match $launcherWorkerPattern -or
            $_.CommandLine -match $watchRuntimePattern
        )
    }
foreach ($w in $watchers) {
    try { Stop-Process -Id $w.ProcessId -Force -ErrorAction SilentlyContinue } catch {}
}

Write-Host "[EmergencyReset] Scanning firewall rules..."
$fwRules = @(Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object {
    $_.DisplayName -like 'Revelation*' -or $_.DisplayName -like '*NetEase*' -or
    $_.DisplayName -like '*Tianyu*' -or $_.DisplayName -like '*GameCenter*'
})
if ($fwRules.Count -gt 0) {
    foreach ($r in $fwRules) { Write-Host ("  Removing firewall: " + $r.DisplayName) }
    $fwRules | Remove-NetFirewallRule -ErrorAction SilentlyContinue | Out-Null
} else {
    Write-Host "  No launcher firewall rules found."
}

Write-Host "[EmergencyReset] Scanning QoS policies..."
$qosRules = @(Get-NetQosPolicy -PolicyStore ActiveStore -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -like 'Revelation*' -or $_.Name -like 'QosGame*' -or
    $_.Name -like '*Tianyu*' -or $_.Name -like '*GameCenter*'
})
if ($qosRules.Count -gt 0) {
    foreach ($q in $qosRules) { Write-Host ("  Removing QoS: " + $q.Name) }
    $qosRules | ForEach-Object { Remove-NetQosPolicy -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue | Out-Null }
} else {
    Write-Host "  No launcher QoS policies found."
}

if ($DeepReset) {
    Write-Host "[EmergencyReset] Running deep TCP/IP reset commands..."
    & netsh winsock reset | Out-Null
    & netsh int ip reset | Out-Null
}

Write-Host "[EmergencyReset] Flushing DNS..."
& ipconfig /flushdns | Out-Null

Write-Host "[EmergencyReset] Completed. Restart VK Play and test server login."
if ($DeepReset) {
    Write-Host "[EmergencyReset] Deep reset was used: reboot Windows before retest."
}
